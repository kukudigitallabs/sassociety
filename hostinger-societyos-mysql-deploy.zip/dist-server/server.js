import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/delayed-stream/lib/delayed_stream.js
var require_delayed_stream = __commonJS({
  "node_modules/delayed-stream/lib/delayed_stream.js"(exports, module) {
    var Stream = __require("stream").Stream;
    var util = __require("util");
    module.exports = DelayedStream;
    function DelayedStream() {
      this.source = null;
      this.dataSize = 0;
      this.maxDataSize = 1024 * 1024;
      this.pauseStream = true;
      this._maxDataSizeExceeded = false;
      this._released = false;
      this._bufferedEvents = [];
    }
    util.inherits(DelayedStream, Stream);
    DelayedStream.create = function(source, options) {
      var delayedStream = new this();
      options = options || {};
      for (var option in options) {
        delayedStream[option] = options[option];
      }
      delayedStream.source = source;
      var realEmit = source.emit;
      source.emit = function() {
        delayedStream._handleEmit(arguments);
        return realEmit.apply(source, arguments);
      };
      source.on("error", function() {
      });
      if (delayedStream.pauseStream) {
        source.pause();
      }
      return delayedStream;
    };
    Object.defineProperty(DelayedStream.prototype, "readable", {
      configurable: true,
      enumerable: true,
      get: function() {
        return this.source.readable;
      }
    });
    DelayedStream.prototype.setEncoding = function() {
      return this.source.setEncoding.apply(this.source, arguments);
    };
    DelayedStream.prototype.resume = function() {
      if (!this._released) {
        this.release();
      }
      this.source.resume();
    };
    DelayedStream.prototype.pause = function() {
      this.source.pause();
    };
    DelayedStream.prototype.release = function() {
      this._released = true;
      this._bufferedEvents.forEach(function(args) {
        this.emit.apply(this, args);
      }.bind(this));
      this._bufferedEvents = [];
    };
    DelayedStream.prototype.pipe = function() {
      var r = Stream.prototype.pipe.apply(this, arguments);
      this.resume();
      return r;
    };
    DelayedStream.prototype._handleEmit = function(args) {
      if (this._released) {
        this.emit.apply(this, args);
        return;
      }
      if (args[0] === "data") {
        this.dataSize += args[1].length;
        this._checkIfMaxDataSizeExceeded();
      }
      this._bufferedEvents.push(args);
    };
    DelayedStream.prototype._checkIfMaxDataSizeExceeded = function() {
      if (this._maxDataSizeExceeded) {
        return;
      }
      if (this.dataSize <= this.maxDataSize) {
        return;
      }
      this._maxDataSizeExceeded = true;
      var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
      this.emit("error", new Error(message));
    };
  }
});

// node_modules/combined-stream/lib/combined_stream.js
var require_combined_stream = __commonJS({
  "node_modules/combined-stream/lib/combined_stream.js"(exports, module) {
    var util = __require("util");
    var Stream = __require("stream").Stream;
    var DelayedStream = require_delayed_stream();
    module.exports = CombinedStream;
    function CombinedStream() {
      this.writable = false;
      this.readable = true;
      this.dataSize = 0;
      this.maxDataSize = 2 * 1024 * 1024;
      this.pauseStreams = true;
      this._released = false;
      this._streams = [];
      this._currentStream = null;
      this._insideLoop = false;
      this._pendingNext = false;
    }
    util.inherits(CombinedStream, Stream);
    CombinedStream.create = function(options) {
      var combinedStream = new this();
      options = options || {};
      for (var option in options) {
        combinedStream[option] = options[option];
      }
      return combinedStream;
    };
    CombinedStream.isStreamLike = function(stream) {
      return typeof stream !== "function" && typeof stream !== "string" && typeof stream !== "boolean" && typeof stream !== "number" && !Buffer.isBuffer(stream);
    };
    CombinedStream.prototype.append = function(stream) {
      var isStreamLike = CombinedStream.isStreamLike(stream);
      if (isStreamLike) {
        if (!(stream instanceof DelayedStream)) {
          var newStream = DelayedStream.create(stream, {
            maxDataSize: Infinity,
            pauseStream: this.pauseStreams
          });
          stream.on("data", this._checkDataSize.bind(this));
          stream = newStream;
        }
        this._handleErrors(stream);
        if (this.pauseStreams) {
          stream.pause();
        }
      }
      this._streams.push(stream);
      return this;
    };
    CombinedStream.prototype.pipe = function(dest, options) {
      Stream.prototype.pipe.call(this, dest, options);
      this.resume();
      return dest;
    };
    CombinedStream.prototype._getNext = function() {
      this._currentStream = null;
      if (this._insideLoop) {
        this._pendingNext = true;
        return;
      }
      this._insideLoop = true;
      try {
        do {
          this._pendingNext = false;
          this._realGetNext();
        } while (this._pendingNext);
      } finally {
        this._insideLoop = false;
      }
    };
    CombinedStream.prototype._realGetNext = function() {
      var stream = this._streams.shift();
      if (typeof stream == "undefined") {
        this.end();
        return;
      }
      if (typeof stream !== "function") {
        this._pipeNext(stream);
        return;
      }
      var getStream = stream;
      getStream(function(stream2) {
        var isStreamLike = CombinedStream.isStreamLike(stream2);
        if (isStreamLike) {
          stream2.on("data", this._checkDataSize.bind(this));
          this._handleErrors(stream2);
        }
        this._pipeNext(stream2);
      }.bind(this));
    };
    CombinedStream.prototype._pipeNext = function(stream) {
      this._currentStream = stream;
      var isStreamLike = CombinedStream.isStreamLike(stream);
      if (isStreamLike) {
        stream.on("end", this._getNext.bind(this));
        stream.pipe(this, { end: false });
        return;
      }
      var value = stream;
      this.write(value);
      this._getNext();
    };
    CombinedStream.prototype._handleErrors = function(stream) {
      var self2 = this;
      stream.on("error", function(err) {
        self2._emitError(err);
      });
    };
    CombinedStream.prototype.write = function(data) {
      this.emit("data", data);
    };
    CombinedStream.prototype.pause = function() {
      if (!this.pauseStreams) {
        return;
      }
      if (this.pauseStreams && this._currentStream && typeof this._currentStream.pause == "function") this._currentStream.pause();
      this.emit("pause");
    };
    CombinedStream.prototype.resume = function() {
      if (!this._released) {
        this._released = true;
        this.writable = true;
        this._getNext();
      }
      if (this.pauseStreams && this._currentStream && typeof this._currentStream.resume == "function") this._currentStream.resume();
      this.emit("resume");
    };
    CombinedStream.prototype.end = function() {
      this._reset();
      this.emit("end");
    };
    CombinedStream.prototype.destroy = function() {
      this._reset();
      this.emit("close");
    };
    CombinedStream.prototype._reset = function() {
      this.writable = false;
      this._streams = [];
      this._currentStream = null;
    };
    CombinedStream.prototype._checkDataSize = function() {
      this._updateDataSize();
      if (this.dataSize <= this.maxDataSize) {
        return;
      }
      var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
      this._emitError(new Error(message));
    };
    CombinedStream.prototype._updateDataSize = function() {
      this.dataSize = 0;
      var self2 = this;
      this._streams.forEach(function(stream) {
        if (!stream.dataSize) {
          return;
        }
        self2.dataSize += stream.dataSize;
      });
      if (this._currentStream && this._currentStream.dataSize) {
        this.dataSize += this._currentStream.dataSize;
      }
    };
    CombinedStream.prototype._emitError = function(err) {
      this._reset();
      this.emit("error", err);
    };
  }
});

// node_modules/mime-db/db.json
var require_db = __commonJS({
  "node_modules/mime-db/db.json"(exports, module) {
    module.exports = {
      "application/1d-interleaved-parityfec": {
        source: "iana"
      },
      "application/3gpdash-qoe-report+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/3gpp-ims+xml": {
        source: "iana",
        compressible: true
      },
      "application/3gpphal+json": {
        source: "iana",
        compressible: true
      },
      "application/3gpphalforms+json": {
        source: "iana",
        compressible: true
      },
      "application/a2l": {
        source: "iana"
      },
      "application/ace+cbor": {
        source: "iana"
      },
      "application/activemessage": {
        source: "iana"
      },
      "application/activity+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-costmap+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-costmapfilter+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-directory+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointcost+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointcostparams+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointprop+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointpropparams+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-error+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-networkmap+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-networkmapfilter+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-updatestreamcontrol+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-updatestreamparams+json": {
        source: "iana",
        compressible: true
      },
      "application/aml": {
        source: "iana"
      },
      "application/andrew-inset": {
        source: "iana",
        extensions: ["ez"]
      },
      "application/applefile": {
        source: "iana"
      },
      "application/applixware": {
        source: "apache",
        extensions: ["aw"]
      },
      "application/at+jwt": {
        source: "iana"
      },
      "application/atf": {
        source: "iana"
      },
      "application/atfx": {
        source: "iana"
      },
      "application/atom+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atom"]
      },
      "application/atomcat+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomcat"]
      },
      "application/atomdeleted+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomdeleted"]
      },
      "application/atomicmail": {
        source: "iana"
      },
      "application/atomsvc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomsvc"]
      },
      "application/atsc-dwd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dwd"]
      },
      "application/atsc-dynamic-event-message": {
        source: "iana"
      },
      "application/atsc-held+xml": {
        source: "iana",
        compressible: true,
        extensions: ["held"]
      },
      "application/atsc-rdt+json": {
        source: "iana",
        compressible: true
      },
      "application/atsc-rsat+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rsat"]
      },
      "application/atxml": {
        source: "iana"
      },
      "application/auth-policy+xml": {
        source: "iana",
        compressible: true
      },
      "application/bacnet-xdd+zip": {
        source: "iana",
        compressible: false
      },
      "application/batch-smtp": {
        source: "iana"
      },
      "application/bdoc": {
        compressible: false,
        extensions: ["bdoc"]
      },
      "application/beep+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/calendar+json": {
        source: "iana",
        compressible: true
      },
      "application/calendar+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xcs"]
      },
      "application/call-completion": {
        source: "iana"
      },
      "application/cals-1840": {
        source: "iana"
      },
      "application/captive+json": {
        source: "iana",
        compressible: true
      },
      "application/cbor": {
        source: "iana"
      },
      "application/cbor-seq": {
        source: "iana"
      },
      "application/cccex": {
        source: "iana"
      },
      "application/ccmp+xml": {
        source: "iana",
        compressible: true
      },
      "application/ccxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ccxml"]
      },
      "application/cdfx+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cdfx"]
      },
      "application/cdmi-capability": {
        source: "iana",
        extensions: ["cdmia"]
      },
      "application/cdmi-container": {
        source: "iana",
        extensions: ["cdmic"]
      },
      "application/cdmi-domain": {
        source: "iana",
        extensions: ["cdmid"]
      },
      "application/cdmi-object": {
        source: "iana",
        extensions: ["cdmio"]
      },
      "application/cdmi-queue": {
        source: "iana",
        extensions: ["cdmiq"]
      },
      "application/cdni": {
        source: "iana"
      },
      "application/cea": {
        source: "iana"
      },
      "application/cea-2018+xml": {
        source: "iana",
        compressible: true
      },
      "application/cellml+xml": {
        source: "iana",
        compressible: true
      },
      "application/cfw": {
        source: "iana"
      },
      "application/city+json": {
        source: "iana",
        compressible: true
      },
      "application/clr": {
        source: "iana"
      },
      "application/clue+xml": {
        source: "iana",
        compressible: true
      },
      "application/clue_info+xml": {
        source: "iana",
        compressible: true
      },
      "application/cms": {
        source: "iana"
      },
      "application/cnrp+xml": {
        source: "iana",
        compressible: true
      },
      "application/coap-group+json": {
        source: "iana",
        compressible: true
      },
      "application/coap-payload": {
        source: "iana"
      },
      "application/commonground": {
        source: "iana"
      },
      "application/conference-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/cose": {
        source: "iana"
      },
      "application/cose-key": {
        source: "iana"
      },
      "application/cose-key-set": {
        source: "iana"
      },
      "application/cpl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cpl"]
      },
      "application/csrattrs": {
        source: "iana"
      },
      "application/csta+xml": {
        source: "iana",
        compressible: true
      },
      "application/cstadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/csvm+json": {
        source: "iana",
        compressible: true
      },
      "application/cu-seeme": {
        source: "apache",
        extensions: ["cu"]
      },
      "application/cwt": {
        source: "iana"
      },
      "application/cybercash": {
        source: "iana"
      },
      "application/dart": {
        compressible: true
      },
      "application/dash+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpd"]
      },
      "application/dash-patch+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpp"]
      },
      "application/dashdelta": {
        source: "iana"
      },
      "application/davmount+xml": {
        source: "iana",
        compressible: true,
        extensions: ["davmount"]
      },
      "application/dca-rft": {
        source: "iana"
      },
      "application/dcd": {
        source: "iana"
      },
      "application/dec-dx": {
        source: "iana"
      },
      "application/dialog-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/dicom": {
        source: "iana"
      },
      "application/dicom+json": {
        source: "iana",
        compressible: true
      },
      "application/dicom+xml": {
        source: "iana",
        compressible: true
      },
      "application/dii": {
        source: "iana"
      },
      "application/dit": {
        source: "iana"
      },
      "application/dns": {
        source: "iana"
      },
      "application/dns+json": {
        source: "iana",
        compressible: true
      },
      "application/dns-message": {
        source: "iana"
      },
      "application/docbook+xml": {
        source: "apache",
        compressible: true,
        extensions: ["dbk"]
      },
      "application/dots+cbor": {
        source: "iana"
      },
      "application/dskpp+xml": {
        source: "iana",
        compressible: true
      },
      "application/dssc+der": {
        source: "iana",
        extensions: ["dssc"]
      },
      "application/dssc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdssc"]
      },
      "application/dvcs": {
        source: "iana"
      },
      "application/ecmascript": {
        source: "iana",
        compressible: true,
        extensions: ["es", "ecma"]
      },
      "application/edi-consent": {
        source: "iana"
      },
      "application/edi-x12": {
        source: "iana",
        compressible: false
      },
      "application/edifact": {
        source: "iana",
        compressible: false
      },
      "application/efi": {
        source: "iana"
      },
      "application/elm+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/elm+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.cap+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/emergencycalldata.comment+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.control+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.deviceinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.ecall.msd": {
        source: "iana"
      },
      "application/emergencycalldata.providerinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.serviceinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.subscriberinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.veds+xml": {
        source: "iana",
        compressible: true
      },
      "application/emma+xml": {
        source: "iana",
        compressible: true,
        extensions: ["emma"]
      },
      "application/emotionml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["emotionml"]
      },
      "application/encaprtp": {
        source: "iana"
      },
      "application/epp+xml": {
        source: "iana",
        compressible: true
      },
      "application/epub+zip": {
        source: "iana",
        compressible: false,
        extensions: ["epub"]
      },
      "application/eshop": {
        source: "iana"
      },
      "application/exi": {
        source: "iana",
        extensions: ["exi"]
      },
      "application/expect-ct-report+json": {
        source: "iana",
        compressible: true
      },
      "application/express": {
        source: "iana",
        extensions: ["exp"]
      },
      "application/fastinfoset": {
        source: "iana"
      },
      "application/fastsoap": {
        source: "iana"
      },
      "application/fdt+xml": {
        source: "iana",
        compressible: true,
        extensions: ["fdt"]
      },
      "application/fhir+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/fhir+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/fido.trusted-apps+json": {
        compressible: true
      },
      "application/fits": {
        source: "iana"
      },
      "application/flexfec": {
        source: "iana"
      },
      "application/font-sfnt": {
        source: "iana"
      },
      "application/font-tdpfr": {
        source: "iana",
        extensions: ["pfr"]
      },
      "application/font-woff": {
        source: "iana",
        compressible: false
      },
      "application/framework-attributes+xml": {
        source: "iana",
        compressible: true
      },
      "application/geo+json": {
        source: "iana",
        compressible: true,
        extensions: ["geojson"]
      },
      "application/geo+json-seq": {
        source: "iana"
      },
      "application/geopackage+sqlite3": {
        source: "iana"
      },
      "application/geoxacml+xml": {
        source: "iana",
        compressible: true
      },
      "application/gltf-buffer": {
        source: "iana"
      },
      "application/gml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["gml"]
      },
      "application/gpx+xml": {
        source: "apache",
        compressible: true,
        extensions: ["gpx"]
      },
      "application/gxf": {
        source: "apache",
        extensions: ["gxf"]
      },
      "application/gzip": {
        source: "iana",
        compressible: false,
        extensions: ["gz"]
      },
      "application/h224": {
        source: "iana"
      },
      "application/held+xml": {
        source: "iana",
        compressible: true
      },
      "application/hjson": {
        extensions: ["hjson"]
      },
      "application/http": {
        source: "iana"
      },
      "application/hyperstudio": {
        source: "iana",
        extensions: ["stk"]
      },
      "application/ibe-key-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/ibe-pkg-reply+xml": {
        source: "iana",
        compressible: true
      },
      "application/ibe-pp-data": {
        source: "iana"
      },
      "application/iges": {
        source: "iana"
      },
      "application/im-iscomposing+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/index": {
        source: "iana"
      },
      "application/index.cmd": {
        source: "iana"
      },
      "application/index.obj": {
        source: "iana"
      },
      "application/index.response": {
        source: "iana"
      },
      "application/index.vnd": {
        source: "iana"
      },
      "application/inkml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ink", "inkml"]
      },
      "application/iotp": {
        source: "iana"
      },
      "application/ipfix": {
        source: "iana",
        extensions: ["ipfix"]
      },
      "application/ipp": {
        source: "iana"
      },
      "application/isup": {
        source: "iana"
      },
      "application/its+xml": {
        source: "iana",
        compressible: true,
        extensions: ["its"]
      },
      "application/java-archive": {
        source: "apache",
        compressible: false,
        extensions: ["jar", "war", "ear"]
      },
      "application/java-serialized-object": {
        source: "apache",
        compressible: false,
        extensions: ["ser"]
      },
      "application/java-vm": {
        source: "apache",
        compressible: false,
        extensions: ["class"]
      },
      "application/javascript": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["js", "mjs"]
      },
      "application/jf2feed+json": {
        source: "iana",
        compressible: true
      },
      "application/jose": {
        source: "iana"
      },
      "application/jose+json": {
        source: "iana",
        compressible: true
      },
      "application/jrd+json": {
        source: "iana",
        compressible: true
      },
      "application/jscalendar+json": {
        source: "iana",
        compressible: true
      },
      "application/json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["json", "map"]
      },
      "application/json-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/json-seq": {
        source: "iana"
      },
      "application/json5": {
        extensions: ["json5"]
      },
      "application/jsonml+json": {
        source: "apache",
        compressible: true,
        extensions: ["jsonml"]
      },
      "application/jwk+json": {
        source: "iana",
        compressible: true
      },
      "application/jwk-set+json": {
        source: "iana",
        compressible: true
      },
      "application/jwt": {
        source: "iana"
      },
      "application/kpml-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/kpml-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/ld+json": {
        source: "iana",
        compressible: true,
        extensions: ["jsonld"]
      },
      "application/lgr+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lgr"]
      },
      "application/link-format": {
        source: "iana"
      },
      "application/load-control+xml": {
        source: "iana",
        compressible: true
      },
      "application/lost+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lostxml"]
      },
      "application/lostsync+xml": {
        source: "iana",
        compressible: true
      },
      "application/lpf+zip": {
        source: "iana",
        compressible: false
      },
      "application/lxf": {
        source: "iana"
      },
      "application/mac-binhex40": {
        source: "iana",
        extensions: ["hqx"]
      },
      "application/mac-compactpro": {
        source: "apache",
        extensions: ["cpt"]
      },
      "application/macwriteii": {
        source: "iana"
      },
      "application/mads+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mads"]
      },
      "application/manifest+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["webmanifest"]
      },
      "application/marc": {
        source: "iana",
        extensions: ["mrc"]
      },
      "application/marcxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mrcx"]
      },
      "application/mathematica": {
        source: "iana",
        extensions: ["ma", "nb", "mb"]
      },
      "application/mathml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mathml"]
      },
      "application/mathml-content+xml": {
        source: "iana",
        compressible: true
      },
      "application/mathml-presentation+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-associated-procedure-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-deregister+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-envelope+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-msk+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-msk-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-protection-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-reception-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-register+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-register-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-schedule+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-user-service-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbox": {
        source: "iana",
        extensions: ["mbox"]
      },
      "application/media-policy-dataset+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpf"]
      },
      "application/media_control+xml": {
        source: "iana",
        compressible: true
      },
      "application/mediaservercontrol+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mscml"]
      },
      "application/merge-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/metalink+xml": {
        source: "apache",
        compressible: true,
        extensions: ["metalink"]
      },
      "application/metalink4+xml": {
        source: "iana",
        compressible: true,
        extensions: ["meta4"]
      },
      "application/mets+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mets"]
      },
      "application/mf4": {
        source: "iana"
      },
      "application/mikey": {
        source: "iana"
      },
      "application/mipc": {
        source: "iana"
      },
      "application/missing-blocks+cbor-seq": {
        source: "iana"
      },
      "application/mmt-aei+xml": {
        source: "iana",
        compressible: true,
        extensions: ["maei"]
      },
      "application/mmt-usd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["musd"]
      },
      "application/mods+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mods"]
      },
      "application/moss-keys": {
        source: "iana"
      },
      "application/moss-signature": {
        source: "iana"
      },
      "application/mosskey-data": {
        source: "iana"
      },
      "application/mosskey-request": {
        source: "iana"
      },
      "application/mp21": {
        source: "iana",
        extensions: ["m21", "mp21"]
      },
      "application/mp4": {
        source: "iana",
        extensions: ["mp4s", "m4p"]
      },
      "application/mpeg4-generic": {
        source: "iana"
      },
      "application/mpeg4-iod": {
        source: "iana"
      },
      "application/mpeg4-iod-xmt": {
        source: "iana"
      },
      "application/mrb-consumer+xml": {
        source: "iana",
        compressible: true
      },
      "application/mrb-publish+xml": {
        source: "iana",
        compressible: true
      },
      "application/msc-ivr+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/msc-mixer+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/msword": {
        source: "iana",
        compressible: false,
        extensions: ["doc", "dot"]
      },
      "application/mud+json": {
        source: "iana",
        compressible: true
      },
      "application/multipart-core": {
        source: "iana"
      },
      "application/mxf": {
        source: "iana",
        extensions: ["mxf"]
      },
      "application/n-quads": {
        source: "iana",
        extensions: ["nq"]
      },
      "application/n-triples": {
        source: "iana",
        extensions: ["nt"]
      },
      "application/nasdata": {
        source: "iana"
      },
      "application/news-checkgroups": {
        source: "iana",
        charset: "US-ASCII"
      },
      "application/news-groupinfo": {
        source: "iana",
        charset: "US-ASCII"
      },
      "application/news-transmission": {
        source: "iana"
      },
      "application/nlsml+xml": {
        source: "iana",
        compressible: true
      },
      "application/node": {
        source: "iana",
        extensions: ["cjs"]
      },
      "application/nss": {
        source: "iana"
      },
      "application/oauth-authz-req+jwt": {
        source: "iana"
      },
      "application/oblivious-dns-message": {
        source: "iana"
      },
      "application/ocsp-request": {
        source: "iana"
      },
      "application/ocsp-response": {
        source: "iana"
      },
      "application/octet-stream": {
        source: "iana",
        compressible: false,
        extensions: ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"]
      },
      "application/oda": {
        source: "iana",
        extensions: ["oda"]
      },
      "application/odm+xml": {
        source: "iana",
        compressible: true
      },
      "application/odx": {
        source: "iana"
      },
      "application/oebps-package+xml": {
        source: "iana",
        compressible: true,
        extensions: ["opf"]
      },
      "application/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["ogx"]
      },
      "application/omdoc+xml": {
        source: "apache",
        compressible: true,
        extensions: ["omdoc"]
      },
      "application/onenote": {
        source: "apache",
        extensions: ["onetoc", "onetoc2", "onetmp", "onepkg"]
      },
      "application/opc-nodeset+xml": {
        source: "iana",
        compressible: true
      },
      "application/oscore": {
        source: "iana"
      },
      "application/oxps": {
        source: "iana",
        extensions: ["oxps"]
      },
      "application/p21": {
        source: "iana"
      },
      "application/p21+zip": {
        source: "iana",
        compressible: false
      },
      "application/p2p-overlay+xml": {
        source: "iana",
        compressible: true,
        extensions: ["relo"]
      },
      "application/parityfec": {
        source: "iana"
      },
      "application/passport": {
        source: "iana"
      },
      "application/patch-ops-error+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xer"]
      },
      "application/pdf": {
        source: "iana",
        compressible: false,
        extensions: ["pdf"]
      },
      "application/pdx": {
        source: "iana"
      },
      "application/pem-certificate-chain": {
        source: "iana"
      },
      "application/pgp-encrypted": {
        source: "iana",
        compressible: false,
        extensions: ["pgp"]
      },
      "application/pgp-keys": {
        source: "iana",
        extensions: ["asc"]
      },
      "application/pgp-signature": {
        source: "iana",
        extensions: ["asc", "sig"]
      },
      "application/pics-rules": {
        source: "apache",
        extensions: ["prf"]
      },
      "application/pidf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/pidf-diff+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/pkcs10": {
        source: "iana",
        extensions: ["p10"]
      },
      "application/pkcs12": {
        source: "iana"
      },
      "application/pkcs7-mime": {
        source: "iana",
        extensions: ["p7m", "p7c"]
      },
      "application/pkcs7-signature": {
        source: "iana",
        extensions: ["p7s"]
      },
      "application/pkcs8": {
        source: "iana",
        extensions: ["p8"]
      },
      "application/pkcs8-encrypted": {
        source: "iana"
      },
      "application/pkix-attr-cert": {
        source: "iana",
        extensions: ["ac"]
      },
      "application/pkix-cert": {
        source: "iana",
        extensions: ["cer"]
      },
      "application/pkix-crl": {
        source: "iana",
        extensions: ["crl"]
      },
      "application/pkix-pkipath": {
        source: "iana",
        extensions: ["pkipath"]
      },
      "application/pkixcmp": {
        source: "iana",
        extensions: ["pki"]
      },
      "application/pls+xml": {
        source: "iana",
        compressible: true,
        extensions: ["pls"]
      },
      "application/poc-settings+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/postscript": {
        source: "iana",
        compressible: true,
        extensions: ["ai", "eps", "ps"]
      },
      "application/ppsp-tracker+json": {
        source: "iana",
        compressible: true
      },
      "application/problem+json": {
        source: "iana",
        compressible: true
      },
      "application/problem+xml": {
        source: "iana",
        compressible: true
      },
      "application/provenance+xml": {
        source: "iana",
        compressible: true,
        extensions: ["provx"]
      },
      "application/prs.alvestrand.titrax-sheet": {
        source: "iana"
      },
      "application/prs.cww": {
        source: "iana",
        extensions: ["cww"]
      },
      "application/prs.cyn": {
        source: "iana",
        charset: "7-BIT"
      },
      "application/prs.hpub+zip": {
        source: "iana",
        compressible: false
      },
      "application/prs.nprend": {
        source: "iana"
      },
      "application/prs.plucker": {
        source: "iana"
      },
      "application/prs.rdf-xml-crypt": {
        source: "iana"
      },
      "application/prs.xsf+xml": {
        source: "iana",
        compressible: true
      },
      "application/pskc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["pskcxml"]
      },
      "application/pvd+json": {
        source: "iana",
        compressible: true
      },
      "application/qsig": {
        source: "iana"
      },
      "application/raml+yaml": {
        compressible: true,
        extensions: ["raml"]
      },
      "application/raptorfec": {
        source: "iana"
      },
      "application/rdap+json": {
        source: "iana",
        compressible: true
      },
      "application/rdf+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rdf", "owl"]
      },
      "application/reginfo+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rif"]
      },
      "application/relax-ng-compact-syntax": {
        source: "iana",
        extensions: ["rnc"]
      },
      "application/remote-printing": {
        source: "iana"
      },
      "application/reputon+json": {
        source: "iana",
        compressible: true
      },
      "application/resource-lists+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rl"]
      },
      "application/resource-lists-diff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rld"]
      },
      "application/rfc+xml": {
        source: "iana",
        compressible: true
      },
      "application/riscos": {
        source: "iana"
      },
      "application/rlmi+xml": {
        source: "iana",
        compressible: true
      },
      "application/rls-services+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rs"]
      },
      "application/route-apd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rapd"]
      },
      "application/route-s-tsid+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sls"]
      },
      "application/route-usd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rusd"]
      },
      "application/rpki-ghostbusters": {
        source: "iana",
        extensions: ["gbr"]
      },
      "application/rpki-manifest": {
        source: "iana",
        extensions: ["mft"]
      },
      "application/rpki-publication": {
        source: "iana"
      },
      "application/rpki-roa": {
        source: "iana",
        extensions: ["roa"]
      },
      "application/rpki-updown": {
        source: "iana"
      },
      "application/rsd+xml": {
        source: "apache",
        compressible: true,
        extensions: ["rsd"]
      },
      "application/rss+xml": {
        source: "apache",
        compressible: true,
        extensions: ["rss"]
      },
      "application/rtf": {
        source: "iana",
        compressible: true,
        extensions: ["rtf"]
      },
      "application/rtploopback": {
        source: "iana"
      },
      "application/rtx": {
        source: "iana"
      },
      "application/samlassertion+xml": {
        source: "iana",
        compressible: true
      },
      "application/samlmetadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/sarif+json": {
        source: "iana",
        compressible: true
      },
      "application/sarif-external-properties+json": {
        source: "iana",
        compressible: true
      },
      "application/sbe": {
        source: "iana"
      },
      "application/sbml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sbml"]
      },
      "application/scaip+xml": {
        source: "iana",
        compressible: true
      },
      "application/scim+json": {
        source: "iana",
        compressible: true
      },
      "application/scvp-cv-request": {
        source: "iana",
        extensions: ["scq"]
      },
      "application/scvp-cv-response": {
        source: "iana",
        extensions: ["scs"]
      },
      "application/scvp-vp-request": {
        source: "iana",
        extensions: ["spq"]
      },
      "application/scvp-vp-response": {
        source: "iana",
        extensions: ["spp"]
      },
      "application/sdp": {
        source: "iana",
        extensions: ["sdp"]
      },
      "application/secevent+jwt": {
        source: "iana"
      },
      "application/senml+cbor": {
        source: "iana"
      },
      "application/senml+json": {
        source: "iana",
        compressible: true
      },
      "application/senml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["senmlx"]
      },
      "application/senml-etch+cbor": {
        source: "iana"
      },
      "application/senml-etch+json": {
        source: "iana",
        compressible: true
      },
      "application/senml-exi": {
        source: "iana"
      },
      "application/sensml+cbor": {
        source: "iana"
      },
      "application/sensml+json": {
        source: "iana",
        compressible: true
      },
      "application/sensml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sensmlx"]
      },
      "application/sensml-exi": {
        source: "iana"
      },
      "application/sep+xml": {
        source: "iana",
        compressible: true
      },
      "application/sep-exi": {
        source: "iana"
      },
      "application/session-info": {
        source: "iana"
      },
      "application/set-payment": {
        source: "iana"
      },
      "application/set-payment-initiation": {
        source: "iana",
        extensions: ["setpay"]
      },
      "application/set-registration": {
        source: "iana"
      },
      "application/set-registration-initiation": {
        source: "iana",
        extensions: ["setreg"]
      },
      "application/sgml": {
        source: "iana"
      },
      "application/sgml-open-catalog": {
        source: "iana"
      },
      "application/shf+xml": {
        source: "iana",
        compressible: true,
        extensions: ["shf"]
      },
      "application/sieve": {
        source: "iana",
        extensions: ["siv", "sieve"]
      },
      "application/simple-filter+xml": {
        source: "iana",
        compressible: true
      },
      "application/simple-message-summary": {
        source: "iana"
      },
      "application/simplesymbolcontainer": {
        source: "iana"
      },
      "application/sipc": {
        source: "iana"
      },
      "application/slate": {
        source: "iana"
      },
      "application/smil": {
        source: "iana"
      },
      "application/smil+xml": {
        source: "iana",
        compressible: true,
        extensions: ["smi", "smil"]
      },
      "application/smpte336m": {
        source: "iana"
      },
      "application/soap+fastinfoset": {
        source: "iana"
      },
      "application/soap+xml": {
        source: "iana",
        compressible: true
      },
      "application/sparql-query": {
        source: "iana",
        extensions: ["rq"]
      },
      "application/sparql-results+xml": {
        source: "iana",
        compressible: true,
        extensions: ["srx"]
      },
      "application/spdx+json": {
        source: "iana",
        compressible: true
      },
      "application/spirits-event+xml": {
        source: "iana",
        compressible: true
      },
      "application/sql": {
        source: "iana"
      },
      "application/srgs": {
        source: "iana",
        extensions: ["gram"]
      },
      "application/srgs+xml": {
        source: "iana",
        compressible: true,
        extensions: ["grxml"]
      },
      "application/sru+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sru"]
      },
      "application/ssdl+xml": {
        source: "apache",
        compressible: true,
        extensions: ["ssdl"]
      },
      "application/ssml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ssml"]
      },
      "application/stix+json": {
        source: "iana",
        compressible: true
      },
      "application/swid+xml": {
        source: "iana",
        compressible: true,
        extensions: ["swidtag"]
      },
      "application/tamp-apex-update": {
        source: "iana"
      },
      "application/tamp-apex-update-confirm": {
        source: "iana"
      },
      "application/tamp-community-update": {
        source: "iana"
      },
      "application/tamp-community-update-confirm": {
        source: "iana"
      },
      "application/tamp-error": {
        source: "iana"
      },
      "application/tamp-sequence-adjust": {
        source: "iana"
      },
      "application/tamp-sequence-adjust-confirm": {
        source: "iana"
      },
      "application/tamp-status-query": {
        source: "iana"
      },
      "application/tamp-status-response": {
        source: "iana"
      },
      "application/tamp-update": {
        source: "iana"
      },
      "application/tamp-update-confirm": {
        source: "iana"
      },
      "application/tar": {
        compressible: true
      },
      "application/taxii+json": {
        source: "iana",
        compressible: true
      },
      "application/td+json": {
        source: "iana",
        compressible: true
      },
      "application/tei+xml": {
        source: "iana",
        compressible: true,
        extensions: ["tei", "teicorpus"]
      },
      "application/tetra_isi": {
        source: "iana"
      },
      "application/thraud+xml": {
        source: "iana",
        compressible: true,
        extensions: ["tfi"]
      },
      "application/timestamp-query": {
        source: "iana"
      },
      "application/timestamp-reply": {
        source: "iana"
      },
      "application/timestamped-data": {
        source: "iana",
        extensions: ["tsd"]
      },
      "application/tlsrpt+gzip": {
        source: "iana"
      },
      "application/tlsrpt+json": {
        source: "iana",
        compressible: true
      },
      "application/tnauthlist": {
        source: "iana"
      },
      "application/token-introspection+jwt": {
        source: "iana"
      },
      "application/toml": {
        compressible: true,
        extensions: ["toml"]
      },
      "application/trickle-ice-sdpfrag": {
        source: "iana"
      },
      "application/trig": {
        source: "iana",
        extensions: ["trig"]
      },
      "application/ttml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ttml"]
      },
      "application/tve-trigger": {
        source: "iana"
      },
      "application/tzif": {
        source: "iana"
      },
      "application/tzif-leap": {
        source: "iana"
      },
      "application/ubjson": {
        compressible: false,
        extensions: ["ubj"]
      },
      "application/ulpfec": {
        source: "iana"
      },
      "application/urc-grpsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/urc-ressheet+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rsheet"]
      },
      "application/urc-targetdesc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["td"]
      },
      "application/urc-uisocketdesc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vcard+json": {
        source: "iana",
        compressible: true
      },
      "application/vcard+xml": {
        source: "iana",
        compressible: true
      },
      "application/vemmi": {
        source: "iana"
      },
      "application/vividence.scriptfile": {
        source: "apache"
      },
      "application/vnd.1000minds.decision-model+xml": {
        source: "iana",
        compressible: true,
        extensions: ["1km"]
      },
      "application/vnd.3gpp-prose+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp-prose-pc3ch+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp-v2x-local-service-information": {
        source: "iana"
      },
      "application/vnd.3gpp.5gnas": {
        source: "iana"
      },
      "application/vnd.3gpp.access-transfer-events+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.bsf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.gmop+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.gtpc": {
        source: "iana"
      },
      "application/vnd.3gpp.interworking-data": {
        source: "iana"
      },
      "application/vnd.3gpp.lpp": {
        source: "iana"
      },
      "application/vnd.3gpp.mc-signalling-ear": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-payload": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-signalling": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-floor-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-location-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-mbms-usage-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-signed+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-ue-init-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-affiliation-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-location-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-mbms-usage-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-transmission-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mid-call+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.ngap": {
        source: "iana"
      },
      "application/vnd.3gpp.pfcp": {
        source: "iana"
      },
      "application/vnd.3gpp.pic-bw-large": {
        source: "iana",
        extensions: ["plb"]
      },
      "application/vnd.3gpp.pic-bw-small": {
        source: "iana",
        extensions: ["psb"]
      },
      "application/vnd.3gpp.pic-bw-var": {
        source: "iana",
        extensions: ["pvb"]
      },
      "application/vnd.3gpp.s1ap": {
        source: "iana"
      },
      "application/vnd.3gpp.sms": {
        source: "iana"
      },
      "application/vnd.3gpp.sms+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.srvcc-ext+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.srvcc-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.state-and-event-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.ussd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp2.bcmcsinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp2.sms": {
        source: "iana"
      },
      "application/vnd.3gpp2.tcap": {
        source: "iana",
        extensions: ["tcap"]
      },
      "application/vnd.3lightssoftware.imagescal": {
        source: "iana"
      },
      "application/vnd.3m.post-it-notes": {
        source: "iana",
        extensions: ["pwn"]
      },
      "application/vnd.accpac.simply.aso": {
        source: "iana",
        extensions: ["aso"]
      },
      "application/vnd.accpac.simply.imp": {
        source: "iana",
        extensions: ["imp"]
      },
      "application/vnd.acucobol": {
        source: "iana",
        extensions: ["acu"]
      },
      "application/vnd.acucorp": {
        source: "iana",
        extensions: ["atc", "acutc"]
      },
      "application/vnd.adobe.air-application-installer-package+zip": {
        source: "apache",
        compressible: false,
        extensions: ["air"]
      },
      "application/vnd.adobe.flash.movie": {
        source: "iana"
      },
      "application/vnd.adobe.formscentral.fcdt": {
        source: "iana",
        extensions: ["fcdt"]
      },
      "application/vnd.adobe.fxp": {
        source: "iana",
        extensions: ["fxp", "fxpl"]
      },
      "application/vnd.adobe.partial-upload": {
        source: "iana"
      },
      "application/vnd.adobe.xdp+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdp"]
      },
      "application/vnd.adobe.xfdf": {
        source: "iana",
        extensions: ["xfdf"]
      },
      "application/vnd.aether.imp": {
        source: "iana"
      },
      "application/vnd.afpc.afplinedata": {
        source: "iana"
      },
      "application/vnd.afpc.afplinedata-pagedef": {
        source: "iana"
      },
      "application/vnd.afpc.cmoca-cmresource": {
        source: "iana"
      },
      "application/vnd.afpc.foca-charset": {
        source: "iana"
      },
      "application/vnd.afpc.foca-codedfont": {
        source: "iana"
      },
      "application/vnd.afpc.foca-codepage": {
        source: "iana"
      },
      "application/vnd.afpc.modca": {
        source: "iana"
      },
      "application/vnd.afpc.modca-cmtable": {
        source: "iana"
      },
      "application/vnd.afpc.modca-formdef": {
        source: "iana"
      },
      "application/vnd.afpc.modca-mediummap": {
        source: "iana"
      },
      "application/vnd.afpc.modca-objectcontainer": {
        source: "iana"
      },
      "application/vnd.afpc.modca-overlay": {
        source: "iana"
      },
      "application/vnd.afpc.modca-pagesegment": {
        source: "iana"
      },
      "application/vnd.age": {
        source: "iana",
        extensions: ["age"]
      },
      "application/vnd.ah-barcode": {
        source: "iana"
      },
      "application/vnd.ahead.space": {
        source: "iana",
        extensions: ["ahead"]
      },
      "application/vnd.airzip.filesecure.azf": {
        source: "iana",
        extensions: ["azf"]
      },
      "application/vnd.airzip.filesecure.azs": {
        source: "iana",
        extensions: ["azs"]
      },
      "application/vnd.amadeus+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.amazon.ebook": {
        source: "apache",
        extensions: ["azw"]
      },
      "application/vnd.amazon.mobi8-ebook": {
        source: "iana"
      },
      "application/vnd.americandynamics.acc": {
        source: "iana",
        extensions: ["acc"]
      },
      "application/vnd.amiga.ami": {
        source: "iana",
        extensions: ["ami"]
      },
      "application/vnd.amundsen.maze+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.android.ota": {
        source: "iana"
      },
      "application/vnd.android.package-archive": {
        source: "apache",
        compressible: false,
        extensions: ["apk"]
      },
      "application/vnd.anki": {
        source: "iana"
      },
      "application/vnd.anser-web-certificate-issue-initiation": {
        source: "iana",
        extensions: ["cii"]
      },
      "application/vnd.anser-web-funds-transfer-initiation": {
        source: "apache",
        extensions: ["fti"]
      },
      "application/vnd.antix.game-component": {
        source: "iana",
        extensions: ["atx"]
      },
      "application/vnd.apache.arrow.file": {
        source: "iana"
      },
      "application/vnd.apache.arrow.stream": {
        source: "iana"
      },
      "application/vnd.apache.thrift.binary": {
        source: "iana"
      },
      "application/vnd.apache.thrift.compact": {
        source: "iana"
      },
      "application/vnd.apache.thrift.json": {
        source: "iana"
      },
      "application/vnd.api+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.aplextor.warrp+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.apothekende.reservation+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.apple.installer+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpkg"]
      },
      "application/vnd.apple.keynote": {
        source: "iana",
        extensions: ["key"]
      },
      "application/vnd.apple.mpegurl": {
        source: "iana",
        extensions: ["m3u8"]
      },
      "application/vnd.apple.numbers": {
        source: "iana",
        extensions: ["numbers"]
      },
      "application/vnd.apple.pages": {
        source: "iana",
        extensions: ["pages"]
      },
      "application/vnd.apple.pkpass": {
        compressible: false,
        extensions: ["pkpass"]
      },
      "application/vnd.arastra.swi": {
        source: "iana"
      },
      "application/vnd.aristanetworks.swi": {
        source: "iana",
        extensions: ["swi"]
      },
      "application/vnd.artisan+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.artsquare": {
        source: "iana"
      },
      "application/vnd.astraea-software.iota": {
        source: "iana",
        extensions: ["iota"]
      },
      "application/vnd.audiograph": {
        source: "iana",
        extensions: ["aep"]
      },
      "application/vnd.autopackage": {
        source: "iana"
      },
      "application/vnd.avalon+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.avistar+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.balsamiq.bmml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["bmml"]
      },
      "application/vnd.balsamiq.bmpr": {
        source: "iana"
      },
      "application/vnd.banana-accounting": {
        source: "iana"
      },
      "application/vnd.bbf.usp.error": {
        source: "iana"
      },
      "application/vnd.bbf.usp.msg": {
        source: "iana"
      },
      "application/vnd.bbf.usp.msg+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.bekitzur-stech+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.bint.med-content": {
        source: "iana"
      },
      "application/vnd.biopax.rdf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.blink-idb-value-wrapper": {
        source: "iana"
      },
      "application/vnd.blueice.multipass": {
        source: "iana",
        extensions: ["mpm"]
      },
      "application/vnd.bluetooth.ep.oob": {
        source: "iana"
      },
      "application/vnd.bluetooth.le.oob": {
        source: "iana"
      },
      "application/vnd.bmi": {
        source: "iana",
        extensions: ["bmi"]
      },
      "application/vnd.bpf": {
        source: "iana"
      },
      "application/vnd.bpf3": {
        source: "iana"
      },
      "application/vnd.businessobjects": {
        source: "iana",
        extensions: ["rep"]
      },
      "application/vnd.byu.uapi+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cab-jscript": {
        source: "iana"
      },
      "application/vnd.canon-cpdl": {
        source: "iana"
      },
      "application/vnd.canon-lips": {
        source: "iana"
      },
      "application/vnd.capasystems-pg+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cendio.thinlinc.clientconf": {
        source: "iana"
      },
      "application/vnd.century-systems.tcp_stream": {
        source: "iana"
      },
      "application/vnd.chemdraw+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cdxml"]
      },
      "application/vnd.chess-pgn": {
        source: "iana"
      },
      "application/vnd.chipnuts.karaoke-mmd": {
        source: "iana",
        extensions: ["mmd"]
      },
      "application/vnd.ciedi": {
        source: "iana"
      },
      "application/vnd.cinderella": {
        source: "iana",
        extensions: ["cdy"]
      },
      "application/vnd.cirpack.isdn-ext": {
        source: "iana"
      },
      "application/vnd.citationstyles.style+xml": {
        source: "iana",
        compressible: true,
        extensions: ["csl"]
      },
      "application/vnd.claymore": {
        source: "iana",
        extensions: ["cla"]
      },
      "application/vnd.cloanto.rp9": {
        source: "iana",
        extensions: ["rp9"]
      },
      "application/vnd.clonk.c4group": {
        source: "iana",
        extensions: ["c4g", "c4d", "c4f", "c4p", "c4u"]
      },
      "application/vnd.cluetrust.cartomobile-config": {
        source: "iana",
        extensions: ["c11amc"]
      },
      "application/vnd.cluetrust.cartomobile-config-pkg": {
        source: "iana",
        extensions: ["c11amz"]
      },
      "application/vnd.coffeescript": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.document": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.document-template": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.presentation": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.presentation-template": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.spreadsheet": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.spreadsheet-template": {
        source: "iana"
      },
      "application/vnd.collection+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.collection.doc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.collection.next+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.comicbook+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.comicbook-rar": {
        source: "iana"
      },
      "application/vnd.commerce-battelle": {
        source: "iana"
      },
      "application/vnd.commonspace": {
        source: "iana",
        extensions: ["csp"]
      },
      "application/vnd.contact.cmsg": {
        source: "iana",
        extensions: ["cdbcmsg"]
      },
      "application/vnd.coreos.ignition+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cosmocaller": {
        source: "iana",
        extensions: ["cmc"]
      },
      "application/vnd.crick.clicker": {
        source: "iana",
        extensions: ["clkx"]
      },
      "application/vnd.crick.clicker.keyboard": {
        source: "iana",
        extensions: ["clkk"]
      },
      "application/vnd.crick.clicker.palette": {
        source: "iana",
        extensions: ["clkp"]
      },
      "application/vnd.crick.clicker.template": {
        source: "iana",
        extensions: ["clkt"]
      },
      "application/vnd.crick.clicker.wordbank": {
        source: "iana",
        extensions: ["clkw"]
      },
      "application/vnd.criticaltools.wbs+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wbs"]
      },
      "application/vnd.cryptii.pipe+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.crypto-shade-file": {
        source: "iana"
      },
      "application/vnd.cryptomator.encrypted": {
        source: "iana"
      },
      "application/vnd.cryptomator.vault": {
        source: "iana"
      },
      "application/vnd.ctc-posml": {
        source: "iana",
        extensions: ["pml"]
      },
      "application/vnd.ctct.ws+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cups-pdf": {
        source: "iana"
      },
      "application/vnd.cups-postscript": {
        source: "iana"
      },
      "application/vnd.cups-ppd": {
        source: "iana",
        extensions: ["ppd"]
      },
      "application/vnd.cups-raster": {
        source: "iana"
      },
      "application/vnd.cups-raw": {
        source: "iana"
      },
      "application/vnd.curl": {
        source: "iana"
      },
      "application/vnd.curl.car": {
        source: "apache",
        extensions: ["car"]
      },
      "application/vnd.curl.pcurl": {
        source: "apache",
        extensions: ["pcurl"]
      },
      "application/vnd.cyan.dean.root+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cybank": {
        source: "iana"
      },
      "application/vnd.cyclonedx+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cyclonedx+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.d2l.coursepackage1p0+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.d3m-dataset": {
        source: "iana"
      },
      "application/vnd.d3m-problem": {
        source: "iana"
      },
      "application/vnd.dart": {
        source: "iana",
        compressible: true,
        extensions: ["dart"]
      },
      "application/vnd.data-vision.rdz": {
        source: "iana",
        extensions: ["rdz"]
      },
      "application/vnd.datapackage+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dataresource+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dbf": {
        source: "iana",
        extensions: ["dbf"]
      },
      "application/vnd.debian.binary-package": {
        source: "iana"
      },
      "application/vnd.dece.data": {
        source: "iana",
        extensions: ["uvf", "uvvf", "uvd", "uvvd"]
      },
      "application/vnd.dece.ttml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["uvt", "uvvt"]
      },
      "application/vnd.dece.unspecified": {
        source: "iana",
        extensions: ["uvx", "uvvx"]
      },
      "application/vnd.dece.zip": {
        source: "iana",
        extensions: ["uvz", "uvvz"]
      },
      "application/vnd.denovo.fcselayout-link": {
        source: "iana",
        extensions: ["fe_launch"]
      },
      "application/vnd.desmume.movie": {
        source: "iana"
      },
      "application/vnd.dir-bi.plate-dl-nosuffix": {
        source: "iana"
      },
      "application/vnd.dm.delegation+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dna": {
        source: "iana",
        extensions: ["dna"]
      },
      "application/vnd.document+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dolby.mlp": {
        source: "apache",
        extensions: ["mlp"]
      },
      "application/vnd.dolby.mobile.1": {
        source: "iana"
      },
      "application/vnd.dolby.mobile.2": {
        source: "iana"
      },
      "application/vnd.doremir.scorecloud-binary-document": {
        source: "iana"
      },
      "application/vnd.dpgraph": {
        source: "iana",
        extensions: ["dpg"]
      },
      "application/vnd.dreamfactory": {
        source: "iana",
        extensions: ["dfac"]
      },
      "application/vnd.drive+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ds-keypoint": {
        source: "apache",
        extensions: ["kpxx"]
      },
      "application/vnd.dtg.local": {
        source: "iana"
      },
      "application/vnd.dtg.local.flash": {
        source: "iana"
      },
      "application/vnd.dtg.local.html": {
        source: "iana"
      },
      "application/vnd.dvb.ait": {
        source: "iana",
        extensions: ["ait"]
      },
      "application/vnd.dvb.dvbisl+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.dvbj": {
        source: "iana"
      },
      "application/vnd.dvb.esgcontainer": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcdftnotifaccess": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgaccess": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgaccess2": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgpdd": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcroaming": {
        source: "iana"
      },
      "application/vnd.dvb.iptv.alfec-base": {
        source: "iana"
      },
      "application/vnd.dvb.iptv.alfec-enhancement": {
        source: "iana"
      },
      "application/vnd.dvb.notif-aggregate-root+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-container+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-generic+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-msglist+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-registration-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-registration-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-init+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.pfr": {
        source: "iana"
      },
      "application/vnd.dvb.service": {
        source: "iana",
        extensions: ["svc"]
      },
      "application/vnd.dxr": {
        source: "iana"
      },
      "application/vnd.dynageo": {
        source: "iana",
        extensions: ["geo"]
      },
      "application/vnd.dzr": {
        source: "iana"
      },
      "application/vnd.easykaraoke.cdgdownload": {
        source: "iana"
      },
      "application/vnd.ecdis-update": {
        source: "iana"
      },
      "application/vnd.ecip.rlp": {
        source: "iana"
      },
      "application/vnd.eclipse.ditto+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ecowin.chart": {
        source: "iana",
        extensions: ["mag"]
      },
      "application/vnd.ecowin.filerequest": {
        source: "iana"
      },
      "application/vnd.ecowin.fileupdate": {
        source: "iana"
      },
      "application/vnd.ecowin.series": {
        source: "iana"
      },
      "application/vnd.ecowin.seriesrequest": {
        source: "iana"
      },
      "application/vnd.ecowin.seriesupdate": {
        source: "iana"
      },
      "application/vnd.efi.img": {
        source: "iana"
      },
      "application/vnd.efi.iso": {
        source: "iana"
      },
      "application/vnd.emclient.accessrequest+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.enliven": {
        source: "iana",
        extensions: ["nml"]
      },
      "application/vnd.enphase.envoy": {
        source: "iana"
      },
      "application/vnd.eprints.data+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.epson.esf": {
        source: "iana",
        extensions: ["esf"]
      },
      "application/vnd.epson.msf": {
        source: "iana",
        extensions: ["msf"]
      },
      "application/vnd.epson.quickanime": {
        source: "iana",
        extensions: ["qam"]
      },
      "application/vnd.epson.salt": {
        source: "iana",
        extensions: ["slt"]
      },
      "application/vnd.epson.ssf": {
        source: "iana",
        extensions: ["ssf"]
      },
      "application/vnd.ericsson.quickcall": {
        source: "iana"
      },
      "application/vnd.espass-espass+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.eszigno3+xml": {
        source: "iana",
        compressible: true,
        extensions: ["es3", "et3"]
      },
      "application/vnd.etsi.aoc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.asic-e+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.etsi.asic-s+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.etsi.cug+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvcommand+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvdiscovery+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-bc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-cod+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-npvr+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvservice+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsync+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvueprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.mcid+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.mheg5": {
        source: "iana"
      },
      "application/vnd.etsi.overload-control-policy-dataset+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.pstn+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.sci+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.simservs+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.timestamp-token": {
        source: "iana"
      },
      "application/vnd.etsi.tsl+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.tsl.der": {
        source: "iana"
      },
      "application/vnd.eu.kasparian.car+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.eudora.data": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.profile": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.settings": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.theme": {
        source: "iana"
      },
      "application/vnd.exstream-empower+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.exstream-package": {
        source: "iana"
      },
      "application/vnd.ezpix-album": {
        source: "iana",
        extensions: ["ez2"]
      },
      "application/vnd.ezpix-package": {
        source: "iana",
        extensions: ["ez3"]
      },
      "application/vnd.f-secure.mobile": {
        source: "iana"
      },
      "application/vnd.familysearch.gedcom+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.fastcopy-disk-image": {
        source: "iana"
      },
      "application/vnd.fdf": {
        source: "iana",
        extensions: ["fdf"]
      },
      "application/vnd.fdsn.mseed": {
        source: "iana",
        extensions: ["mseed"]
      },
      "application/vnd.fdsn.seed": {
        source: "iana",
        extensions: ["seed", "dataless"]
      },
      "application/vnd.ffsns": {
        source: "iana"
      },
      "application/vnd.ficlab.flb+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.filmit.zfc": {
        source: "iana"
      },
      "application/vnd.fints": {
        source: "iana"
      },
      "application/vnd.firemonkeys.cloudcell": {
        source: "iana"
      },
      "application/vnd.flographit": {
        source: "iana",
        extensions: ["gph"]
      },
      "application/vnd.fluxtime.clip": {
        source: "iana",
        extensions: ["ftc"]
      },
      "application/vnd.font-fontforge-sfd": {
        source: "iana"
      },
      "application/vnd.framemaker": {
        source: "iana",
        extensions: ["fm", "frame", "maker", "book"]
      },
      "application/vnd.frogans.fnc": {
        source: "iana",
        extensions: ["fnc"]
      },
      "application/vnd.frogans.ltf": {
        source: "iana",
        extensions: ["ltf"]
      },
      "application/vnd.fsc.weblaunch": {
        source: "iana",
        extensions: ["fsc"]
      },
      "application/vnd.fujifilm.fb.docuworks": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.docuworks.binder": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.docuworks.container": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.jfi+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.fujitsu.oasys": {
        source: "iana",
        extensions: ["oas"]
      },
      "application/vnd.fujitsu.oasys2": {
        source: "iana",
        extensions: ["oa2"]
      },
      "application/vnd.fujitsu.oasys3": {
        source: "iana",
        extensions: ["oa3"]
      },
      "application/vnd.fujitsu.oasysgp": {
        source: "iana",
        extensions: ["fg5"]
      },
      "application/vnd.fujitsu.oasysprs": {
        source: "iana",
        extensions: ["bh2"]
      },
      "application/vnd.fujixerox.art-ex": {
        source: "iana"
      },
      "application/vnd.fujixerox.art4": {
        source: "iana"
      },
      "application/vnd.fujixerox.ddd": {
        source: "iana",
        extensions: ["ddd"]
      },
      "application/vnd.fujixerox.docuworks": {
        source: "iana",
        extensions: ["xdw"]
      },
      "application/vnd.fujixerox.docuworks.binder": {
        source: "iana",
        extensions: ["xbd"]
      },
      "application/vnd.fujixerox.docuworks.container": {
        source: "iana"
      },
      "application/vnd.fujixerox.hbpl": {
        source: "iana"
      },
      "application/vnd.fut-misnet": {
        source: "iana"
      },
      "application/vnd.futoin+cbor": {
        source: "iana"
      },
      "application/vnd.futoin+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.fuzzysheet": {
        source: "iana",
        extensions: ["fzs"]
      },
      "application/vnd.genomatix.tuxedo": {
        source: "iana",
        extensions: ["txd"]
      },
      "application/vnd.gentics.grd+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geo+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geocube+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geogebra.file": {
        source: "iana",
        extensions: ["ggb"]
      },
      "application/vnd.geogebra.slides": {
        source: "iana"
      },
      "application/vnd.geogebra.tool": {
        source: "iana",
        extensions: ["ggt"]
      },
      "application/vnd.geometry-explorer": {
        source: "iana",
        extensions: ["gex", "gre"]
      },
      "application/vnd.geonext": {
        source: "iana",
        extensions: ["gxt"]
      },
      "application/vnd.geoplan": {
        source: "iana",
        extensions: ["g2w"]
      },
      "application/vnd.geospace": {
        source: "iana",
        extensions: ["g3w"]
      },
      "application/vnd.gerber": {
        source: "iana"
      },
      "application/vnd.globalplatform.card-content-mgt": {
        source: "iana"
      },
      "application/vnd.globalplatform.card-content-mgt-response": {
        source: "iana"
      },
      "application/vnd.gmx": {
        source: "iana",
        extensions: ["gmx"]
      },
      "application/vnd.google-apps.document": {
        compressible: false,
        extensions: ["gdoc"]
      },
      "application/vnd.google-apps.presentation": {
        compressible: false,
        extensions: ["gslides"]
      },
      "application/vnd.google-apps.spreadsheet": {
        compressible: false,
        extensions: ["gsheet"]
      },
      "application/vnd.google-earth.kml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["kml"]
      },
      "application/vnd.google-earth.kmz": {
        source: "iana",
        compressible: false,
        extensions: ["kmz"]
      },
      "application/vnd.gov.sk.e-form+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.gov.sk.e-form+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.gov.sk.xmldatacontainer+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.grafeq": {
        source: "iana",
        extensions: ["gqf", "gqs"]
      },
      "application/vnd.gridmp": {
        source: "iana"
      },
      "application/vnd.groove-account": {
        source: "iana",
        extensions: ["gac"]
      },
      "application/vnd.groove-help": {
        source: "iana",
        extensions: ["ghf"]
      },
      "application/vnd.groove-identity-message": {
        source: "iana",
        extensions: ["gim"]
      },
      "application/vnd.groove-injector": {
        source: "iana",
        extensions: ["grv"]
      },
      "application/vnd.groove-tool-message": {
        source: "iana",
        extensions: ["gtm"]
      },
      "application/vnd.groove-tool-template": {
        source: "iana",
        extensions: ["tpl"]
      },
      "application/vnd.groove-vcard": {
        source: "iana",
        extensions: ["vcg"]
      },
      "application/vnd.hal+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hal+xml": {
        source: "iana",
        compressible: true,
        extensions: ["hal"]
      },
      "application/vnd.handheld-entertainment+xml": {
        source: "iana",
        compressible: true,
        extensions: ["zmm"]
      },
      "application/vnd.hbci": {
        source: "iana",
        extensions: ["hbci"]
      },
      "application/vnd.hc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hcl-bireports": {
        source: "iana"
      },
      "application/vnd.hdt": {
        source: "iana"
      },
      "application/vnd.heroku+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hhe.lesson-player": {
        source: "iana",
        extensions: ["les"]
      },
      "application/vnd.hl7cda+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.hl7v2+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.hp-hpgl": {
        source: "iana",
        extensions: ["hpgl"]
      },
      "application/vnd.hp-hpid": {
        source: "iana",
        extensions: ["hpid"]
      },
      "application/vnd.hp-hps": {
        source: "iana",
        extensions: ["hps"]
      },
      "application/vnd.hp-jlyt": {
        source: "iana",
        extensions: ["jlt"]
      },
      "application/vnd.hp-pcl": {
        source: "iana",
        extensions: ["pcl"]
      },
      "application/vnd.hp-pclxl": {
        source: "iana",
        extensions: ["pclxl"]
      },
      "application/vnd.httphone": {
        source: "iana"
      },
      "application/vnd.hydrostatix.sof-data": {
        source: "iana",
        extensions: ["sfd-hdstx"]
      },
      "application/vnd.hyper+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hyper-item+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hyperdrive+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hzn-3d-crossword": {
        source: "iana"
      },
      "application/vnd.ibm.afplinedata": {
        source: "iana"
      },
      "application/vnd.ibm.electronic-media": {
        source: "iana"
      },
      "application/vnd.ibm.minipay": {
        source: "iana",
        extensions: ["mpy"]
      },
      "application/vnd.ibm.modcap": {
        source: "iana",
        extensions: ["afp", "listafp", "list3820"]
      },
      "application/vnd.ibm.rights-management": {
        source: "iana",
        extensions: ["irm"]
      },
      "application/vnd.ibm.secure-container": {
        source: "iana",
        extensions: ["sc"]
      },
      "application/vnd.iccprofile": {
        source: "iana",
        extensions: ["icc", "icm"]
      },
      "application/vnd.ieee.1905": {
        source: "iana"
      },
      "application/vnd.igloader": {
        source: "iana",
        extensions: ["igl"]
      },
      "application/vnd.imagemeter.folder+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.imagemeter.image+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.immervision-ivp": {
        source: "iana",
        extensions: ["ivp"]
      },
      "application/vnd.immervision-ivu": {
        source: "iana",
        extensions: ["ivu"]
      },
      "application/vnd.ims.imsccv1p1": {
        source: "iana"
      },
      "application/vnd.ims.imsccv1p2": {
        source: "iana"
      },
      "application/vnd.ims.imsccv1p3": {
        source: "iana"
      },
      "application/vnd.ims.lis.v2.result+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolconsumerprofile+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolproxy+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolproxy.id+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolsettings+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolsettings.simple+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.informedcontrol.rms+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.informix-visionary": {
        source: "iana"
      },
      "application/vnd.infotech.project": {
        source: "iana"
      },
      "application/vnd.infotech.project+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.innopath.wamp.notification": {
        source: "iana"
      },
      "application/vnd.insors.igm": {
        source: "iana",
        extensions: ["igm"]
      },
      "application/vnd.intercon.formnet": {
        source: "iana",
        extensions: ["xpw", "xpx"]
      },
      "application/vnd.intergeo": {
        source: "iana",
        extensions: ["i2g"]
      },
      "application/vnd.intertrust.digibox": {
        source: "iana"
      },
      "application/vnd.intertrust.nncp": {
        source: "iana"
      },
      "application/vnd.intu.qbo": {
        source: "iana",
        extensions: ["qbo"]
      },
      "application/vnd.intu.qfx": {
        source: "iana",
        extensions: ["qfx"]
      },
      "application/vnd.iptc.g2.catalogitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.conceptitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.knowledgeitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.newsitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.newsmessage+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.packageitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.planningitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ipunplugged.rcprofile": {
        source: "iana",
        extensions: ["rcprofile"]
      },
      "application/vnd.irepository.package+xml": {
        source: "iana",
        compressible: true,
        extensions: ["irp"]
      },
      "application/vnd.is-xpr": {
        source: "iana",
        extensions: ["xpr"]
      },
      "application/vnd.isac.fcs": {
        source: "iana",
        extensions: ["fcs"]
      },
      "application/vnd.iso11783-10+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.jam": {
        source: "iana",
        extensions: ["jam"]
      },
      "application/vnd.japannet-directory-service": {
        source: "iana"
      },
      "application/vnd.japannet-jpnstore-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-payment-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-registration": {
        source: "iana"
      },
      "application/vnd.japannet-registration-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-setstore-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-verification": {
        source: "iana"
      },
      "application/vnd.japannet-verification-wakeup": {
        source: "iana"
      },
      "application/vnd.jcp.javame.midlet-rms": {
        source: "iana",
        extensions: ["rms"]
      },
      "application/vnd.jisp": {
        source: "iana",
        extensions: ["jisp"]
      },
      "application/vnd.joost.joda-archive": {
        source: "iana",
        extensions: ["joda"]
      },
      "application/vnd.jsk.isdn-ngn": {
        source: "iana"
      },
      "application/vnd.kahootz": {
        source: "iana",
        extensions: ["ktz", "ktr"]
      },
      "application/vnd.kde.karbon": {
        source: "iana",
        extensions: ["karbon"]
      },
      "application/vnd.kde.kchart": {
        source: "iana",
        extensions: ["chrt"]
      },
      "application/vnd.kde.kformula": {
        source: "iana",
        extensions: ["kfo"]
      },
      "application/vnd.kde.kivio": {
        source: "iana",
        extensions: ["flw"]
      },
      "application/vnd.kde.kontour": {
        source: "iana",
        extensions: ["kon"]
      },
      "application/vnd.kde.kpresenter": {
        source: "iana",
        extensions: ["kpr", "kpt"]
      },
      "application/vnd.kde.kspread": {
        source: "iana",
        extensions: ["ksp"]
      },
      "application/vnd.kde.kword": {
        source: "iana",
        extensions: ["kwd", "kwt"]
      },
      "application/vnd.kenameaapp": {
        source: "iana",
        extensions: ["htke"]
      },
      "application/vnd.kidspiration": {
        source: "iana",
        extensions: ["kia"]
      },
      "application/vnd.kinar": {
        source: "iana",
        extensions: ["kne", "knp"]
      },
      "application/vnd.koan": {
        source: "iana",
        extensions: ["skp", "skd", "skt", "skm"]
      },
      "application/vnd.kodak-descriptor": {
        source: "iana",
        extensions: ["sse"]
      },
      "application/vnd.las": {
        source: "iana"
      },
      "application/vnd.las.las+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.las.las+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lasxml"]
      },
      "application/vnd.laszip": {
        source: "iana"
      },
      "application/vnd.leap+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.liberty-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.llamagraphics.life-balance.desktop": {
        source: "iana",
        extensions: ["lbd"]
      },
      "application/vnd.llamagraphics.life-balance.exchange+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lbe"]
      },
      "application/vnd.logipipe.circuit+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.loom": {
        source: "iana"
      },
      "application/vnd.lotus-1-2-3": {
        source: "iana",
        extensions: ["123"]
      },
      "application/vnd.lotus-approach": {
        source: "iana",
        extensions: ["apr"]
      },
      "application/vnd.lotus-freelance": {
        source: "iana",
        extensions: ["pre"]
      },
      "application/vnd.lotus-notes": {
        source: "iana",
        extensions: ["nsf"]
      },
      "application/vnd.lotus-organizer": {
        source: "iana",
        extensions: ["org"]
      },
      "application/vnd.lotus-screencam": {
        source: "iana",
        extensions: ["scm"]
      },
      "application/vnd.lotus-wordpro": {
        source: "iana",
        extensions: ["lwp"]
      },
      "application/vnd.macports.portpkg": {
        source: "iana",
        extensions: ["portpkg"]
      },
      "application/vnd.mapbox-vector-tile": {
        source: "iana",
        extensions: ["mvt"]
      },
      "application/vnd.marlin.drm.actiontoken+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.conftoken+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.license+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.mdcf": {
        source: "iana"
      },
      "application/vnd.mason+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.maxar.archive.3tz+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.maxmind.maxmind-db": {
        source: "iana"
      },
      "application/vnd.mcd": {
        source: "iana",
        extensions: ["mcd"]
      },
      "application/vnd.medcalcdata": {
        source: "iana",
        extensions: ["mc1"]
      },
      "application/vnd.mediastation.cdkey": {
        source: "iana",
        extensions: ["cdkey"]
      },
      "application/vnd.meridian-slingshot": {
        source: "iana"
      },
      "application/vnd.mfer": {
        source: "iana",
        extensions: ["mwf"]
      },
      "application/vnd.mfmp": {
        source: "iana",
        extensions: ["mfm"]
      },
      "application/vnd.micro+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.micrografx.flo": {
        source: "iana",
        extensions: ["flo"]
      },
      "application/vnd.micrografx.igx": {
        source: "iana",
        extensions: ["igx"]
      },
      "application/vnd.microsoft.portable-executable": {
        source: "iana"
      },
      "application/vnd.microsoft.windows.thumbnail-cache": {
        source: "iana"
      },
      "application/vnd.miele+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.mif": {
        source: "iana",
        extensions: ["mif"]
      },
      "application/vnd.minisoft-hp3000-save": {
        source: "iana"
      },
      "application/vnd.mitsubishi.misty-guard.trustweb": {
        source: "iana"
      },
      "application/vnd.mobius.daf": {
        source: "iana",
        extensions: ["daf"]
      },
      "application/vnd.mobius.dis": {
        source: "iana",
        extensions: ["dis"]
      },
      "application/vnd.mobius.mbk": {
        source: "iana",
        extensions: ["mbk"]
      },
      "application/vnd.mobius.mqy": {
        source: "iana",
        extensions: ["mqy"]
      },
      "application/vnd.mobius.msl": {
        source: "iana",
        extensions: ["msl"]
      },
      "application/vnd.mobius.plc": {
        source: "iana",
        extensions: ["plc"]
      },
      "application/vnd.mobius.txf": {
        source: "iana",
        extensions: ["txf"]
      },
      "application/vnd.mophun.application": {
        source: "iana",
        extensions: ["mpn"]
      },
      "application/vnd.mophun.certificate": {
        source: "iana",
        extensions: ["mpc"]
      },
      "application/vnd.motorola.flexsuite": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.adsi": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.fis": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.gotap": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.kmr": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.ttc": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.wem": {
        source: "iana"
      },
      "application/vnd.motorola.iprm": {
        source: "iana"
      },
      "application/vnd.mozilla.xul+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xul"]
      },
      "application/vnd.ms-3mfdocument": {
        source: "iana"
      },
      "application/vnd.ms-artgalry": {
        source: "iana",
        extensions: ["cil"]
      },
      "application/vnd.ms-asf": {
        source: "iana"
      },
      "application/vnd.ms-cab-compressed": {
        source: "iana",
        extensions: ["cab"]
      },
      "application/vnd.ms-color.iccprofile": {
        source: "apache"
      },
      "application/vnd.ms-excel": {
        source: "iana",
        compressible: false,
        extensions: ["xls", "xlm", "xla", "xlc", "xlt", "xlw"]
      },
      "application/vnd.ms-excel.addin.macroenabled.12": {
        source: "iana",
        extensions: ["xlam"]
      },
      "application/vnd.ms-excel.sheet.binary.macroenabled.12": {
        source: "iana",
        extensions: ["xlsb"]
      },
      "application/vnd.ms-excel.sheet.macroenabled.12": {
        source: "iana",
        extensions: ["xlsm"]
      },
      "application/vnd.ms-excel.template.macroenabled.12": {
        source: "iana",
        extensions: ["xltm"]
      },
      "application/vnd.ms-fontobject": {
        source: "iana",
        compressible: true,
        extensions: ["eot"]
      },
      "application/vnd.ms-htmlhelp": {
        source: "iana",
        extensions: ["chm"]
      },
      "application/vnd.ms-ims": {
        source: "iana",
        extensions: ["ims"]
      },
      "application/vnd.ms-lrm": {
        source: "iana",
        extensions: ["lrm"]
      },
      "application/vnd.ms-office.activex+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-officetheme": {
        source: "iana",
        extensions: ["thmx"]
      },
      "application/vnd.ms-opentype": {
        source: "apache",
        compressible: true
      },
      "application/vnd.ms-outlook": {
        compressible: false,
        extensions: ["msg"]
      },
      "application/vnd.ms-package.obfuscated-opentype": {
        source: "apache"
      },
      "application/vnd.ms-pki.seccat": {
        source: "apache",
        extensions: ["cat"]
      },
      "application/vnd.ms-pki.stl": {
        source: "apache",
        extensions: ["stl"]
      },
      "application/vnd.ms-playready.initiator+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-powerpoint": {
        source: "iana",
        compressible: false,
        extensions: ["ppt", "pps", "pot"]
      },
      "application/vnd.ms-powerpoint.addin.macroenabled.12": {
        source: "iana",
        extensions: ["ppam"]
      },
      "application/vnd.ms-powerpoint.presentation.macroenabled.12": {
        source: "iana",
        extensions: ["pptm"]
      },
      "application/vnd.ms-powerpoint.slide.macroenabled.12": {
        source: "iana",
        extensions: ["sldm"]
      },
      "application/vnd.ms-powerpoint.slideshow.macroenabled.12": {
        source: "iana",
        extensions: ["ppsm"]
      },
      "application/vnd.ms-powerpoint.template.macroenabled.12": {
        source: "iana",
        extensions: ["potm"]
      },
      "application/vnd.ms-printdevicecapabilities+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-printing.printticket+xml": {
        source: "apache",
        compressible: true
      },
      "application/vnd.ms-printschematicket+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-project": {
        source: "iana",
        extensions: ["mpp", "mpt"]
      },
      "application/vnd.ms-tnef": {
        source: "iana"
      },
      "application/vnd.ms-windows.devicepairing": {
        source: "iana"
      },
      "application/vnd.ms-windows.nwprinting.oob": {
        source: "iana"
      },
      "application/vnd.ms-windows.printerpairing": {
        source: "iana"
      },
      "application/vnd.ms-windows.wsd.oob": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.lic-chlg-req": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.lic-resp": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.meter-chlg-req": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.meter-resp": {
        source: "iana"
      },
      "application/vnd.ms-word.document.macroenabled.12": {
        source: "iana",
        extensions: ["docm"]
      },
      "application/vnd.ms-word.template.macroenabled.12": {
        source: "iana",
        extensions: ["dotm"]
      },
      "application/vnd.ms-works": {
        source: "iana",
        extensions: ["wps", "wks", "wcm", "wdb"]
      },
      "application/vnd.ms-wpl": {
        source: "iana",
        extensions: ["wpl"]
      },
      "application/vnd.ms-xpsdocument": {
        source: "iana",
        compressible: false,
        extensions: ["xps"]
      },
      "application/vnd.msa-disk-image": {
        source: "iana"
      },
      "application/vnd.mseq": {
        source: "iana",
        extensions: ["mseq"]
      },
      "application/vnd.msign": {
        source: "iana"
      },
      "application/vnd.multiad.creator": {
        source: "iana"
      },
      "application/vnd.multiad.creator.cif": {
        source: "iana"
      },
      "application/vnd.music-niff": {
        source: "iana"
      },
      "application/vnd.musician": {
        source: "iana",
        extensions: ["mus"]
      },
      "application/vnd.muvee.style": {
        source: "iana",
        extensions: ["msty"]
      },
      "application/vnd.mynfc": {
        source: "iana",
        extensions: ["taglet"]
      },
      "application/vnd.nacamar.ybrid+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ncd.control": {
        source: "iana"
      },
      "application/vnd.ncd.reference": {
        source: "iana"
      },
      "application/vnd.nearst.inv+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nebumind.line": {
        source: "iana"
      },
      "application/vnd.nervana": {
        source: "iana"
      },
      "application/vnd.netfpx": {
        source: "iana"
      },
      "application/vnd.neurolanguage.nlu": {
        source: "iana",
        extensions: ["nlu"]
      },
      "application/vnd.nimn": {
        source: "iana"
      },
      "application/vnd.nintendo.nitro.rom": {
        source: "iana"
      },
      "application/vnd.nintendo.snes.rom": {
        source: "iana"
      },
      "application/vnd.nitf": {
        source: "iana",
        extensions: ["ntf", "nitf"]
      },
      "application/vnd.noblenet-directory": {
        source: "iana",
        extensions: ["nnd"]
      },
      "application/vnd.noblenet-sealer": {
        source: "iana",
        extensions: ["nns"]
      },
      "application/vnd.noblenet-web": {
        source: "iana",
        extensions: ["nnw"]
      },
      "application/vnd.nokia.catalogs": {
        source: "iana"
      },
      "application/vnd.nokia.conml+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.conml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.iptv.config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.isds-radio-presets": {
        source: "iana"
      },
      "application/vnd.nokia.landmark+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.landmark+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.landmarkcollection+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.n-gage.ac+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ac"]
      },
      "application/vnd.nokia.n-gage.data": {
        source: "iana",
        extensions: ["ngdat"]
      },
      "application/vnd.nokia.n-gage.symbian.install": {
        source: "iana",
        extensions: ["n-gage"]
      },
      "application/vnd.nokia.ncd": {
        source: "iana"
      },
      "application/vnd.nokia.pcd+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.pcd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.radio-preset": {
        source: "iana",
        extensions: ["rpst"]
      },
      "application/vnd.nokia.radio-presets": {
        source: "iana",
        extensions: ["rpss"]
      },
      "application/vnd.novadigm.edm": {
        source: "iana",
        extensions: ["edm"]
      },
      "application/vnd.novadigm.edx": {
        source: "iana",
        extensions: ["edx"]
      },
      "application/vnd.novadigm.ext": {
        source: "iana",
        extensions: ["ext"]
      },
      "application/vnd.ntt-local.content-share": {
        source: "iana"
      },
      "application/vnd.ntt-local.file-transfer": {
        source: "iana"
      },
      "application/vnd.ntt-local.ogw_remote-access": {
        source: "iana"
      },
      "application/vnd.ntt-local.sip-ta_remote": {
        source: "iana"
      },
      "application/vnd.ntt-local.sip-ta_tcp_stream": {
        source: "iana"
      },
      "application/vnd.oasis.opendocument.chart": {
        source: "iana",
        extensions: ["odc"]
      },
      "application/vnd.oasis.opendocument.chart-template": {
        source: "iana",
        extensions: ["otc"]
      },
      "application/vnd.oasis.opendocument.database": {
        source: "iana",
        extensions: ["odb"]
      },
      "application/vnd.oasis.opendocument.formula": {
        source: "iana",
        extensions: ["odf"]
      },
      "application/vnd.oasis.opendocument.formula-template": {
        source: "iana",
        extensions: ["odft"]
      },
      "application/vnd.oasis.opendocument.graphics": {
        source: "iana",
        compressible: false,
        extensions: ["odg"]
      },
      "application/vnd.oasis.opendocument.graphics-template": {
        source: "iana",
        extensions: ["otg"]
      },
      "application/vnd.oasis.opendocument.image": {
        source: "iana",
        extensions: ["odi"]
      },
      "application/vnd.oasis.opendocument.image-template": {
        source: "iana",
        extensions: ["oti"]
      },
      "application/vnd.oasis.opendocument.presentation": {
        source: "iana",
        compressible: false,
        extensions: ["odp"]
      },
      "application/vnd.oasis.opendocument.presentation-template": {
        source: "iana",
        extensions: ["otp"]
      },
      "application/vnd.oasis.opendocument.spreadsheet": {
        source: "iana",
        compressible: false,
        extensions: ["ods"]
      },
      "application/vnd.oasis.opendocument.spreadsheet-template": {
        source: "iana",
        extensions: ["ots"]
      },
      "application/vnd.oasis.opendocument.text": {
        source: "iana",
        compressible: false,
        extensions: ["odt"]
      },
      "application/vnd.oasis.opendocument.text-master": {
        source: "iana",
        extensions: ["odm"]
      },
      "application/vnd.oasis.opendocument.text-template": {
        source: "iana",
        extensions: ["ott"]
      },
      "application/vnd.oasis.opendocument.text-web": {
        source: "iana",
        extensions: ["oth"]
      },
      "application/vnd.obn": {
        source: "iana"
      },
      "application/vnd.ocf+cbor": {
        source: "iana"
      },
      "application/vnd.oci.image.manifest.v1+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oftn.l10n+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.contentaccessdownload+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.contentaccessstreaming+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.cspg-hexbinary": {
        source: "iana"
      },
      "application/vnd.oipf.dae.svg+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.dae.xhtml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.mippvcontrolmessage+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.pae.gem": {
        source: "iana"
      },
      "application/vnd.oipf.spdiscovery+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.spdlist+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.ueprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.userprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.olpc-sugar": {
        source: "iana",
        extensions: ["xo"]
      },
      "application/vnd.oma-scws-config": {
        source: "iana"
      },
      "application/vnd.oma-scws-http-request": {
        source: "iana"
      },
      "application/vnd.oma-scws-http-response": {
        source: "iana"
      },
      "application/vnd.oma.bcast.associated-procedure-parameter+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.drm-trigger+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.imd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.ltkm": {
        source: "iana"
      },
      "application/vnd.oma.bcast.notification+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.provisioningtrigger": {
        source: "iana"
      },
      "application/vnd.oma.bcast.sgboot": {
        source: "iana"
      },
      "application/vnd.oma.bcast.sgdd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.sgdu": {
        source: "iana"
      },
      "application/vnd.oma.bcast.simple-symbol-container": {
        source: "iana"
      },
      "application/vnd.oma.bcast.smartcard-trigger+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.sprov+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.stkm": {
        source: "iana"
      },
      "application/vnd.oma.cab-address-book+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-feature-handler+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-pcc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-subs-invite+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-user-prefs+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.dcd": {
        source: "iana"
      },
      "application/vnd.oma.dcdc": {
        source: "iana"
      },
      "application/vnd.oma.dd2+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dd2"]
      },
      "application/vnd.oma.drm.risd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.group-usage-list+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.lwm2m+cbor": {
        source: "iana"
      },
      "application/vnd.oma.lwm2m+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.lwm2m+tlv": {
        source: "iana"
      },
      "application/vnd.oma.pal+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.detailed-progress-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.final-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.groups+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.invocation-descriptor+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.optimized-progress-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.push": {
        source: "iana"
      },
      "application/vnd.oma.scidm.messages+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.xcap-directory+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.omads-email+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omads-file+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omads-folder+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omaloc-supl-init": {
        source: "iana"
      },
      "application/vnd.onepager": {
        source: "iana"
      },
      "application/vnd.onepagertamp": {
        source: "iana"
      },
      "application/vnd.onepagertamx": {
        source: "iana"
      },
      "application/vnd.onepagertat": {
        source: "iana"
      },
      "application/vnd.onepagertatp": {
        source: "iana"
      },
      "application/vnd.onepagertatx": {
        source: "iana"
      },
      "application/vnd.openblox.game+xml": {
        source: "iana",
        compressible: true,
        extensions: ["obgx"]
      },
      "application/vnd.openblox.game-binary": {
        source: "iana"
      },
      "application/vnd.openeye.oeb": {
        source: "iana"
      },
      "application/vnd.openofficeorg.extension": {
        source: "apache",
        extensions: ["oxt"]
      },
      "application/vnd.openstreetmap.data+xml": {
        source: "iana",
        compressible: true,
        extensions: ["osm"]
      },
      "application/vnd.opentimestamps.ots": {
        source: "iana"
      },
      "application/vnd.openxmlformats-officedocument.custom-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.customxmlproperties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawing+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramcolors+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramdata+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramlayout+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramstyle+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.extended-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.commentauthors+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.handoutmaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.notesmaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.notesslide+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": {
        source: "iana",
        compressible: false,
        extensions: ["pptx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presprops+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slide": {
        source: "iana",
        extensions: ["sldx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slide+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slidelayout+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slidemaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideshow": {
        source: "iana",
        extensions: ["ppsx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideupdateinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.tablestyles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.tags+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.template": {
        source: "iana",
        extensions: ["potx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.viewprops+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.calcchain+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.externallink+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcachedefinition+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcacherecords+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivottable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.querytable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionheaders+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionlog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedstrings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
        source: "iana",
        compressible: false,
        extensions: ["xlsx"]
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetmetadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.tablesinglecells+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.template": {
        source: "iana",
        extensions: ["xltx"]
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.usernames+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.volatiledependencies+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.theme+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.themeoverride+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.vmldrawing": {
        source: "iana"
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
        source: "iana",
        compressible: false,
        extensions: ["docx"]
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document.glossary+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.fonttable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.template": {
        source: "iana",
        extensions: ["dotx"]
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.websettings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.core-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.digital-signature-xmlsignature+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.relationships+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oracle.resource+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.orange.indata": {
        source: "iana"
      },
      "application/vnd.osa.netdeploy": {
        source: "iana"
      },
      "application/vnd.osgeo.mapguide.package": {
        source: "iana",
        extensions: ["mgp"]
      },
      "application/vnd.osgi.bundle": {
        source: "iana"
      },
      "application/vnd.osgi.dp": {
        source: "iana",
        extensions: ["dp"]
      },
      "application/vnd.osgi.subsystem": {
        source: "iana",
        extensions: ["esa"]
      },
      "application/vnd.otps.ct-kip+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oxli.countgraph": {
        source: "iana"
      },
      "application/vnd.pagerduty+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.palm": {
        source: "iana",
        extensions: ["pdb", "pqa", "oprc"]
      },
      "application/vnd.panoply": {
        source: "iana"
      },
      "application/vnd.paos.xml": {
        source: "iana"
      },
      "application/vnd.patentdive": {
        source: "iana"
      },
      "application/vnd.patientecommsdoc": {
        source: "iana"
      },
      "application/vnd.pawaafile": {
        source: "iana",
        extensions: ["paw"]
      },
      "application/vnd.pcos": {
        source: "iana"
      },
      "application/vnd.pg.format": {
        source: "iana",
        extensions: ["str"]
      },
      "application/vnd.pg.osasli": {
        source: "iana",
        extensions: ["ei6"]
      },
      "application/vnd.piaccess.application-licence": {
        source: "iana"
      },
      "application/vnd.picsel": {
        source: "iana",
        extensions: ["efif"]
      },
      "application/vnd.pmi.widget": {
        source: "iana",
        extensions: ["wg"]
      },
      "application/vnd.poc.group-advertisement+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.pocketlearn": {
        source: "iana",
        extensions: ["plf"]
      },
      "application/vnd.powerbuilder6": {
        source: "iana",
        extensions: ["pbd"]
      },
      "application/vnd.powerbuilder6-s": {
        source: "iana"
      },
      "application/vnd.powerbuilder7": {
        source: "iana"
      },
      "application/vnd.powerbuilder7-s": {
        source: "iana"
      },
      "application/vnd.powerbuilder75": {
        source: "iana"
      },
      "application/vnd.powerbuilder75-s": {
        source: "iana"
      },
      "application/vnd.preminet": {
        source: "iana"
      },
      "application/vnd.previewsystems.box": {
        source: "iana",
        extensions: ["box"]
      },
      "application/vnd.proteus.magazine": {
        source: "iana",
        extensions: ["mgz"]
      },
      "application/vnd.psfs": {
        source: "iana"
      },
      "application/vnd.publishare-delta-tree": {
        source: "iana",
        extensions: ["qps"]
      },
      "application/vnd.pvi.ptid1": {
        source: "iana",
        extensions: ["ptid"]
      },
      "application/vnd.pwg-multiplexed": {
        source: "iana"
      },
      "application/vnd.pwg-xhtml-print+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.qualcomm.brew-app-res": {
        source: "iana"
      },
      "application/vnd.quarantainenet": {
        source: "iana"
      },
      "application/vnd.quark.quarkxpress": {
        source: "iana",
        extensions: ["qxd", "qxt", "qwd", "qwt", "qxl", "qxb"]
      },
      "application/vnd.quobject-quoxdocument": {
        source: "iana"
      },
      "application/vnd.radisys.moml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-conf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-conn+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-dialog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-stream+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-conf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-base+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-fax-detect+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-fax-sendrecv+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-group+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-speech+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-transform+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.rainstor.data": {
        source: "iana"
      },
      "application/vnd.rapid": {
        source: "iana"
      },
      "application/vnd.rar": {
        source: "iana",
        extensions: ["rar"]
      },
      "application/vnd.realvnc.bed": {
        source: "iana",
        extensions: ["bed"]
      },
      "application/vnd.recordare.musicxml": {
        source: "iana",
        extensions: ["mxl"]
      },
      "application/vnd.recordare.musicxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["musicxml"]
      },
      "application/vnd.renlearn.rlprint": {
        source: "iana"
      },
      "application/vnd.resilient.logic": {
        source: "iana"
      },
      "application/vnd.restful+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.rig.cryptonote": {
        source: "iana",
        extensions: ["cryptonote"]
      },
      "application/vnd.rim.cod": {
        source: "apache",
        extensions: ["cod"]
      },
      "application/vnd.rn-realmedia": {
        source: "apache",
        extensions: ["rm"]
      },
      "application/vnd.rn-realmedia-vbr": {
        source: "apache",
        extensions: ["rmvb"]
      },
      "application/vnd.route66.link66+xml": {
        source: "iana",
        compressible: true,
        extensions: ["link66"]
      },
      "application/vnd.rs-274x": {
        source: "iana"
      },
      "application/vnd.ruckus.download": {
        source: "iana"
      },
      "application/vnd.s3sms": {
        source: "iana"
      },
      "application/vnd.sailingtracker.track": {
        source: "iana",
        extensions: ["st"]
      },
      "application/vnd.sar": {
        source: "iana"
      },
      "application/vnd.sbm.cid": {
        source: "iana"
      },
      "application/vnd.sbm.mid2": {
        source: "iana"
      },
      "application/vnd.scribus": {
        source: "iana"
      },
      "application/vnd.sealed.3df": {
        source: "iana"
      },
      "application/vnd.sealed.csf": {
        source: "iana"
      },
      "application/vnd.sealed.doc": {
        source: "iana"
      },
      "application/vnd.sealed.eml": {
        source: "iana"
      },
      "application/vnd.sealed.mht": {
        source: "iana"
      },
      "application/vnd.sealed.net": {
        source: "iana"
      },
      "application/vnd.sealed.ppt": {
        source: "iana"
      },
      "application/vnd.sealed.tiff": {
        source: "iana"
      },
      "application/vnd.sealed.xls": {
        source: "iana"
      },
      "application/vnd.sealedmedia.softseal.html": {
        source: "iana"
      },
      "application/vnd.sealedmedia.softseal.pdf": {
        source: "iana"
      },
      "application/vnd.seemail": {
        source: "iana",
        extensions: ["see"]
      },
      "application/vnd.seis+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.sema": {
        source: "iana",
        extensions: ["sema"]
      },
      "application/vnd.semd": {
        source: "iana",
        extensions: ["semd"]
      },
      "application/vnd.semf": {
        source: "iana",
        extensions: ["semf"]
      },
      "application/vnd.shade-save-file": {
        source: "iana"
      },
      "application/vnd.shana.informed.formdata": {
        source: "iana",
        extensions: ["ifm"]
      },
      "application/vnd.shana.informed.formtemplate": {
        source: "iana",
        extensions: ["itp"]
      },
      "application/vnd.shana.informed.interchange": {
        source: "iana",
        extensions: ["iif"]
      },
      "application/vnd.shana.informed.package": {
        source: "iana",
        extensions: ["ipk"]
      },
      "application/vnd.shootproof+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.shopkick+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.shp": {
        source: "iana"
      },
      "application/vnd.shx": {
        source: "iana"
      },
      "application/vnd.sigrok.session": {
        source: "iana"
      },
      "application/vnd.simtech-mindmapper": {
        source: "iana",
        extensions: ["twd", "twds"]
      },
      "application/vnd.siren+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.smaf": {
        source: "iana",
        extensions: ["mmf"]
      },
      "application/vnd.smart.notebook": {
        source: "iana"
      },
      "application/vnd.smart.teacher": {
        source: "iana",
        extensions: ["teacher"]
      },
      "application/vnd.snesdev-page-table": {
        source: "iana"
      },
      "application/vnd.software602.filler.form+xml": {
        source: "iana",
        compressible: true,
        extensions: ["fo"]
      },
      "application/vnd.software602.filler.form-xml-zip": {
        source: "iana"
      },
      "application/vnd.solent.sdkm+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sdkm", "sdkd"]
      },
      "application/vnd.spotfire.dxp": {
        source: "iana",
        extensions: ["dxp"]
      },
      "application/vnd.spotfire.sfs": {
        source: "iana",
        extensions: ["sfs"]
      },
      "application/vnd.sqlite3": {
        source: "iana"
      },
      "application/vnd.sss-cod": {
        source: "iana"
      },
      "application/vnd.sss-dtf": {
        source: "iana"
      },
      "application/vnd.sss-ntf": {
        source: "iana"
      },
      "application/vnd.stardivision.calc": {
        source: "apache",
        extensions: ["sdc"]
      },
      "application/vnd.stardivision.draw": {
        source: "apache",
        extensions: ["sda"]
      },
      "application/vnd.stardivision.impress": {
        source: "apache",
        extensions: ["sdd"]
      },
      "application/vnd.stardivision.math": {
        source: "apache",
        extensions: ["smf"]
      },
      "application/vnd.stardivision.writer": {
        source: "apache",
        extensions: ["sdw", "vor"]
      },
      "application/vnd.stardivision.writer-global": {
        source: "apache",
        extensions: ["sgl"]
      },
      "application/vnd.stepmania.package": {
        source: "iana",
        extensions: ["smzip"]
      },
      "application/vnd.stepmania.stepchart": {
        source: "iana",
        extensions: ["sm"]
      },
      "application/vnd.street-stream": {
        source: "iana"
      },
      "application/vnd.sun.wadl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wadl"]
      },
      "application/vnd.sun.xml.calc": {
        source: "apache",
        extensions: ["sxc"]
      },
      "application/vnd.sun.xml.calc.template": {
        source: "apache",
        extensions: ["stc"]
      },
      "application/vnd.sun.xml.draw": {
        source: "apache",
        extensions: ["sxd"]
      },
      "application/vnd.sun.xml.draw.template": {
        source: "apache",
        extensions: ["std"]
      },
      "application/vnd.sun.xml.impress": {
        source: "apache",
        extensions: ["sxi"]
      },
      "application/vnd.sun.xml.impress.template": {
        source: "apache",
        extensions: ["sti"]
      },
      "application/vnd.sun.xml.math": {
        source: "apache",
        extensions: ["sxm"]
      },
      "application/vnd.sun.xml.writer": {
        source: "apache",
        extensions: ["sxw"]
      },
      "application/vnd.sun.xml.writer.global": {
        source: "apache",
        extensions: ["sxg"]
      },
      "application/vnd.sun.xml.writer.template": {
        source: "apache",
        extensions: ["stw"]
      },
      "application/vnd.sus-calendar": {
        source: "iana",
        extensions: ["sus", "susp"]
      },
      "application/vnd.svd": {
        source: "iana",
        extensions: ["svd"]
      },
      "application/vnd.swiftview-ics": {
        source: "iana"
      },
      "application/vnd.sycle+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.syft+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.symbian.install": {
        source: "apache",
        extensions: ["sis", "sisx"]
      },
      "application/vnd.syncml+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["xsm"]
      },
      "application/vnd.syncml.dm+wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["bdm"]
      },
      "application/vnd.syncml.dm+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["xdm"]
      },
      "application/vnd.syncml.dm.notification": {
        source: "iana"
      },
      "application/vnd.syncml.dmddf+wbxml": {
        source: "iana"
      },
      "application/vnd.syncml.dmddf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["ddf"]
      },
      "application/vnd.syncml.dmtnds+wbxml": {
        source: "iana"
      },
      "application/vnd.syncml.dmtnds+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.syncml.ds.notification": {
        source: "iana"
      },
      "application/vnd.tableschema+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tao.intent-module-archive": {
        source: "iana",
        extensions: ["tao"]
      },
      "application/vnd.tcpdump.pcap": {
        source: "iana",
        extensions: ["pcap", "cap", "dmp"]
      },
      "application/vnd.think-cell.ppttc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tmd.mediaflex.api+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tml": {
        source: "iana"
      },
      "application/vnd.tmobile-livetv": {
        source: "iana",
        extensions: ["tmo"]
      },
      "application/vnd.tri.onesource": {
        source: "iana"
      },
      "application/vnd.trid.tpt": {
        source: "iana",
        extensions: ["tpt"]
      },
      "application/vnd.triscape.mxs": {
        source: "iana",
        extensions: ["mxs"]
      },
      "application/vnd.trueapp": {
        source: "iana",
        extensions: ["tra"]
      },
      "application/vnd.truedoc": {
        source: "iana"
      },
      "application/vnd.ubisoft.webplayer": {
        source: "iana"
      },
      "application/vnd.ufdl": {
        source: "iana",
        extensions: ["ufd", "ufdl"]
      },
      "application/vnd.uiq.theme": {
        source: "iana",
        extensions: ["utz"]
      },
      "application/vnd.umajin": {
        source: "iana",
        extensions: ["umj"]
      },
      "application/vnd.unity": {
        source: "iana",
        extensions: ["unityweb"]
      },
      "application/vnd.uoml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["uoml"]
      },
      "application/vnd.uplanet.alert": {
        source: "iana"
      },
      "application/vnd.uplanet.alert-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.bearer-choice": {
        source: "iana"
      },
      "application/vnd.uplanet.bearer-choice-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.cacheop": {
        source: "iana"
      },
      "application/vnd.uplanet.cacheop-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.channel": {
        source: "iana"
      },
      "application/vnd.uplanet.channel-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.list": {
        source: "iana"
      },
      "application/vnd.uplanet.list-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.listcmd": {
        source: "iana"
      },
      "application/vnd.uplanet.listcmd-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.signal": {
        source: "iana"
      },
      "application/vnd.uri-map": {
        source: "iana"
      },
      "application/vnd.valve.source.material": {
        source: "iana"
      },
      "application/vnd.vcx": {
        source: "iana",
        extensions: ["vcx"]
      },
      "application/vnd.vd-study": {
        source: "iana"
      },
      "application/vnd.vectorworks": {
        source: "iana"
      },
      "application/vnd.vel+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.verimatrix.vcas": {
        source: "iana"
      },
      "application/vnd.veritone.aion+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.veryant.thin": {
        source: "iana"
      },
      "application/vnd.ves.encrypted": {
        source: "iana"
      },
      "application/vnd.vidsoft.vidconference": {
        source: "iana"
      },
      "application/vnd.visio": {
        source: "iana",
        extensions: ["vsd", "vst", "vss", "vsw"]
      },
      "application/vnd.visionary": {
        source: "iana",
        extensions: ["vis"]
      },
      "application/vnd.vividence.scriptfile": {
        source: "iana"
      },
      "application/vnd.vsf": {
        source: "iana",
        extensions: ["vsf"]
      },
      "application/vnd.wap.sic": {
        source: "iana"
      },
      "application/vnd.wap.slc": {
        source: "iana"
      },
      "application/vnd.wap.wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["wbxml"]
      },
      "application/vnd.wap.wmlc": {
        source: "iana",
        extensions: ["wmlc"]
      },
      "application/vnd.wap.wmlscriptc": {
        source: "iana",
        extensions: ["wmlsc"]
      },
      "application/vnd.webturbo": {
        source: "iana",
        extensions: ["wtb"]
      },
      "application/vnd.wfa.dpp": {
        source: "iana"
      },
      "application/vnd.wfa.p2p": {
        source: "iana"
      },
      "application/vnd.wfa.wsc": {
        source: "iana"
      },
      "application/vnd.windows.devicepairing": {
        source: "iana"
      },
      "application/vnd.wmc": {
        source: "iana"
      },
      "application/vnd.wmf.bootstrap": {
        source: "iana"
      },
      "application/vnd.wolfram.mathematica": {
        source: "iana"
      },
      "application/vnd.wolfram.mathematica.package": {
        source: "iana"
      },
      "application/vnd.wolfram.player": {
        source: "iana",
        extensions: ["nbp"]
      },
      "application/vnd.wordperfect": {
        source: "iana",
        extensions: ["wpd"]
      },
      "application/vnd.wqd": {
        source: "iana",
        extensions: ["wqd"]
      },
      "application/vnd.wrq-hp3000-labelled": {
        source: "iana"
      },
      "application/vnd.wt.stf": {
        source: "iana",
        extensions: ["stf"]
      },
      "application/vnd.wv.csp+wbxml": {
        source: "iana"
      },
      "application/vnd.wv.csp+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.wv.ssp+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xacml+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xara": {
        source: "iana",
        extensions: ["xar"]
      },
      "application/vnd.xfdl": {
        source: "iana",
        extensions: ["xfdl"]
      },
      "application/vnd.xfdl.webform": {
        source: "iana"
      },
      "application/vnd.xmi+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xmpie.cpkg": {
        source: "iana"
      },
      "application/vnd.xmpie.dpkg": {
        source: "iana"
      },
      "application/vnd.xmpie.plan": {
        source: "iana"
      },
      "application/vnd.xmpie.ppkg": {
        source: "iana"
      },
      "application/vnd.xmpie.xlim": {
        source: "iana"
      },
      "application/vnd.yamaha.hv-dic": {
        source: "iana",
        extensions: ["hvd"]
      },
      "application/vnd.yamaha.hv-script": {
        source: "iana",
        extensions: ["hvs"]
      },
      "application/vnd.yamaha.hv-voice": {
        source: "iana",
        extensions: ["hvp"]
      },
      "application/vnd.yamaha.openscoreformat": {
        source: "iana",
        extensions: ["osf"]
      },
      "application/vnd.yamaha.openscoreformat.osfpvg+xml": {
        source: "iana",
        compressible: true,
        extensions: ["osfpvg"]
      },
      "application/vnd.yamaha.remote-setup": {
        source: "iana"
      },
      "application/vnd.yamaha.smaf-audio": {
        source: "iana",
        extensions: ["saf"]
      },
      "application/vnd.yamaha.smaf-phrase": {
        source: "iana",
        extensions: ["spf"]
      },
      "application/vnd.yamaha.through-ngn": {
        source: "iana"
      },
      "application/vnd.yamaha.tunnel-udpencap": {
        source: "iana"
      },
      "application/vnd.yaoweme": {
        source: "iana"
      },
      "application/vnd.yellowriver-custom-menu": {
        source: "iana",
        extensions: ["cmp"]
      },
      "application/vnd.youtube.yt": {
        source: "iana"
      },
      "application/vnd.zul": {
        source: "iana",
        extensions: ["zir", "zirz"]
      },
      "application/vnd.zzazz.deck+xml": {
        source: "iana",
        compressible: true,
        extensions: ["zaz"]
      },
      "application/voicexml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["vxml"]
      },
      "application/voucher-cms+json": {
        source: "iana",
        compressible: true
      },
      "application/vq-rtcpxr": {
        source: "iana"
      },
      "application/wasm": {
        source: "iana",
        compressible: true,
        extensions: ["wasm"]
      },
      "application/watcherinfo+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wif"]
      },
      "application/webpush-options+json": {
        source: "iana",
        compressible: true
      },
      "application/whoispp-query": {
        source: "iana"
      },
      "application/whoispp-response": {
        source: "iana"
      },
      "application/widget": {
        source: "iana",
        extensions: ["wgt"]
      },
      "application/winhlp": {
        source: "apache",
        extensions: ["hlp"]
      },
      "application/wita": {
        source: "iana"
      },
      "application/wordperfect5.1": {
        source: "iana"
      },
      "application/wsdl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wsdl"]
      },
      "application/wspolicy+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wspolicy"]
      },
      "application/x-7z-compressed": {
        source: "apache",
        compressible: false,
        extensions: ["7z"]
      },
      "application/x-abiword": {
        source: "apache",
        extensions: ["abw"]
      },
      "application/x-ace-compressed": {
        source: "apache",
        extensions: ["ace"]
      },
      "application/x-amf": {
        source: "apache"
      },
      "application/x-apple-diskimage": {
        source: "apache",
        extensions: ["dmg"]
      },
      "application/x-arj": {
        compressible: false,
        extensions: ["arj"]
      },
      "application/x-authorware-bin": {
        source: "apache",
        extensions: ["aab", "x32", "u32", "vox"]
      },
      "application/x-authorware-map": {
        source: "apache",
        extensions: ["aam"]
      },
      "application/x-authorware-seg": {
        source: "apache",
        extensions: ["aas"]
      },
      "application/x-bcpio": {
        source: "apache",
        extensions: ["bcpio"]
      },
      "application/x-bdoc": {
        compressible: false,
        extensions: ["bdoc"]
      },
      "application/x-bittorrent": {
        source: "apache",
        extensions: ["torrent"]
      },
      "application/x-blorb": {
        source: "apache",
        extensions: ["blb", "blorb"]
      },
      "application/x-bzip": {
        source: "apache",
        compressible: false,
        extensions: ["bz"]
      },
      "application/x-bzip2": {
        source: "apache",
        compressible: false,
        extensions: ["bz2", "boz"]
      },
      "application/x-cbr": {
        source: "apache",
        extensions: ["cbr", "cba", "cbt", "cbz", "cb7"]
      },
      "application/x-cdlink": {
        source: "apache",
        extensions: ["vcd"]
      },
      "application/x-cfs-compressed": {
        source: "apache",
        extensions: ["cfs"]
      },
      "application/x-chat": {
        source: "apache",
        extensions: ["chat"]
      },
      "application/x-chess-pgn": {
        source: "apache",
        extensions: ["pgn"]
      },
      "application/x-chrome-extension": {
        extensions: ["crx"]
      },
      "application/x-cocoa": {
        source: "nginx",
        extensions: ["cco"]
      },
      "application/x-compress": {
        source: "apache"
      },
      "application/x-conference": {
        source: "apache",
        extensions: ["nsc"]
      },
      "application/x-cpio": {
        source: "apache",
        extensions: ["cpio"]
      },
      "application/x-csh": {
        source: "apache",
        extensions: ["csh"]
      },
      "application/x-deb": {
        compressible: false
      },
      "application/x-debian-package": {
        source: "apache",
        extensions: ["deb", "udeb"]
      },
      "application/x-dgc-compressed": {
        source: "apache",
        extensions: ["dgc"]
      },
      "application/x-director": {
        source: "apache",
        extensions: ["dir", "dcr", "dxr", "cst", "cct", "cxt", "w3d", "fgd", "swa"]
      },
      "application/x-doom": {
        source: "apache",
        extensions: ["wad"]
      },
      "application/x-dtbncx+xml": {
        source: "apache",
        compressible: true,
        extensions: ["ncx"]
      },
      "application/x-dtbook+xml": {
        source: "apache",
        compressible: true,
        extensions: ["dtb"]
      },
      "application/x-dtbresource+xml": {
        source: "apache",
        compressible: true,
        extensions: ["res"]
      },
      "application/x-dvi": {
        source: "apache",
        compressible: false,
        extensions: ["dvi"]
      },
      "application/x-envoy": {
        source: "apache",
        extensions: ["evy"]
      },
      "application/x-eva": {
        source: "apache",
        extensions: ["eva"]
      },
      "application/x-font-bdf": {
        source: "apache",
        extensions: ["bdf"]
      },
      "application/x-font-dos": {
        source: "apache"
      },
      "application/x-font-framemaker": {
        source: "apache"
      },
      "application/x-font-ghostscript": {
        source: "apache",
        extensions: ["gsf"]
      },
      "application/x-font-libgrx": {
        source: "apache"
      },
      "application/x-font-linux-psf": {
        source: "apache",
        extensions: ["psf"]
      },
      "application/x-font-pcf": {
        source: "apache",
        extensions: ["pcf"]
      },
      "application/x-font-snf": {
        source: "apache",
        extensions: ["snf"]
      },
      "application/x-font-speedo": {
        source: "apache"
      },
      "application/x-font-sunos-news": {
        source: "apache"
      },
      "application/x-font-type1": {
        source: "apache",
        extensions: ["pfa", "pfb", "pfm", "afm"]
      },
      "application/x-font-vfont": {
        source: "apache"
      },
      "application/x-freearc": {
        source: "apache",
        extensions: ["arc"]
      },
      "application/x-futuresplash": {
        source: "apache",
        extensions: ["spl"]
      },
      "application/x-gca-compressed": {
        source: "apache",
        extensions: ["gca"]
      },
      "application/x-glulx": {
        source: "apache",
        extensions: ["ulx"]
      },
      "application/x-gnumeric": {
        source: "apache",
        extensions: ["gnumeric"]
      },
      "application/x-gramps-xml": {
        source: "apache",
        extensions: ["gramps"]
      },
      "application/x-gtar": {
        source: "apache",
        extensions: ["gtar"]
      },
      "application/x-gzip": {
        source: "apache"
      },
      "application/x-hdf": {
        source: "apache",
        extensions: ["hdf"]
      },
      "application/x-httpd-php": {
        compressible: true,
        extensions: ["php"]
      },
      "application/x-install-instructions": {
        source: "apache",
        extensions: ["install"]
      },
      "application/x-iso9660-image": {
        source: "apache",
        extensions: ["iso"]
      },
      "application/x-iwork-keynote-sffkey": {
        extensions: ["key"]
      },
      "application/x-iwork-numbers-sffnumbers": {
        extensions: ["numbers"]
      },
      "application/x-iwork-pages-sffpages": {
        extensions: ["pages"]
      },
      "application/x-java-archive-diff": {
        source: "nginx",
        extensions: ["jardiff"]
      },
      "application/x-java-jnlp-file": {
        source: "apache",
        compressible: false,
        extensions: ["jnlp"]
      },
      "application/x-javascript": {
        compressible: true
      },
      "application/x-keepass2": {
        extensions: ["kdbx"]
      },
      "application/x-latex": {
        source: "apache",
        compressible: false,
        extensions: ["latex"]
      },
      "application/x-lua-bytecode": {
        extensions: ["luac"]
      },
      "application/x-lzh-compressed": {
        source: "apache",
        extensions: ["lzh", "lha"]
      },
      "application/x-makeself": {
        source: "nginx",
        extensions: ["run"]
      },
      "application/x-mie": {
        source: "apache",
        extensions: ["mie"]
      },
      "application/x-mobipocket-ebook": {
        source: "apache",
        extensions: ["prc", "mobi"]
      },
      "application/x-mpegurl": {
        compressible: false
      },
      "application/x-ms-application": {
        source: "apache",
        extensions: ["application"]
      },
      "application/x-ms-shortcut": {
        source: "apache",
        extensions: ["lnk"]
      },
      "application/x-ms-wmd": {
        source: "apache",
        extensions: ["wmd"]
      },
      "application/x-ms-wmz": {
        source: "apache",
        extensions: ["wmz"]
      },
      "application/x-ms-xbap": {
        source: "apache",
        extensions: ["xbap"]
      },
      "application/x-msaccess": {
        source: "apache",
        extensions: ["mdb"]
      },
      "application/x-msbinder": {
        source: "apache",
        extensions: ["obd"]
      },
      "application/x-mscardfile": {
        source: "apache",
        extensions: ["crd"]
      },
      "application/x-msclip": {
        source: "apache",
        extensions: ["clp"]
      },
      "application/x-msdos-program": {
        extensions: ["exe"]
      },
      "application/x-msdownload": {
        source: "apache",
        extensions: ["exe", "dll", "com", "bat", "msi"]
      },
      "application/x-msmediaview": {
        source: "apache",
        extensions: ["mvb", "m13", "m14"]
      },
      "application/x-msmetafile": {
        source: "apache",
        extensions: ["wmf", "wmz", "emf", "emz"]
      },
      "application/x-msmoney": {
        source: "apache",
        extensions: ["mny"]
      },
      "application/x-mspublisher": {
        source: "apache",
        extensions: ["pub"]
      },
      "application/x-msschedule": {
        source: "apache",
        extensions: ["scd"]
      },
      "application/x-msterminal": {
        source: "apache",
        extensions: ["trm"]
      },
      "application/x-mswrite": {
        source: "apache",
        extensions: ["wri"]
      },
      "application/x-netcdf": {
        source: "apache",
        extensions: ["nc", "cdf"]
      },
      "application/x-ns-proxy-autoconfig": {
        compressible: true,
        extensions: ["pac"]
      },
      "application/x-nzb": {
        source: "apache",
        extensions: ["nzb"]
      },
      "application/x-perl": {
        source: "nginx",
        extensions: ["pl", "pm"]
      },
      "application/x-pilot": {
        source: "nginx",
        extensions: ["prc", "pdb"]
      },
      "application/x-pkcs12": {
        source: "apache",
        compressible: false,
        extensions: ["p12", "pfx"]
      },
      "application/x-pkcs7-certificates": {
        source: "apache",
        extensions: ["p7b", "spc"]
      },
      "application/x-pkcs7-certreqresp": {
        source: "apache",
        extensions: ["p7r"]
      },
      "application/x-pki-message": {
        source: "iana"
      },
      "application/x-rar-compressed": {
        source: "apache",
        compressible: false,
        extensions: ["rar"]
      },
      "application/x-redhat-package-manager": {
        source: "nginx",
        extensions: ["rpm"]
      },
      "application/x-research-info-systems": {
        source: "apache",
        extensions: ["ris"]
      },
      "application/x-sea": {
        source: "nginx",
        extensions: ["sea"]
      },
      "application/x-sh": {
        source: "apache",
        compressible: true,
        extensions: ["sh"]
      },
      "application/x-shar": {
        source: "apache",
        extensions: ["shar"]
      },
      "application/x-shockwave-flash": {
        source: "apache",
        compressible: false,
        extensions: ["swf"]
      },
      "application/x-silverlight-app": {
        source: "apache",
        extensions: ["xap"]
      },
      "application/x-sql": {
        source: "apache",
        extensions: ["sql"]
      },
      "application/x-stuffit": {
        source: "apache",
        compressible: false,
        extensions: ["sit"]
      },
      "application/x-stuffitx": {
        source: "apache",
        extensions: ["sitx"]
      },
      "application/x-subrip": {
        source: "apache",
        extensions: ["srt"]
      },
      "application/x-sv4cpio": {
        source: "apache",
        extensions: ["sv4cpio"]
      },
      "application/x-sv4crc": {
        source: "apache",
        extensions: ["sv4crc"]
      },
      "application/x-t3vm-image": {
        source: "apache",
        extensions: ["t3"]
      },
      "application/x-tads": {
        source: "apache",
        extensions: ["gam"]
      },
      "application/x-tar": {
        source: "apache",
        compressible: true,
        extensions: ["tar"]
      },
      "application/x-tcl": {
        source: "apache",
        extensions: ["tcl", "tk"]
      },
      "application/x-tex": {
        source: "apache",
        extensions: ["tex"]
      },
      "application/x-tex-tfm": {
        source: "apache",
        extensions: ["tfm"]
      },
      "application/x-texinfo": {
        source: "apache",
        extensions: ["texinfo", "texi"]
      },
      "application/x-tgif": {
        source: "apache",
        extensions: ["obj"]
      },
      "application/x-ustar": {
        source: "apache",
        extensions: ["ustar"]
      },
      "application/x-virtualbox-hdd": {
        compressible: true,
        extensions: ["hdd"]
      },
      "application/x-virtualbox-ova": {
        compressible: true,
        extensions: ["ova"]
      },
      "application/x-virtualbox-ovf": {
        compressible: true,
        extensions: ["ovf"]
      },
      "application/x-virtualbox-vbox": {
        compressible: true,
        extensions: ["vbox"]
      },
      "application/x-virtualbox-vbox-extpack": {
        compressible: false,
        extensions: ["vbox-extpack"]
      },
      "application/x-virtualbox-vdi": {
        compressible: true,
        extensions: ["vdi"]
      },
      "application/x-virtualbox-vhd": {
        compressible: true,
        extensions: ["vhd"]
      },
      "application/x-virtualbox-vmdk": {
        compressible: true,
        extensions: ["vmdk"]
      },
      "application/x-wais-source": {
        source: "apache",
        extensions: ["src"]
      },
      "application/x-web-app-manifest+json": {
        compressible: true,
        extensions: ["webapp"]
      },
      "application/x-www-form-urlencoded": {
        source: "iana",
        compressible: true
      },
      "application/x-x509-ca-cert": {
        source: "iana",
        extensions: ["der", "crt", "pem"]
      },
      "application/x-x509-ca-ra-cert": {
        source: "iana"
      },
      "application/x-x509-next-ca-cert": {
        source: "iana"
      },
      "application/x-xfig": {
        source: "apache",
        extensions: ["fig"]
      },
      "application/x-xliff+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xlf"]
      },
      "application/x-xpinstall": {
        source: "apache",
        compressible: false,
        extensions: ["xpi"]
      },
      "application/x-xz": {
        source: "apache",
        extensions: ["xz"]
      },
      "application/x-zmachine": {
        source: "apache",
        extensions: ["z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8"]
      },
      "application/x400-bp": {
        source: "iana"
      },
      "application/xacml+xml": {
        source: "iana",
        compressible: true
      },
      "application/xaml+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xaml"]
      },
      "application/xcap-att+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xav"]
      },
      "application/xcap-caps+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xca"]
      },
      "application/xcap-diff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdf"]
      },
      "application/xcap-el+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xel"]
      },
      "application/xcap-error+xml": {
        source: "iana",
        compressible: true
      },
      "application/xcap-ns+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xns"]
      },
      "application/xcon-conference-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/xcon-conference-info-diff+xml": {
        source: "iana",
        compressible: true
      },
      "application/xenc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xenc"]
      },
      "application/xhtml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xhtml", "xht"]
      },
      "application/xhtml-voice+xml": {
        source: "apache",
        compressible: true
      },
      "application/xliff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xlf"]
      },
      "application/xml": {
        source: "iana",
        compressible: true,
        extensions: ["xml", "xsl", "xsd", "rng"]
      },
      "application/xml-dtd": {
        source: "iana",
        compressible: true,
        extensions: ["dtd"]
      },
      "application/xml-external-parsed-entity": {
        source: "iana"
      },
      "application/xml-patch+xml": {
        source: "iana",
        compressible: true
      },
      "application/xmpp+xml": {
        source: "iana",
        compressible: true
      },
      "application/xop+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xop"]
      },
      "application/xproc+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xpl"]
      },
      "application/xslt+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xsl", "xslt"]
      },
      "application/xspf+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xspf"]
      },
      "application/xv+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mxml", "xhvml", "xvml", "xvm"]
      },
      "application/yang": {
        source: "iana",
        extensions: ["yang"]
      },
      "application/yang-data+json": {
        source: "iana",
        compressible: true
      },
      "application/yang-data+xml": {
        source: "iana",
        compressible: true
      },
      "application/yang-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/yang-patch+xml": {
        source: "iana",
        compressible: true
      },
      "application/yin+xml": {
        source: "iana",
        compressible: true,
        extensions: ["yin"]
      },
      "application/zip": {
        source: "iana",
        compressible: false,
        extensions: ["zip"]
      },
      "application/zlib": {
        source: "iana"
      },
      "application/zstd": {
        source: "iana"
      },
      "audio/1d-interleaved-parityfec": {
        source: "iana"
      },
      "audio/32kadpcm": {
        source: "iana"
      },
      "audio/3gpp": {
        source: "iana",
        compressible: false,
        extensions: ["3gpp"]
      },
      "audio/3gpp2": {
        source: "iana"
      },
      "audio/aac": {
        source: "iana"
      },
      "audio/ac3": {
        source: "iana"
      },
      "audio/adpcm": {
        source: "apache",
        extensions: ["adp"]
      },
      "audio/amr": {
        source: "iana",
        extensions: ["amr"]
      },
      "audio/amr-wb": {
        source: "iana"
      },
      "audio/amr-wb+": {
        source: "iana"
      },
      "audio/aptx": {
        source: "iana"
      },
      "audio/asc": {
        source: "iana"
      },
      "audio/atrac-advanced-lossless": {
        source: "iana"
      },
      "audio/atrac-x": {
        source: "iana"
      },
      "audio/atrac3": {
        source: "iana"
      },
      "audio/basic": {
        source: "iana",
        compressible: false,
        extensions: ["au", "snd"]
      },
      "audio/bv16": {
        source: "iana"
      },
      "audio/bv32": {
        source: "iana"
      },
      "audio/clearmode": {
        source: "iana"
      },
      "audio/cn": {
        source: "iana"
      },
      "audio/dat12": {
        source: "iana"
      },
      "audio/dls": {
        source: "iana"
      },
      "audio/dsr-es201108": {
        source: "iana"
      },
      "audio/dsr-es202050": {
        source: "iana"
      },
      "audio/dsr-es202211": {
        source: "iana"
      },
      "audio/dsr-es202212": {
        source: "iana"
      },
      "audio/dv": {
        source: "iana"
      },
      "audio/dvi4": {
        source: "iana"
      },
      "audio/eac3": {
        source: "iana"
      },
      "audio/encaprtp": {
        source: "iana"
      },
      "audio/evrc": {
        source: "iana"
      },
      "audio/evrc-qcp": {
        source: "iana"
      },
      "audio/evrc0": {
        source: "iana"
      },
      "audio/evrc1": {
        source: "iana"
      },
      "audio/evrcb": {
        source: "iana"
      },
      "audio/evrcb0": {
        source: "iana"
      },
      "audio/evrcb1": {
        source: "iana"
      },
      "audio/evrcnw": {
        source: "iana"
      },
      "audio/evrcnw0": {
        source: "iana"
      },
      "audio/evrcnw1": {
        source: "iana"
      },
      "audio/evrcwb": {
        source: "iana"
      },
      "audio/evrcwb0": {
        source: "iana"
      },
      "audio/evrcwb1": {
        source: "iana"
      },
      "audio/evs": {
        source: "iana"
      },
      "audio/flexfec": {
        source: "iana"
      },
      "audio/fwdred": {
        source: "iana"
      },
      "audio/g711-0": {
        source: "iana"
      },
      "audio/g719": {
        source: "iana"
      },
      "audio/g722": {
        source: "iana"
      },
      "audio/g7221": {
        source: "iana"
      },
      "audio/g723": {
        source: "iana"
      },
      "audio/g726-16": {
        source: "iana"
      },
      "audio/g726-24": {
        source: "iana"
      },
      "audio/g726-32": {
        source: "iana"
      },
      "audio/g726-40": {
        source: "iana"
      },
      "audio/g728": {
        source: "iana"
      },
      "audio/g729": {
        source: "iana"
      },
      "audio/g7291": {
        source: "iana"
      },
      "audio/g729d": {
        source: "iana"
      },
      "audio/g729e": {
        source: "iana"
      },
      "audio/gsm": {
        source: "iana"
      },
      "audio/gsm-efr": {
        source: "iana"
      },
      "audio/gsm-hr-08": {
        source: "iana"
      },
      "audio/ilbc": {
        source: "iana"
      },
      "audio/ip-mr_v2.5": {
        source: "iana"
      },
      "audio/isac": {
        source: "apache"
      },
      "audio/l16": {
        source: "iana"
      },
      "audio/l20": {
        source: "iana"
      },
      "audio/l24": {
        source: "iana",
        compressible: false
      },
      "audio/l8": {
        source: "iana"
      },
      "audio/lpc": {
        source: "iana"
      },
      "audio/melp": {
        source: "iana"
      },
      "audio/melp1200": {
        source: "iana"
      },
      "audio/melp2400": {
        source: "iana"
      },
      "audio/melp600": {
        source: "iana"
      },
      "audio/mhas": {
        source: "iana"
      },
      "audio/midi": {
        source: "apache",
        extensions: ["mid", "midi", "kar", "rmi"]
      },
      "audio/mobile-xmf": {
        source: "iana",
        extensions: ["mxmf"]
      },
      "audio/mp3": {
        compressible: false,
        extensions: ["mp3"]
      },
      "audio/mp4": {
        source: "iana",
        compressible: false,
        extensions: ["m4a", "mp4a"]
      },
      "audio/mp4a-latm": {
        source: "iana"
      },
      "audio/mpa": {
        source: "iana"
      },
      "audio/mpa-robust": {
        source: "iana"
      },
      "audio/mpeg": {
        source: "iana",
        compressible: false,
        extensions: ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"]
      },
      "audio/mpeg4-generic": {
        source: "iana"
      },
      "audio/musepack": {
        source: "apache"
      },
      "audio/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["oga", "ogg", "spx", "opus"]
      },
      "audio/opus": {
        source: "iana"
      },
      "audio/parityfec": {
        source: "iana"
      },
      "audio/pcma": {
        source: "iana"
      },
      "audio/pcma-wb": {
        source: "iana"
      },
      "audio/pcmu": {
        source: "iana"
      },
      "audio/pcmu-wb": {
        source: "iana"
      },
      "audio/prs.sid": {
        source: "iana"
      },
      "audio/qcelp": {
        source: "iana"
      },
      "audio/raptorfec": {
        source: "iana"
      },
      "audio/red": {
        source: "iana"
      },
      "audio/rtp-enc-aescm128": {
        source: "iana"
      },
      "audio/rtp-midi": {
        source: "iana"
      },
      "audio/rtploopback": {
        source: "iana"
      },
      "audio/rtx": {
        source: "iana"
      },
      "audio/s3m": {
        source: "apache",
        extensions: ["s3m"]
      },
      "audio/scip": {
        source: "iana"
      },
      "audio/silk": {
        source: "apache",
        extensions: ["sil"]
      },
      "audio/smv": {
        source: "iana"
      },
      "audio/smv-qcp": {
        source: "iana"
      },
      "audio/smv0": {
        source: "iana"
      },
      "audio/sofa": {
        source: "iana"
      },
      "audio/sp-midi": {
        source: "iana"
      },
      "audio/speex": {
        source: "iana"
      },
      "audio/t140c": {
        source: "iana"
      },
      "audio/t38": {
        source: "iana"
      },
      "audio/telephone-event": {
        source: "iana"
      },
      "audio/tetra_acelp": {
        source: "iana"
      },
      "audio/tetra_acelp_bb": {
        source: "iana"
      },
      "audio/tone": {
        source: "iana"
      },
      "audio/tsvcis": {
        source: "iana"
      },
      "audio/uemclip": {
        source: "iana"
      },
      "audio/ulpfec": {
        source: "iana"
      },
      "audio/usac": {
        source: "iana"
      },
      "audio/vdvi": {
        source: "iana"
      },
      "audio/vmr-wb": {
        source: "iana"
      },
      "audio/vnd.3gpp.iufp": {
        source: "iana"
      },
      "audio/vnd.4sb": {
        source: "iana"
      },
      "audio/vnd.audiokoz": {
        source: "iana"
      },
      "audio/vnd.celp": {
        source: "iana"
      },
      "audio/vnd.cisco.nse": {
        source: "iana"
      },
      "audio/vnd.cmles.radio-events": {
        source: "iana"
      },
      "audio/vnd.cns.anp1": {
        source: "iana"
      },
      "audio/vnd.cns.inf1": {
        source: "iana"
      },
      "audio/vnd.dece.audio": {
        source: "iana",
        extensions: ["uva", "uvva"]
      },
      "audio/vnd.digital-winds": {
        source: "iana",
        extensions: ["eol"]
      },
      "audio/vnd.dlna.adts": {
        source: "iana"
      },
      "audio/vnd.dolby.heaac.1": {
        source: "iana"
      },
      "audio/vnd.dolby.heaac.2": {
        source: "iana"
      },
      "audio/vnd.dolby.mlp": {
        source: "iana"
      },
      "audio/vnd.dolby.mps": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2x": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2z": {
        source: "iana"
      },
      "audio/vnd.dolby.pulse.1": {
        source: "iana"
      },
      "audio/vnd.dra": {
        source: "iana",
        extensions: ["dra"]
      },
      "audio/vnd.dts": {
        source: "iana",
        extensions: ["dts"]
      },
      "audio/vnd.dts.hd": {
        source: "iana",
        extensions: ["dtshd"]
      },
      "audio/vnd.dts.uhd": {
        source: "iana"
      },
      "audio/vnd.dvb.file": {
        source: "iana"
      },
      "audio/vnd.everad.plj": {
        source: "iana"
      },
      "audio/vnd.hns.audio": {
        source: "iana"
      },
      "audio/vnd.lucent.voice": {
        source: "iana",
        extensions: ["lvp"]
      },
      "audio/vnd.ms-playready.media.pya": {
        source: "iana",
        extensions: ["pya"]
      },
      "audio/vnd.nokia.mobile-xmf": {
        source: "iana"
      },
      "audio/vnd.nortel.vbk": {
        source: "iana"
      },
      "audio/vnd.nuera.ecelp4800": {
        source: "iana",
        extensions: ["ecelp4800"]
      },
      "audio/vnd.nuera.ecelp7470": {
        source: "iana",
        extensions: ["ecelp7470"]
      },
      "audio/vnd.nuera.ecelp9600": {
        source: "iana",
        extensions: ["ecelp9600"]
      },
      "audio/vnd.octel.sbc": {
        source: "iana"
      },
      "audio/vnd.presonus.multitrack": {
        source: "iana"
      },
      "audio/vnd.qcelp": {
        source: "iana"
      },
      "audio/vnd.rhetorex.32kadpcm": {
        source: "iana"
      },
      "audio/vnd.rip": {
        source: "iana",
        extensions: ["rip"]
      },
      "audio/vnd.rn-realaudio": {
        compressible: false
      },
      "audio/vnd.sealedmedia.softseal.mpeg": {
        source: "iana"
      },
      "audio/vnd.vmx.cvsd": {
        source: "iana"
      },
      "audio/vnd.wave": {
        compressible: false
      },
      "audio/vorbis": {
        source: "iana",
        compressible: false
      },
      "audio/vorbis-config": {
        source: "iana"
      },
      "audio/wav": {
        compressible: false,
        extensions: ["wav"]
      },
      "audio/wave": {
        compressible: false,
        extensions: ["wav"]
      },
      "audio/webm": {
        source: "apache",
        compressible: false,
        extensions: ["weba"]
      },
      "audio/x-aac": {
        source: "apache",
        compressible: false,
        extensions: ["aac"]
      },
      "audio/x-aiff": {
        source: "apache",
        extensions: ["aif", "aiff", "aifc"]
      },
      "audio/x-caf": {
        source: "apache",
        compressible: false,
        extensions: ["caf"]
      },
      "audio/x-flac": {
        source: "apache",
        extensions: ["flac"]
      },
      "audio/x-m4a": {
        source: "nginx",
        extensions: ["m4a"]
      },
      "audio/x-matroska": {
        source: "apache",
        extensions: ["mka"]
      },
      "audio/x-mpegurl": {
        source: "apache",
        extensions: ["m3u"]
      },
      "audio/x-ms-wax": {
        source: "apache",
        extensions: ["wax"]
      },
      "audio/x-ms-wma": {
        source: "apache",
        extensions: ["wma"]
      },
      "audio/x-pn-realaudio": {
        source: "apache",
        extensions: ["ram", "ra"]
      },
      "audio/x-pn-realaudio-plugin": {
        source: "apache",
        extensions: ["rmp"]
      },
      "audio/x-realaudio": {
        source: "nginx",
        extensions: ["ra"]
      },
      "audio/x-tta": {
        source: "apache"
      },
      "audio/x-wav": {
        source: "apache",
        extensions: ["wav"]
      },
      "audio/xm": {
        source: "apache",
        extensions: ["xm"]
      },
      "chemical/x-cdx": {
        source: "apache",
        extensions: ["cdx"]
      },
      "chemical/x-cif": {
        source: "apache",
        extensions: ["cif"]
      },
      "chemical/x-cmdf": {
        source: "apache",
        extensions: ["cmdf"]
      },
      "chemical/x-cml": {
        source: "apache",
        extensions: ["cml"]
      },
      "chemical/x-csml": {
        source: "apache",
        extensions: ["csml"]
      },
      "chemical/x-pdb": {
        source: "apache"
      },
      "chemical/x-xyz": {
        source: "apache",
        extensions: ["xyz"]
      },
      "font/collection": {
        source: "iana",
        extensions: ["ttc"]
      },
      "font/otf": {
        source: "iana",
        compressible: true,
        extensions: ["otf"]
      },
      "font/sfnt": {
        source: "iana"
      },
      "font/ttf": {
        source: "iana",
        compressible: true,
        extensions: ["ttf"]
      },
      "font/woff": {
        source: "iana",
        extensions: ["woff"]
      },
      "font/woff2": {
        source: "iana",
        extensions: ["woff2"]
      },
      "image/aces": {
        source: "iana",
        extensions: ["exr"]
      },
      "image/apng": {
        compressible: false,
        extensions: ["apng"]
      },
      "image/avci": {
        source: "iana",
        extensions: ["avci"]
      },
      "image/avcs": {
        source: "iana",
        extensions: ["avcs"]
      },
      "image/avif": {
        source: "iana",
        compressible: false,
        extensions: ["avif"]
      },
      "image/bmp": {
        source: "iana",
        compressible: true,
        extensions: ["bmp"]
      },
      "image/cgm": {
        source: "iana",
        extensions: ["cgm"]
      },
      "image/dicom-rle": {
        source: "iana",
        extensions: ["drle"]
      },
      "image/emf": {
        source: "iana",
        extensions: ["emf"]
      },
      "image/fits": {
        source: "iana",
        extensions: ["fits"]
      },
      "image/g3fax": {
        source: "iana",
        extensions: ["g3"]
      },
      "image/gif": {
        source: "iana",
        compressible: false,
        extensions: ["gif"]
      },
      "image/heic": {
        source: "iana",
        extensions: ["heic"]
      },
      "image/heic-sequence": {
        source: "iana",
        extensions: ["heics"]
      },
      "image/heif": {
        source: "iana",
        extensions: ["heif"]
      },
      "image/heif-sequence": {
        source: "iana",
        extensions: ["heifs"]
      },
      "image/hej2k": {
        source: "iana",
        extensions: ["hej2"]
      },
      "image/hsj2": {
        source: "iana",
        extensions: ["hsj2"]
      },
      "image/ief": {
        source: "iana",
        extensions: ["ief"]
      },
      "image/jls": {
        source: "iana",
        extensions: ["jls"]
      },
      "image/jp2": {
        source: "iana",
        compressible: false,
        extensions: ["jp2", "jpg2"]
      },
      "image/jpeg": {
        source: "iana",
        compressible: false,
        extensions: ["jpeg", "jpg", "jpe"]
      },
      "image/jph": {
        source: "iana",
        extensions: ["jph"]
      },
      "image/jphc": {
        source: "iana",
        extensions: ["jhc"]
      },
      "image/jpm": {
        source: "iana",
        compressible: false,
        extensions: ["jpm"]
      },
      "image/jpx": {
        source: "iana",
        compressible: false,
        extensions: ["jpx", "jpf"]
      },
      "image/jxr": {
        source: "iana",
        extensions: ["jxr"]
      },
      "image/jxra": {
        source: "iana",
        extensions: ["jxra"]
      },
      "image/jxrs": {
        source: "iana",
        extensions: ["jxrs"]
      },
      "image/jxs": {
        source: "iana",
        extensions: ["jxs"]
      },
      "image/jxsc": {
        source: "iana",
        extensions: ["jxsc"]
      },
      "image/jxsi": {
        source: "iana",
        extensions: ["jxsi"]
      },
      "image/jxss": {
        source: "iana",
        extensions: ["jxss"]
      },
      "image/ktx": {
        source: "iana",
        extensions: ["ktx"]
      },
      "image/ktx2": {
        source: "iana",
        extensions: ["ktx2"]
      },
      "image/naplps": {
        source: "iana"
      },
      "image/pjpeg": {
        compressible: false
      },
      "image/png": {
        source: "iana",
        compressible: false,
        extensions: ["png"]
      },
      "image/prs.btif": {
        source: "iana",
        extensions: ["btif"]
      },
      "image/prs.pti": {
        source: "iana",
        extensions: ["pti"]
      },
      "image/pwg-raster": {
        source: "iana"
      },
      "image/sgi": {
        source: "apache",
        extensions: ["sgi"]
      },
      "image/svg+xml": {
        source: "iana",
        compressible: true,
        extensions: ["svg", "svgz"]
      },
      "image/t38": {
        source: "iana",
        extensions: ["t38"]
      },
      "image/tiff": {
        source: "iana",
        compressible: false,
        extensions: ["tif", "tiff"]
      },
      "image/tiff-fx": {
        source: "iana",
        extensions: ["tfx"]
      },
      "image/vnd.adobe.photoshop": {
        source: "iana",
        compressible: true,
        extensions: ["psd"]
      },
      "image/vnd.airzip.accelerator.azv": {
        source: "iana",
        extensions: ["azv"]
      },
      "image/vnd.cns.inf2": {
        source: "iana"
      },
      "image/vnd.dece.graphic": {
        source: "iana",
        extensions: ["uvi", "uvvi", "uvg", "uvvg"]
      },
      "image/vnd.djvu": {
        source: "iana",
        extensions: ["djvu", "djv"]
      },
      "image/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
      },
      "image/vnd.dwg": {
        source: "iana",
        extensions: ["dwg"]
      },
      "image/vnd.dxf": {
        source: "iana",
        extensions: ["dxf"]
      },
      "image/vnd.fastbidsheet": {
        source: "iana",
        extensions: ["fbs"]
      },
      "image/vnd.fpx": {
        source: "iana",
        extensions: ["fpx"]
      },
      "image/vnd.fst": {
        source: "iana",
        extensions: ["fst"]
      },
      "image/vnd.fujixerox.edmics-mmr": {
        source: "iana",
        extensions: ["mmr"]
      },
      "image/vnd.fujixerox.edmics-rlc": {
        source: "iana",
        extensions: ["rlc"]
      },
      "image/vnd.globalgraphics.pgb": {
        source: "iana"
      },
      "image/vnd.microsoft.icon": {
        source: "iana",
        compressible: true,
        extensions: ["ico"]
      },
      "image/vnd.mix": {
        source: "iana"
      },
      "image/vnd.mozilla.apng": {
        source: "iana"
      },
      "image/vnd.ms-dds": {
        compressible: true,
        extensions: ["dds"]
      },
      "image/vnd.ms-modi": {
        source: "iana",
        extensions: ["mdi"]
      },
      "image/vnd.ms-photo": {
        source: "apache",
        extensions: ["wdp"]
      },
      "image/vnd.net-fpx": {
        source: "iana",
        extensions: ["npx"]
      },
      "image/vnd.pco.b16": {
        source: "iana",
        extensions: ["b16"]
      },
      "image/vnd.radiance": {
        source: "iana"
      },
      "image/vnd.sealed.png": {
        source: "iana"
      },
      "image/vnd.sealedmedia.softseal.gif": {
        source: "iana"
      },
      "image/vnd.sealedmedia.softseal.jpg": {
        source: "iana"
      },
      "image/vnd.svf": {
        source: "iana"
      },
      "image/vnd.tencent.tap": {
        source: "iana",
        extensions: ["tap"]
      },
      "image/vnd.valve.source.texture": {
        source: "iana",
        extensions: ["vtf"]
      },
      "image/vnd.wap.wbmp": {
        source: "iana",
        extensions: ["wbmp"]
      },
      "image/vnd.xiff": {
        source: "iana",
        extensions: ["xif"]
      },
      "image/vnd.zbrush.pcx": {
        source: "iana",
        extensions: ["pcx"]
      },
      "image/webp": {
        source: "apache",
        extensions: ["webp"]
      },
      "image/wmf": {
        source: "iana",
        extensions: ["wmf"]
      },
      "image/x-3ds": {
        source: "apache",
        extensions: ["3ds"]
      },
      "image/x-cmu-raster": {
        source: "apache",
        extensions: ["ras"]
      },
      "image/x-cmx": {
        source: "apache",
        extensions: ["cmx"]
      },
      "image/x-freehand": {
        source: "apache",
        extensions: ["fh", "fhc", "fh4", "fh5", "fh7"]
      },
      "image/x-icon": {
        source: "apache",
        compressible: true,
        extensions: ["ico"]
      },
      "image/x-jng": {
        source: "nginx",
        extensions: ["jng"]
      },
      "image/x-mrsid-image": {
        source: "apache",
        extensions: ["sid"]
      },
      "image/x-ms-bmp": {
        source: "nginx",
        compressible: true,
        extensions: ["bmp"]
      },
      "image/x-pcx": {
        source: "apache",
        extensions: ["pcx"]
      },
      "image/x-pict": {
        source: "apache",
        extensions: ["pic", "pct"]
      },
      "image/x-portable-anymap": {
        source: "apache",
        extensions: ["pnm"]
      },
      "image/x-portable-bitmap": {
        source: "apache",
        extensions: ["pbm"]
      },
      "image/x-portable-graymap": {
        source: "apache",
        extensions: ["pgm"]
      },
      "image/x-portable-pixmap": {
        source: "apache",
        extensions: ["ppm"]
      },
      "image/x-rgb": {
        source: "apache",
        extensions: ["rgb"]
      },
      "image/x-tga": {
        source: "apache",
        extensions: ["tga"]
      },
      "image/x-xbitmap": {
        source: "apache",
        extensions: ["xbm"]
      },
      "image/x-xcf": {
        compressible: false
      },
      "image/x-xpixmap": {
        source: "apache",
        extensions: ["xpm"]
      },
      "image/x-xwindowdump": {
        source: "apache",
        extensions: ["xwd"]
      },
      "message/cpim": {
        source: "iana"
      },
      "message/delivery-status": {
        source: "iana"
      },
      "message/disposition-notification": {
        source: "iana",
        extensions: [
          "disposition-notification"
        ]
      },
      "message/external-body": {
        source: "iana"
      },
      "message/feedback-report": {
        source: "iana"
      },
      "message/global": {
        source: "iana",
        extensions: ["u8msg"]
      },
      "message/global-delivery-status": {
        source: "iana",
        extensions: ["u8dsn"]
      },
      "message/global-disposition-notification": {
        source: "iana",
        extensions: ["u8mdn"]
      },
      "message/global-headers": {
        source: "iana",
        extensions: ["u8hdr"]
      },
      "message/http": {
        source: "iana",
        compressible: false
      },
      "message/imdn+xml": {
        source: "iana",
        compressible: true
      },
      "message/news": {
        source: "iana"
      },
      "message/partial": {
        source: "iana",
        compressible: false
      },
      "message/rfc822": {
        source: "iana",
        compressible: true,
        extensions: ["eml", "mime"]
      },
      "message/s-http": {
        source: "iana"
      },
      "message/sip": {
        source: "iana"
      },
      "message/sipfrag": {
        source: "iana"
      },
      "message/tracking-status": {
        source: "iana"
      },
      "message/vnd.si.simp": {
        source: "iana"
      },
      "message/vnd.wfa.wsc": {
        source: "iana",
        extensions: ["wsc"]
      },
      "model/3mf": {
        source: "iana",
        extensions: ["3mf"]
      },
      "model/e57": {
        source: "iana"
      },
      "model/gltf+json": {
        source: "iana",
        compressible: true,
        extensions: ["gltf"]
      },
      "model/gltf-binary": {
        source: "iana",
        compressible: true,
        extensions: ["glb"]
      },
      "model/iges": {
        source: "iana",
        compressible: false,
        extensions: ["igs", "iges"]
      },
      "model/mesh": {
        source: "iana",
        compressible: false,
        extensions: ["msh", "mesh", "silo"]
      },
      "model/mtl": {
        source: "iana",
        extensions: ["mtl"]
      },
      "model/obj": {
        source: "iana",
        extensions: ["obj"]
      },
      "model/step": {
        source: "iana"
      },
      "model/step+xml": {
        source: "iana",
        compressible: true,
        extensions: ["stpx"]
      },
      "model/step+zip": {
        source: "iana",
        compressible: false,
        extensions: ["stpz"]
      },
      "model/step-xml+zip": {
        source: "iana",
        compressible: false,
        extensions: ["stpxz"]
      },
      "model/stl": {
        source: "iana",
        extensions: ["stl"]
      },
      "model/vnd.collada+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dae"]
      },
      "model/vnd.dwf": {
        source: "iana",
        extensions: ["dwf"]
      },
      "model/vnd.flatland.3dml": {
        source: "iana"
      },
      "model/vnd.gdl": {
        source: "iana",
        extensions: ["gdl"]
      },
      "model/vnd.gs-gdl": {
        source: "apache"
      },
      "model/vnd.gs.gdl": {
        source: "iana"
      },
      "model/vnd.gtw": {
        source: "iana",
        extensions: ["gtw"]
      },
      "model/vnd.moml+xml": {
        source: "iana",
        compressible: true
      },
      "model/vnd.mts": {
        source: "iana",
        extensions: ["mts"]
      },
      "model/vnd.opengex": {
        source: "iana",
        extensions: ["ogex"]
      },
      "model/vnd.parasolid.transmit.binary": {
        source: "iana",
        extensions: ["x_b"]
      },
      "model/vnd.parasolid.transmit.text": {
        source: "iana",
        extensions: ["x_t"]
      },
      "model/vnd.pytha.pyox": {
        source: "iana"
      },
      "model/vnd.rosette.annotated-data-model": {
        source: "iana"
      },
      "model/vnd.sap.vds": {
        source: "iana",
        extensions: ["vds"]
      },
      "model/vnd.usdz+zip": {
        source: "iana",
        compressible: false,
        extensions: ["usdz"]
      },
      "model/vnd.valve.source.compiled-map": {
        source: "iana",
        extensions: ["bsp"]
      },
      "model/vnd.vtu": {
        source: "iana",
        extensions: ["vtu"]
      },
      "model/vrml": {
        source: "iana",
        compressible: false,
        extensions: ["wrl", "vrml"]
      },
      "model/x3d+binary": {
        source: "apache",
        compressible: false,
        extensions: ["x3db", "x3dbz"]
      },
      "model/x3d+fastinfoset": {
        source: "iana",
        extensions: ["x3db"]
      },
      "model/x3d+vrml": {
        source: "apache",
        compressible: false,
        extensions: ["x3dv", "x3dvz"]
      },
      "model/x3d+xml": {
        source: "iana",
        compressible: true,
        extensions: ["x3d", "x3dz"]
      },
      "model/x3d-vrml": {
        source: "iana",
        extensions: ["x3dv"]
      },
      "multipart/alternative": {
        source: "iana",
        compressible: false
      },
      "multipart/appledouble": {
        source: "iana"
      },
      "multipart/byteranges": {
        source: "iana"
      },
      "multipart/digest": {
        source: "iana"
      },
      "multipart/encrypted": {
        source: "iana",
        compressible: false
      },
      "multipart/form-data": {
        source: "iana",
        compressible: false
      },
      "multipart/header-set": {
        source: "iana"
      },
      "multipart/mixed": {
        source: "iana"
      },
      "multipart/multilingual": {
        source: "iana"
      },
      "multipart/parallel": {
        source: "iana"
      },
      "multipart/related": {
        source: "iana",
        compressible: false
      },
      "multipart/report": {
        source: "iana"
      },
      "multipart/signed": {
        source: "iana",
        compressible: false
      },
      "multipart/vnd.bint.med-plus": {
        source: "iana"
      },
      "multipart/voice-message": {
        source: "iana"
      },
      "multipart/x-mixed-replace": {
        source: "iana"
      },
      "text/1d-interleaved-parityfec": {
        source: "iana"
      },
      "text/cache-manifest": {
        source: "iana",
        compressible: true,
        extensions: ["appcache", "manifest"]
      },
      "text/calendar": {
        source: "iana",
        extensions: ["ics", "ifb"]
      },
      "text/calender": {
        compressible: true
      },
      "text/cmd": {
        compressible: true
      },
      "text/coffeescript": {
        extensions: ["coffee", "litcoffee"]
      },
      "text/cql": {
        source: "iana"
      },
      "text/cql-expression": {
        source: "iana"
      },
      "text/cql-identifier": {
        source: "iana"
      },
      "text/css": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["css"]
      },
      "text/csv": {
        source: "iana",
        compressible: true,
        extensions: ["csv"]
      },
      "text/csv-schema": {
        source: "iana"
      },
      "text/directory": {
        source: "iana"
      },
      "text/dns": {
        source: "iana"
      },
      "text/ecmascript": {
        source: "iana"
      },
      "text/encaprtp": {
        source: "iana"
      },
      "text/enriched": {
        source: "iana"
      },
      "text/fhirpath": {
        source: "iana"
      },
      "text/flexfec": {
        source: "iana"
      },
      "text/fwdred": {
        source: "iana"
      },
      "text/gff3": {
        source: "iana"
      },
      "text/grammar-ref-list": {
        source: "iana"
      },
      "text/html": {
        source: "iana",
        compressible: true,
        extensions: ["html", "htm", "shtml"]
      },
      "text/jade": {
        extensions: ["jade"]
      },
      "text/javascript": {
        source: "iana",
        compressible: true
      },
      "text/jcr-cnd": {
        source: "iana"
      },
      "text/jsx": {
        compressible: true,
        extensions: ["jsx"]
      },
      "text/less": {
        compressible: true,
        extensions: ["less"]
      },
      "text/markdown": {
        source: "iana",
        compressible: true,
        extensions: ["markdown", "md"]
      },
      "text/mathml": {
        source: "nginx",
        extensions: ["mml"]
      },
      "text/mdx": {
        compressible: true,
        extensions: ["mdx"]
      },
      "text/mizar": {
        source: "iana"
      },
      "text/n3": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["n3"]
      },
      "text/parameters": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/parityfec": {
        source: "iana"
      },
      "text/plain": {
        source: "iana",
        compressible: true,
        extensions: ["txt", "text", "conf", "def", "list", "log", "in", "ini"]
      },
      "text/provenance-notation": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/prs.fallenstein.rst": {
        source: "iana"
      },
      "text/prs.lines.tag": {
        source: "iana",
        extensions: ["dsc"]
      },
      "text/prs.prop.logic": {
        source: "iana"
      },
      "text/raptorfec": {
        source: "iana"
      },
      "text/red": {
        source: "iana"
      },
      "text/rfc822-headers": {
        source: "iana"
      },
      "text/richtext": {
        source: "iana",
        compressible: true,
        extensions: ["rtx"]
      },
      "text/rtf": {
        source: "iana",
        compressible: true,
        extensions: ["rtf"]
      },
      "text/rtp-enc-aescm128": {
        source: "iana"
      },
      "text/rtploopback": {
        source: "iana"
      },
      "text/rtx": {
        source: "iana"
      },
      "text/sgml": {
        source: "iana",
        extensions: ["sgml", "sgm"]
      },
      "text/shaclc": {
        source: "iana"
      },
      "text/shex": {
        source: "iana",
        extensions: ["shex"]
      },
      "text/slim": {
        extensions: ["slim", "slm"]
      },
      "text/spdx": {
        source: "iana",
        extensions: ["spdx"]
      },
      "text/strings": {
        source: "iana"
      },
      "text/stylus": {
        extensions: ["stylus", "styl"]
      },
      "text/t140": {
        source: "iana"
      },
      "text/tab-separated-values": {
        source: "iana",
        compressible: true,
        extensions: ["tsv"]
      },
      "text/troff": {
        source: "iana",
        extensions: ["t", "tr", "roff", "man", "me", "ms"]
      },
      "text/turtle": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["ttl"]
      },
      "text/ulpfec": {
        source: "iana"
      },
      "text/uri-list": {
        source: "iana",
        compressible: true,
        extensions: ["uri", "uris", "urls"]
      },
      "text/vcard": {
        source: "iana",
        compressible: true,
        extensions: ["vcard"]
      },
      "text/vnd.a": {
        source: "iana"
      },
      "text/vnd.abc": {
        source: "iana"
      },
      "text/vnd.ascii-art": {
        source: "iana"
      },
      "text/vnd.curl": {
        source: "iana",
        extensions: ["curl"]
      },
      "text/vnd.curl.dcurl": {
        source: "apache",
        extensions: ["dcurl"]
      },
      "text/vnd.curl.mcurl": {
        source: "apache",
        extensions: ["mcurl"]
      },
      "text/vnd.curl.scurl": {
        source: "apache",
        extensions: ["scurl"]
      },
      "text/vnd.debian.copyright": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.dmclientscript": {
        source: "iana"
      },
      "text/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
      },
      "text/vnd.esmertec.theme-descriptor": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.familysearch.gedcom": {
        source: "iana",
        extensions: ["ged"]
      },
      "text/vnd.ficlab.flt": {
        source: "iana"
      },
      "text/vnd.fly": {
        source: "iana",
        extensions: ["fly"]
      },
      "text/vnd.fmi.flexstor": {
        source: "iana",
        extensions: ["flx"]
      },
      "text/vnd.gml": {
        source: "iana"
      },
      "text/vnd.graphviz": {
        source: "iana",
        extensions: ["gv"]
      },
      "text/vnd.hans": {
        source: "iana"
      },
      "text/vnd.hgl": {
        source: "iana"
      },
      "text/vnd.in3d.3dml": {
        source: "iana",
        extensions: ["3dml"]
      },
      "text/vnd.in3d.spot": {
        source: "iana",
        extensions: ["spot"]
      },
      "text/vnd.iptc.newsml": {
        source: "iana"
      },
      "text/vnd.iptc.nitf": {
        source: "iana"
      },
      "text/vnd.latex-z": {
        source: "iana"
      },
      "text/vnd.motorola.reflex": {
        source: "iana"
      },
      "text/vnd.ms-mediapackage": {
        source: "iana"
      },
      "text/vnd.net2phone.commcenter.command": {
        source: "iana"
      },
      "text/vnd.radisys.msml-basic-layout": {
        source: "iana"
      },
      "text/vnd.senx.warpscript": {
        source: "iana"
      },
      "text/vnd.si.uricatalogue": {
        source: "iana"
      },
      "text/vnd.sosi": {
        source: "iana"
      },
      "text/vnd.sun.j2me.app-descriptor": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["jad"]
      },
      "text/vnd.trolltech.linguist": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.wap.si": {
        source: "iana"
      },
      "text/vnd.wap.sl": {
        source: "iana"
      },
      "text/vnd.wap.wml": {
        source: "iana",
        extensions: ["wml"]
      },
      "text/vnd.wap.wmlscript": {
        source: "iana",
        extensions: ["wmls"]
      },
      "text/vtt": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["vtt"]
      },
      "text/x-asm": {
        source: "apache",
        extensions: ["s", "asm"]
      },
      "text/x-c": {
        source: "apache",
        extensions: ["c", "cc", "cxx", "cpp", "h", "hh", "dic"]
      },
      "text/x-component": {
        source: "nginx",
        extensions: ["htc"]
      },
      "text/x-fortran": {
        source: "apache",
        extensions: ["f", "for", "f77", "f90"]
      },
      "text/x-gwt-rpc": {
        compressible: true
      },
      "text/x-handlebars-template": {
        extensions: ["hbs"]
      },
      "text/x-java-source": {
        source: "apache",
        extensions: ["java"]
      },
      "text/x-jquery-tmpl": {
        compressible: true
      },
      "text/x-lua": {
        extensions: ["lua"]
      },
      "text/x-markdown": {
        compressible: true,
        extensions: ["mkd"]
      },
      "text/x-nfo": {
        source: "apache",
        extensions: ["nfo"]
      },
      "text/x-opml": {
        source: "apache",
        extensions: ["opml"]
      },
      "text/x-org": {
        compressible: true,
        extensions: ["org"]
      },
      "text/x-pascal": {
        source: "apache",
        extensions: ["p", "pas"]
      },
      "text/x-processing": {
        compressible: true,
        extensions: ["pde"]
      },
      "text/x-sass": {
        extensions: ["sass"]
      },
      "text/x-scss": {
        extensions: ["scss"]
      },
      "text/x-setext": {
        source: "apache",
        extensions: ["etx"]
      },
      "text/x-sfv": {
        source: "apache",
        extensions: ["sfv"]
      },
      "text/x-suse-ymp": {
        compressible: true,
        extensions: ["ymp"]
      },
      "text/x-uuencode": {
        source: "apache",
        extensions: ["uu"]
      },
      "text/x-vcalendar": {
        source: "apache",
        extensions: ["vcs"]
      },
      "text/x-vcard": {
        source: "apache",
        extensions: ["vcf"]
      },
      "text/xml": {
        source: "iana",
        compressible: true,
        extensions: ["xml"]
      },
      "text/xml-external-parsed-entity": {
        source: "iana"
      },
      "text/yaml": {
        compressible: true,
        extensions: ["yaml", "yml"]
      },
      "video/1d-interleaved-parityfec": {
        source: "iana"
      },
      "video/3gpp": {
        source: "iana",
        extensions: ["3gp", "3gpp"]
      },
      "video/3gpp-tt": {
        source: "iana"
      },
      "video/3gpp2": {
        source: "iana",
        extensions: ["3g2"]
      },
      "video/av1": {
        source: "iana"
      },
      "video/bmpeg": {
        source: "iana"
      },
      "video/bt656": {
        source: "iana"
      },
      "video/celb": {
        source: "iana"
      },
      "video/dv": {
        source: "iana"
      },
      "video/encaprtp": {
        source: "iana"
      },
      "video/ffv1": {
        source: "iana"
      },
      "video/flexfec": {
        source: "iana"
      },
      "video/h261": {
        source: "iana",
        extensions: ["h261"]
      },
      "video/h263": {
        source: "iana",
        extensions: ["h263"]
      },
      "video/h263-1998": {
        source: "iana"
      },
      "video/h263-2000": {
        source: "iana"
      },
      "video/h264": {
        source: "iana",
        extensions: ["h264"]
      },
      "video/h264-rcdo": {
        source: "iana"
      },
      "video/h264-svc": {
        source: "iana"
      },
      "video/h265": {
        source: "iana"
      },
      "video/iso.segment": {
        source: "iana",
        extensions: ["m4s"]
      },
      "video/jpeg": {
        source: "iana",
        extensions: ["jpgv"]
      },
      "video/jpeg2000": {
        source: "iana"
      },
      "video/jpm": {
        source: "apache",
        extensions: ["jpm", "jpgm"]
      },
      "video/jxsv": {
        source: "iana"
      },
      "video/mj2": {
        source: "iana",
        extensions: ["mj2", "mjp2"]
      },
      "video/mp1s": {
        source: "iana"
      },
      "video/mp2p": {
        source: "iana"
      },
      "video/mp2t": {
        source: "iana",
        extensions: ["ts"]
      },
      "video/mp4": {
        source: "iana",
        compressible: false,
        extensions: ["mp4", "mp4v", "mpg4"]
      },
      "video/mp4v-es": {
        source: "iana"
      },
      "video/mpeg": {
        source: "iana",
        compressible: false,
        extensions: ["mpeg", "mpg", "mpe", "m1v", "m2v"]
      },
      "video/mpeg4-generic": {
        source: "iana"
      },
      "video/mpv": {
        source: "iana"
      },
      "video/nv": {
        source: "iana"
      },
      "video/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["ogv"]
      },
      "video/parityfec": {
        source: "iana"
      },
      "video/pointer": {
        source: "iana"
      },
      "video/quicktime": {
        source: "iana",
        compressible: false,
        extensions: ["qt", "mov"]
      },
      "video/raptorfec": {
        source: "iana"
      },
      "video/raw": {
        source: "iana"
      },
      "video/rtp-enc-aescm128": {
        source: "iana"
      },
      "video/rtploopback": {
        source: "iana"
      },
      "video/rtx": {
        source: "iana"
      },
      "video/scip": {
        source: "iana"
      },
      "video/smpte291": {
        source: "iana"
      },
      "video/smpte292m": {
        source: "iana"
      },
      "video/ulpfec": {
        source: "iana"
      },
      "video/vc1": {
        source: "iana"
      },
      "video/vc2": {
        source: "iana"
      },
      "video/vnd.cctv": {
        source: "iana"
      },
      "video/vnd.dece.hd": {
        source: "iana",
        extensions: ["uvh", "uvvh"]
      },
      "video/vnd.dece.mobile": {
        source: "iana",
        extensions: ["uvm", "uvvm"]
      },
      "video/vnd.dece.mp4": {
        source: "iana"
      },
      "video/vnd.dece.pd": {
        source: "iana",
        extensions: ["uvp", "uvvp"]
      },
      "video/vnd.dece.sd": {
        source: "iana",
        extensions: ["uvs", "uvvs"]
      },
      "video/vnd.dece.video": {
        source: "iana",
        extensions: ["uvv", "uvvv"]
      },
      "video/vnd.directv.mpeg": {
        source: "iana"
      },
      "video/vnd.directv.mpeg-tts": {
        source: "iana"
      },
      "video/vnd.dlna.mpeg-tts": {
        source: "iana"
      },
      "video/vnd.dvb.file": {
        source: "iana",
        extensions: ["dvb"]
      },
      "video/vnd.fvt": {
        source: "iana",
        extensions: ["fvt"]
      },
      "video/vnd.hns.video": {
        source: "iana"
      },
      "video/vnd.iptvforum.1dparityfec-1010": {
        source: "iana"
      },
      "video/vnd.iptvforum.1dparityfec-2005": {
        source: "iana"
      },
      "video/vnd.iptvforum.2dparityfec-1010": {
        source: "iana"
      },
      "video/vnd.iptvforum.2dparityfec-2005": {
        source: "iana"
      },
      "video/vnd.iptvforum.ttsavc": {
        source: "iana"
      },
      "video/vnd.iptvforum.ttsmpeg2": {
        source: "iana"
      },
      "video/vnd.motorola.video": {
        source: "iana"
      },
      "video/vnd.motorola.videop": {
        source: "iana"
      },
      "video/vnd.mpegurl": {
        source: "iana",
        extensions: ["mxu", "m4u"]
      },
      "video/vnd.ms-playready.media.pyv": {
        source: "iana",
        extensions: ["pyv"]
      },
      "video/vnd.nokia.interleaved-multimedia": {
        source: "iana"
      },
      "video/vnd.nokia.mp4vr": {
        source: "iana"
      },
      "video/vnd.nokia.videovoip": {
        source: "iana"
      },
      "video/vnd.objectvideo": {
        source: "iana"
      },
      "video/vnd.radgamettools.bink": {
        source: "iana"
      },
      "video/vnd.radgamettools.smacker": {
        source: "iana"
      },
      "video/vnd.sealed.mpeg1": {
        source: "iana"
      },
      "video/vnd.sealed.mpeg4": {
        source: "iana"
      },
      "video/vnd.sealed.swf": {
        source: "iana"
      },
      "video/vnd.sealedmedia.softseal.mov": {
        source: "iana"
      },
      "video/vnd.uvvu.mp4": {
        source: "iana",
        extensions: ["uvu", "uvvu"]
      },
      "video/vnd.vivo": {
        source: "iana",
        extensions: ["viv"]
      },
      "video/vnd.youtube.yt": {
        source: "iana"
      },
      "video/vp8": {
        source: "iana"
      },
      "video/vp9": {
        source: "iana"
      },
      "video/webm": {
        source: "apache",
        compressible: false,
        extensions: ["webm"]
      },
      "video/x-f4v": {
        source: "apache",
        extensions: ["f4v"]
      },
      "video/x-fli": {
        source: "apache",
        extensions: ["fli"]
      },
      "video/x-flv": {
        source: "apache",
        compressible: false,
        extensions: ["flv"]
      },
      "video/x-m4v": {
        source: "apache",
        extensions: ["m4v"]
      },
      "video/x-matroska": {
        source: "apache",
        compressible: false,
        extensions: ["mkv", "mk3d", "mks"]
      },
      "video/x-mng": {
        source: "apache",
        extensions: ["mng"]
      },
      "video/x-ms-asf": {
        source: "apache",
        extensions: ["asf", "asx"]
      },
      "video/x-ms-vob": {
        source: "apache",
        extensions: ["vob"]
      },
      "video/x-ms-wm": {
        source: "apache",
        extensions: ["wm"]
      },
      "video/x-ms-wmv": {
        source: "apache",
        compressible: false,
        extensions: ["wmv"]
      },
      "video/x-ms-wmx": {
        source: "apache",
        extensions: ["wmx"]
      },
      "video/x-ms-wvx": {
        source: "apache",
        extensions: ["wvx"]
      },
      "video/x-msvideo": {
        source: "apache",
        extensions: ["avi"]
      },
      "video/x-sgi-movie": {
        source: "apache",
        extensions: ["movie"]
      },
      "video/x-smv": {
        source: "apache",
        extensions: ["smv"]
      },
      "x-conference/x-cooltalk": {
        source: "apache",
        extensions: ["ice"]
      },
      "x-shader/x-fragment": {
        compressible: true
      },
      "x-shader/x-vertex": {
        compressible: true
      }
    };
  }
});

// node_modules/mime-db/index.js
var require_mime_db = __commonJS({
  "node_modules/mime-db/index.js"(exports, module) {
    module.exports = require_db();
  }
});

// node_modules/mime-types/index.js
var require_mime_types = __commonJS({
  "node_modules/mime-types/index.js"(exports) {
    "use strict";
    var db2 = require_mime_db();
    var extname = __require("path").extname;
    var EXTRACT_TYPE_REGEXP = /^\s*([^;\s]*)(?:;|\s|$)/;
    var TEXT_TYPE_REGEXP = /^text\//i;
    exports.charset = charset;
    exports.charsets = { lookup: charset };
    exports.contentType = contentType;
    exports.extension = extension;
    exports.extensions = /* @__PURE__ */ Object.create(null);
    exports.lookup = lookup;
    exports.types = /* @__PURE__ */ Object.create(null);
    populateMaps(exports.extensions, exports.types);
    function charset(type) {
      if (!type || typeof type !== "string") {
        return false;
      }
      var match = EXTRACT_TYPE_REGEXP.exec(type);
      var mime = match && db2[match[1].toLowerCase()];
      if (mime && mime.charset) {
        return mime.charset;
      }
      if (match && TEXT_TYPE_REGEXP.test(match[1])) {
        return "UTF-8";
      }
      return false;
    }
    function contentType(str) {
      if (!str || typeof str !== "string") {
        return false;
      }
      var mime = str.indexOf("/") === -1 ? exports.lookup(str) : str;
      if (!mime) {
        return false;
      }
      if (mime.indexOf("charset") === -1) {
        var charset2 = exports.charset(mime);
        if (charset2) mime += "; charset=" + charset2.toLowerCase();
      }
      return mime;
    }
    function extension(type) {
      if (!type || typeof type !== "string") {
        return false;
      }
      var match = EXTRACT_TYPE_REGEXP.exec(type);
      var exts = match && exports.extensions[match[1].toLowerCase()];
      if (!exts || !exts.length) {
        return false;
      }
      return exts[0];
    }
    function lookup(path6) {
      if (!path6 || typeof path6 !== "string") {
        return false;
      }
      var extension2 = extname("x." + path6).toLowerCase().substr(1);
      if (!extension2) {
        return false;
      }
      return exports.types[extension2] || false;
    }
    function populateMaps(extensions, types) {
      var preference = ["nginx", "apache", void 0, "iana"];
      Object.keys(db2).forEach(function forEachMimeType(type) {
        var mime = db2[type];
        var exts = mime.extensions;
        if (!exts || !exts.length) {
          return;
        }
        extensions[type] = exts;
        for (var i = 0; i < exts.length; i++) {
          var extension2 = exts[i];
          if (types[extension2]) {
            var from = preference.indexOf(db2[types[extension2]].source);
            var to = preference.indexOf(mime.source);
            if (types[extension2] !== "application/octet-stream" && (from > to || from === to && types[extension2].substr(0, 12) === "application/")) {
              continue;
            }
          }
          types[extension2] = type;
        }
      });
    }
  }
});

// node_modules/asynckit/lib/defer.js
var require_defer = __commonJS({
  "node_modules/asynckit/lib/defer.js"(exports, module) {
    module.exports = defer;
    function defer(fn) {
      var nextTick = typeof setImmediate == "function" ? setImmediate : typeof process == "object" && typeof process.nextTick == "function" ? process.nextTick : null;
      if (nextTick) {
        nextTick(fn);
      } else {
        setTimeout(fn, 0);
      }
    }
  }
});

// node_modules/asynckit/lib/async.js
var require_async = __commonJS({
  "node_modules/asynckit/lib/async.js"(exports, module) {
    var defer = require_defer();
    module.exports = async;
    function async(callback) {
      var isAsync = false;
      defer(function() {
        isAsync = true;
      });
      return function async_callback(err, result) {
        if (isAsync) {
          callback(err, result);
        } else {
          defer(function nextTick_callback() {
            callback(err, result);
          });
        }
      };
    }
  }
});

// node_modules/asynckit/lib/abort.js
var require_abort = __commonJS({
  "node_modules/asynckit/lib/abort.js"(exports, module) {
    module.exports = abort;
    function abort(state) {
      Object.keys(state.jobs).forEach(clean.bind(state));
      state.jobs = {};
    }
    function clean(key) {
      if (typeof this.jobs[key] == "function") {
        this.jobs[key]();
      }
    }
  }
});

// node_modules/asynckit/lib/iterate.js
var require_iterate = __commonJS({
  "node_modules/asynckit/lib/iterate.js"(exports, module) {
    var async = require_async();
    var abort = require_abort();
    module.exports = iterate;
    function iterate(list, iterator, state, callback) {
      var key = state["keyedList"] ? state["keyedList"][state.index] : state.index;
      state.jobs[key] = runJob(iterator, key, list[key], function(error, output) {
        if (!(key in state.jobs)) {
          return;
        }
        delete state.jobs[key];
        if (error) {
          abort(state);
        } else {
          state.results[key] = output;
        }
        callback(error, state.results);
      });
    }
    function runJob(iterator, key, item, callback) {
      var aborter;
      if (iterator.length == 2) {
        aborter = iterator(item, async(callback));
      } else {
        aborter = iterator(item, key, async(callback));
      }
      return aborter;
    }
  }
});

// node_modules/asynckit/lib/state.js
var require_state = __commonJS({
  "node_modules/asynckit/lib/state.js"(exports, module) {
    module.exports = state;
    function state(list, sortMethod) {
      var isNamedList = !Array.isArray(list), initState = {
        index: 0,
        keyedList: isNamedList || sortMethod ? Object.keys(list) : null,
        jobs: {},
        results: isNamedList ? {} : [],
        size: isNamedList ? Object.keys(list).length : list.length
      };
      if (sortMethod) {
        initState.keyedList.sort(isNamedList ? sortMethod : function(a, b) {
          return sortMethod(list[a], list[b]);
        });
      }
      return initState;
    }
  }
});

// node_modules/asynckit/lib/terminator.js
var require_terminator = __commonJS({
  "node_modules/asynckit/lib/terminator.js"(exports, module) {
    var abort = require_abort();
    var async = require_async();
    module.exports = terminator;
    function terminator(callback) {
      if (!Object.keys(this.jobs).length) {
        return;
      }
      this.index = this.size;
      abort(this);
      async(callback)(null, this.results);
    }
  }
});

// node_modules/asynckit/parallel.js
var require_parallel = __commonJS({
  "node_modules/asynckit/parallel.js"(exports, module) {
    var iterate = require_iterate();
    var initState = require_state();
    var terminator = require_terminator();
    module.exports = parallel;
    function parallel(list, iterator, callback) {
      var state = initState(list);
      while (state.index < (state["keyedList"] || list).length) {
        iterate(list, iterator, state, function(error, result) {
          if (error) {
            callback(error, result);
            return;
          }
          if (Object.keys(state.jobs).length === 0) {
            callback(null, state.results);
            return;
          }
        });
        state.index++;
      }
      return terminator.bind(state, callback);
    }
  }
});

// node_modules/asynckit/serialOrdered.js
var require_serialOrdered = __commonJS({
  "node_modules/asynckit/serialOrdered.js"(exports, module) {
    var iterate = require_iterate();
    var initState = require_state();
    var terminator = require_terminator();
    module.exports = serialOrdered;
    module.exports.ascending = ascending;
    module.exports.descending = descending;
    function serialOrdered(list, iterator, sortMethod, callback) {
      var state = initState(list, sortMethod);
      iterate(list, iterator, state, function iteratorHandler(error, result) {
        if (error) {
          callback(error, result);
          return;
        }
        state.index++;
        if (state.index < (state["keyedList"] || list).length) {
          iterate(list, iterator, state, iteratorHandler);
          return;
        }
        callback(null, state.results);
      });
      return terminator.bind(state, callback);
    }
    function ascending(a, b) {
      return a < b ? -1 : a > b ? 1 : 0;
    }
    function descending(a, b) {
      return -1 * ascending(a, b);
    }
  }
});

// node_modules/asynckit/serial.js
var require_serial = __commonJS({
  "node_modules/asynckit/serial.js"(exports, module) {
    var serialOrdered = require_serialOrdered();
    module.exports = serial;
    function serial(list, iterator, callback) {
      return serialOrdered(list, iterator, null, callback);
    }
  }
});

// node_modules/asynckit/index.js
var require_asynckit = __commonJS({
  "node_modules/asynckit/index.js"(exports, module) {
    module.exports = {
      parallel: require_parallel(),
      serial: require_serial(),
      serialOrdered: require_serialOrdered()
    };
  }
});

// node_modules/es-object-atoms/index.js
var require_es_object_atoms = __commonJS({
  "node_modules/es-object-atoms/index.js"(exports, module) {
    "use strict";
    module.exports = Object;
  }
});

// node_modules/es-errors/index.js
var require_es_errors = __commonJS({
  "node_modules/es-errors/index.js"(exports, module) {
    "use strict";
    module.exports = Error;
  }
});

// node_modules/es-errors/eval.js
var require_eval = __commonJS({
  "node_modules/es-errors/eval.js"(exports, module) {
    "use strict";
    module.exports = EvalError;
  }
});

// node_modules/es-errors/range.js
var require_range = __commonJS({
  "node_modules/es-errors/range.js"(exports, module) {
    "use strict";
    module.exports = RangeError;
  }
});

// node_modules/es-errors/ref.js
var require_ref = __commonJS({
  "node_modules/es-errors/ref.js"(exports, module) {
    "use strict";
    module.exports = ReferenceError;
  }
});

// node_modules/es-errors/syntax.js
var require_syntax = __commonJS({
  "node_modules/es-errors/syntax.js"(exports, module) {
    "use strict";
    module.exports = SyntaxError;
  }
});

// node_modules/es-errors/type.js
var require_type = __commonJS({
  "node_modules/es-errors/type.js"(exports, module) {
    "use strict";
    module.exports = TypeError;
  }
});

// node_modules/es-errors/uri.js
var require_uri = __commonJS({
  "node_modules/es-errors/uri.js"(exports, module) {
    "use strict";
    module.exports = URIError;
  }
});

// node_modules/math-intrinsics/abs.js
var require_abs = __commonJS({
  "node_modules/math-intrinsics/abs.js"(exports, module) {
    "use strict";
    module.exports = Math.abs;
  }
});

// node_modules/math-intrinsics/floor.js
var require_floor = __commonJS({
  "node_modules/math-intrinsics/floor.js"(exports, module) {
    "use strict";
    module.exports = Math.floor;
  }
});

// node_modules/math-intrinsics/max.js
var require_max = __commonJS({
  "node_modules/math-intrinsics/max.js"(exports, module) {
    "use strict";
    module.exports = Math.max;
  }
});

// node_modules/math-intrinsics/min.js
var require_min = __commonJS({
  "node_modules/math-intrinsics/min.js"(exports, module) {
    "use strict";
    module.exports = Math.min;
  }
});

// node_modules/math-intrinsics/pow.js
var require_pow = __commonJS({
  "node_modules/math-intrinsics/pow.js"(exports, module) {
    "use strict";
    module.exports = Math.pow;
  }
});

// node_modules/math-intrinsics/round.js
var require_round = __commonJS({
  "node_modules/math-intrinsics/round.js"(exports, module) {
    "use strict";
    module.exports = Math.round;
  }
});

// node_modules/math-intrinsics/isNaN.js
var require_isNaN = __commonJS({
  "node_modules/math-intrinsics/isNaN.js"(exports, module) {
    "use strict";
    module.exports = Number.isNaN || function isNaN2(a) {
      return a !== a;
    };
  }
});

// node_modules/math-intrinsics/sign.js
var require_sign = __commonJS({
  "node_modules/math-intrinsics/sign.js"(exports, module) {
    "use strict";
    var $isNaN = require_isNaN();
    module.exports = function sign(number) {
      if ($isNaN(number) || number === 0) {
        return number;
      }
      return number < 0 ? -1 : 1;
    };
  }
});

// node_modules/gopd/gOPD.js
var require_gOPD = __commonJS({
  "node_modules/gopd/gOPD.js"(exports, module) {
    "use strict";
    module.exports = Object.getOwnPropertyDescriptor;
  }
});

// node_modules/gopd/index.js
var require_gopd = __commonJS({
  "node_modules/gopd/index.js"(exports, module) {
    "use strict";
    var $gOPD = require_gOPD();
    if ($gOPD) {
      try {
        $gOPD([], "length");
      } catch (e) {
        $gOPD = null;
      }
    }
    module.exports = $gOPD;
  }
});

// node_modules/es-define-property/index.js
var require_es_define_property = __commonJS({
  "node_modules/es-define-property/index.js"(exports, module) {
    "use strict";
    var $defineProperty = Object.defineProperty || false;
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e) {
        $defineProperty = false;
      }
    }
    module.exports = $defineProperty;
  }
});

// node_modules/has-symbols/shams.js
var require_shams = __commonJS({
  "node_modules/has-symbols/shams.js"(exports, module) {
    "use strict";
    module.exports = function hasSymbols() {
      if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
        return false;
      }
      if (typeof Symbol.iterator === "symbol") {
        return true;
      }
      var obj = {};
      var sym = /* @__PURE__ */ Symbol("test");
      var symObj = Object(sym);
      if (typeof sym === "string") {
        return false;
      }
      if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
        return false;
      }
      if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
        return false;
      }
      var symVal = 42;
      obj[sym] = symVal;
      for (var _ in obj) {
        return false;
      }
      if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
        return false;
      }
      if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
        return false;
      }
      var syms = Object.getOwnPropertySymbols(obj);
      if (syms.length !== 1 || syms[0] !== sym) {
        return false;
      }
      if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
        return false;
      }
      if (typeof Object.getOwnPropertyDescriptor === "function") {
        var descriptor = (
          /** @type {PropertyDescriptor} */
          Object.getOwnPropertyDescriptor(obj, sym)
        );
        if (descriptor.value !== symVal || descriptor.enumerable !== true) {
          return false;
        }
      }
      return true;
    };
  }
});

// node_modules/has-symbols/index.js
var require_has_symbols = __commonJS({
  "node_modules/has-symbols/index.js"(exports, module) {
    "use strict";
    var origSymbol = typeof Symbol !== "undefined" && Symbol;
    var hasSymbolSham = require_shams();
    module.exports = function hasNativeSymbols() {
      if (typeof origSymbol !== "function") {
        return false;
      }
      if (typeof Symbol !== "function") {
        return false;
      }
      if (typeof origSymbol("foo") !== "symbol") {
        return false;
      }
      if (typeof /* @__PURE__ */ Symbol("bar") !== "symbol") {
        return false;
      }
      return hasSymbolSham();
    };
  }
});

// node_modules/get-proto/Reflect.getPrototypeOf.js
var require_Reflect_getPrototypeOf = __commonJS({
  "node_modules/get-proto/Reflect.getPrototypeOf.js"(exports, module) {
    "use strict";
    module.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
  }
});

// node_modules/get-proto/Object.getPrototypeOf.js
var require_Object_getPrototypeOf = __commonJS({
  "node_modules/get-proto/Object.getPrototypeOf.js"(exports, module) {
    "use strict";
    var $Object = require_es_object_atoms();
    module.exports = $Object.getPrototypeOf || null;
  }
});

// node_modules/function-bind/implementation.js
var require_implementation = __commonJS({
  "node_modules/function-bind/implementation.js"(exports, module) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var toStr = Object.prototype.toString;
    var max = Math.max;
    var funcType = "[object Function]";
    var concatty = function concatty2(a, b) {
      var arr = [];
      for (var i = 0; i < a.length; i += 1) {
        arr[i] = a[i];
      }
      for (var j = 0; j < b.length; j += 1) {
        arr[j + a.length] = b[j];
      }
      return arr;
    };
    var slicy = function slicy2(arrLike, offset) {
      var arr = [];
      for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) {
        arr[j] = arrLike[i];
      }
      return arr;
    };
    var joiny = function(arr, joiner) {
      var str = "";
      for (var i = 0; i < arr.length; i += 1) {
        str += arr[i];
        if (i + 1 < arr.length) {
          str += joiner;
        }
      }
      return str;
    };
    module.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.apply(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slicy(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(
            this,
            concatty(args, arguments)
          );
          if (Object(result) === result) {
            return result;
          }
          return this;
        }
        return target.apply(
          that,
          concatty(args, arguments)
        );
      };
      var boundLength = max(0, target.length - args.length);
      var boundArgs = [];
      for (var i = 0; i < boundLength; i++) {
        boundArgs[i] = "$" + i;
      }
      bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "node_modules/function-bind/index.js"(exports, module) {
    "use strict";
    var implementation = require_implementation();
    module.exports = Function.prototype.bind || implementation;
  }
});

// node_modules/call-bind-apply-helpers/functionCall.js
var require_functionCall = __commonJS({
  "node_modules/call-bind-apply-helpers/functionCall.js"(exports, module) {
    "use strict";
    module.exports = Function.prototype.call;
  }
});

// node_modules/call-bind-apply-helpers/functionApply.js
var require_functionApply = __commonJS({
  "node_modules/call-bind-apply-helpers/functionApply.js"(exports, module) {
    "use strict";
    module.exports = Function.prototype.apply;
  }
});

// node_modules/call-bind-apply-helpers/reflectApply.js
var require_reflectApply = __commonJS({
  "node_modules/call-bind-apply-helpers/reflectApply.js"(exports, module) {
    "use strict";
    module.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
  }
});

// node_modules/call-bind-apply-helpers/actualApply.js
var require_actualApply = __commonJS({
  "node_modules/call-bind-apply-helpers/actualApply.js"(exports, module) {
    "use strict";
    var bind = require_function_bind();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var $reflectApply = require_reflectApply();
    module.exports = $reflectApply || bind.call($call, $apply);
  }
});

// node_modules/call-bind-apply-helpers/index.js
var require_call_bind_apply_helpers = __commonJS({
  "node_modules/call-bind-apply-helpers/index.js"(exports, module) {
    "use strict";
    var bind = require_function_bind();
    var $TypeError = require_type();
    var $call = require_functionCall();
    var $actualApply = require_actualApply();
    module.exports = function callBindBasic(args) {
      if (args.length < 1 || typeof args[0] !== "function") {
        throw new $TypeError("a function is required");
      }
      return $actualApply(bind, $call, args);
    };
  }
});

// node_modules/dunder-proto/get.js
var require_get = __commonJS({
  "node_modules/dunder-proto/get.js"(exports, module) {
    "use strict";
    var callBind = require_call_bind_apply_helpers();
    var gOPD = require_gopd();
    var hasProtoAccessor;
    try {
      hasProtoAccessor = /** @type {{ __proto__?: typeof Array.prototype }} */
      [].__proto__ === Array.prototype;
    } catch (e) {
      if (!e || typeof e !== "object" || !("code" in e) || e.code !== "ERR_PROTO_ACCESS") {
        throw e;
      }
    }
    var desc = !!hasProtoAccessor && gOPD && gOPD(
      Object.prototype,
      /** @type {keyof typeof Object.prototype} */
      "__proto__"
    );
    var $Object = Object;
    var $getPrototypeOf = $Object.getPrototypeOf;
    module.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? (
      /** @type {import('./get')} */
      function getDunder(value) {
        return $getPrototypeOf(value == null ? value : $Object(value));
      }
    ) : false;
  }
});

// node_modules/get-proto/index.js
var require_get_proto = __commonJS({
  "node_modules/get-proto/index.js"(exports, module) {
    "use strict";
    var reflectGetProto = require_Reflect_getPrototypeOf();
    var originalGetProto = require_Object_getPrototypeOf();
    var getDunderProto = require_get();
    module.exports = reflectGetProto ? function getProto(O) {
      return reflectGetProto(O);
    } : originalGetProto ? function getProto(O) {
      if (!O || typeof O !== "object" && typeof O !== "function") {
        throw new TypeError("getProto: not an object");
      }
      return originalGetProto(O);
    } : getDunderProto ? function getProto(O) {
      return getDunderProto(O);
    } : null;
  }
});

// node_modules/hasown/index.js
var require_hasown = __commonJS({
  "node_modules/hasown/index.js"(exports, module) {
    "use strict";
    var call = Function.prototype.call;
    var $hasOwn = Object.prototype.hasOwnProperty;
    var bind = require_function_bind();
    module.exports = bind.call(call, $hasOwn);
  }
});

// node_modules/get-intrinsic/index.js
var require_get_intrinsic = __commonJS({
  "node_modules/get-intrinsic/index.js"(exports, module) {
    "use strict";
    var undefined2;
    var $Object = require_es_object_atoms();
    var $Error = require_es_errors();
    var $EvalError = require_eval();
    var $RangeError = require_range();
    var $ReferenceError = require_ref();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var $URIError = require_uri();
    var abs = require_abs();
    var floor = require_floor();
    var max = require_max();
    var min = require_min();
    var pow = require_pow();
    var round = require_round();
    var sign = require_sign();
    var $Function = Function;
    var getEvalledConstructor = function(expressionSyntax) {
      try {
        return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
      } catch (e) {
      }
    };
    var $gOPD = require_gopd();
    var $defineProperty = require_es_define_property();
    var throwTypeError = function() {
      throw new $TypeError();
    };
    var ThrowTypeError = $gOPD ? (function() {
      try {
        arguments.callee;
        return throwTypeError;
      } catch (calleeThrows) {
        try {
          return $gOPD(arguments, "callee").get;
        } catch (gOPDthrows) {
          return throwTypeError;
        }
      }
    })() : throwTypeError;
    var hasSymbols = require_has_symbols()();
    var getProto = require_get_proto();
    var $ObjectGPO = require_Object_getPrototypeOf();
    var $ReflectGPO = require_Reflect_getPrototypeOf();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var needsEval = {};
    var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
    var INTRINSICS = {
      __proto__: null,
      "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
      "%Array%": Array,
      "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
      "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
      "%AsyncFromSyncIteratorPrototype%": undefined2,
      "%AsyncFunction%": needsEval,
      "%AsyncGenerator%": needsEval,
      "%AsyncGeneratorFunction%": needsEval,
      "%AsyncIteratorPrototype%": needsEval,
      "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
      "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
      "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
      "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
      "%Boolean%": Boolean,
      "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
      "%Date%": Date,
      "%decodeURI%": decodeURI,
      "%decodeURIComponent%": decodeURIComponent,
      "%encodeURI%": encodeURI,
      "%encodeURIComponent%": encodeURIComponent,
      "%Error%": $Error,
      "%eval%": eval,
      // eslint-disable-line no-eval
      "%EvalError%": $EvalError,
      "%Float16Array%": typeof Float16Array === "undefined" ? undefined2 : Float16Array,
      "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
      "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
      "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
      "%Function%": $Function,
      "%GeneratorFunction%": needsEval,
      "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
      "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
      "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
      "%isFinite%": isFinite,
      "%isNaN%": isNaN,
      "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
      "%JSON%": typeof JSON === "object" ? JSON : undefined2,
      "%Map%": typeof Map === "undefined" ? undefined2 : Map,
      "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
      "%Math%": Math,
      "%Number%": Number,
      "%Object%": $Object,
      "%Object.getOwnPropertyDescriptor%": $gOPD,
      "%parseFloat%": parseFloat,
      "%parseInt%": parseInt,
      "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
      "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
      "%RangeError%": $RangeError,
      "%ReferenceError%": $ReferenceError,
      "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
      "%RegExp%": RegExp,
      "%Set%": typeof Set === "undefined" ? undefined2 : Set,
      "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
      "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
      "%String%": String,
      "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
      "%Symbol%": hasSymbols ? Symbol : undefined2,
      "%SyntaxError%": $SyntaxError,
      "%ThrowTypeError%": ThrowTypeError,
      "%TypedArray%": TypedArray,
      "%TypeError%": $TypeError,
      "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
      "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
      "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
      "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
      "%URIError%": $URIError,
      "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
      "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
      "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet,
      "%Function.prototype.call%": $call,
      "%Function.prototype.apply%": $apply,
      "%Object.defineProperty%": $defineProperty,
      "%Object.getPrototypeOf%": $ObjectGPO,
      "%Math.abs%": abs,
      "%Math.floor%": floor,
      "%Math.max%": max,
      "%Math.min%": min,
      "%Math.pow%": pow,
      "%Math.round%": round,
      "%Math.sign%": sign,
      "%Reflect.getPrototypeOf%": $ReflectGPO
    };
    if (getProto) {
      try {
        null.error;
      } catch (e) {
        errorProto = getProto(getProto(e));
        INTRINSICS["%Error.prototype%"] = errorProto;
      }
    }
    var errorProto;
    var doEval = function doEval2(name) {
      var value;
      if (name === "%AsyncFunction%") {
        value = getEvalledConstructor("async function () {}");
      } else if (name === "%GeneratorFunction%") {
        value = getEvalledConstructor("function* () {}");
      } else if (name === "%AsyncGeneratorFunction%") {
        value = getEvalledConstructor("async function* () {}");
      } else if (name === "%AsyncGenerator%") {
        var fn = doEval2("%AsyncGeneratorFunction%");
        if (fn) {
          value = fn.prototype;
        }
      } else if (name === "%AsyncIteratorPrototype%") {
        var gen = doEval2("%AsyncGenerator%");
        if (gen && getProto) {
          value = getProto(gen.prototype);
        }
      }
      INTRINSICS[name] = value;
      return value;
    };
    var LEGACY_ALIASES = {
      __proto__: null,
      "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
      "%ArrayPrototype%": ["Array", "prototype"],
      "%ArrayProto_entries%": ["Array", "prototype", "entries"],
      "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
      "%ArrayProto_keys%": ["Array", "prototype", "keys"],
      "%ArrayProto_values%": ["Array", "prototype", "values"],
      "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
      "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
      "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
      "%BooleanPrototype%": ["Boolean", "prototype"],
      "%DataViewPrototype%": ["DataView", "prototype"],
      "%DatePrototype%": ["Date", "prototype"],
      "%ErrorPrototype%": ["Error", "prototype"],
      "%EvalErrorPrototype%": ["EvalError", "prototype"],
      "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
      "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
      "%FunctionPrototype%": ["Function", "prototype"],
      "%Generator%": ["GeneratorFunction", "prototype"],
      "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
      "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
      "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
      "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
      "%JSONParse%": ["JSON", "parse"],
      "%JSONStringify%": ["JSON", "stringify"],
      "%MapPrototype%": ["Map", "prototype"],
      "%NumberPrototype%": ["Number", "prototype"],
      "%ObjectPrototype%": ["Object", "prototype"],
      "%ObjProto_toString%": ["Object", "prototype", "toString"],
      "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
      "%PromisePrototype%": ["Promise", "prototype"],
      "%PromiseProto_then%": ["Promise", "prototype", "then"],
      "%Promise_all%": ["Promise", "all"],
      "%Promise_reject%": ["Promise", "reject"],
      "%Promise_resolve%": ["Promise", "resolve"],
      "%RangeErrorPrototype%": ["RangeError", "prototype"],
      "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
      "%RegExpPrototype%": ["RegExp", "prototype"],
      "%SetPrototype%": ["Set", "prototype"],
      "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
      "%StringPrototype%": ["String", "prototype"],
      "%SymbolPrototype%": ["Symbol", "prototype"],
      "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
      "%TypedArrayPrototype%": ["TypedArray", "prototype"],
      "%TypeErrorPrototype%": ["TypeError", "prototype"],
      "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
      "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
      "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
      "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
      "%URIErrorPrototype%": ["URIError", "prototype"],
      "%WeakMapPrototype%": ["WeakMap", "prototype"],
      "%WeakSetPrototype%": ["WeakSet", "prototype"]
    };
    var bind = require_function_bind();
    var hasOwn = require_hasown();
    var $concat = bind.call($call, Array.prototype.concat);
    var $spliceApply = bind.call($apply, Array.prototype.splice);
    var $replace = bind.call($call, String.prototype.replace);
    var $strSlice = bind.call($call, String.prototype.slice);
    var $exec = bind.call($call, RegExp.prototype.exec);
    var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
    var reEscapeChar = /\\(\\)?/g;
    var stringToPath = function stringToPath2(string) {
      var first = $strSlice(string, 0, 1);
      var last = $strSlice(string, -1);
      if (first === "%" && last !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
      } else if (last === "%" && first !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
      }
      var result = [];
      $replace(string, rePropName, function(match, number, quote, subString) {
        result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
      });
      return result;
    };
    var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
      var intrinsicName = name;
      var alias;
      if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
        alias = LEGACY_ALIASES[intrinsicName];
        intrinsicName = "%" + alias[0] + "%";
      }
      if (hasOwn(INTRINSICS, intrinsicName)) {
        var value = INTRINSICS[intrinsicName];
        if (value === needsEval) {
          value = doEval(intrinsicName);
        }
        if (typeof value === "undefined" && !allowMissing) {
          throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
        }
        return {
          alias,
          name: intrinsicName,
          value
        };
      }
      throw new $SyntaxError("intrinsic " + name + " does not exist!");
    };
    module.exports = function GetIntrinsic(name, allowMissing) {
      if (typeof name !== "string" || name.length === 0) {
        throw new $TypeError("intrinsic name must be a non-empty string");
      }
      if (arguments.length > 1 && typeof allowMissing !== "boolean") {
        throw new $TypeError('"allowMissing" argument must be a boolean');
      }
      if ($exec(/^%?[^%]*%?$/, name) === null) {
        throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
      }
      var parts = stringToPath(name);
      var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
      var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
      var intrinsicRealName = intrinsic.name;
      var value = intrinsic.value;
      var skipFurtherCaching = false;
      var alias = intrinsic.alias;
      if (alias) {
        intrinsicBaseName = alias[0];
        $spliceApply(parts, $concat([0, 1], alias));
      }
      for (var i = 1, isOwn = true; i < parts.length; i += 1) {
        var part = parts[i];
        var first = $strSlice(part, 0, 1);
        var last = $strSlice(part, -1);
        if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
          throw new $SyntaxError("property names with quotes must have matching quotes");
        }
        if (part === "constructor" || !isOwn) {
          skipFurtherCaching = true;
        }
        intrinsicBaseName += "." + part;
        intrinsicRealName = "%" + intrinsicBaseName + "%";
        if (hasOwn(INTRINSICS, intrinsicRealName)) {
          value = INTRINSICS[intrinsicRealName];
        } else if (value != null) {
          if (!(part in value)) {
            if (!allowMissing) {
              throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
            }
            return void undefined2;
          }
          if ($gOPD && i + 1 >= parts.length) {
            var desc = $gOPD(value, part);
            isOwn = !!desc;
            if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
              value = desc.get;
            } else {
              value = value[part];
            }
          } else {
            isOwn = hasOwn(value, part);
            value = value[part];
          }
          if (isOwn && !skipFurtherCaching) {
            INTRINSICS[intrinsicRealName] = value;
          }
        }
      }
      return value;
    };
  }
});

// node_modules/has-tostringtag/shams.js
var require_shams2 = __commonJS({
  "node_modules/has-tostringtag/shams.js"(exports, module) {
    "use strict";
    var hasSymbols = require_shams();
    module.exports = function hasToStringTagShams() {
      return hasSymbols() && !!Symbol.toStringTag;
    };
  }
});

// node_modules/es-set-tostringtag/index.js
var require_es_set_tostringtag = __commonJS({
  "node_modules/es-set-tostringtag/index.js"(exports, module) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $defineProperty = GetIntrinsic("%Object.defineProperty%", true);
    var hasToStringTag = require_shams2()();
    var hasOwn = require_hasown();
    var $TypeError = require_type();
    var toStringTag = hasToStringTag ? Symbol.toStringTag : null;
    module.exports = function setToStringTag(object, value) {
      var overrideIfSet = arguments.length > 2 && !!arguments[2] && arguments[2].force;
      var nonConfigurable = arguments.length > 2 && !!arguments[2] && arguments[2].nonConfigurable;
      if (typeof overrideIfSet !== "undefined" && typeof overrideIfSet !== "boolean" || typeof nonConfigurable !== "undefined" && typeof nonConfigurable !== "boolean") {
        throw new $TypeError("if provided, the `overrideIfSet` and `nonConfigurable` options must be booleans");
      }
      if (toStringTag && (overrideIfSet || !hasOwn(object, toStringTag))) {
        if ($defineProperty) {
          $defineProperty(object, toStringTag, {
            configurable: !nonConfigurable,
            enumerable: false,
            value,
            writable: false
          });
        } else {
          object[toStringTag] = value;
        }
      }
    };
  }
});

// node_modules/form-data/lib/populate.js
var require_populate = __commonJS({
  "node_modules/form-data/lib/populate.js"(exports, module) {
    "use strict";
    module.exports = function(dst, src) {
      Object.keys(src).forEach(function(prop) {
        dst[prop] = dst[prop] || src[prop];
      });
      return dst;
    };
  }
});

// node_modules/form-data/lib/form_data.js
var require_form_data = __commonJS({
  "node_modules/form-data/lib/form_data.js"(exports, module) {
    "use strict";
    var CombinedStream = require_combined_stream();
    var util = __require("util");
    var path6 = __require("path");
    var http2 = __require("http");
    var https = __require("https");
    var parseUrl = __require("url").parse;
    var fs6 = __require("fs");
    var Stream = __require("stream").Stream;
    var crypto3 = __require("crypto");
    var mime = require_mime_types();
    var asynckit = require_asynckit();
    var setToStringTag = require_es_set_tostringtag();
    var hasOwn = require_hasown();
    var populate = require_populate();
    function escapeHeaderParam(str) {
      return String(str).replace(/\r/g, "%0D").replace(/\n/g, "%0A").replace(/"/g, "%22");
    }
    function FormData2(options) {
      if (!(this instanceof FormData2)) {
        return new FormData2(options);
      }
      this._overheadLength = 0;
      this._valueLength = 0;
      this._valuesToMeasure = [];
      CombinedStream.call(this);
      options = options || {};
      for (var option in options) {
        this[option] = options[option];
      }
    }
    util.inherits(FormData2, CombinedStream);
    FormData2.LINE_BREAK = "\r\n";
    FormData2.DEFAULT_CONTENT_TYPE = "application/octet-stream";
    FormData2.prototype.append = function(field, value, options) {
      options = options || {};
      if (typeof options === "string") {
        options = { filename: options };
      }
      var append = CombinedStream.prototype.append.bind(this);
      if (typeof value === "number" || value == null) {
        value = String(value);
      }
      if (Array.isArray(value)) {
        this._error(new Error("Arrays are not supported."));
        return;
      }
      var header = this._multiPartHeader(field, value, options);
      var footer = this._multiPartFooter();
      append(header);
      append(value);
      append(footer);
      this._trackLength(header, value, options);
    };
    FormData2.prototype._trackLength = function(header, value, options) {
      var valueLength = 0;
      if (options.knownLength != null) {
        valueLength += Number(options.knownLength);
      } else if (Buffer.isBuffer(value)) {
        valueLength = value.length;
      } else if (typeof value === "string") {
        valueLength = Buffer.byteLength(value);
      }
      this._valueLength += valueLength;
      this._overheadLength += Buffer.byteLength(header) + FormData2.LINE_BREAK.length;
      if (!value || !value.path && !(value.readable && hasOwn(value, "httpVersion")) && !(value instanceof Stream)) {
        return;
      }
      if (!options.knownLength) {
        this._valuesToMeasure.push(value);
      }
    };
    FormData2.prototype._lengthRetriever = function(value, callback) {
      if (hasOwn(value, "fd")) {
        if (value.end != void 0 && value.end != Infinity && value.start != void 0) {
          callback(null, value.end + 1 - (value.start ? value.start : 0));
        } else {
          fs6.stat(value.path, function(err, stat) {
            if (err) {
              callback(err);
              return;
            }
            var fileSize = stat.size - (value.start ? value.start : 0);
            callback(null, fileSize);
          });
        }
      } else if (hasOwn(value, "httpVersion")) {
        callback(null, Number(value.headers["content-length"]));
      } else if (hasOwn(value, "httpModule")) {
        value.on("response", function(response) {
          value.pause();
          callback(null, Number(response.headers["content-length"]));
        });
        value.resume();
      } else {
        callback("Unknown stream");
      }
    };
    FormData2.prototype._multiPartHeader = function(field, value, options) {
      if (typeof options.header === "string") {
        return options.header;
      }
      var contentDisposition = this._getContentDisposition(value, options);
      var contentType = this._getContentType(value, options);
      var contents = "";
      var headers = {
        // add custom disposition as third element or keep it two elements if not
        "Content-Disposition": ["form-data", 'name="' + escapeHeaderParam(field) + '"'].concat(contentDisposition || []),
        // if no content type. allow it to be empty array
        "Content-Type": [].concat(contentType || [])
      };
      if (typeof options.header === "object") {
        populate(headers, options.header);
      }
      var header;
      for (var prop in headers) {
        if (hasOwn(headers, prop)) {
          header = headers[prop];
          if (header == null) {
            continue;
          }
          if (!Array.isArray(header)) {
            header = [header];
          }
          if (header.length) {
            contents += prop + ": " + header.join("; ") + FormData2.LINE_BREAK;
          }
        }
      }
      return "--" + this.getBoundary() + FormData2.LINE_BREAK + contents + FormData2.LINE_BREAK;
    };
    FormData2.prototype._getContentDisposition = function(value, options) {
      var filename;
      if (typeof options.filepath === "string") {
        filename = path6.normalize(options.filepath).replace(/\\/g, "/");
      } else if (options.filename || value && (value.name || value.path)) {
        filename = path6.basename(options.filename || value && (value.name || value.path));
      } else if (value && value.readable && hasOwn(value, "httpVersion")) {
        filename = path6.basename(value.client._httpMessage.path || "");
      }
      if (filename) {
        return 'filename="' + escapeHeaderParam(filename) + '"';
      }
    };
    FormData2.prototype._getContentType = function(value, options) {
      var contentType = options.contentType;
      if (!contentType && value && value.name) {
        contentType = mime.lookup(value.name);
      }
      if (!contentType && value && value.path) {
        contentType = mime.lookup(value.path);
      }
      if (!contentType && value && value.readable && hasOwn(value, "httpVersion")) {
        contentType = value.headers["content-type"];
      }
      if (!contentType && (options.filepath || options.filename)) {
        contentType = mime.lookup(options.filepath || options.filename);
      }
      if (!contentType && value && typeof value === "object") {
        contentType = FormData2.DEFAULT_CONTENT_TYPE;
      }
      return contentType;
    };
    FormData2.prototype._multiPartFooter = function() {
      return function(next) {
        var footer = FormData2.LINE_BREAK;
        var lastPart = this._streams.length === 0;
        if (lastPart) {
          footer += this._lastBoundary();
        }
        next(footer);
      }.bind(this);
    };
    FormData2.prototype._lastBoundary = function() {
      return "--" + this.getBoundary() + "--" + FormData2.LINE_BREAK;
    };
    FormData2.prototype.getHeaders = function(userHeaders) {
      var header;
      var formHeaders = {
        "content-type": "multipart/form-data; boundary=" + this.getBoundary()
      };
      for (header in userHeaders) {
        if (hasOwn(userHeaders, header)) {
          formHeaders[header.toLowerCase()] = userHeaders[header];
        }
      }
      return formHeaders;
    };
    FormData2.prototype.setBoundary = function(boundary) {
      if (typeof boundary !== "string") {
        throw new TypeError("FormData boundary must be a string");
      }
      this._boundary = boundary;
    };
    FormData2.prototype.getBoundary = function() {
      if (!this._boundary) {
        this._generateBoundary();
      }
      return this._boundary;
    };
    FormData2.prototype.getBuffer = function() {
      var dataBuffer = new Buffer.alloc(0);
      var boundary = this.getBoundary();
      for (var i = 0, len = this._streams.length; i < len; i++) {
        if (typeof this._streams[i] !== "function") {
          if (Buffer.isBuffer(this._streams[i])) {
            dataBuffer = Buffer.concat([dataBuffer, this._streams[i]]);
          } else {
            dataBuffer = Buffer.concat([dataBuffer, Buffer.from(this._streams[i])]);
          }
          if (typeof this._streams[i] !== "string" || this._streams[i].substring(2, boundary.length + 2) !== boundary) {
            dataBuffer = Buffer.concat([dataBuffer, Buffer.from(FormData2.LINE_BREAK)]);
          }
        }
      }
      return Buffer.concat([dataBuffer, Buffer.from(this._lastBoundary())]);
    };
    FormData2.prototype._generateBoundary = function() {
      this._boundary = "--------------------------" + crypto3.randomBytes(12).toString("hex");
    };
    FormData2.prototype.getLengthSync = function() {
      var knownLength = this._overheadLength + this._valueLength;
      if (this._streams.length) {
        knownLength += this._lastBoundary().length;
      }
      if (!this.hasKnownLength()) {
        this._error(new Error("Cannot calculate proper length in synchronous way."));
      }
      return knownLength;
    };
    FormData2.prototype.hasKnownLength = function() {
      var hasKnownLength = true;
      if (this._valuesToMeasure.length) {
        hasKnownLength = false;
      }
      return hasKnownLength;
    };
    FormData2.prototype.getLength = function(cb) {
      var knownLength = this._overheadLength + this._valueLength;
      if (this._streams.length) {
        knownLength += this._lastBoundary().length;
      }
      if (!this._valuesToMeasure.length) {
        process.nextTick(cb.bind(this, null, knownLength));
        return;
      }
      asynckit.parallel(this._valuesToMeasure, this._lengthRetriever, function(err, values) {
        if (err) {
          cb(err);
          return;
        }
        values.forEach(function(length) {
          knownLength += length;
        });
        cb(null, knownLength);
      });
    };
    FormData2.prototype.submit = function(params, cb) {
      var request;
      var options;
      var defaults = { method: "post" };
      if (typeof params === "string") {
        params = parseUrl(params);
        options = populate({
          port: params.port,
          path: params.pathname,
          host: params.hostname,
          protocol: params.protocol
        }, defaults);
      } else {
        options = populate(params, defaults);
        if (!options.port) {
          options.port = options.protocol === "https:" ? 443 : 80;
        }
      }
      options.headers = this.getHeaders(params.headers);
      if (options.protocol === "https:") {
        request = https.request(options);
      } else {
        request = http2.request(options);
      }
      this.getLength(function(err, length) {
        if (err && err !== "Unknown stream") {
          this._error(err);
          return;
        }
        if (length) {
          request.setHeader("Content-Length", length);
        }
        this.pipe(request);
        if (cb) {
          var onResponse;
          var callback = function(error, responce) {
            request.removeListener("error", callback);
            request.removeListener("response", onResponse);
            return cb.call(this, error, responce);
          };
          onResponse = callback.bind(this, null);
          request.on("error", callback);
          request.on("response", onResponse);
        }
      }.bind(this));
      return request;
    };
    FormData2.prototype._error = function(err) {
      if (!this.error) {
        this.error = err;
        this.pause();
        this.emit("error", err);
      }
    };
    FormData2.prototype.toString = function() {
      return "[object FormData]";
    };
    setToStringTag(FormData2.prototype, "FormData");
    module.exports = FormData2;
  }
});

// node_modules/ms/index.js
var require_ms = __commonJS({
  "node_modules/ms/index.js"(exports, module) {
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var w = d * 7;
    var y = d * 365.25;
    module.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse(val);
      } else if (type === "number" && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error(
        "val is not a non-empty string or a valid number. val=" + JSON.stringify(val)
      );
    };
    function parse(str) {
      str = String(str);
      if (str.length > 100) {
        return;
      }
      var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
        str
      );
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "weeks":
        case "week":
        case "w":
          return n * w;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    function fmtShort(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return Math.round(ms / d) + "d";
      }
      if (msAbs >= h) {
        return Math.round(ms / h) + "h";
      }
      if (msAbs >= m) {
        return Math.round(ms / m) + "m";
      }
      if (msAbs >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    function fmtLong(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return plural(ms, msAbs, d, "day");
      }
      if (msAbs >= h) {
        return plural(ms, msAbs, h, "hour");
      }
      if (msAbs >= m) {
        return plural(ms, msAbs, m, "minute");
      }
      if (msAbs >= s) {
        return plural(ms, msAbs, s, "second");
      }
      return ms + " ms";
    }
    function plural(ms, msAbs, n, name) {
      var isPlural = msAbs >= n * 1.5;
      return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
    }
  }
});

// node_modules/debug/src/common.js
var require_common = __commonJS({
  "node_modules/debug/src/common.js"(exports, module) {
    function setup(env) {
      createDebug.debug = createDebug;
      createDebug.default = createDebug;
      createDebug.coerce = coerce;
      createDebug.disable = disable;
      createDebug.enable = enable;
      createDebug.enabled = enabled;
      createDebug.humanize = require_ms();
      createDebug.destroy = destroy;
      Object.keys(env).forEach((key) => {
        createDebug[key] = env[key];
      });
      createDebug.names = [];
      createDebug.skips = [];
      createDebug.formatters = {};
      function selectColor(namespace) {
        let hash = 0;
        for (let i = 0; i < namespace.length; i++) {
          hash = (hash << 5) - hash + namespace.charCodeAt(i);
          hash |= 0;
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
      }
      createDebug.selectColor = selectColor;
      function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug(...args) {
          if (!debug.enabled) {
            return;
          }
          const self2 = debug;
          const curr = Number(/* @__PURE__ */ new Date());
          const ms = curr - (prevTime || curr);
          self2.diff = ms;
          self2.prev = prevTime;
          self2.curr = curr;
          prevTime = curr;
          args[0] = createDebug.coerce(args[0]);
          if (typeof args[0] !== "string") {
            args.unshift("%O");
          }
          let index = 0;
          args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
            if (match === "%%") {
              return "%";
            }
            index++;
            const formatter = createDebug.formatters[format];
            if (typeof formatter === "function") {
              const val = args[index];
              match = formatter.call(self2, val);
              args.splice(index, 1);
              index--;
            }
            return match;
          });
          createDebug.formatArgs.call(self2, args);
          const logFn = self2.log || createDebug.log;
          logFn.apply(self2, args);
        }
        debug.namespace = namespace;
        debug.useColors = createDebug.useColors();
        debug.color = createDebug.selectColor(namespace);
        debug.extend = extend;
        debug.destroy = createDebug.destroy;
        Object.defineProperty(debug, "enabled", {
          enumerable: true,
          configurable: false,
          get: () => {
            if (enableOverride !== null) {
              return enableOverride;
            }
            if (namespacesCache !== createDebug.namespaces) {
              namespacesCache = createDebug.namespaces;
              enabledCache = createDebug.enabled(namespace);
            }
            return enabledCache;
          },
          set: (v) => {
            enableOverride = v;
          }
        });
        if (typeof createDebug.init === "function") {
          createDebug.init(debug);
        }
        return debug;
      }
      function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
      }
      function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        const split = (typeof namespaces === "string" ? namespaces : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
        for (const ns of split) {
          if (ns[0] === "-") {
            createDebug.skips.push(ns.slice(1));
          } else {
            createDebug.names.push(ns);
          }
        }
      }
      function matchesTemplate(search, template) {
        let searchIndex = 0;
        let templateIndex = 0;
        let starIndex = -1;
        let matchIndex = 0;
        while (searchIndex < search.length) {
          if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === "*")) {
            if (template[templateIndex] === "*") {
              starIndex = templateIndex;
              matchIndex = searchIndex;
              templateIndex++;
            } else {
              searchIndex++;
              templateIndex++;
            }
          } else if (starIndex !== -1) {
            templateIndex = starIndex + 1;
            matchIndex++;
            searchIndex = matchIndex;
          } else {
            return false;
          }
        }
        while (templateIndex < template.length && template[templateIndex] === "*") {
          templateIndex++;
        }
        return templateIndex === template.length;
      }
      function disable() {
        const namespaces = [
          ...createDebug.names,
          ...createDebug.skips.map((namespace) => "-" + namespace)
        ].join(",");
        createDebug.enable("");
        return namespaces;
      }
      function enabled(name) {
        for (const skip of createDebug.skips) {
          if (matchesTemplate(name, skip)) {
            return false;
          }
        }
        for (const ns of createDebug.names) {
          if (matchesTemplate(name, ns)) {
            return true;
          }
        }
        return false;
      }
      function coerce(val) {
        if (val instanceof Error) {
          return val.stack || val.message;
        }
        return val;
      }
      function destroy() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      createDebug.enable(createDebug.load());
      return createDebug;
    }
    module.exports = setup;
  }
});

// node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "node_modules/debug/src/browser.js"(exports, module) {
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.storage = localstorage();
    exports.destroy = /* @__PURE__ */ (() => {
      let warned = false;
      return () => {
        if (!warned) {
          warned = true;
          console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
        }
      };
    })();
    exports.colors = [
      "#0000CC",
      "#0000FF",
      "#0033CC",
      "#0033FF",
      "#0066CC",
      "#0066FF",
      "#0099CC",
      "#0099FF",
      "#00CC00",
      "#00CC33",
      "#00CC66",
      "#00CC99",
      "#00CCCC",
      "#00CCFF",
      "#3300CC",
      "#3300FF",
      "#3333CC",
      "#3333FF",
      "#3366CC",
      "#3366FF",
      "#3399CC",
      "#3399FF",
      "#33CC00",
      "#33CC33",
      "#33CC66",
      "#33CC99",
      "#33CCCC",
      "#33CCFF",
      "#6600CC",
      "#6600FF",
      "#6633CC",
      "#6633FF",
      "#66CC00",
      "#66CC33",
      "#9900CC",
      "#9900FF",
      "#9933CC",
      "#9933FF",
      "#99CC00",
      "#99CC33",
      "#CC0000",
      "#CC0033",
      "#CC0066",
      "#CC0099",
      "#CC00CC",
      "#CC00FF",
      "#CC3300",
      "#CC3333",
      "#CC3366",
      "#CC3399",
      "#CC33CC",
      "#CC33FF",
      "#CC6600",
      "#CC6633",
      "#CC9900",
      "#CC9933",
      "#CCCC00",
      "#CCCC33",
      "#FF0000",
      "#FF0033",
      "#FF0066",
      "#FF0099",
      "#FF00CC",
      "#FF00FF",
      "#FF3300",
      "#FF3333",
      "#FF3366",
      "#FF3399",
      "#FF33CC",
      "#FF33FF",
      "#FF6600",
      "#FF6633",
      "#FF9900",
      "#FF9933",
      "#FFCC00",
      "#FFCC33"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) {
        return true;
      }
      if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
      }
      let m;
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || // Is firebug? http://stackoverflow.com/a/398120/376773
      typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || // Is firefox >= v31?
      // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
      typeof navigator !== "undefined" && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || // Double check webkit in userAgent just in case we are in a worker
      typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    function formatArgs(args) {
      args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
      if (!this.useColors) {
        return;
      }
      const c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      let index = 0;
      let lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, (match) => {
        if (match === "%%") {
          return;
        }
        index++;
        if (match === "%c") {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    exports.log = console.debug || console.log || (() => {
    });
    function save(namespaces) {
      try {
        if (namespaces) {
          exports.storage.setItem("debug", namespaces);
        } else {
          exports.storage.removeItem("debug");
        }
      } catch (error) {
      }
    }
    function load() {
      let r;
      try {
        r = exports.storage.getItem("debug") || exports.storage.getItem("DEBUG");
      } catch (error) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    function localstorage() {
      try {
        return localStorage;
      } catch (error) {
      }
    }
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (error) {
        return "[UnexpectedJSONParseError]: " + error.message;
      }
    };
  }
});

// node_modules/debug/src/node.js
var require_node = __commonJS({
  "node_modules/debug/src/node.js"(exports, module) {
    var tty = __require("tty");
    var util = __require("util");
    exports.init = init;
    exports.log = log;
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.destroy = util.deprecate(
      () => {
      },
      "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."
    );
    exports.colors = [6, 2, 3, 4, 5, 1];
    try {
      const supportsColor = __require("supports-color");
      if (supportsColor && (supportsColor.stderr || supportsColor).level >= 2) {
        exports.colors = [
          20,
          21,
          26,
          27,
          32,
          33,
          38,
          39,
          40,
          41,
          42,
          43,
          44,
          45,
          56,
          57,
          62,
          63,
          68,
          69,
          74,
          75,
          76,
          77,
          78,
          79,
          80,
          81,
          92,
          93,
          98,
          99,
          112,
          113,
          128,
          129,
          134,
          135,
          148,
          149,
          160,
          161,
          162,
          163,
          164,
          165,
          166,
          167,
          168,
          169,
          170,
          171,
          172,
          173,
          178,
          179,
          184,
          185,
          196,
          197,
          198,
          199,
          200,
          201,
          202,
          203,
          204,
          205,
          206,
          207,
          208,
          209,
          214,
          215,
          220,
          221
        ];
      }
    } catch (error) {
    }
    exports.inspectOpts = Object.keys(process.env).filter((key) => {
      return /^debug_/i.test(key);
    }).reduce((obj, key) => {
      const prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, (_, k) => {
        return k.toUpperCase();
      });
      let val = process.env[key];
      if (/^(yes|on|true|enabled)$/i.test(val)) {
        val = true;
      } else if (/^(no|off|false|disabled)$/i.test(val)) {
        val = false;
      } else if (val === "null") {
        val = null;
      } else {
        val = Number(val);
      }
      obj[prop] = val;
      return obj;
    }, {});
    function useColors() {
      return "colors" in exports.inspectOpts ? Boolean(exports.inspectOpts.colors) : tty.isatty(process.stderr.fd);
    }
    function formatArgs(args) {
      const { namespace: name, useColors: useColors2 } = this;
      if (useColors2) {
        const c = this.color;
        const colorCode = "\x1B[3" + (c < 8 ? c : "8;5;" + c);
        const prefix = `  ${colorCode};1m${name} \x1B[0m`;
        args[0] = prefix + args[0].split("\n").join("\n" + prefix);
        args.push(colorCode + "m+" + module.exports.humanize(this.diff) + "\x1B[0m");
      } else {
        args[0] = getDate() + name + " " + args[0];
      }
    }
    function getDate() {
      if (exports.inspectOpts.hideDate) {
        return "";
      }
      return (/* @__PURE__ */ new Date()).toISOString() + " ";
    }
    function log(...args) {
      return process.stderr.write(util.formatWithOptions(exports.inspectOpts, ...args) + "\n");
    }
    function save(namespaces) {
      if (namespaces) {
        process.env.DEBUG = namespaces;
      } else {
        delete process.env.DEBUG;
      }
    }
    function load() {
      return process.env.DEBUG;
    }
    function init(debug) {
      debug.inspectOpts = {};
      const keys = Object.keys(exports.inspectOpts);
      for (let i = 0; i < keys.length; i++) {
        debug.inspectOpts[keys[i]] = exports.inspectOpts[keys[i]];
      }
    }
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.o = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts).split("\n").map((str) => str.trim()).join(" ");
    };
    formatters.O = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts);
    };
  }
});

// node_modules/debug/src/index.js
var require_src = __commonJS({
  "node_modules/debug/src/index.js"(exports, module) {
    if (typeof process === "undefined" || process.type === "renderer" || process.browser === true || process.__nwjs) {
      module.exports = require_browser();
    } else {
      module.exports = require_node();
    }
  }
});

// node_modules/agent-base/dist/src/promisify.js
var require_promisify = __commonJS({
  "node_modules/agent-base/dist/src/promisify.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function promisify(fn) {
      return function(req, opts) {
        return new Promise((resolve, reject) => {
          fn.call(this, req, opts, (err, rtn) => {
            if (err) {
              reject(err);
            } else {
              resolve(rtn);
            }
          });
        });
      };
    }
    exports.default = promisify;
  }
});

// node_modules/agent-base/dist/src/index.js
var require_src2 = __commonJS({
  "node_modules/agent-base/dist/src/index.js"(exports, module) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    var events_1 = __require("events");
    var debug_1 = __importDefault(require_src());
    var promisify_1 = __importDefault(require_promisify());
    var debug = debug_1.default("agent-base");
    function isAgent(v) {
      return Boolean(v) && typeof v.addRequest === "function";
    }
    function isSecureEndpoint() {
      const { stack } = new Error();
      if (typeof stack !== "string")
        return false;
      return stack.split("\n").some((l) => l.indexOf("(https.js:") !== -1 || l.indexOf("node:https:") !== -1);
    }
    function createAgent(callback, opts) {
      return new createAgent.Agent(callback, opts);
    }
    (function(createAgent2) {
      class Agent extends events_1.EventEmitter {
        constructor(callback, _opts) {
          super();
          let opts = _opts;
          if (typeof callback === "function") {
            this.callback = callback;
          } else if (callback) {
            opts = callback;
          }
          this.timeout = null;
          if (opts && typeof opts.timeout === "number") {
            this.timeout = opts.timeout;
          }
          this.maxFreeSockets = 1;
          this.maxSockets = 1;
          this.maxTotalSockets = Infinity;
          this.sockets = {};
          this.freeSockets = {};
          this.requests = {};
          this.options = {};
        }
        get defaultPort() {
          if (typeof this.explicitDefaultPort === "number") {
            return this.explicitDefaultPort;
          }
          return isSecureEndpoint() ? 443 : 80;
        }
        set defaultPort(v) {
          this.explicitDefaultPort = v;
        }
        get protocol() {
          if (typeof this.explicitProtocol === "string") {
            return this.explicitProtocol;
          }
          return isSecureEndpoint() ? "https:" : "http:";
        }
        set protocol(v) {
          this.explicitProtocol = v;
        }
        callback(req, opts, fn) {
          throw new Error('"agent-base" has no default implementation, you must subclass and override `callback()`');
        }
        /**
         * Called by node-core's "_http_client.js" module when creating
         * a new HTTP request with this Agent instance.
         *
         * @api public
         */
        addRequest(req, _opts) {
          const opts = Object.assign({}, _opts);
          if (typeof opts.secureEndpoint !== "boolean") {
            opts.secureEndpoint = isSecureEndpoint();
          }
          if (opts.host == null) {
            opts.host = "localhost";
          }
          if (opts.port == null) {
            opts.port = opts.secureEndpoint ? 443 : 80;
          }
          if (opts.protocol == null) {
            opts.protocol = opts.secureEndpoint ? "https:" : "http:";
          }
          if (opts.host && opts.path) {
            delete opts.path;
          }
          delete opts.agent;
          delete opts.hostname;
          delete opts._defaultAgent;
          delete opts.defaultPort;
          delete opts.createConnection;
          req._last = true;
          req.shouldKeepAlive = false;
          let timedOut = false;
          let timeoutId = null;
          const timeoutMs = opts.timeout || this.timeout;
          const onerror = (err) => {
            if (req._hadError)
              return;
            req.emit("error", err);
            req._hadError = true;
          };
          const ontimeout = () => {
            timeoutId = null;
            timedOut = true;
            const err = new Error(`A "socket" was not created for HTTP request before ${timeoutMs}ms`);
            err.code = "ETIMEOUT";
            onerror(err);
          };
          const callbackError = (err) => {
            if (timedOut)
              return;
            if (timeoutId !== null) {
              clearTimeout(timeoutId);
              timeoutId = null;
            }
            onerror(err);
          };
          const onsocket = (socket) => {
            if (timedOut)
              return;
            if (timeoutId != null) {
              clearTimeout(timeoutId);
              timeoutId = null;
            }
            if (isAgent(socket)) {
              debug("Callback returned another Agent instance %o", socket.constructor.name);
              socket.addRequest(req, opts);
              return;
            }
            if (socket) {
              socket.once("free", () => {
                this.freeSocket(socket, opts);
              });
              req.onSocket(socket);
              return;
            }
            const err = new Error(`no Duplex stream was returned to agent-base for \`${req.method} ${req.path}\``);
            onerror(err);
          };
          if (typeof this.callback !== "function") {
            onerror(new Error("`callback` is not defined"));
            return;
          }
          if (!this.promisifiedCallback) {
            if (this.callback.length >= 3) {
              debug("Converting legacy callback function to promise");
              this.promisifiedCallback = promisify_1.default(this.callback);
            } else {
              this.promisifiedCallback = this.callback;
            }
          }
          if (typeof timeoutMs === "number" && timeoutMs > 0) {
            timeoutId = setTimeout(ontimeout, timeoutMs);
          }
          if ("port" in opts && typeof opts.port !== "number") {
            opts.port = Number(opts.port);
          }
          try {
            debug("Resolving socket for %o request: %o", opts.protocol, `${req.method} ${req.path}`);
            Promise.resolve(this.promisifiedCallback(req, opts)).then(onsocket, callbackError);
          } catch (err) {
            Promise.reject(err).catch(callbackError);
          }
        }
        freeSocket(socket, opts) {
          debug("Freeing socket %o %o", socket.constructor.name, opts);
          socket.destroy();
        }
        destroy() {
          debug("Destroying agent %o", this.constructor.name);
        }
      }
      createAgent2.Agent = Agent;
      createAgent2.prototype = createAgent2.Agent.prototype;
    })(createAgent || (createAgent = {}));
    module.exports = createAgent;
  }
});

// node_modules/https-proxy-agent/dist/parse-proxy-response.js
var require_parse_proxy_response = __commonJS({
  "node_modules/https-proxy-agent/dist/parse-proxy-response.js"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    var debug_1 = __importDefault(require_src());
    var debug = debug_1.default("https-proxy-agent:parse-proxy-response");
    function parseProxyResponse(socket) {
      return new Promise((resolve, reject) => {
        let buffersLength = 0;
        const buffers = [];
        function read() {
          const b = socket.read();
          if (b)
            ondata(b);
          else
            socket.once("readable", read);
        }
        function cleanup() {
          socket.removeListener("end", onend);
          socket.removeListener("error", onerror);
          socket.removeListener("close", onclose);
          socket.removeListener("readable", read);
        }
        function onclose(err) {
          debug("onclose had error %o", err);
        }
        function onend() {
          debug("onend");
        }
        function onerror(err) {
          cleanup();
          debug("onerror %o", err);
          reject(err);
        }
        function ondata(b) {
          buffers.push(b);
          buffersLength += b.length;
          const buffered = Buffer.concat(buffers, buffersLength);
          const endOfHeaders = buffered.indexOf("\r\n\r\n");
          if (endOfHeaders === -1) {
            debug("have not received end of HTTP headers yet...");
            read();
            return;
          }
          const firstLine = buffered.toString("ascii", 0, buffered.indexOf("\r\n"));
          const statusCode = +firstLine.split(" ")[1];
          debug("got proxy server response: %o", firstLine);
          resolve({
            statusCode,
            buffered
          });
        }
        socket.on("error", onerror);
        socket.on("close", onclose);
        socket.on("end", onend);
        read();
      });
    }
    exports.default = parseProxyResponse;
  }
});

// node_modules/https-proxy-agent/dist/agent.js
var require_agent = __commonJS({
  "node_modules/https-proxy-agent/dist/agent.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    var net_1 = __importDefault(__require("net"));
    var tls_1 = __importDefault(__require("tls"));
    var url_1 = __importDefault(__require("url"));
    var assert_1 = __importDefault(__require("assert"));
    var debug_1 = __importDefault(require_src());
    var agent_base_1 = require_src2();
    var parse_proxy_response_1 = __importDefault(require_parse_proxy_response());
    var debug = debug_1.default("https-proxy-agent:agent");
    var HttpsProxyAgent = class extends agent_base_1.Agent {
      constructor(_opts) {
        let opts;
        if (typeof _opts === "string") {
          opts = url_1.default.parse(_opts);
        } else {
          opts = _opts;
        }
        if (!opts) {
          throw new Error("an HTTP(S) proxy server `host` and `port` must be specified!");
        }
        debug("creating new HttpsProxyAgent instance: %o", opts);
        super(opts);
        const proxy = Object.assign({}, opts);
        this.secureProxy = opts.secureProxy || isHTTPS(proxy.protocol);
        proxy.host = proxy.hostname || proxy.host;
        if (typeof proxy.port === "string") {
          proxy.port = parseInt(proxy.port, 10);
        }
        if (!proxy.port && proxy.host) {
          proxy.port = this.secureProxy ? 443 : 80;
        }
        if (this.secureProxy && !("ALPNProtocols" in proxy)) {
          proxy.ALPNProtocols = ["http 1.1"];
        }
        if (proxy.host && proxy.path) {
          delete proxy.path;
          delete proxy.pathname;
        }
        this.proxy = proxy;
      }
      /**
       * Called when the node-core HTTP client library is creating a
       * new HTTP request.
       *
       * @api protected
       */
      callback(req, opts) {
        return __awaiter(this, void 0, void 0, function* () {
          const { proxy, secureProxy } = this;
          let socket;
          if (secureProxy) {
            debug("Creating `tls.Socket`: %o", proxy);
            socket = tls_1.default.connect(proxy);
          } else {
            debug("Creating `net.Socket`: %o", proxy);
            socket = net_1.default.connect(proxy);
          }
          const headers = Object.assign({}, proxy.headers);
          const hostname = `${opts.host}:${opts.port}`;
          let payload = `CONNECT ${hostname} HTTP/1.1\r
`;
          if (proxy.auth) {
            headers["Proxy-Authorization"] = `Basic ${Buffer.from(proxy.auth).toString("base64")}`;
          }
          let { host, port, secureEndpoint } = opts;
          if (!isDefaultPort(port, secureEndpoint)) {
            host += `:${port}`;
          }
          headers.Host = host;
          headers.Connection = "close";
          for (const name of Object.keys(headers)) {
            payload += `${name}: ${headers[name]}\r
`;
          }
          const proxyResponsePromise = parse_proxy_response_1.default(socket);
          socket.write(`${payload}\r
`);
          const { statusCode, buffered } = yield proxyResponsePromise;
          if (statusCode === 200) {
            req.once("socket", resume);
            if (opts.secureEndpoint) {
              debug("Upgrading socket connection to TLS");
              const servername = opts.servername || opts.host;
              return tls_1.default.connect(Object.assign(Object.assign({}, omit(opts, "host", "hostname", "path", "port")), {
                socket,
                servername
              }));
            }
            return socket;
          }
          socket.destroy();
          const fakeSocket = new net_1.default.Socket({ writable: false });
          fakeSocket.readable = true;
          req.once("socket", (s) => {
            debug("replaying proxy buffer for failed request");
            assert_1.default(s.listenerCount("data") > 0);
            s.push(buffered);
            s.push(null);
          });
          return fakeSocket;
        });
      }
    };
    exports.default = HttpsProxyAgent;
    function resume(socket) {
      socket.resume();
    }
    function isDefaultPort(port, secure) {
      return Boolean(!secure && port === 80 || secure && port === 443);
    }
    function isHTTPS(protocol) {
      return typeof protocol === "string" ? /^https:?$/i.test(protocol) : false;
    }
    function omit(obj, ...keys) {
      const ret = {};
      let key;
      for (key in obj) {
        if (!keys.includes(key)) {
          ret[key] = obj[key];
        }
      }
      return ret;
    }
  }
});

// node_modules/https-proxy-agent/dist/index.js
var require_dist = __commonJS({
  "node_modules/https-proxy-agent/dist/index.js"(exports, module) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    var agent_1 = __importDefault(require_agent());
    function createHttpsProxyAgent(opts) {
      return new agent_1.default(opts);
    }
    (function(createHttpsProxyAgent2) {
      createHttpsProxyAgent2.HttpsProxyAgent = agent_1.default;
      createHttpsProxyAgent2.prototype = agent_1.default.prototype;
    })(createHttpsProxyAgent || (createHttpsProxyAgent = {}));
    module.exports = createHttpsProxyAgent;
  }
});

// node_modules/follow-redirects/debug.js
var require_debug = __commonJS({
  "node_modules/follow-redirects/debug.js"(exports, module) {
    var debug;
    module.exports = function() {
      if (!debug) {
        try {
          debug = require_src()("follow-redirects");
        } catch (error) {
        }
        if (typeof debug !== "function") {
          debug = function() {
          };
        }
      }
      debug.apply(null, arguments);
    };
  }
});

// node_modules/follow-redirects/index.js
var require_follow_redirects = __commonJS({
  "node_modules/follow-redirects/index.js"(exports, module) {
    var url = __require("url");
    var URL2 = url.URL;
    var http2 = __require("http");
    var https = __require("https");
    var Writable = __require("stream").Writable;
    var assert = __require("assert");
    var debug = require_debug();
    (function detectUnsupportedEnvironment() {
      var looksLikeNode = typeof process !== "undefined";
      var looksLikeBrowser = typeof window !== "undefined" && typeof document !== "undefined";
      var looksLikeV8 = isFunction(Error.captureStackTrace);
      if (!looksLikeNode && (looksLikeBrowser || !looksLikeV8)) {
        console.warn("The follow-redirects package should be excluded from browser builds.");
      }
    })();
    var useNativeURL = false;
    try {
      assert(new URL2(""));
    } catch (error) {
      useNativeURL = error.code === "ERR_INVALID_URL";
    }
    var sensitiveHeaders = [
      "Authorization",
      "Proxy-Authorization",
      "Cookie"
    ];
    var preservedUrlFields = [
      "auth",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "hash"
    ];
    var events = ["abort", "aborted", "connect", "error", "socket", "timeout"];
    var eventHandlers = /* @__PURE__ */ Object.create(null);
    events.forEach(function(event) {
      eventHandlers[event] = function(arg1, arg2, arg3) {
        this._redirectable.emit(event, arg1, arg2, arg3);
      };
    });
    var InvalidUrlError = createErrorType(
      "ERR_INVALID_URL",
      "Invalid URL",
      TypeError
    );
    var RedirectionError = createErrorType(
      "ERR_FR_REDIRECTION_FAILURE",
      "Redirected request failed"
    );
    var TooManyRedirectsError = createErrorType(
      "ERR_FR_TOO_MANY_REDIRECTS",
      "Maximum number of redirects exceeded",
      RedirectionError
    );
    var MaxBodyLengthExceededError = createErrorType(
      "ERR_FR_MAX_BODY_LENGTH_EXCEEDED",
      "Request body larger than maxBodyLength limit"
    );
    var WriteAfterEndError = createErrorType(
      "ERR_STREAM_WRITE_AFTER_END",
      "write after end"
    );
    var destroy = Writable.prototype.destroy || noop;
    function RedirectableRequest(options, responseCallback) {
      Writable.call(this);
      this._sanitizeOptions(options);
      this._options = options;
      this._ended = false;
      this._ending = false;
      this._redirectCount = 0;
      this._redirects = [];
      this._requestBodyLength = 0;
      this._requestBodyBuffers = [];
      if (responseCallback) {
        this.on("response", responseCallback);
      }
      var self2 = this;
      this._onNativeResponse = function(response) {
        try {
          self2._processResponse(response);
        } catch (cause) {
          self2.emit("error", cause instanceof RedirectionError ? cause : new RedirectionError({ cause }));
        }
      };
      this._headerFilter = new RegExp("^(?:" + sensitiveHeaders.concat(options.sensitiveHeaders).map(escapeRegex).join("|") + ")$", "i");
      this._performRequest();
    }
    RedirectableRequest.prototype = Object.create(Writable.prototype);
    RedirectableRequest.prototype.abort = function() {
      destroyRequest(this._currentRequest);
      this._currentRequest.abort();
      this.emit("abort");
    };
    RedirectableRequest.prototype.destroy = function(error) {
      destroyRequest(this._currentRequest, error);
      destroy.call(this, error);
      return this;
    };
    RedirectableRequest.prototype.write = function(data, encoding, callback) {
      if (this._ending) {
        throw new WriteAfterEndError();
      }
      if (!isString(data) && !isBuffer(data)) {
        throw new TypeError("data should be a string, Buffer or Uint8Array");
      }
      if (isFunction(encoding)) {
        callback = encoding;
        encoding = null;
      }
      if (data.length === 0) {
        if (callback) {
          callback();
        }
        return;
      }
      if (this._requestBodyLength + data.length <= this._options.maxBodyLength) {
        this._requestBodyLength += data.length;
        this._requestBodyBuffers.push({ data, encoding });
        this._currentRequest.write(data, encoding, callback);
      } else {
        this.emit("error", new MaxBodyLengthExceededError());
        this.abort();
      }
    };
    RedirectableRequest.prototype.end = function(data, encoding, callback) {
      if (isFunction(data)) {
        callback = data;
        data = encoding = null;
      } else if (isFunction(encoding)) {
        callback = encoding;
        encoding = null;
      }
      if (!data) {
        this._ended = this._ending = true;
        this._currentRequest.end(null, null, callback);
      } else {
        var self2 = this;
        var currentRequest = this._currentRequest;
        this.write(data, encoding, function() {
          self2._ended = true;
          currentRequest.end(null, null, callback);
        });
        this._ending = true;
      }
    };
    RedirectableRequest.prototype.setHeader = function(name, value) {
      this._options.headers[name] = value;
      this._currentRequest.setHeader(name, value);
    };
    RedirectableRequest.prototype.removeHeader = function(name) {
      delete this._options.headers[name];
      this._currentRequest.removeHeader(name);
    };
    RedirectableRequest.prototype.setTimeout = function(msecs, callback) {
      var self2 = this;
      function destroyOnTimeout(socket) {
        socket.setTimeout(msecs);
        socket.removeListener("timeout", socket.destroy);
        socket.addListener("timeout", socket.destroy);
      }
      function startTimer(socket) {
        if (self2._timeout) {
          clearTimeout(self2._timeout);
        }
        self2._timeout = setTimeout(function() {
          self2.emit("timeout");
          clearTimer();
        }, msecs);
        destroyOnTimeout(socket);
      }
      function clearTimer() {
        if (self2._timeout) {
          clearTimeout(self2._timeout);
          self2._timeout = null;
        }
        self2.removeListener("abort", clearTimer);
        self2.removeListener("error", clearTimer);
        self2.removeListener("response", clearTimer);
        self2.removeListener("close", clearTimer);
        if (callback) {
          self2.removeListener("timeout", callback);
        }
        if (!self2.socket) {
          self2._currentRequest.removeListener("socket", startTimer);
        }
      }
      if (callback) {
        this.on("timeout", callback);
      }
      if (this.socket) {
        startTimer(this.socket);
      } else {
        this._currentRequest.once("socket", startTimer);
      }
      this.on("socket", destroyOnTimeout);
      this.on("abort", clearTimer);
      this.on("error", clearTimer);
      this.on("response", clearTimer);
      this.on("close", clearTimer);
      return this;
    };
    [
      "flushHeaders",
      "getHeader",
      "setNoDelay",
      "setSocketKeepAlive"
    ].forEach(function(method) {
      RedirectableRequest.prototype[method] = function(a, b) {
        return this._currentRequest[method](a, b);
      };
    });
    ["aborted", "connection", "socket"].forEach(function(property) {
      Object.defineProperty(RedirectableRequest.prototype, property, {
        get: function() {
          return this._currentRequest[property];
        }
      });
    });
    RedirectableRequest.prototype._sanitizeOptions = function(options) {
      if (!options.headers) {
        options.headers = {};
      } else if (Array.isArray(options.headers)) {
        var headerList = options.headers;
        options.headers = {};
        for (var i = 0; i < headerList.length; i += 2) {
          options.headers[headerList[i]] = headerList[i + 1];
        }
      }
      if (!isArray(options.sensitiveHeaders)) {
        options.sensitiveHeaders = [];
      }
      if (options.host) {
        if (!options.hostname) {
          options.hostname = options.host;
        }
        delete options.host;
      }
      if (!options.pathname && options.path) {
        var searchPos = options.path.indexOf("?");
        if (searchPos < 0) {
          options.pathname = options.path;
        } else {
          options.pathname = options.path.substring(0, searchPos);
          options.search = options.path.substring(searchPos);
        }
      }
    };
    RedirectableRequest.prototype._performRequest = function() {
      var protocol = this._options.protocol;
      var nativeProtocol = this._options.nativeProtocols[protocol];
      if (!nativeProtocol) {
        throw new TypeError("Unsupported protocol " + protocol);
      }
      if (this._options.agents) {
        var scheme = protocol.slice(0, -1);
        this._options.agent = this._options.agents[scheme];
      }
      var request = this._currentRequest = nativeProtocol.request(this._options, this._onNativeResponse);
      request._redirectable = this;
      for (var event of events) {
        request.on(event, eventHandlers[event]);
      }
      this._currentUrl = /^\//.test(this._options.path) ? url.format(this._options) : (
        // When making a request to a proxy, […]
        // a client MUST send the target URI in absolute-form […].
        this._options.path
      );
      if (this._isRedirect) {
        var i = 0;
        var self2 = this;
        var buffers = this._requestBodyBuffers;
        (function writeNext(error) {
          if (request === self2._currentRequest) {
            if (error) {
              self2.emit("error", error);
            } else if (i < buffers.length) {
              var buffer = buffers[i++];
              if (!request.finished) {
                request.write(buffer.data, buffer.encoding, writeNext);
              }
            } else if (self2._ended) {
              request.end();
            }
          }
        })();
      }
    };
    RedirectableRequest.prototype._processResponse = function(response) {
      var statusCode = response.statusCode;
      if (this._options.trackRedirects) {
        this._redirects.push({
          url: this._currentUrl,
          headers: response.headers,
          statusCode
        });
      }
      var location = response.headers.location;
      if (!location || this._options.followRedirects === false || statusCode < 300 || statusCode >= 400) {
        response.responseUrl = this._currentUrl;
        response.redirects = this._redirects;
        this.emit("response", response);
        this._requestBodyBuffers = [];
        return;
      }
      destroyRequest(this._currentRequest);
      response.destroy();
      if (++this._redirectCount > this._options.maxRedirects) {
        throw new TooManyRedirectsError();
      }
      var requestHeaders;
      var beforeRedirect = this._options.beforeRedirect;
      if (beforeRedirect) {
        requestHeaders = Object.assign({
          // The Host header was set by nativeProtocol.request
          Host: response.req.getHeader("host")
        }, this._options.headers);
      }
      var method = this._options.method;
      if ((statusCode === 301 || statusCode === 302) && this._options.method === "POST" || // RFC7231§6.4.4: The 303 (See Other) status code indicates that
      // the server is redirecting the user agent to a different resource […]
      // A user agent can perform a retrieval request targeting that URI
      // (a GET or HEAD request if using HTTP) […]
      statusCode === 303 && !/^(?:GET|HEAD)$/.test(this._options.method)) {
        this._options.method = "GET";
        this._requestBodyBuffers = [];
        removeMatchingHeaders(/^content-/i, this._options.headers);
      }
      var currentHostHeader = removeMatchingHeaders(/^host$/i, this._options.headers);
      var currentUrlParts = parseUrl(this._currentUrl);
      var currentHost = currentHostHeader || currentUrlParts.host;
      var currentUrl = /^\w+:/.test(location) ? this._currentUrl : url.format(Object.assign(currentUrlParts, { host: currentHost }));
      var redirectUrl = resolveUrl(location, currentUrl);
      debug("redirecting to", redirectUrl.href);
      this._isRedirect = true;
      spreadUrlObject(redirectUrl, this._options);
      if (redirectUrl.protocol !== currentUrlParts.protocol && redirectUrl.protocol !== "https:" || redirectUrl.host !== currentHost && !isSubdomain(redirectUrl.host, currentHost)) {
        removeMatchingHeaders(this._headerFilter, this._options.headers);
      }
      if (isFunction(beforeRedirect)) {
        var responseDetails = {
          headers: response.headers,
          statusCode
        };
        var requestDetails = {
          url: currentUrl,
          method,
          headers: requestHeaders
        };
        beforeRedirect(this._options, responseDetails, requestDetails);
        this._sanitizeOptions(this._options);
      }
      this._performRequest();
    };
    function wrap(protocols) {
      var exports2 = {
        maxRedirects: 21,
        maxBodyLength: 10 * 1024 * 1024
      };
      var nativeProtocols = {};
      Object.keys(protocols).forEach(function(scheme) {
        var protocol = scheme + ":";
        var nativeProtocol = nativeProtocols[protocol] = protocols[scheme];
        var wrappedProtocol = exports2[scheme] = Object.create(nativeProtocol);
        function request(input, options, callback) {
          if (isURL(input)) {
            input = spreadUrlObject(input);
          } else if (isString(input)) {
            input = spreadUrlObject(parseUrl(input));
          } else {
            callback = options;
            options = validateUrl(input);
            input = { protocol };
          }
          if (isFunction(options)) {
            callback = options;
            options = null;
          }
          options = Object.assign({
            maxRedirects: exports2.maxRedirects,
            maxBodyLength: exports2.maxBodyLength
          }, input, options);
          options.nativeProtocols = nativeProtocols;
          if (!isString(options.host) && !isString(options.hostname)) {
            options.hostname = "::1";
          }
          assert.equal(options.protocol, protocol, "protocol mismatch");
          debug("options", options);
          return new RedirectableRequest(options, callback);
        }
        function get(input, options, callback) {
          var wrappedRequest = wrappedProtocol.request(input, options, callback);
          wrappedRequest.end();
          return wrappedRequest;
        }
        Object.defineProperties(wrappedProtocol, {
          request: { value: request, configurable: true, enumerable: true, writable: true },
          get: { value: get, configurable: true, enumerable: true, writable: true }
        });
      });
      return exports2;
    }
    function noop() {
    }
    function parseUrl(input) {
      var parsed;
      if (useNativeURL) {
        parsed = new URL2(input);
      } else {
        parsed = validateUrl(url.parse(input));
        if (!isString(parsed.protocol)) {
          throw new InvalidUrlError({ input });
        }
      }
      return parsed;
    }
    function resolveUrl(relative, base) {
      return useNativeURL ? new URL2(relative, base) : parseUrl(url.resolve(base, relative));
    }
    function validateUrl(input) {
      if (/^\[/.test(input.hostname) && !/^\[[:0-9a-f]+\]$/i.test(input.hostname)) {
        throw new InvalidUrlError({ input: input.href || input });
      }
      if (/^\[/.test(input.host) && !/^\[[:0-9a-f]+\](:\d+)?$/i.test(input.host)) {
        throw new InvalidUrlError({ input: input.href || input });
      }
      return input;
    }
    function spreadUrlObject(urlObject, target) {
      var spread = target || {};
      for (var key of preservedUrlFields) {
        spread[key] = urlObject[key];
      }
      if (spread.hostname.startsWith("[")) {
        spread.hostname = spread.hostname.slice(1, -1);
      }
      if (spread.port !== "") {
        spread.port = Number(spread.port);
      }
      spread.path = spread.search ? spread.pathname + spread.search : spread.pathname;
      return spread;
    }
    function removeMatchingHeaders(regex, headers) {
      var lastValue;
      for (var header in headers) {
        if (regex.test(header)) {
          lastValue = headers[header];
          delete headers[header];
        }
      }
      return lastValue === null || typeof lastValue === "undefined" ? void 0 : String(lastValue).trim();
    }
    function createErrorType(code, message, baseClass) {
      function CustomError(properties) {
        if (isFunction(Error.captureStackTrace)) {
          Error.captureStackTrace(this, this.constructor);
        }
        Object.assign(this, properties || {});
        this.code = code;
        this.message = this.cause ? message + ": " + this.cause.message : message;
      }
      CustomError.prototype = new (baseClass || Error)();
      Object.defineProperties(CustomError.prototype, {
        constructor: {
          value: CustomError,
          enumerable: false
        },
        name: {
          value: "Error [" + code + "]",
          enumerable: false
        }
      });
      return CustomError;
    }
    function destroyRequest(request, error) {
      for (var event of events) {
        request.removeListener(event, eventHandlers[event]);
      }
      request.on("error", noop);
      request.destroy(error);
    }
    function isSubdomain(subdomain, domain) {
      assert(isString(subdomain) && isString(domain));
      var dot = subdomain.length - domain.length - 1;
      return dot > 0 && subdomain[dot] === "." && subdomain.endsWith(domain);
    }
    function isArray(value) {
      return value instanceof Array;
    }
    function isString(value) {
      return typeof value === "string" || value instanceof String;
    }
    function isFunction(value) {
      return typeof value === "function";
    }
    function isBuffer(value) {
      return typeof value === "object" && "length" in value;
    }
    function isURL(value) {
      return URL2 && value instanceof URL2;
    }
    function escapeRegex(regex) {
      return regex.replace(/[[\]\\/()*+?.^$|]/g, "\\$&");
    }
    module.exports = wrap({ http: http2, https });
    module.exports.wrap = wrap;
  }
});

// node_modules/axios/dist/node/axios.cjs
var require_axios = __commonJS({
  "node_modules/axios/dist/node/axios.cjs"(exports, module) {
    "use strict";
    var FormData$1 = require_form_data();
    var crypto3 = __require("crypto");
    var url = __require("url");
    var HttpsProxyAgent = require_dist();
    var http2 = __require("http");
    var https = __require("https");
    var http22 = __require("http2");
    var util = __require("util");
    var path6 = __require("path");
    var followRedirects = require_follow_redirects();
    var zlib = __require("zlib");
    var stream = __require("stream");
    var events = __require("events");
    function bind(fn, thisArg) {
      return function wrap() {
        return fn.apply(thisArg, arguments);
      };
    }
    var {
      toString
    } = Object.prototype;
    var {
      getPrototypeOf
    } = Object;
    var {
      iterator,
      toStringTag
    } = Symbol;
    var hasOwnProperty = (({
      hasOwnProperty: hasOwnProperty2
    }) => (obj, prop) => hasOwnProperty2.call(obj, prop))(Object.prototype);
    var isUnsafeObjectKey = (prop) => typeof prop === "string" && (prop === "__proto__" || prop === "constructor" || prop === "prototype");
    var isPrototypeBoundary = (obj, prototype2, source) => obj === Object.prototype || !source && prototype2 === null;
    var isSafeAndFullyMutable = (obj) => {
      if (!Object.isExtensible(obj)) {
        return false;
      }
      const props = Object.getOwnPropertyNames(obj);
      if (Object.getOwnPropertySymbols) {
        props.push(...Object.getOwnPropertySymbols(obj));
      }
      return props.every((prop) => {
        if (isUnsafeObjectKey(prop)) {
          return false;
        }
        const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
        return !!descriptor && descriptor.configurable && descriptor.writable === true;
      });
    };
    var hasOwnInPrototypeChain = (thing, prop) => {
      let obj = thing;
      const seen = [];
      while (obj != null) {
        if (seen.indexOf(obj) !== -1) {
          return false;
        }
        seen.push(obj);
        const prototype2 = getPrototypeOf(obj);
        if (isPrototypeBoundary(obj, prototype2, obj === thing)) {
          return false;
        }
        if (hasOwnProperty(obj, prop)) {
          return true;
        }
        obj = prototype2;
      }
      return false;
    };
    var getSafeProp = (obj, prop) => obj != null && hasOwnInPrototypeChain(obj, prop) ? obj[prop] : void 0;
    var toSafeFlatObject = (thing) => {
      if (thing == null || typeof thing !== "object" && typeof thing !== "function") {
        return thing;
      }
      const sourcePrototype = getPrototypeOf(thing);
      if (sourcePrototype === null && isSafeAndFullyMutable(thing)) {
        return thing;
      }
      const result = /* @__PURE__ */ Object.create(null);
      const merged = /* @__PURE__ */ Object.create(null);
      const seen = [];
      let current = thing;
      while (current != null) {
        if (seen.indexOf(current) !== -1) {
          break;
        }
        seen.push(current);
        const prototype2 = current === thing ? sourcePrototype : getPrototypeOf(current);
        if (isPrototypeBoundary(current, prototype2, current === thing)) {
          break;
        }
        const props = Object.getOwnPropertyNames(current);
        if (Object.getOwnPropertySymbols) {
          props.push(...Object.getOwnPropertySymbols(current));
        }
        for (const prop of props) {
          if (isUnsafeObjectKey(prop)) {
            continue;
          }
          if (!hasOwnProperty(merged, prop)) {
            result[prop] = thing[prop];
            merged[prop] = true;
          }
        }
        current = prototype2;
      }
      return result;
    };
    var kindOf = /* @__PURE__ */ ((cache) => (thing) => {
      const str = toString.call(thing);
      return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
    })(/* @__PURE__ */ Object.create(null));
    var kindOfTest = (type) => {
      type = type.toLowerCase();
      return (thing) => kindOf(thing) === type;
    };
    var typeOfTest = (type) => (thing) => typeof thing === type;
    var {
      isArray
    } = Array;
    var isUndefined = typeOfTest("undefined");
    function isBuffer(val) {
      return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction$1(val.constructor.isBuffer) && val.constructor.isBuffer(val);
    }
    var isArrayBuffer = kindOfTest("ArrayBuffer");
    function isArrayBufferView(val) {
      let result;
      if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
        result = ArrayBuffer.isView(val);
      } else {
        result = val && val.buffer && isArrayBuffer(val.buffer);
      }
      return result;
    }
    var isString = typeOfTest("string");
    var isFunction$1 = typeOfTest("function");
    var isNumber = typeOfTest("number");
    var isObject = (thing) => thing !== null && typeof thing === "object";
    var isBoolean = (thing) => thing === true || thing === false;
    var isPlainObject = (val) => {
      if (!isObject(val)) {
        return false;
      }
      const prototype2 = getPrototypeOf(val);
      return (prototype2 === null || prototype2 === Object.prototype || getPrototypeOf(prototype2) === null) && // Treat safe own/inherited Symbol.toStringTag or Symbol.iterator members as
      // evidence the value is tagged/iterable, while ignoring members reachable
      // only through shared or terminal prototype boundaries.
      !hasOwnInPrototypeChain(val, toStringTag) && !hasOwnInPrototypeChain(val, iterator);
    };
    var isEmptyObject = (val) => {
      if (!isObject(val) || isBuffer(val)) {
        return false;
      }
      try {
        return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
      } catch (e) {
        return false;
      }
    };
    var isDate = kindOfTest("Date");
    var isFile = kindOfTest("File");
    var isReactNativeBlob = (value) => {
      return !!(value && typeof value.uri !== "undefined");
    };
    var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
    var isBlob = kindOfTest("Blob");
    var isFileList = kindOfTest("FileList");
    var isSet = kindOfTest("Set");
    var isStream = (val) => isObject(val) && isFunction$1(val.pipe);
    function getGlobal() {
      if (typeof globalThis !== "undefined") return globalThis;
      if (typeof self !== "undefined") return self;
      if (typeof window !== "undefined") return window;
      if (typeof global !== "undefined") return global;
      return {};
    }
    var G = getGlobal();
    var FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
    var isFormData = (thing) => {
      if (!thing) return false;
      if (FormDataCtor && thing instanceof FormDataCtor) return true;
      const proto = getPrototypeOf(thing);
      if (!proto || proto === Object.prototype) return false;
      if (!isFunction$1(thing.append)) return false;
      const kind = kindOf(thing);
      return kind === "formdata" || // detect form-data instance
      kind === "object" && isFunction$1(thing.toString) && thing.toString() === "[object FormData]";
    };
    var isURLSearchParams = kindOfTest("URLSearchParams");
    var [isReadableStream, isRequest, isResponse, isHeaders] = ["ReadableStream", "Request", "Response", "Headers"].map(kindOfTest);
    var trim = (str) => {
      return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
    };
    function forEach(obj, fn, {
      allOwnKeys = false
    } = {}) {
      if (obj === null || typeof obj === "undefined") {
        return;
      }
      let i;
      let l;
      if (typeof obj !== "object") {
        obj = [obj];
      }
      if (isArray(obj)) {
        for (i = 0, l = obj.length; i < l; i++) {
          fn.call(null, obj[i], i, obj);
        }
      } else {
        if (isBuffer(obj)) {
          return;
        }
        const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
        const len = keys.length;
        let key;
        for (i = 0; i < len; i++) {
          key = keys[i];
          fn.call(null, obj[key], key, obj);
        }
      }
    }
    function findKey(obj, key) {
      if (isBuffer(obj)) {
        return null;
      }
      key = key.toLowerCase();
      const keys = Object.keys(obj);
      let i = keys.length;
      let _key;
      while (i-- > 0) {
        _key = keys[i];
        if (key === _key.toLowerCase()) {
          return _key;
        }
      }
      return null;
    }
    var _global = (() => {
      if (typeof globalThis !== "undefined") return globalThis;
      return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
    })();
    var isContextDefined = (context) => !isUndefined(context) && context !== _global;
    function merge(...objs) {
      const {
        caseless,
        skipUndefined
      } = isContextDefined(this) && this || {};
      const result = {};
      const assignValue = (val, key) => {
        if (key === "__proto__" || key === "constructor" || key === "prototype") {
          return;
        }
        const targetKey = caseless && typeof key === "string" && findKey(result, key) || key;
        const existing = hasOwnProperty(result, targetKey) ? result[targetKey] : void 0;
        if (isPlainObject(existing) && isPlainObject(val)) {
          result[targetKey] = merge(existing, val);
        } else if (isPlainObject(val)) {
          result[targetKey] = merge({}, val);
        } else if (isArray(val)) {
          result[targetKey] = val.slice();
        } else if (!skipUndefined || !isUndefined(val)) {
          result[targetKey] = val;
        }
      };
      for (let i = 0, l = objs.length; i < l; i++) {
        const source = objs[i];
        if (!source || isBuffer(source)) {
          continue;
        }
        forEach(source, assignValue);
        if (typeof source !== "object" || isArray(source)) {
          continue;
        }
        const symbols = Object.getOwnPropertySymbols(source);
        for (let j = 0; j < symbols.length; j++) {
          const symbol = symbols[j];
          if (propertyIsEnumerable.call(source, symbol)) {
            assignValue(source[symbol], symbol);
          }
        }
      }
      return result;
    }
    var extend = (a, b, thisArg, {
      allOwnKeys
    } = {}) => {
      forEach(b, (val, key) => {
        if (thisArg && isFunction$1(val)) {
          Object.defineProperty(a, key, {
            // Null-proto descriptor so a polluted Object.prototype.get cannot
            // hijack defineProperty's accessor-vs-data resolution.
            __proto__: null,
            value: bind(val, thisArg),
            writable: true,
            enumerable: true,
            configurable: true
          });
        } else {
          Object.defineProperty(a, key, {
            __proto__: null,
            value: val,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      }, {
        allOwnKeys
      });
      return a;
    };
    var stripBOM = (content) => {
      if (content.charCodeAt(0) === 65279) {
        content = content.slice(1);
      }
      return content;
    };
    var inherits = (constructor, superConstructor, props, descriptors) => {
      constructor.prototype = Object.create(superConstructor.prototype, descriptors);
      Object.defineProperty(constructor.prototype, "constructor", {
        __proto__: null,
        value: constructor,
        writable: true,
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(constructor, "super", {
        __proto__: null,
        value: superConstructor.prototype
      });
      props && Object.assign(constructor.prototype, props);
    };
    var toFlatObject = (sourceObj, destObj, filter, propFilter) => {
      let props;
      let i;
      let prop;
      const merged = {};
      destObj = destObj || {};
      if (sourceObj == null) return destObj;
      do {
        props = Object.getOwnPropertyNames(sourceObj);
        i = props.length;
        while (i-- > 0) {
          prop = props[i];
          if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
            destObj[prop] = sourceObj[prop];
            merged[prop] = true;
          }
        }
        sourceObj = filter !== false && getPrototypeOf(sourceObj);
      } while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
      return destObj;
    };
    var endsWith = (str, searchString, position) => {
      str = String(str);
      if (position === void 0 || position > str.length) {
        position = str.length;
      }
      position -= searchString.length;
      const lastIndex = str.indexOf(searchString, position);
      return lastIndex !== -1 && lastIndex === position;
    };
    var toArray = (thing) => {
      if (!thing) return null;
      if (isArray(thing)) return thing;
      let i = thing.length;
      if (!isNumber(i)) return null;
      const arr = new Array(i);
      while (i-- > 0) {
        arr[i] = thing[i];
      }
      return arr;
    };
    var isTypedArray = /* @__PURE__ */ ((TypedArray) => {
      return (thing) => {
        return TypedArray && thing instanceof TypedArray;
      };
    })(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
    var forEachEntry = (obj, fn) => {
      const generator = obj && obj[iterator];
      const _iterator = generator.call(obj);
      let result;
      while ((result = _iterator.next()) && !result.done) {
        const pair = result.value;
        fn.call(obj, pair[0], pair[1]);
      }
    };
    var matchAll = (regExp, str) => {
      let matches;
      const arr = [];
      while ((matches = regExp.exec(str)) !== null) {
        arr.push(matches);
      }
      return arr;
    };
    var isHTMLForm = kindOfTest("HTMLFormElement");
    var toCamelCase = (str) => {
      return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
        return p1.toUpperCase() + p2;
      });
    };
    var {
      propertyIsEnumerable
    } = Object.prototype;
    var isRegExp = kindOfTest("RegExp");
    var reduceDescriptors = (obj, reducer) => {
      const descriptors = Object.getOwnPropertyDescriptors(obj);
      const reducedDescriptors = {};
      forEach(descriptors, (descriptor, name) => {
        let ret;
        if ((ret = reducer(descriptor, name, obj)) !== false) {
          reducedDescriptors[name] = ret || descriptor;
        }
      });
      Object.defineProperties(obj, reducedDescriptors);
    };
    var freezeMethods = (obj) => {
      reduceDescriptors(obj, (descriptor, name) => {
        if (isFunction$1(obj) && ["arguments", "caller", "callee"].includes(name)) {
          return false;
        }
        const value = obj[name];
        if (!isFunction$1(value)) return;
        descriptor.enumerable = false;
        if ("writable" in descriptor) {
          descriptor.writable = false;
          return;
        }
        if (!descriptor.set) {
          descriptor.set = () => {
            throw Error("Can not rewrite read-only method '" + name + "'");
          };
        }
      });
    };
    var toObjectSet = (arrayOrString, delimiter) => {
      const obj = {};
      const define = (arr) => {
        arr.forEach((value) => {
          obj[value] = true;
        });
      };
      isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
      return obj;
    };
    var noop = () => {
    };
    var toFiniteNumber = (value, defaultValue) => {
      return value != null && Number.isFinite(value = +value) ? value : defaultValue;
    };
    function isSpecCompliantForm(thing) {
      return !!(thing && isFunction$1(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
    }
    var toJSONObject = (obj) => {
      const visited = /* @__PURE__ */ new WeakSet();
      const visit = (source) => {
        if (isObject(source)) {
          if (visited.has(source)) {
            return;
          }
          if (isBuffer(source)) {
            return source;
          }
          if (!("toJSON" in source)) {
            visited.add(source);
            let target;
            if (isSet(source)) {
              target = [];
              for (const value of source) {
                const reducedValue = visit(value);
                !isUndefined(reducedValue) && target.push(reducedValue);
              }
            } else {
              target = isArray(source) ? [] : {};
              forEach(source, (value, key) => {
                const reducedValue = visit(value);
                !isUndefined(reducedValue) && (target[key] = reducedValue);
              });
            }
            visited.delete(source);
            return target;
          }
        }
        return source;
      };
      return visit(obj);
    };
    var isAsyncFn = kindOfTest("AsyncFunction");
    var isThenable = (thing) => thing && (isObject(thing) || isFunction$1(thing)) && isFunction$1(thing.then) && isFunction$1(thing.catch);
    var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
      if (setImmediateSupported) {
        return setImmediate;
      }
      return postMessageSupported ? ((token, callbacks) => {
        _global.addEventListener("message", ({
          source,
          data
        }) => {
          if (source === _global && data === token) {
            callbacks.length && callbacks.shift()();
          }
        }, false);
        return (cb) => {
          callbacks.push(cb);
          _global.postMessage(token, "*");
        };
      })(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
    })(typeof setImmediate === "function", isFunction$1(_global.postMessage));
    var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
    var isIterable = (thing) => thing != null && isFunction$1(thing[iterator]);
    var isSafeIterable = (thing) => thing != null && hasOwnInPrototypeChain(thing, iterator) && isIterable(thing);
    var utils$1 = {
      isArray,
      isArrayBuffer,
      isBuffer,
      isFormData,
      isArrayBufferView,
      isString,
      isNumber,
      isBoolean,
      isObject,
      isPlainObject,
      isEmptyObject,
      isReadableStream,
      isRequest,
      isResponse,
      isHeaders,
      isUndefined,
      isDate,
      isFile,
      isReactNativeBlob,
      isReactNative,
      isBlob,
      isRegExp,
      isFunction: isFunction$1,
      isStream,
      isURLSearchParams,
      isTypedArray,
      isFileList,
      forEach,
      merge,
      extend,
      trim,
      stripBOM,
      inherits,
      toFlatObject,
      kindOf,
      kindOfTest,
      endsWith,
      toArray,
      forEachEntry,
      matchAll,
      isHTMLForm,
      hasOwnProperty,
      hasOwnProp: hasOwnProperty,
      // an alias to avoid ESLint no-prototype-builtins detection
      hasOwnInPrototypeChain,
      getSafeProp,
      toSafeFlatObject,
      reduceDescriptors,
      freezeMethods,
      toObjectSet,
      toCamelCase,
      noop,
      toFiniteNumber,
      findKey,
      global: _global,
      isContextDefined,
      isSpecCompliantForm,
      toJSONObject,
      isAsyncFn,
      isThenable,
      setImmediate: _setImmediate,
      asap,
      isIterable,
      isSafeIterable
    };
    var ignoreDuplicateOf = utils$1.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]);
    var parseHeaders = (rawHeaders) => {
      const parsed = {};
      let key;
      let val;
      let i;
      rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
        i = line.indexOf(":");
        key = line.substring(0, i).trim().toLowerCase();
        val = line.substring(i + 1).trim();
        const hasKey = utils$1.hasOwnProp(parsed, key);
        if (!key || hasKey && utils$1.hasOwnProp(ignoreDuplicateOf, key)) {
          return;
        }
        if (key === "set-cookie") {
          if (hasKey) {
            parsed[key].push(val);
          } else {
            parsed[key] = [val];
          }
        } else {
          parsed[key] = hasKey ? parsed[key] + ", " + val : val;
        }
      });
      return parsed;
    };
    function trimSPorHTAB(str) {
      let start = 0;
      let end = str.length;
      while (start < end) {
        const code = str.charCodeAt(start);
        if (code !== 9 && code !== 32) {
          break;
        }
        start += 1;
      }
      while (end > start) {
        const code = str.charCodeAt(end - 1);
        if (code !== 9 && code !== 32) {
          break;
        }
        end -= 1;
      }
      return start === 0 && end === str.length ? str : str.slice(start, end);
    }
    var INVALID_UNICODE_HEADER_VALUE_CHARS = new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
    var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
    function sanitizeValue(value, invalidChars) {
      if (utils$1.isArray(value)) {
        return value.map((item) => sanitizeValue(item, invalidChars));
      }
      return trimSPorHTAB(String(value).replace(invalidChars, ""));
    }
    var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
    var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
    function toByteStringHeaderObject(headers) {
      const byteStringHeaders = /* @__PURE__ */ Object.create(null);
      utils$1.forEach(headers.toJSON(), (value, header) => {
        byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
      });
      return byteStringHeaders;
    }
    var $internals$1 = /* @__PURE__ */ Symbol("internals");
    function normalizeHeader(header) {
      return header && String(header).trim().toLowerCase();
    }
    function normalizeValue(value) {
      if (value === false || value == null) {
        return value;
      }
      return utils$1.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
    }
    function parseTokens(str) {
      const tokens = /* @__PURE__ */ Object.create(null);
      const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
      let match;
      while (match = tokensRE.exec(str)) {
        tokens[match[1]] = match[2];
      }
      return tokens;
    }
    var parameterNameRE = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
    function trimOWS(value) {
      let start = 0;
      let end = value.length;
      while (start < end) {
        const code = value.charCodeAt(start);
        if (code !== 9 && code !== 32) {
          break;
        }
        start += 1;
      }
      while (end > start) {
        const code = value.charCodeAt(end - 1);
        if (code !== 9 && code !== 32) {
          break;
        }
        end -= 1;
      }
      return start === 0 && end === value.length ? value : value.slice(start, end);
    }
    function decodeQuotedString(value) {
      const last = value.length - 1;
      if (last < 1 || value.charCodeAt(0) !== 34 || value.charCodeAt(last) !== 34) {
        return value;
      }
      let decoded = "";
      for (let i = 1; i < last; i++) {
        const code = value.charCodeAt(i);
        if (code === 34) {
          return value;
        }
        if (code === 92) {
          i += 1;
          if (i >= last) {
            return value;
          }
        }
        decoded += value[i];
      }
      return decoded;
    }
    function parseParameters(value) {
      const parameters = /* @__PURE__ */ Object.create(null);
      const str = String(value);
      let start = 0;
      let quoted = false;
      let escaped = false;
      function parseParameter(end) {
        const part = trimOWS(str.slice(start, end));
        const equals = part.indexOf("=");
        if (equals < 1) {
          return;
        }
        const name = trimOWS(part.slice(0, equals));
        if (!parameterNameRE.test(name)) {
          return;
        }
        const normalizedName = name.toLowerCase();
        if (normalizedName === "__proto__" || normalizedName === "constructor" || normalizedName === "prototype") {
          return;
        }
        const parameterValue = trimOWS(part.slice(equals + 1));
        parameters[normalizedName] = decodeQuotedString(parameterValue);
      }
      for (let i = 0; i < str.length; i++) {
        const code = str.charCodeAt(i);
        if (quoted) {
          if (escaped) {
            escaped = false;
          } else if (code === 92) {
            escaped = true;
          } else if (code === 34) {
            quoted = false;
          }
        } else if (code === 34) {
          quoted = true;
        } else if (code === 44 || code === 59) {
          parseParameter(i);
          start = i + 1;
        }
      }
      parseParameter(str.length);
      return parameters;
    }
    var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
    function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
      if (utils$1.isFunction(filter)) {
        return filter.call(this, value, header);
      }
      if (isHeaderNameFilter) {
        value = header;
      }
      if (!utils$1.isString(value)) return;
      if (utils$1.isString(filter)) {
        return value.indexOf(filter) !== -1;
      }
      if (utils$1.isRegExp(filter)) {
        return filter.test(value);
      }
    }
    function formatHeader(header) {
      return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
        return char.toUpperCase() + str;
      });
    }
    function buildAccessors(obj, header) {
      const accessorName = utils$1.toCamelCase(" " + header);
      ["get", "set", "has"].forEach((methodName) => {
        Object.defineProperty(obj, methodName + accessorName, {
          // Null-proto descriptor so a polluted Object.prototype.get cannot turn
          // this data descriptor into an accessor descriptor on the way in.
          __proto__: null,
          value: function(arg1, arg2, arg3) {
            return this[methodName].call(this, header, arg1, arg2, arg3);
          },
          configurable: true
        });
      });
    }
    var AxiosHeaders = class {
      constructor(headers) {
        headers && this.set(headers);
      }
      set(header, valueOrRewrite, rewrite) {
        const self2 = this;
        function setHeader(_value, _header, _rewrite) {
          const lHeader = normalizeHeader(_header);
          if (!lHeader) {
            return;
          }
          const key = utils$1.findKey(self2, lHeader);
          if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
            self2[key || _header] = normalizeValue(_value);
          }
        }
        const setHeaders = (headers, _rewrite) => utils$1.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
        if (utils$1.isPlainObject(header) || header instanceof this.constructor) {
          setHeaders(header, valueOrRewrite);
        } else if (utils$1.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
          setHeaders(parseHeaders(header), valueOrRewrite);
        } else if (utils$1.isObject(header) && utils$1.isSafeIterable(header)) {
          let obj = /* @__PURE__ */ Object.create(null), dest, key;
          for (const entry of header) {
            if (!utils$1.isArray(entry)) {
              throw new TypeError("Object iterator must return a key-value pair");
            }
            key = entry[0];
            if (utils$1.hasOwnProp(obj, key)) {
              dest = obj[key];
              obj[key] = utils$1.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]];
            } else {
              obj[key] = entry[1];
            }
          }
          setHeaders(obj, valueOrRewrite);
        } else {
          header != null && setHeader(valueOrRewrite, header, rewrite);
        }
        return this;
      }
      get(header, parser) {
        header = normalizeHeader(header);
        if (header) {
          const key = utils$1.findKey(this, header);
          if (key) {
            const value = this[key];
            if (!parser) {
              return value;
            }
            if (parser === true) {
              return parseTokens(value);
            }
            if (utils$1.isFunction(parser)) {
              return parser.call(this, value, key);
            }
            if (utils$1.isRegExp(parser)) {
              return parser.exec(value);
            }
            throw new TypeError("parser must be boolean|regexp|function");
          }
        }
      }
      has(header, matcher) {
        header = normalizeHeader(header);
        if (header) {
          const key = utils$1.findKey(this, header);
          return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
        }
        return false;
      }
      delete(header, matcher) {
        const self2 = this;
        let deleted = false;
        function deleteHeader(_header) {
          _header = normalizeHeader(_header);
          if (_header) {
            const key = utils$1.findKey(self2, _header);
            if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
              delete self2[key];
              deleted = true;
            }
          }
        }
        if (utils$1.isArray(header)) {
          header.forEach(deleteHeader);
        } else {
          deleteHeader(header);
        }
        return deleted;
      }
      clear(matcher) {
        const keys = Object.keys(this);
        let i = keys.length;
        let deleted = false;
        while (i--) {
          const key = keys[i];
          if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
            delete this[key];
            deleted = true;
          }
        }
        return deleted;
      }
      normalize(format) {
        const self2 = this;
        const headers = {};
        utils$1.forEach(this, (value, header) => {
          const key = utils$1.findKey(headers, header);
          if (key) {
            self2[key] = normalizeValue(value);
            delete self2[header];
            return;
          }
          const normalized = format ? formatHeader(header) : String(header).trim();
          if (normalized !== header) {
            delete self2[header];
          }
          self2[normalized] = normalizeValue(value);
          headers[normalized] = true;
        });
        return this;
      }
      concat(...targets) {
        return this.constructor.concat(this, ...targets);
      }
      toJSON(asStrings) {
        const obj = /* @__PURE__ */ Object.create(null);
        utils$1.forEach(this, (value, header) => {
          value != null && value !== false && (obj[header] = asStrings && utils$1.isArray(value) ? value.join(", ") : value);
        });
        return obj;
      }
      [Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]();
      }
      toString() {
        return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
      }
      getSetCookie() {
        const value = this.get("set-cookie");
        return utils$1.isArray(value) ? value : value == null || value === false ? [] : [value];
      }
      get [Symbol.toStringTag]() {
        return "AxiosHeaders";
      }
      static from(thing) {
        return thing instanceof this ? thing : new this(thing);
      }
      static parseParameters(value) {
        return parseParameters(value);
      }
      static concat(first, ...targets) {
        const computed = new this(first);
        targets.forEach((target) => computed.set(target));
        return computed;
      }
      static accessor(header) {
        const internals = this[$internals$1] = this[$internals$1] = {
          accessors: {}
        };
        const accessors = internals.accessors;
        const prototype2 = this.prototype;
        function defineAccessor(_header) {
          const lHeader = normalizeHeader(_header);
          if (!accessors[lHeader]) {
            buildAccessors(prototype2, _header);
            accessors[lHeader] = true;
          }
        }
        utils$1.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
        return this;
      }
    };
    AxiosHeaders.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
    utils$1.reduceDescriptors(AxiosHeaders.prototype, ({
      value
    }, key) => {
      let mapped = key[0].toUpperCase() + key.slice(1);
      return {
        get: () => value,
        set(headerValue) {
          this[mapped] = headerValue;
        }
      };
    });
    utils$1.freezeMethods(AxiosHeaders);
    var REDACTED = "[REDACTED ****]";
    function hasOwnOrPrototypeToJSON(source) {
      if (utils$1.hasOwnProp(source, "toJSON")) {
        return true;
      }
      let prototype2 = Object.getPrototypeOf(source);
      while (prototype2 && prototype2 !== Object.prototype) {
        if (utils$1.hasOwnProp(prototype2, "toJSON")) {
          return true;
        }
        prototype2 = Object.getPrototypeOf(prototype2);
      }
      return false;
    }
    function redactConfig(config, redactKeys) {
      const lowerKeys = new Set(redactKeys.map((k) => String(k).toLowerCase()));
      const seen = [];
      const visit = (source) => {
        if (source === null || typeof source !== "object") return source;
        if (utils$1.isBuffer(source)) return source;
        if (seen.indexOf(source) !== -1) return void 0;
        if (source instanceof AxiosHeaders) {
          source = source.toJSON();
        }
        seen.push(source);
        let result;
        if (utils$1.isArray(source)) {
          result = [];
          source.forEach((v, i) => {
            const reducedValue = visit(v);
            if (!utils$1.isUndefined(reducedValue)) {
              result[i] = reducedValue;
            }
          });
        } else {
          if (!utils$1.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
            seen.pop();
            return source;
          }
          result = /* @__PURE__ */ Object.create(null);
          for (const [key, value] of Object.entries(source)) {
            const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
            if (!utils$1.isUndefined(reducedValue)) {
              result[key] = reducedValue;
            }
          }
        }
        seen.pop();
        return result;
      };
      return visit(config);
    }
    function stringifySafely$1(value) {
      try {
        return String(value);
      } catch (err) {
        return "";
      }
    }
    function aggregateErrorMessage(error) {
      const message = error.errors.map((entry) => {
        try {
          return entry && entry.message ? stringifySafely$1(entry.message) : stringifySafely$1(entry);
        } catch (err) {
          return "";
        }
      }).filter(Boolean).join("; ");
      return message || error.name || "AggregateError";
    }
    var AxiosError = class _AxiosError extends Error {
      static from(error, code, config, request, response, customProps) {
        let message = error.message;
        if (!message && utils$1.isArray(error.errors) && error.errors.length) {
          message = aggregateErrorMessage(error);
        }
        const axiosError = new _AxiosError(message, code || error.code, config, request, response);
        Object.defineProperty(axiosError, "cause", {
          __proto__: null,
          value: error,
          writable: true,
          enumerable: false,
          configurable: true
        });
        axiosError.name = error.name;
        if (error.status != null && axiosError.status == null) {
          axiosError.status = error.status;
        }
        customProps && Object.assign(axiosError, customProps);
        return axiosError;
      }
      /**
       * Create an Error with the specified message, config, error code, request and response.
       *
       * @param {string} message The error message.
       * @param {string} [code] The error code (for example, 'ECONNABORTED').
       * @param {Object} [config] The config.
       * @param {Object} [request] The request.
       * @param {Object} [response] The response.
       *
       * @returns {Error} The created error.
       */
      constructor(message, code, config, request, response) {
        super(message);
        Object.defineProperty(this, "message", {
          // Null-proto descriptor so a polluted Object.prototype.get cannot turn
          // this data descriptor into an accessor descriptor on the way in.
          __proto__: null,
          value: message,
          enumerable: true,
          writable: true,
          configurable: true
        });
        this.name = "AxiosError";
        this.isAxiosError = true;
        code && (this.code = code);
        config && (this.config = config);
        request && (this.request = request);
        if (response) {
          this.response = response;
          this.status = response.status;
        }
      }
      toJSON() {
        const config = this.config;
        const redactKeys = config && utils$1.hasOwnProp(config, "redact") ? config.redact : void 0;
        const serializedConfig = utils$1.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config, redactKeys) : utils$1.toJSONObject(config);
        return {
          // Standard
          message: this.message,
          name: this.name,
          // Microsoft
          description: this.description,
          number: this.number,
          // Mozilla
          fileName: this.fileName,
          lineNumber: this.lineNumber,
          columnNumber: this.columnNumber,
          stack: this.stack,
          // Axios
          config: serializedConfig,
          code: this.code,
          status: this.status
        };
      }
    };
    AxiosError.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
    AxiosError.ERR_BAD_OPTION = "ERR_BAD_OPTION";
    AxiosError.ECONNABORTED = "ECONNABORTED";
    AxiosError.ETIMEDOUT = "ETIMEDOUT";
    AxiosError.ECONNREFUSED = "ECONNREFUSED";
    AxiosError.ERR_NETWORK = "ERR_NETWORK";
    AxiosError.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
    AxiosError.ERR_DEPRECATED = "ERR_DEPRECATED";
    AxiosError.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
    AxiosError.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
    AxiosError.ERR_CANCELED = "ERR_CANCELED";
    AxiosError.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
    AxiosError.ERR_INVALID_URL = "ERR_INVALID_URL";
    AxiosError.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
    var PlatformBuffer = {
      isBufferAvailable() {
        return typeof Buffer !== "undefined";
      },
      from(value) {
        return Buffer.from(value);
      }
    };
    var DEFAULT_FORM_DATA_MAX_DEPTH = 100;
    function isVisitable(thing) {
      return utils$1.isPlainObject(thing) || utils$1.isArray(thing);
    }
    function removeBrackets(key) {
      return utils$1.endsWith(key, "[]") ? key.slice(0, -2) : key;
    }
    function renderKey(path7, key, dots) {
      if (!path7) return key;
      return path7.concat(key).map(function each(token, i) {
        token = removeBrackets(token);
        return !dots && i ? "[" + token + "]" : token;
      }).join(dots ? "." : "");
    }
    function isFlatArray(arr) {
      return utils$1.isArray(arr) && !arr.some(isVisitable);
    }
    var predicates = utils$1.toFlatObject(utils$1, {}, null, function filter(prop) {
      return /^is[A-Z]/.test(prop);
    });
    function toFormData(obj, formData, options) {
      if (!utils$1.isObject(obj)) {
        throw new TypeError("target must be an object");
      }
      formData = formData || new (FormData$1 || FormData)();
      const option = (name, fallback) => {
        const value = utils$1.getSafeProp(options, name);
        return utils$1.isUndefined(value) ? fallback : value;
      };
      const metaTokens = option("metaTokens", true);
      const visitor = option("visitor") || defaultVisitor;
      const dots = option("dots", false);
      const indexes = option("indexes", false);
      const _Blob = option("Blob") || typeof Blob !== "undefined" && Blob;
      const maxDepth = option("maxDepth", DEFAULT_FORM_DATA_MAX_DEPTH);
      const useBlob = _Blob && utils$1.isSpecCompliantForm(formData);
      const stack = [];
      if (!utils$1.isFunction(visitor)) {
        throw new TypeError("visitor must be a function");
      }
      function convertValue(value) {
        if (value === null) return "";
        if (utils$1.isDate(value)) {
          return value.toISOString();
        }
        if (utils$1.isBoolean(value)) {
          return value.toString();
        }
        if (!useBlob && utils$1.isBlob(value)) {
          throw new AxiosError("Blob is not supported. Use a Buffer instead.");
        }
        if (utils$1.isArrayBuffer(value) || utils$1.isTypedArray(value)) {
          if (useBlob && typeof _Blob === "function") {
            return new _Blob([value]);
          }
          if (PlatformBuffer && PlatformBuffer.isBufferAvailable()) {
            return PlatformBuffer.from(value);
          }
          throw new AxiosError("Blob is not supported. Use a Buffer instead.", AxiosError.ERR_NOT_SUPPORT);
        }
        return value;
      }
      function throwIfMaxDepthExceeded(depth) {
        if (depth > maxDepth) {
          throw new AxiosError("Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth, AxiosError.ERR_FORM_DATA_DEPTH_EXCEEDED);
        }
      }
      function stringifyWithDepthLimit(value, depth) {
        if (maxDepth === Infinity) {
          return JSON.stringify(value);
        }
        const ancestors = [];
        return JSON.stringify(value, function limitDepth(_key, currentValue) {
          if (!utils$1.isObject(currentValue)) {
            return currentValue;
          }
          while (ancestors.length && ancestors[ancestors.length - 1] !== this) {
            ancestors.pop();
          }
          ancestors.push(currentValue);
          throwIfMaxDepthExceeded(depth + ancestors.length - 1);
          return currentValue;
        });
      }
      function defaultVisitor(value, key, path7) {
        let arr = value;
        if (utils$1.isReactNative(formData) && utils$1.isReactNativeBlob(value)) {
          formData.append(renderKey(path7, key, dots), convertValue(value));
          return false;
        }
        if (value && !path7 && typeof value === "object") {
          if (utils$1.endsWith(key, "{}")) {
            key = metaTokens ? key : key.slice(0, -2);
            value = stringifyWithDepthLimit(value, 1);
          } else if (utils$1.isArray(value) && isFlatArray(value) || (utils$1.isFileList(value) || utils$1.endsWith(key, "[]")) && (arr = utils$1.toArray(value))) {
            key = removeBrackets(key);
            arr.forEach(function each(el, index) {
              !(utils$1.isUndefined(el) || el === null) && formData.append(
                // eslint-disable-next-line no-nested-ternary
                indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]",
                convertValue(el)
              );
            });
            return false;
          }
        }
        if (isVisitable(value)) {
          return true;
        }
        formData.append(renderKey(path7, key, dots), convertValue(value));
        return false;
      }
      const exposedHelpers = Object.assign(predicates, {
        defaultVisitor,
        convertValue,
        isVisitable
      });
      function build(value, path7, depth = 0) {
        if (utils$1.isUndefined(value)) return;
        throwIfMaxDepthExceeded(depth);
        if (stack.indexOf(value) !== -1) {
          throw new Error("Circular reference detected in " + path7.join("."));
        }
        stack.push(value);
        utils$1.forEach(value, function each(el, key) {
          const result = !(utils$1.isUndefined(el) || el === null) && visitor.call(formData, el, utils$1.isString(key) ? key.trim() : key, path7, exposedHelpers);
          if (result === true) {
            build(el, path7 ? path7.concat(key) : [key], depth + 1);
          }
        });
        stack.pop();
      }
      if (!utils$1.isObject(obj)) {
        throw new TypeError("data must be an object");
      }
      build(obj);
      return formData;
    }
    function encode$1(str) {
      const charMap = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+"
      };
      return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
        return charMap[match];
      });
    }
    function AxiosURLSearchParams(params, options) {
      this._pairs = [];
      params && toFormData(params, this, options);
    }
    var prototype = AxiosURLSearchParams.prototype;
    prototype.append = function append(name, value) {
      this._pairs.push([name, value]);
    };
    prototype.toString = function toString2(encoder) {
      const _encode = encoder ? (value) => encoder.call(this, value, encode$1) : encode$1;
      return this._pairs.map(function each(pair) {
        return _encode(pair[0]) + "=" + _encode(pair[1]);
      }, "").join("&");
    };
    function encode(val) {
      return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
    }
    function buildURL(url2, params, options) {
      if (!params) {
        return url2;
      }
      url2 = url2 || "";
      const _options = utils$1.isFunction(options) ? {
        serialize: options
      } : options;
      const _encode = utils$1.getSafeProp(_options, "encode") || encode;
      const serializeFn = utils$1.getSafeProp(_options, "serialize");
      let serializedParams;
      if (serializeFn) {
        serializedParams = serializeFn(params, _options);
      } else {
        serializedParams = utils$1.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, _options).toString(_encode);
      }
      if (serializedParams) {
        const hashmarkIndex = url2.indexOf("#");
        if (hashmarkIndex !== -1) {
          url2 = url2.slice(0, hashmarkIndex);
        }
        url2 += (url2.indexOf("?") === -1 ? "?" : "&") + serializedParams;
      }
      return url2;
    }
    var $internals = /* @__PURE__ */ Symbol("internals");
    function countHandlers(handlers) {
      return handlers ? handlers.length : 0;
    }
    function trimHandlers(handlers) {
      if (!handlers) {
        return;
      }
      while (handlers.length && handlers[handlers.length - 1] === null) {
        handlers.pop();
      }
    }
    function syncHandlerEntries(manager, internals) {
      const handlers = manager.handlers;
      const length = countHandlers(handlers);
      if (handlers !== internals.handlersRef) {
        internals.handlersRef = handlers;
        internals.handlerEntries.clear();
      } else if (length !== internals.handlersLength) {
        if (!length) {
          internals.handlerEntries.clear();
        } else {
          internals.handlerEntries.forEach(function removeStaleEntry(entry, id) {
            if (handlers[entry.index] !== entry.handler) {
              internals.handlerEntries.delete(id);
            }
          });
        }
      }
      internals.handlersLength = length;
    }
    var InterceptorManager = class {
      constructor() {
        this.handlers = [];
        this[$internals] = {
          handlersRef: this.handlers,
          handlersLength: this.handlers.length,
          handlerEntries: /* @__PURE__ */ new Map(),
          iterationDepth: 0,
          nextId: 0
        };
      }
      /**
       * Add a new interceptor to the stack
       *
       * @param {Function} fulfilled The function to handle `then` for a `Promise`
       * @param {Function} rejected The function to handle `reject` for a `Promise`
       * @param {Object} options The options for the interceptor, synchronous and runWhen
       *
       * @return {Number} An ID used to remove interceptor later
       */
      use(fulfilled, rejected, options) {
        const handler = {
          fulfilled,
          rejected,
          synchronous: options ? options.synchronous : false,
          runWhen: options ? options.runWhen : null
        };
        const internals = this[$internals];
        if (this.handlers == null) {
          this.handlers = [];
        }
        syncHandlerEntries(this, internals);
        const id = internals.nextId++;
        this.handlers.push(handler);
        internals.handlerEntries.set(id, {
          handler,
          index: this.handlers.length - 1
        });
        internals.handlersLength = this.handlers.length;
        return id;
      }
      /**
       * Remove an interceptor from the stack
       *
       * @param {Number} id The ID that was returned by `use`
       *
       * @returns {void}
       */
      eject(id) {
        const internals = this[$internals];
        syncHandlerEntries(this, internals);
        const entry = internals.handlerEntries.get(id);
        if (entry) {
          internals.handlerEntries.delete(id);
          if (this.handlers[entry.index] !== entry.handler) {
            return;
          }
          this.handlers[entry.index] = null;
          if (!internals.iterationDepth) {
            trimHandlers(this.handlers);
            internals.handlersLength = this.handlers.length;
          }
        }
      }
      /**
       * Clear all interceptors from the stack
       *
       * @returns {void}
       */
      clear() {
        if (this.handlers) {
          this.handlers = [];
          syncHandlerEntries(this, this[$internals]);
        }
      }
      /**
       * Iterate over all the registered interceptors
       *
       * This method is particularly useful for skipping over any
       * interceptors that may have become `null` calling `eject`.
       *
       * @param {Function} fn The function to call for each interceptor
       *
       * @returns {void}
       */
      forEach(fn) {
        const internals = this[$internals];
        syncHandlerEntries(this, internals);
        internals.iterationDepth++;
        try {
          utils$1.forEach(this.handlers, function forEachHandler(h) {
            if (h !== null) {
              fn(h);
            }
          });
        } finally {
          if (!--internals.iterationDepth) {
            syncHandlerEntries(this, internals);
            trimHandlers(this.handlers);
            internals.handlersLength = countHandlers(this.handlers);
          }
        }
      }
    };
    var transitionalDefaults = {
      silentJSONParsing: true,
      forcedJSONParsing: true,
      clarifyTimeoutError: false,
      legacyInterceptorReqResOrdering: true,
      advertiseZstdAcceptEncoding: false,
      validateStatusUndefinedResolves: true
    };
    var URLSearchParams = url.URLSearchParams;
    var ALPHA = "abcdefghijklmnopqrstuvwxyz";
    var DIGIT = "0123456789";
    var ALPHABET = {
      DIGIT,
      ALPHA,
      ALPHA_DIGIT: ALPHA + ALPHA.toUpperCase() + DIGIT
    };
    var generateString = (size = 16, alphabet = ALPHABET.ALPHA_DIGIT) => {
      let str = "";
      const {
        length
      } = alphabet;
      const randomValues = new Uint32Array(size);
      crypto3.randomFillSync(randomValues);
      for (let i = 0; i < size; i++) {
        str += alphabet[randomValues[i] % length];
      }
      return str;
    };
    var platform$1 = {
      isNode: true,
      classes: {
        URLSearchParams,
        FormData: FormData$1,
        Blob: typeof Blob !== "undefined" && Blob || null
      },
      ALPHABET,
      generateString,
      protocols: ["http", "https", "file", "data"]
    };
    var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
    var _navigator = typeof navigator === "object" && navigator || void 0;
    var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || ["ReactNative", "NativeScript", "NS"].indexOf(_navigator.product) < 0);
    var hasStandardBrowserWebWorkerEnv = (() => {
      return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
      self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
    })();
    var origin = hasBrowserEnv && window.location.href || "http://localhost";
    var utils = /* @__PURE__ */ Object.freeze({
      __proto__: null,
      hasBrowserEnv,
      hasStandardBrowserEnv,
      hasStandardBrowserWebWorkerEnv,
      navigator: _navigator,
      origin
    });
    var platform = {
      ...utils,
      ...platform$1
    };
    function toURLEncodedForm(data, options) {
      return toFormData(data, new platform.classes.URLSearchParams(), {
        visitor: function(value, key, path7, helpers) {
          if (platform.isNode && utils$1.isBuffer(value)) {
            this.append(key, value.toString("base64"));
            return false;
          }
          return helpers.defaultVisitor.apply(this, arguments);
        },
        ...options
      });
    }
    var MAX_DEPTH = DEFAULT_FORM_DATA_MAX_DEPTH;
    function throwIfDepthExceeded(index) {
      if (index > MAX_DEPTH) {
        throw new AxiosError("FormData field is too deeply nested (" + index + " levels). Max depth: " + MAX_DEPTH, AxiosError.ERR_FORM_DATA_DEPTH_EXCEEDED);
      }
    }
    function parsePropPath(name) {
      const path7 = [];
      const pattern = /[^.[\]]+|\[([^.[\]]*)]/g;
      let match;
      while ((match = pattern.exec(name)) !== null) {
        throwIfDepthExceeded(path7.length);
        path7.push(match[0] === "[]" ? "" : match[1] || match[0]);
      }
      return path7;
    }
    function arrayToObject(arr) {
      const obj = {};
      const keys = Object.keys(arr);
      let i;
      const len = keys.length;
      let key;
      for (i = 0; i < len; i++) {
        key = keys[i];
        obj[key] = arr[key];
      }
      return obj;
    }
    function formDataToJSON(formData) {
      function buildPath(path7, value, target, index) {
        throwIfDepthExceeded(index);
        let name = path7[index++];
        if (name === "__proto__") return true;
        const isNumericKey = Number.isFinite(+name);
        const isLast = index >= path7.length;
        name = !name && utils$1.isArray(target) ? target.length : name;
        if (isLast) {
          if (utils$1.hasOwnProp(target, name)) {
            target[name] = utils$1.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
          } else {
            target[name] = value;
          }
          return !isNumericKey;
        }
        if (!utils$1.hasOwnProp(target, name) || !utils$1.isObject(target[name])) {
          target[name] = [];
        }
        const result = buildPath(path7, value, target[name], index);
        if (result && utils$1.isArray(target[name])) {
          target[name] = arrayToObject(target[name]);
        }
        return !isNumericKey;
      }
      if (utils$1.isFormData(formData) && utils$1.isFunction(formData.entries)) {
        const obj = {};
        utils$1.forEachEntry(formData, (name, value) => {
          buildPath(parsePropPath(name), value, obj, 0);
        });
        return obj;
      }
      return null;
    }
    var methodList = Object.freeze(["get", "delete", "head", "options", "post", "put", "patch", "purge", "link", "unlink", "query"]);
    var own = (obj, key) => obj != null && utils$1.hasOwnProp(obj, key) ? obj[key] : void 0;
    function stringifySafely(rawValue, parser, encoder) {
      if (utils$1.isString(rawValue)) {
        try {
          (parser || JSON.parse)(rawValue);
          return utils$1.trim(rawValue);
        } catch (e) {
          if (e.name !== "SyntaxError") {
            throw e;
          }
        }
      }
      return (encoder || JSON.stringify)(rawValue);
    }
    var defaults = {
      transitional: transitionalDefaults,
      adapter: ["xhr", "http", "fetch"],
      transformRequest: [function transformRequest(data, headers) {
        const contentType = headers.getContentType() || "";
        const hasJSONContentType = contentType.indexOf("application/json") > -1;
        const isObjectPayload = utils$1.isObject(data);
        if (isObjectPayload && utils$1.isHTMLForm(data)) {
          data = new FormData(data);
        }
        const isFormData2 = utils$1.isFormData(data);
        if (isFormData2) {
          return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
        }
        if (utils$1.isArrayBuffer(data) || utils$1.isBuffer(data) || utils$1.isStream(data) || utils$1.isFile(data) || utils$1.isBlob(data) || utils$1.isReadableStream(data)) {
          return data;
        }
        if (utils$1.isArrayBufferView(data)) {
          return data.buffer;
        }
        if (utils$1.isURLSearchParams(data)) {
          headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
          return data.toString();
        }
        let isFileList2;
        if (isObjectPayload) {
          const formSerializer = own(this, "formSerializer");
          if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
            return toURLEncodedForm(data, formSerializer).toString();
          }
          if ((isFileList2 = utils$1.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
            const env = own(this, "env");
            const _FormData = env && env.FormData;
            return toFormData(isFileList2 ? {
              "files[]": data
            } : data, _FormData && new _FormData(), formSerializer);
          }
        }
        if (isObjectPayload || hasJSONContentType) {
          headers.setContentType("application/json", false);
          return stringifySafely(data);
        }
        return data;
      }],
      transformResponse: [function transformResponse(data) {
        const transitional = own(this, "transitional") || defaults.transitional;
        const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
        const responseType = own(this, "responseType");
        const JSONRequested = responseType === "json";
        if (utils$1.isResponse(data) || utils$1.isReadableStream(data)) {
          return data;
        }
        if (data && utils$1.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
          const silentJSONParsing = transitional && transitional.silentJSONParsing;
          const strictJSONParsing = !silentJSONParsing && JSONRequested;
          try {
            return JSON.parse(data, own(this, "parseReviver"));
          } catch (e) {
            if (strictJSONParsing) {
              if (e.name === "SyntaxError") {
                throw AxiosError.from(e, AxiosError.ERR_BAD_RESPONSE, this, null, own(this, "response"));
              }
              throw e;
            }
          }
        }
        return data;
      }],
      /**
       * A timeout in milliseconds to abort a request. If set to 0 (default) a
       * timeout is not created.
       */
      timeout: 0,
      xsrfCookieName: "XSRF-TOKEN",
      xsrfHeaderName: "X-XSRF-TOKEN",
      maxContentLength: -1,
      maxBodyLength: -1,
      env: {
        FormData: platform.classes.FormData,
        Blob: platform.classes.Blob
      },
      validateStatus: function validateStatus(status) {
        return status >= 200 && status < 300;
      },
      headers: {
        common: {
          Accept: "application/json, text/plain, */*",
          "Content-Type": void 0
        }
      }
    };
    utils$1.forEach(methodList, (method) => {
      defaults.headers[method] = {};
    });
    function transformData(fns, response) {
      const config = this || defaults;
      const context = response || config;
      const headers = AxiosHeaders.from(context.headers);
      let data = context.data;
      utils$1.forEach(fns, function transform(fn) {
        data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
      });
      headers.normalize();
      return data;
    }
    function isCancel(value) {
      return !!(value && value.__CANCEL__);
    }
    var CanceledError = class extends AxiosError {
      /**
       * A `CanceledError` is an object that is thrown when an operation is canceled.
       *
       * @param {string=} message The message.
       * @param {Object=} config The config.
       * @param {Object=} request The request.
       *
       * @returns {CanceledError} The created error.
       */
      constructor(message, config, request) {
        super(message == null ? "canceled" : message, AxiosError.ERR_CANCELED, config, request);
        this.name = "CanceledError";
        this.__CANCEL__ = true;
      }
    };
    function settle(resolve, reject, response) {
      const validateStatus = response.config.validateStatus;
      if (!response.status || !validateStatus || validateStatus(response.status)) {
        resolve(response);
      } else {
        reject(new AxiosError("Request failed with status code " + response.status, response.status >= 400 && response.status < 500 ? AxiosError.ERR_BAD_REQUEST : AxiosError.ERR_BAD_RESPONSE, response.config, response.request, response));
      }
    }
    function isAbsoluteURL(url2) {
      if (typeof url2 !== "string") {
        return false;
      }
      return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url2);
    }
    function combineURLs(baseURL, relativeURL) {
      if (!relativeURL) {
        return baseURL;
      }
      let end = baseURL.length;
      while (end > 0 && baseURL.charCodeAt(end - 1) === 47) {
        end--;
      }
      return baseURL.slice(0, end) + "/" + relativeURL.replace(/^\/+/, "");
    }
    var urlParserControlCharacters = /[\t\n\r]/g;
    function normalizeURLForProtocolCheck(url2) {
      if (typeof url2 !== "string") {
        return url2;
      }
      let start = 0;
      while (start < url2.length && url2.charCodeAt(start) <= 32) {
        start++;
      }
      return url2.slice(start).replace(urlParserControlCharacters, "");
    }
    var malformedHttpProtocol = /^https?:(?!\/\/)/i;
    function redactFragment(fragment) {
      if (!fragment) {
        return fragment;
      }
      return fragment.replace(/(^|&)([^=&]*=)?[^&]+/g, (match, separator, parameterName = "") => {
        return `${separator}${parameterName}${REDACTED}`;
      });
    }
    function redactSensitiveURLParts(url2) {
      const redactedURL = url2.replace(/^(https?:\/{0,2})[^/?#]*@/i, `$1${REDACTED}@`);
      const fragmentIndex = redactedURL.indexOf("#");
      const urlWithoutFragment = fragmentIndex === -1 ? redactedURL : redactedURL.slice(0, fragmentIndex);
      const redactedURLWithoutFragment = urlWithoutFragment.replace(/([?&][^=&#]*=)[^&#]*/g, `$1${REDACTED}`);
      if (fragmentIndex === -1) {
        return redactedURLWithoutFragment;
      }
      return `${redactedURLWithoutFragment}#${redactFragment(redactedURL.slice(fragmentIndex + 1))}`;
    }
    function assertValidHttpProtocolURL(url2, config) {
      if (typeof url2 === "string") {
        const normalizedURL = normalizeURLForProtocolCheck(url2);
        if (malformedHttpProtocol.test(normalizedURL)) {
          throw new AxiosError(`Invalid URL ${JSON.stringify(redactSensitiveURLParts(normalizedURL))}: missing "//" after protocol`, AxiosError.ERR_INVALID_URL, config);
        }
      }
    }
    function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls, config) {
      assertValidHttpProtocolURL(requestedURL, config);
      let isRelativeUrl = !isAbsoluteURL(requestedURL);
      if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
        assertValidHttpProtocolURL(baseURL, config);
        return combineURLs(baseURL, requestedURL);
      }
      return requestedURL;
    }
    var DEFAULT_PORTS$1 = {
      ftp: 21,
      gopher: 70,
      http: 80,
      https: 443,
      ws: 80,
      wss: 443
    };
    function parseUrl(urlString) {
      try {
        return new URL(urlString);
      } catch {
        return null;
      }
    }
    function getProxyForUrl(url2) {
      var parsedUrl = (typeof url2 === "string" ? parseUrl(url2) : url2) || {};
      var proto = parsedUrl.protocol;
      var hostname = parsedUrl.host;
      var port = parsedUrl.port;
      if (typeof hostname !== "string" || !hostname || typeof proto !== "string") {
        return "";
      }
      proto = proto.split(":", 1)[0];
      hostname = hostname.replace(/:\d*$/, "");
      port = parseInt(port) || DEFAULT_PORTS$1[proto] || 0;
      if (!shouldProxy(hostname, port)) {
        return "";
      }
      var proxy = getEnv(proto + "_proxy") || getEnv("all_proxy");
      if (proxy && proxy.indexOf("://") === -1) {
        proxy = proto + "://" + proxy;
      }
      return proxy;
    }
    function shouldProxy(hostname, port) {
      var NO_PROXY = getEnv("no_proxy").toLowerCase();
      if (!NO_PROXY) {
        return true;
      }
      if (NO_PROXY === "*") {
        return false;
      }
      return NO_PROXY.split(/[,\s]/).every(function(proxy) {
        if (!proxy) {
          return true;
        }
        var parsedProxy = proxy.match(/^(.+):(\d+)$/);
        var parsedProxyHostname = parsedProxy ? parsedProxy[1] : proxy;
        var parsedProxyPort = parsedProxy ? parseInt(parsedProxy[2]) : 0;
        if (parsedProxyPort && parsedProxyPort !== port) {
          return true;
        }
        if (!/^[.*]/.test(parsedProxyHostname)) {
          return hostname !== parsedProxyHostname;
        }
        if (parsedProxyHostname.charAt(0) === "*") {
          parsedProxyHostname = parsedProxyHostname.slice(1);
        }
        return !hostname.endsWith(parsedProxyHostname);
      });
    }
    function getEnv(key) {
      return process.env[key.toLowerCase()] || process.env[key.toUpperCase()] || "";
    }
    var VERSION = "1.20.0";
    function parseProtocol(url2) {
      const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url2);
      return match && match[1] || "";
    }
    var DATA_URL_PATTERN = /^([^,;/]+\/[^,;/]+)?((?:;[^,;=]+=[^,;]+)*)(;base64)?,([\s\S]*)$/;
    function fromDataURI(uri, asBlob, options) {
      const _Blob = options && options.Blob || platform.classes.Blob;
      const protocol = parseProtocol(uri);
      if (asBlob === void 0 && _Blob) {
        asBlob = true;
      }
      if (protocol === "data") {
        uri = protocol.length ? uri.slice(protocol.length + 1) : uri;
        const match = DATA_URL_PATTERN.exec(uri);
        if (!match) {
          throw new AxiosError("Invalid URL", AxiosError.ERR_INVALID_URL);
        }
        const type = match[1];
        const params = match[2];
        const encoding = match[3] ? "base64" : "utf8";
        const body = match[4];
        let mime = "";
        if (type) {
          mime = params ? type + params : type;
        } else if (params) {
          mime = "text/plain" + params;
        }
        const buffer = encoding === "base64" ? Buffer.from(body, "base64") : Buffer.from(decodeURIComponent(body), encoding);
        if (asBlob) {
          if (!_Blob) {
            throw new AxiosError("Blob is not supported", AxiosError.ERR_NOT_SUPPORT);
          }
          return new _Blob([buffer], {
            type: mime
          });
        }
        return buffer;
      }
      throw new AxiosError("Unsupported protocol " + protocol, AxiosError.ERR_NOT_SUPPORT);
    }
    var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
    function setFormDataHeaders(headers, formHeaders, policy) {
      if (policy !== "content-only") {
        headers.set(formHeaders);
        return;
      }
      Object.entries(formHeaders || {}).forEach(([key, val]) => {
        if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) {
          headers.set(key, val);
        }
      });
    }
    var kInternals = /* @__PURE__ */ Symbol("internals");
    var AxiosTransformStream = class extends stream.Transform {
      constructor(options) {
        options = utils$1.toFlatObject(options, {
          maxRate: 0,
          chunkSize: 64 * 1024,
          minChunkSize: 100,
          timeWindow: 500,
          ticksRate: 2,
          samplesCount: 15
        }, null, (prop, source) => {
          return !utils$1.isUndefined(source[prop]);
        });
        super({
          readableHighWaterMark: options.chunkSize
        });
        const internals = this[kInternals] = {
          timeWindow: options.timeWindow,
          chunkSize: options.chunkSize,
          maxRate: options.maxRate,
          minChunkSize: options.minChunkSize,
          bytesSeen: 0,
          isCaptured: false,
          notifiedBytesLoaded: 0,
          ts: Date.now(),
          bytes: 0,
          onReadCallback: null
        };
        this.on("newListener", (event) => {
          if (event === "progress") {
            if (!internals.isCaptured) {
              internals.isCaptured = true;
            }
          }
        });
      }
      _read(size) {
        const internals = this[kInternals];
        if (internals.onReadCallback) {
          internals.onReadCallback();
        }
        return super._read(size);
      }
      _transform(chunk, encoding, callback) {
        const internals = this[kInternals];
        const maxRate = internals.maxRate;
        const readableHighWaterMark = this.readableHighWaterMark;
        const timeWindow = internals.timeWindow;
        const divider = 1e3 / timeWindow;
        const bytesThreshold = maxRate / divider;
        const minChunkSize = internals.minChunkSize !== false ? Math.max(internals.minChunkSize, bytesThreshold * 0.01) : 0;
        const pushChunk = (_chunk, _callback) => {
          const bytes = Buffer.byteLength(_chunk);
          internals.bytesSeen += bytes;
          internals.bytes += bytes;
          internals.isCaptured && this.emit("progress", internals.bytesSeen);
          if (this.push(_chunk)) {
            process.nextTick(_callback);
          } else {
            internals.onReadCallback = () => {
              internals.onReadCallback = null;
              process.nextTick(_callback);
            };
          }
        };
        const transformChunk = (_chunk, _callback) => {
          const chunkSize = Buffer.byteLength(_chunk);
          let chunkRemainder = null;
          let maxChunkSize = readableHighWaterMark;
          let bytesLeft;
          let passed = 0;
          if (maxRate) {
            const now = Date.now();
            if (!internals.ts || (passed = now - internals.ts) >= timeWindow) {
              internals.ts = now;
              bytesLeft = bytesThreshold - internals.bytes;
              internals.bytes = bytesLeft < 0 ? -bytesLeft : 0;
              passed = 0;
            }
            bytesLeft = bytesThreshold - internals.bytes;
          }
          if (maxRate) {
            if (bytesLeft <= 0) {
              return setTimeout(() => {
                _callback(null, _chunk);
              }, timeWindow - passed);
            }
            if (bytesLeft < maxChunkSize) {
              maxChunkSize = bytesLeft;
            }
          }
          if (maxChunkSize && chunkSize > maxChunkSize && chunkSize - maxChunkSize > minChunkSize) {
            chunkRemainder = _chunk.subarray(maxChunkSize);
            _chunk = _chunk.subarray(0, maxChunkSize);
          }
          pushChunk(_chunk, chunkRemainder ? () => {
            process.nextTick(_callback, null, chunkRemainder);
          } : _callback);
        };
        transformChunk(chunk, function transformNextChunk(err, _chunk) {
          if (err) {
            return callback(err);
          }
          if (_chunk) {
            transformChunk(_chunk, transformNextChunk);
          } else {
            callback(null);
          }
        });
      }
    };
    var {
      asyncIterator
    } = Symbol;
    var readBlob = async function* (blob) {
      if (blob.stream) {
        yield* blob.stream();
      } else if (blob.arrayBuffer) {
        yield await blob.arrayBuffer();
      } else if (blob[asyncIterator]) {
        yield* blob[asyncIterator]();
      } else {
        yield blob;
      }
    };
    var BOUNDARY_ALPHABET = platform.ALPHABET.ALPHA_DIGIT + "-_";
    var textEncoder = typeof TextEncoder === "function" ? new TextEncoder() : new util.TextEncoder();
    var CRLF = "\r\n";
    var CRLF_BYTES = textEncoder.encode(CRLF);
    var CRLF_BYTES_COUNT = 2;
    var FormDataPart = class {
      constructor(name, value) {
        const {
          escapeName
        } = this.constructor;
        const isStringValue = utils$1.isString(value);
        let headers = `Content-Disposition: form-data; name="${escapeName(name)}"${!isStringValue && value.name ? `; filename="${escapeName(value.name)}"` : ""}${CRLF}`;
        if (isStringValue) {
          value = textEncoder.encode(String(value).replace(/\r?\n|\r\n?/g, CRLF));
        } else {
          const safeType = String(value.type || "application/octet-stream").replace(/[\r\n]/g, "");
          headers += `Content-Type: ${safeType}${CRLF}`;
        }
        this.headers = textEncoder.encode(headers + CRLF);
        this.contentLength = isStringValue ? value.byteLength : value.size;
        this.size = this.headers.byteLength + this.contentLength + CRLF_BYTES_COUNT;
        this.name = name;
        this.value = value;
      }
      async *encode() {
        yield this.headers;
        const {
          value
        } = this;
        if (utils$1.isTypedArray(value)) {
          yield value;
        } else {
          yield* readBlob(value);
        }
        yield CRLF_BYTES;
      }
      static escapeName(name) {
        return String(name).replace(/[\r\n"]/g, (match) => ({
          "\r": "%0D",
          "\n": "%0A",
          '"': "%22"
        })[match]);
      }
    };
    var formDataToStream = (form, headersHandler, options) => {
      const {
        tag = "form-data-boundary",
        size = 25,
        boundary = tag + "-" + platform.generateString(size, BOUNDARY_ALPHABET)
      } = options || {};
      if (!utils$1.isFormData(form)) {
        throw new TypeError("FormData instance required");
      }
      if (boundary.length < 1 || boundary.length > 70) {
        throw new Error("boundary must be 1-70 characters long");
      }
      const boundaryBytes = textEncoder.encode("--" + boundary + CRLF);
      const footerBytes = textEncoder.encode("--" + boundary + "--" + CRLF);
      let contentLength = footerBytes.byteLength;
      const parts = Array.from(form.entries()).map(([name, value]) => {
        const part = new FormDataPart(name, value);
        contentLength += part.size;
        return part;
      });
      contentLength += boundaryBytes.byteLength * parts.length;
      contentLength = utils$1.toFiniteNumber(contentLength);
      const computedHeaders = {
        "Content-Type": `multipart/form-data; boundary=${boundary}`
      };
      if (Number.isFinite(contentLength)) {
        computedHeaders["Content-Length"] = contentLength;
      }
      headersHandler && headersHandler(computedHeaders);
      return stream.Readable.from((async function* () {
        for (const part of parts) {
          yield boundaryBytes;
          yield* part.encode();
        }
        yield footerBytes;
      })());
    };
    var ZlibHeaderTransformStream = class extends stream.Transform {
      __transform(chunk, encoding, callback) {
        this.push(chunk);
        callback();
      }
      _transform(chunk, encoding, callback) {
        if (chunk.length !== 0) {
          this._transform = this.__transform;
          if (chunk[0] !== 120) {
            const header = Buffer.alloc(2);
            header[0] = 120;
            header[1] = 156;
            this.push(header, encoding);
          }
        }
        this.__transform(chunk, encoding, callback);
      }
    };
    var Http2Sessions = class {
      constructor() {
        this.sessions = /* @__PURE__ */ Object.create(null);
      }
      getSession(authority, options) {
        options = Object.assign(/* @__PURE__ */ Object.create(null), {
          sessionTimeout: 1e3
        }, options);
        let authoritySessions = this.sessions[authority];
        if (authoritySessions) {
          let len = authoritySessions.length;
          for (let i = 0; i < len; i++) {
            const [sessionHandle, sessionOptions] = authoritySessions[i];
            if (!sessionHandle.destroyed && !sessionHandle.closed && util.isDeepStrictEqual(sessionOptions, options)) {
              return sessionHandle;
            }
          }
        }
        const session = http22.connect(authority, options);
        let removed;
        let timer;
        const removeSession = () => {
          if (removed) {
            return;
          }
          removed = true;
          if (timer) {
            clearTimeout(timer);
            timer = null;
          }
          let entries = authoritySessions, len = entries.length, i = len;
          while (i--) {
            if (entries[i][0] === session) {
              if (len === 1) {
                delete this.sessions[authority];
              } else {
                entries.splice(i, 1);
              }
              if (!session.closed) {
                session.close();
              }
              return;
            }
          }
        };
        const originalRequestFn = session.request;
        const {
          sessionTimeout
        } = options;
        if (sessionTimeout != null) {
          let streamsCount = 0;
          session.request = function() {
            const stream2 = originalRequestFn.apply(this, arguments);
            streamsCount++;
            if (timer) {
              clearTimeout(timer);
              timer = null;
            }
            stream2.once("close", () => {
              if (!--streamsCount) {
                timer = setTimeout(() => {
                  timer = null;
                  removeSession();
                }, sessionTimeout);
              }
            });
            return stream2;
          };
        }
        session.once("close", removeSession);
        session.once("error", removeSession);
        let entry = [session, options];
        authoritySessions ? authoritySessions.push(entry) : authoritySessions = this.sessions[authority] = [entry];
        return session;
      }
    };
    var callbackify = (fn, reducer) => {
      return utils$1.isAsyncFn(fn) ? function(...args) {
        const cb = args.pop();
        fn.apply(this, args).then((value) => {
          try {
            reducer ? cb(null, ...reducer(value)) : cb(null, value);
          } catch (err) {
            cb(err);
          }
        }, cb);
      } : fn;
    };
    var LOOPBACK_HOSTNAMES = /* @__PURE__ */ new Set(["localhost", "0.0.0.0"]);
    var trimTrailingDots = (value) => {
      let end = value.length;
      while (end && value.charCodeAt(end - 1) === 46) {
        end--;
      }
      return end === value.length ? value : value.slice(0, end);
    };
    var isIPv4Loopback = (host) => {
      const parts = host.split(".");
      if (parts.length !== 4) return false;
      if (parts[0] !== "127") return false;
      return parts.every((p) => /^\d+$/.test(p) && Number(p) >= 0 && Number(p) <= 255);
    };
    var parseIPv4Octet = (text) => {
      if (/^0[xX][0-9a-fA-F]+$/.test(text)) {
        const n = parseInt(text.slice(2), 16);
        return Number.isFinite(n) ? n : null;
      }
      if (text.length > 1 && /^0[0-7]+$/.test(text)) {
        const n = parseInt(text, 8);
        return Number.isFinite(n) ? n : null;
      }
      if (text.length > 1 && /^0[0-9]+$/.test(text)) {
        return null;
      }
      if (/^[0-9]+$/.test(text)) {
        const n = parseInt(text, 10);
        return Number.isFinite(n) ? n : null;
      }
      return null;
    };
    var normalizeIPAddress = (host) => {
      if (typeof host !== "string" || !host || host.indexOf(":") !== -1) {
        return host;
      }
      let h = host;
      if (h.charAt(0) === "[" && h.charAt(h.length - 1) === "]") {
        h = h.slice(1, -1);
      }
      h = trimTrailingDots(h);
      if (!/^[0-9.xXa-fA-F]+$/.test(h)) return host;
      const parts = h.split(".");
      if (parts.some((p) => p === "")) return host;
      if (parts.length === 4) {
        const octets = parts.map(parseIPv4Octet);
        if (octets.some((n) => n === null || n < 0 || n > 255)) return host;
        return octets.join(".");
      }
      if (parts.length > 4) {
        return host;
      }
      if (parts.length === 1) return host;
      const literalOctets = parts.slice(0, -1);
      const tail = parts[parts.length - 1];
      const tailSlots = 4 - literalOctets.length;
      const tailValue = parseIPv4Octet(tail);
      if (tailValue === null) return host;
      const maxTail = (1 << 8 * tailSlots) - 1;
      if (tailValue < 0 || tailValue > maxTail) return host;
      const tailOctets = new Array(tailSlots).fill(0);
      for (let i = tailSlots - 1, v = tailValue; i >= 0; i--, v >>= 8) {
        tailOctets[i] = v & 255;
      }
      const literal = literalOctets.map(parseIPv4Octet);
      if (literal.some((n) => n === null || n < 0 || n > 255)) return host;
      return [...literal, ...tailOctets].join(".");
    };
    var isIPv6ZeroGroup = (group) => /^0{1,4}$/.test(group);
    var isIPv6Unspecified = (host) => {
      if (host === "::") return true;
      const compressionIndex = host.indexOf("::");
      if (compressionIndex !== -1) {
        if (compressionIndex !== host.lastIndexOf("::")) return false;
        const left = host.slice(0, compressionIndex);
        const right = host.slice(compressionIndex + 2);
        const leftGroups = left ? left.split(":") : [];
        const rightGroups = right ? right.split(":") : [];
        const explicitGroups = leftGroups.length + rightGroups.length;
        return explicitGroups < 8 && leftGroups.every(isIPv6ZeroGroup) && rightGroups.every(isIPv6ZeroGroup);
      }
      const groups = host.split(":");
      return groups.length === 8 && groups.every(isIPv6ZeroGroup);
    };
    var isIPv6Loopback = (host) => {
      if (host === "::1") return true;
      const v4MappedDotted = host.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i);
      if (v4MappedDotted) return isIPv4Loopback(v4MappedDotted[1]);
      const v4MappedHex = host.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i);
      if (v4MappedHex) {
        const high = parseInt(v4MappedHex[1], 16);
        return high >= 32512 && high <= 32767;
      }
      const groups = host.split(":");
      if (groups.length === 8) {
        for (let i = 0; i < 7; i++) {
          if (!/^0+$/.test(groups[i])) return false;
        }
        return /^0*1$/.test(groups[7]);
      }
      return false;
    };
    var isLoopback = (host) => {
      if (!host) return false;
      if (LOOPBACK_HOSTNAMES.has(host)) return true;
      if (isIPv4Loopback(host)) return true;
      if (isIPv6Unspecified(host)) return true;
      return isIPv6Loopback(host);
    };
    var DEFAULT_PORTS = {
      http: 80,
      https: 443,
      ws: 80,
      wss: 443,
      ftp: 21
    };
    var parseNoProxyEntry = (entry) => {
      let entryHost = entry;
      let entryPort = 0;
      if (entryHost.charAt(0) === "[") {
        const bracketIndex = entryHost.indexOf("]");
        if (bracketIndex !== -1) {
          const host = entryHost.slice(1, bracketIndex);
          const rest = entryHost.slice(bracketIndex + 1);
          if (rest.charAt(0) === ":" && /^\d+$/.test(rest.slice(1))) {
            entryPort = Number.parseInt(rest.slice(1), 10);
          }
          return [host, entryPort];
        }
      }
      const firstColon = entryHost.indexOf(":");
      const lastColon = entryHost.lastIndexOf(":");
      if (firstColon !== -1 && firstColon === lastColon && /^\d+$/.test(entryHost.slice(lastColon + 1))) {
        entryPort = Number.parseInt(entryHost.slice(lastColon + 1), 10);
        entryHost = entryHost.slice(0, lastColon);
      }
      return [entryHost, entryPort];
    };
    var IPV4_MAPPED_DOTTED_RE = /^(?:::|(?:0{1,4}:){1,4}:|(?:0{1,4}:){5})ffff:(\d+\.\d+\.\d+\.\d+)$/i;
    var IPV4_MAPPED_HEX_RE = /^(?:::|(?:0{1,4}:){1,4}:|(?:0{1,4}:){5})ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i;
    var unmapIPv4MappedIPv6 = (host) => {
      if (typeof host !== "string" || host.indexOf(":") === -1) return host;
      const dotted = host.match(IPV4_MAPPED_DOTTED_RE);
      if (dotted) return dotted[1];
      const hex = host.match(IPV4_MAPPED_HEX_RE);
      if (hex) {
        const high = parseInt(hex[1], 16);
        const low = parseInt(hex[2], 16);
        return `${high >> 8}.${high & 255}.${low >> 8}.${low & 255}`;
      }
      return host;
    };
    var IPV4_OCTET_RE = /^(?:0|[1-9]\d{0,2})$/;
    var ipv4ToBytes = (host) => {
      const parts = host.split(".");
      return parts.length === 4 && parts.every((part) => IPV4_OCTET_RE.test(part) && Number(part) <= 255) ? parts.map(Number) : null;
    };
    var IPV6_GROUP_RE = /^[0-9a-f]{1,4}$/i;
    var ipv6ToBytes = (host) => {
      const halves = host.split("::");
      if (halves.length > 2) {
        return null;
      }
      const groups = halves[0] ? halves[0].split(":") : [];
      if (halves.length === 2) {
        const rear = halves[1] ? halves[1].split(":") : [];
        const missing = 8 - groups.length - rear.length;
        if (missing < 1) {
          return null;
        }
        groups.push(...new Array(missing).fill("0"), ...rear);
      }
      if (groups.length !== 8 || groups.some((group) => !IPV6_GROUP_RE.test(group))) {
        return null;
      }
      return groups.flatMap((group) => {
        const value = Number.parseInt(group, 16);
        return [value >> 8 & 255, value & 255];
      });
    };
    var ipToBytes = (host) => {
      if (typeof host !== "string" || !host) {
        return null;
      }
      return host.indexOf(":") !== -1 ? ipv6ToBytes(host) : ipv4ToBytes(host);
    };
    var normalizeNoProxyHost = (hostname) => {
      if (!hostname) {
        return hostname;
      }
      if (hostname.charAt(0) === "[" && hostname.charAt(hostname.length - 1) === "]") {
        hostname = hostname.slice(1, -1);
      }
      const trimmed = trimTrailingDots(hostname);
      const ipv4 = normalizeIPAddress(trimmed);
      if (ipv4 !== trimmed) {
        return ipv4;
      }
      return unmapIPv4MappedIPv6(trimmed);
    };
    var normalizeCidrBase = (input) => {
      let base = input;
      const startsBracket = base.charAt(0) === "[";
      const endsBracket = base.charAt(base.length - 1) === "]";
      const hasBracket = base.includes("[") || base.includes("]");
      if (startsBracket || endsBracket) {
        if (!startsBracket || !endsBracket) {
          return null;
        }
        base = base.slice(1, -1);
        if (base.indexOf(":") === -1 || base.includes("[") || base.includes("]")) {
          return null;
        }
      } else if (hasBracket) {
        return null;
      }
      if (!base || base.charAt(base.length - 1) === ".") {
        return null;
      }
      const wasIPv6 = base.indexOf(":") !== -1;
      if (wasIPv6) {
        try {
          base = new URL(`http://[${base}]/`).hostname.slice(1, -1);
        } catch (_err) {
          return null;
        }
      } else {
        base = normalizeIPAddress(base);
        if (!ipv4ToBytes(base)) {
          return null;
        }
      }
      return {
        normalized: unmapIPv4MappedIPv6(base),
        wasIPv6
      };
    };
    var CIDR_ENTRY_RE = /^(.+)\/(0|[1-9]\d{0,2})$/;
    var parseCidrEntry = (entry) => {
      if (entry.indexOf("/") === -1) {
        return void 0;
      }
      const match = CIDR_ENTRY_RE.exec(entry);
      if (!match) {
        return null;
      }
      let prefix = Number(match[2]);
      const parsedBase = normalizeCidrBase(match[1]);
      if (!parsedBase) {
        return null;
      }
      const {
        normalized,
        wasIPv6
      } = parsedBase;
      if (wasIPv6 && normalized.indexOf(":") === -1) {
        if (prefix < 96) {
          return null;
        }
        prefix -= 96;
      }
      const bytes = ipToBytes(normalized);
      if (!bytes || prefix > bytes.length * 8) {
        return null;
      }
      return {
        bytes,
        prefix
      };
    };
    var isInSubnet = (addressBytes, networkBytes, prefix) => {
      const fullBytes = prefix >> 3;
      for (let i = 0; i < fullBytes; i++) {
        if (addressBytes[i] !== networkBytes[i]) {
          return false;
        }
      }
      const remainingBits = prefix & 7;
      if (remainingBits) {
        const mask = 255 << 8 - remainingBits & 255;
        if ((addressBytes[fullBytes] & mask) !== (networkBytes[fullBytes] & mask)) {
          return false;
        }
      }
      return true;
    };
    function shouldBypassProxy(location) {
      let parsed;
      try {
        parsed = new URL(location);
      } catch (_err) {
        return false;
      }
      const noProxy = (process.env.no_proxy || process.env.NO_PROXY || "").toLowerCase();
      if (!noProxy) {
        return false;
      }
      if (noProxy === "*") {
        return true;
      }
      const port = Number.parseInt(parsed.port, 10) || DEFAULT_PORTS[parsed.protocol.split(":", 1)[0]] || 0;
      const hostname = normalizeNoProxyHost(parsed.hostname.toLowerCase());
      const hostnameBytes = ipToBytes(hostname);
      return noProxy.split(/[\s,]+/).some((entry) => {
        if (!entry) {
          return false;
        }
        if (entry === "*") {
          return true;
        }
        const cidr = parseCidrEntry(entry);
        if (cidr !== void 0) {
          return cidr !== null && !!hostnameBytes && hostnameBytes.length === cidr.bytes.length && isInSubnet(hostnameBytes, cidr.bytes, cidr.prefix);
        }
        let [entryHost, entryPort] = parseNoProxyEntry(entry);
        entryHost = normalizeNoProxyHost(entryHost);
        if (!entryHost) {
          return false;
        }
        if (entryPort && entryPort !== port) {
          return false;
        }
        if (entryHost.charAt(0) === "*") {
          entryHost = entryHost.slice(1);
        }
        if (entryHost.charAt(0) === ".") {
          return hostname.endsWith(entryHost);
        }
        return hostname === entryHost || isLoopback(hostname) && isLoopback(entryHost);
      });
    }
    function speedometer(samplesCount, min) {
      samplesCount = samplesCount || 10;
      const bytes = new Array(samplesCount);
      const timestamps = new Array(samplesCount);
      let head = 0;
      let tail = 0;
      let firstSampleTS;
      min = min !== void 0 ? min : 1e3;
      return function push(chunkLength) {
        const now = Date.now();
        const startedAt = timestamps[tail];
        if (!firstSampleTS) {
          firstSampleTS = now;
        }
        bytes[head] = chunkLength;
        timestamps[head] = now;
        let i = tail;
        let bytesCount = 0;
        while (i !== head) {
          bytesCount += bytes[i++];
          i = i % samplesCount;
        }
        head = (head + 1) % samplesCount;
        if (head === tail) {
          tail = (tail + 1) % samplesCount;
        }
        if (now - firstSampleTS < min) {
          return;
        }
        const passed = startedAt && now - startedAt;
        return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
      };
    }
    function throttle(fn, freq) {
      let timestamp = 0;
      let threshold = 1e3 / freq;
      let lastArgs;
      let timer;
      const invoke = (args, now = Date.now()) => {
        timestamp = now;
        lastArgs = null;
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
        fn(...args);
      };
      const throttled = (...args) => {
        const now = Date.now();
        const passed = now - timestamp;
        if (passed >= threshold) {
          invoke(args, now);
        } else {
          lastArgs = args;
          if (!timer) {
            timer = setTimeout(() => {
              timer = null;
              invoke(lastArgs);
            }, threshold - passed);
          }
        }
      };
      const flush = () => lastArgs && invoke(lastArgs);
      const flushWith = (...args) => invoke(args);
      return [throttled, flush, flushWith];
    }
    var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
      let bytesNotified = 0;
      const _speedometer = speedometer(50, 250);
      return throttle((e) => {
        if (!e || !utils$1.isNumber(e.loaded)) {
          return;
        }
        const rawLoaded = e.loaded;
        const total = e.lengthComputable ? e.total : void 0;
        const loaded = Math.max(0, total != null ? Math.min(rawLoaded, total) : rawLoaded);
        const progressBytes = Math.max(0, loaded - bytesNotified);
        const rate = _speedometer(progressBytes);
        bytesNotified = Math.max(bytesNotified, loaded);
        const data = {
          loaded,
          total,
          progress: total ? loaded / total : void 0,
          bytes: progressBytes,
          rate: rate ? rate : void 0,
          estimated: rate && total ? (total - loaded) / rate : void 0,
          event: e,
          lengthComputable: total != null,
          [isDownloadStream ? "download" : "upload"]: true
        };
        listener(data);
      }, freq);
    };
    var progressEventDecorator = (total, throttled) => {
      const lengthComputable = total != null;
      return [(loaded) => throttled[0]({
        lengthComputable,
        total,
        loaded
      }), throttled[1]];
    };
    var asyncDecorator = (fn, scheduler = utils$1.asap) => (...args) => scheduler(() => fn(...args));
    var isHexDigit = (charCode) => charCode >= 48 && charCode <= 57 || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
    var isPercentEncodedByte = (str, i, len) => i + 2 < len && isHexDigit(str.charCodeAt(i + 1)) && isHexDigit(str.charCodeAt(i + 2));
    var hexValue = (charCode) => charCode <= 57 ? charCode - 48 : (charCode & 223) - 55;
    var isBase64Char = (charCode) => charCode >= 65 && charCode <= 90 || // A-Z
    charCode >= 97 && charCode <= 122 || // a-z
    charCode >= 48 && charCode <= 57 || // 0-9
    charCode === 43 || // +
    charCode === 47 || // /
    charCode === 45 || // - (base64url)
    charCode === 95;
    var isBase64Whitespace = (charCode) => charCode === 9 || charCode === 10 || charCode === 12 || charCode === 13 || charCode === 32;
    var base64Bytes = (significant) => {
      const groups = Math.floor(significant / 4);
      const remainder = significant % 4;
      return groups * 3 + (remainder === 2 ? 1 : remainder === 3 ? 2 : 0);
    };
    var estimateBase64BufferAllocation = (body) => {
      const len = body.length;
      let padding = 0;
      if (len > 0 && body.charCodeAt(len - 1) === 61) {
        padding++;
        if (len > 1 && body.charCodeAt(len - 2) === 61) {
          padding++;
        }
      }
      return Math.floor((len - padding) * 3 / 4);
    };
    var estimatePercentDecodedBase64Bytes = (body) => {
      const len = body.length;
      let significant = 0;
      let padding = 0;
      let invalid = false;
      for (let i = 0; i < len; i++) {
        let code = body.charCodeAt(i);
        if (code === 37 && isPercentEncodedByte(body, i, len)) {
          code = hexValue(body.charCodeAt(i + 1)) * 16 + hexValue(body.charCodeAt(i + 2));
          i += 2;
        }
        if (isBase64Whitespace(code)) {
          continue;
        }
        if (code === 61) {
          padding++;
          continue;
        }
        if (!isBase64Char(code) || padding > 0) {
          invalid = true;
          continue;
        }
        significant++;
      }
      if (invalid || padding > 2 || padding > 0 && (significant + padding) % 4 !== 0 || significant % 4 === 1) {
        return estimateBase64BufferAllocation(body);
      }
      return base64Bytes(significant);
    };
    var estimateDataURLBytes = (url2, estimateBase64) => {
      if (!url2 || typeof url2 !== "string") return 0;
      if (!url2.startsWith("data:")) return 0;
      const comma = url2.indexOf(",");
      if (comma < 0) return 0;
      const meta = url2.slice(5, comma);
      const body = url2.slice(comma + 1);
      const isBase64 = /;base64/i.test(meta);
      if (isBase64) {
        return estimateBase64(body);
      }
      let bytes = 0;
      for (let i = 0, len = body.length; i < len; i++) {
        const c = body.charCodeAt(i);
        if (c === 37 && isPercentEncodedByte(body, i, len)) {
          bytes += 1;
          i += 2;
        } else if (c < 128) {
          bytes += 1;
        } else if (c < 2048) {
          bytes += 2;
        } else if (c >= 55296 && c <= 56319 && i + 1 < len) {
          const next = body.charCodeAt(i + 1);
          if (next >= 56320 && next <= 57343) {
            bytes += 4;
            i++;
          } else {
            bytes += 3;
          }
        } else {
          bytes += 3;
        }
      }
      return bytes;
    };
    function estimateDataURLDecodedBytes(url2) {
      const fragmentIndex = typeof url2 === "string" ? url2.indexOf("#") : -1;
      return estimateDataURLBytes(fragmentIndex === -1 ? url2 : url2.slice(0, fragmentIndex), estimatePercentDecodedBase64Bytes);
    }
    function estimateDataURLBufferAllocation(url2) {
      return estimateDataURLBytes(url2, estimateBase64BufferAllocation);
    }
    var zlibOptions = {
      flush: zlib.constants.Z_SYNC_FLUSH,
      finishFlush: zlib.constants.Z_SYNC_FLUSH
    };
    var brotliOptions = {
      flush: zlib.constants.BROTLI_OPERATION_FLUSH,
      finishFlush: zlib.constants.BROTLI_OPERATION_FLUSH
    };
    var zstdOptions = {
      flush: zlib.constants.ZSTD_e_flush,
      finishFlush: zlib.constants.ZSTD_e_flush
    };
    var isBrotliSupported = utils$1.isFunction(zlib.createBrotliDecompress);
    var isZstdSupported = utils$1.isFunction(zlib.createZstdDecompress);
    var ACCEPT_ENCODING = "gzip, compress, deflate" + (isBrotliSupported ? ", br" : "");
    var ACCEPT_ENCODING_WITH_ZSTD = ACCEPT_ENCODING + (isZstdSupported ? ", zstd" : "");
    var scheduleProgress = typeof process !== "undefined" && process.nextTick ? process.nextTick.bind(process) : utils$1.asap;
    var {
      http: httpFollow,
      https: httpsFollow
    } = followRedirects;
    var isHttps = /https:?/;
    var kAxiosSocketListener = /* @__PURE__ */ Symbol("axios.http.socketListener");
    var kAxiosCurrentReq = /* @__PURE__ */ Symbol("axios.http.currentReq");
    function handleSocketError(err) {
      const current = this[kAxiosCurrentReq];
      if (current && !current.destroyed) {
        current.destroy(err);
      }
    }
    var kAxiosInstalledTunnel = /* @__PURE__ */ Symbol("axios.http.installedTunnel");
    var tunnelingAgentCache = /* @__PURE__ */ new Map();
    var tunnelingAgentCacheUser = /* @__PURE__ */ new WeakMap();
    var NODE_NATIVE_ENV_PROXY_SUPPORT = {
      22: 21,
      24: 5
    };
    function isNodeNativeEnvProxySupported(nodeVersion = process.versions && process.versions.node) {
      if (!nodeVersion) {
        return false;
      }
      const [major, minor] = nodeVersion.split(".").map((part) => Number(part));
      if (!Number.isInteger(major) || !Number.isInteger(minor)) {
        return false;
      }
      if (major > 24) {
        return true;
      }
      return NODE_NATIVE_ENV_PROXY_SUPPORT[major] != null && minor >= NODE_NATIVE_ENV_PROXY_SUPPORT[major];
    }
    function isNodeEnvProxyEnabled(agent, nodeVersion = process.versions && process.versions.node) {
      if (!isNodeNativeEnvProxySupported(nodeVersion)) {
        return false;
      }
      const agentOptions = agent && agent.options;
      return Boolean(agentOptions && utils$1.hasOwnProp(agentOptions, "proxyEnv") && agentOptions.proxyEnv != null);
    }
    function getProxyEnvAgent(options, configHttpAgent, configHttpsAgent) {
      return isHttps.test(options.protocol) ? configHttpsAgent || https.globalAgent : configHttpAgent || http2.globalAgent;
    }
    function getTunnelingAgent(agentOptions, userHttpsAgent) {
      const key = agentOptions.protocol + "//" + agentOptions.hostname + ":" + (agentOptions.port || "") + "#" + (agentOptions.auth || "");
      const cache = userHttpsAgent ? tunnelingAgentCacheUser.get(userHttpsAgent) || tunnelingAgentCacheUser.set(userHttpsAgent, /* @__PURE__ */ new Map()).get(userHttpsAgent) : tunnelingAgentCache;
      let agent = cache.get(key);
      if (agent) return agent;
      const merged = userHttpsAgent && userHttpsAgent.options ? {
        ...userHttpsAgent.options,
        ...agentOptions
      } : agentOptions;
      agent = new HttpsProxyAgent(merged);
      if (userHttpsAgent && userHttpsAgent.options) {
        const originTLSOptions = {
          ...userHttpsAgent.options
        };
        const callback = agent.callback;
        agent.callback = function axiosTunnelingAgentCallback(req, opts) {
          return callback.call(this, req, {
            ...originTLSOptions,
            ...opts
          });
        };
      }
      agent[kAxiosInstalledTunnel] = true;
      cache.set(key, agent);
      return agent;
    }
    var supportedProtocols = platform.protocols.map((protocol) => {
      return protocol + ":";
    });
    var decodeURIComponentSafe$1 = (value) => {
      if (!utils$1.isString(value)) {
        return value;
      }
      try {
        return decodeURIComponent(value);
      } catch (error) {
        return value;
      }
    };
    var flushOnFinish = (stream2, [throttled, flush]) => {
      stream2.on("end", flush).on("error", flush);
      return throttled;
    };
    var http2Sessions = new Http2Sessions();
    function dispatchBeforeRedirect(options, responseDetails, requestDetails) {
      if (options.beforeRedirects.proxy) {
        options.beforeRedirects.proxy(options);
      }
      if (options.beforeRedirects.auth) {
        options.beforeRedirects.auth(options);
      }
      if (options.beforeRedirects.sensitiveHeaders) {
        options.beforeRedirects.sensitiveHeaders(options, requestDetails);
      }
      if (options.beforeRedirects.config) {
        options.beforeRedirects.config(options, responseDetails, requestDetails);
      }
    }
    function stripMatchingHeaders(headers, sensitiveSet) {
      if (!headers) {
        return;
      }
      Object.keys(headers).forEach((header) => {
        if (sensitiveSet.has(header.toLowerCase())) {
          delete headers[header];
        }
      });
    }
    function isSameOriginRedirect(redirectOptions, requestDetails) {
      if (!requestDetails) {
        return false;
      }
      try {
        return new URL(requestDetails.url).origin === new URL(redirectOptions.href).origin;
      } catch (e) {
        return false;
      }
    }
    function setProxy(options, configProxy, location, isRedirect, configHttpsAgent, configHttpAgent, allowEnvProxy = true) {
      let proxy = configProxy;
      const proxyEnvAgent = getProxyEnvAgent(options, configHttpAgent, configHttpsAgent);
      if (!proxy && proxy !== false && allowEnvProxy && !isNodeEnvProxyEnabled(proxyEnvAgent)) {
        const proxyUrl = getProxyForUrl(location);
        if (proxyUrl) {
          if (!shouldBypassProxy(location)) {
            proxy = new URL(proxyUrl);
          }
        }
      }
      if (isRedirect && options.headers) {
        for (const name of Object.keys(options.headers)) {
          if (name.toLowerCase() === "proxy-authorization") {
            delete options.headers[name];
          }
        }
      }
      if (isRedirect && options.agent && options.agent[kAxiosInstalledTunnel]) {
        options.agent = void 0;
      }
      if (proxy) {
        const isProxyURL = proxy instanceof URL;
        const readProxyField = (key) => isProxyURL || utils$1.hasOwnProp(proxy, key) ? proxy[key] : void 0;
        const proxyUsername = readProxyField("username");
        const proxyPassword = readProxyField("password");
        let proxyAuth = utils$1.hasOwnProp(proxy, "auth") ? proxy.auth : void 0;
        if (proxyUsername) {
          proxyAuth = (proxyUsername || "") + ":" + (proxyPassword || "");
        }
        if (proxyAuth) {
          const authIsObject = typeof proxyAuth === "object";
          const authUsername = authIsObject && utils$1.hasOwnProp(proxyAuth, "username") ? proxyAuth.username : void 0;
          const authPassword = authIsObject && utils$1.hasOwnProp(proxyAuth, "password") ? proxyAuth.password : void 0;
          const validProxyAuth = Boolean(authUsername || authPassword);
          if (validProxyAuth) {
            proxyAuth = (authUsername || "") + ":" + (authPassword || "");
          } else if (authIsObject) {
            throw new AxiosError("Invalid proxy authorization", AxiosError.ERR_BAD_OPTION, {
              proxy
            });
          }
        }
        const targetIsHttps = isHttps.test(options.protocol);
        if (targetIsHttps) {
          if (!(configHttpsAgent instanceof HttpsProxyAgent)) {
            const proxyHost = readProxyField("hostname") || readProxyField("host");
            const proxyPort = readProxyField("port");
            const rawProxyProtocol = readProxyField("protocol");
            const normalizedProtocol = rawProxyProtocol ? rawProxyProtocol.includes(":") ? rawProxyProtocol : `${rawProxyProtocol}:` : "http:";
            const proxyHostForURL = proxyHost && proxyHost.includes(":") && !proxyHost.startsWith("[") ? `[${proxyHost}]` : proxyHost;
            const proxyURL = new URL(`${normalizedProtocol}//${proxyHostForURL}${proxyPort ? ":" + proxyPort : ""}`);
            const agentOptions = {
              protocol: proxyURL.protocol,
              hostname: proxyURL.hostname.replace(/^\[|\]$/g, ""),
              port: proxyURL.port,
              auth: proxyAuth && typeof proxyAuth === "string" ? proxyAuth : void 0
            };
            if (proxyURL.protocol === "https:") {
              agentOptions.ALPNProtocols = ["http/1.1"];
            }
            const tunnelingAgent = getTunnelingAgent(agentOptions, configHttpsAgent);
            options.agent = tunnelingAgent;
            if (options.agents) {
              options.agents.https = tunnelingAgent;
            }
          }
        } else {
          if (proxyAuth) {
            const base64 = Buffer.from(proxyAuth, "utf8").toString("base64");
            options.headers["Proxy-Authorization"] = "Basic " + base64;
          }
          let hasUserHostHeader = false;
          for (const name of Object.keys(options.headers)) {
            if (name.toLowerCase() === "host") {
              hasUserHostHeader = true;
              break;
            }
          }
          if (!hasUserHostHeader) {
            options.headers.host = options.hostname + (options.port ? ":" + options.port : "");
          }
          const proxyHost = readProxyField("hostname") || readProxyField("host");
          options.hostname = proxyHost;
          options.host = proxyHost;
          options.port = readProxyField("port");
          options.path = location;
          const proxyProtocol = readProxyField("protocol");
          if (proxyProtocol) {
            options.protocol = proxyProtocol.includes(":") ? proxyProtocol : `${proxyProtocol}:`;
          }
        }
      }
      options.beforeRedirects.proxy = function beforeRedirect(redirectOptions) {
        setProxy(redirectOptions, configProxy, redirectOptions.href, true, configHttpsAgent, configHttpAgent, allowEnvProxy);
      };
      return Boolean(proxy || configProxy !== false && allowEnvProxy && isNodeEnvProxyEnabled(proxyEnvAgent));
    }
    var isHttpAdapterSupported = typeof process !== "undefined" && utils$1.kindOf(process) === "process";
    var wrapAsync = (asyncExecutor) => {
      return new Promise((resolve, reject) => {
        let onDone;
        let isDone;
        const done = (value, isRejected) => {
          if (isDone) return;
          isDone = true;
          onDone && onDone(value, isRejected);
        };
        const _resolve = (value) => {
          done(value);
          resolve(value);
        };
        const _reject = (reason) => {
          done(reason, true);
          reject(reason);
        };
        asyncExecutor(_resolve, _reject, (onDoneHandler) => onDone = onDoneHandler).catch(_reject);
      });
    };
    var resolveFamily = ({
      address,
      family
    }) => {
      if (!utils$1.isString(address)) {
        throw new AxiosError("address must be a string", AxiosError.ERR_BAD_OPTION_VALUE);
      }
      return {
        address,
        family: family || (address.indexOf(".") < 0 ? 6 : 4)
      };
    };
    var buildAddressEntry = (address, family) => resolveFamily(utils$1.isObject(address) ? address : {
      address,
      family
    });
    var normalizedLookupCache = /* @__PURE__ */ new WeakMap();
    var normalizeLookup = (lookup) => {
      let normalized = normalizedLookupCache.get(lookup);
      if (normalized) {
        return normalized;
      }
      const callbackLookup = callbackify(lookup, (value) => utils$1.isArray(value) ? value : [value]);
      normalized = (hostname, opt, cb) => {
        callbackLookup(hostname, opt, (err, arg0, arg1) => {
          if (err) {
            return cb(err);
          }
          let addresses;
          try {
            addresses = utils$1.isArray(arg0) ? arg0.map((addr) => buildAddressEntry(addr)) : [buildAddressEntry(arg0, arg1)];
          } catch (error) {
            return cb(error);
          }
          opt.all ? cb(err, addresses) : cb(err, addresses[0].address, addresses[0].family);
        });
      };
      normalizedLookupCache.set(lookup, normalized);
      return normalized;
    };
    var http2Transport = {
      request(options, cb) {
        const authority = options.protocol + "//" + options.hostname + ":" + (options.port || (options.protocol === "https:" ? 443 : 80));
        const {
          http2Options,
          headers
        } = options;
        const session = http2Sessions.getSession(authority, http2Options);
        const {
          HTTP2_HEADER_SCHEME,
          HTTP2_HEADER_METHOD,
          HTTP2_HEADER_PATH,
          HTTP2_HEADER_STATUS
        } = http22.constants;
        const http2Headers = {
          [HTTP2_HEADER_SCHEME]: options.protocol.replace(":", ""),
          [HTTP2_HEADER_METHOD]: options.method,
          [HTTP2_HEADER_PATH]: options.path
        };
        utils$1.forEach(headers, (header, name) => {
          name.charAt(0) !== ":" && (http2Headers[name] = header);
        });
        const req = session.request(http2Headers);
        req.once("response", (responseHeaders) => {
          const response = req;
          responseHeaders = Object.assign({}, responseHeaders);
          const status = responseHeaders[HTTP2_HEADER_STATUS];
          delete responseHeaders[HTTP2_HEADER_STATUS];
          response.headers = responseHeaders;
          response.statusCode = +status;
          cb(response);
        });
        return req;
      }
    };
    var httpAdapter = isHttpAdapterSupported && function httpAdapter2(config) {
      return wrapAsync(async function dispatchHttpRequest(resolve, reject, onDone) {
        const own2 = (key) => utils$1.getSafeProp(config, key);
        const transitional = own2("transitional") || transitionalDefaults;
        let data = own2("data");
        let lookup = own2("lookup");
        let family = own2("family");
        let httpVersion = own2("httpVersion");
        if (httpVersion === void 0) httpVersion = 1;
        const rawHttpVersion = httpVersion;
        let http2Options = own2("http2Options");
        const httpAgent = own2("httpAgent");
        const httpsAgent = own2("httpsAgent");
        const configProxy = own2("proxy");
        const responseType = own2("responseType");
        const responseEncoding = own2("responseEncoding");
        const socketPath = own2("socketPath");
        const method = own2("method").toUpperCase();
        const maxRedirects = own2("maxRedirects");
        const maxBodyLength = own2("maxBodyLength");
        const maxContentLength = own2("maxContentLength");
        const decompress = own2("decompress");
        let isDone;
        let rejected = false;
        let req;
        let connectPhaseTimer;
        try {
          httpVersion = +httpVersion;
        } catch (err) {
          throw new AxiosError("Invalid protocol version: value is not a number", AxiosError.ERR_BAD_OPTION_VALUE, config);
        }
        if (Number.isNaN(httpVersion)) {
          throw new AxiosError(`Invalid protocol version: '${rawHttpVersion}' is not a number`, AxiosError.ERR_BAD_OPTION_VALUE, config);
        }
        if (httpVersion !== 1 && httpVersion !== 2) {
          throw new AxiosError(`Unsupported protocol version '${httpVersion}'`, AxiosError.ERR_BAD_OPTION_VALUE, config);
        }
        const isHttp2 = httpVersion === 2;
        if (lookup) {
          lookup = normalizeLookup(lookup);
        }
        const abortEmitter = new events.EventEmitter();
        function abort(reason) {
          try {
            abortEmitter.emit("abort", !reason || reason.type ? new CanceledError(null, config, req) : reason);
          } catch (err) {
          }
        }
        function clearConnectPhaseTimer() {
          if (connectPhaseTimer) {
            clearTimeout(connectPhaseTimer);
            connectPhaseTimer = null;
          }
        }
        function createTimeoutError() {
          const configTimeout = own2("timeout");
          let timeoutErrorMessage = configTimeout ? "timeout of " + configTimeout + "ms exceeded" : "timeout exceeded";
          const configTimeoutErrorMessage = own2("timeoutErrorMessage");
          if (configTimeoutErrorMessage) {
            timeoutErrorMessage = configTimeoutErrorMessage;
          }
          return new AxiosError(timeoutErrorMessage, transitional.clarifyTimeoutError ? AxiosError.ETIMEDOUT : AxiosError.ECONNABORTED, config, req);
        }
        abortEmitter.once("abort", reject);
        const onFinished = () => {
          clearConnectPhaseTimer();
          if (config.cancelToken) {
            config.cancelToken.unsubscribe(abort);
          }
          if (config.signal) {
            config.signal.removeEventListener("abort", abort);
          }
          abortEmitter.removeAllListeners();
        };
        if (config.cancelToken || config.signal) {
          config.cancelToken && config.cancelToken.subscribe(abort);
          if (config.signal) {
            config.signal.aborted ? abort() : config.signal.addEventListener("abort", abort);
          }
        }
        onDone((response, isRejected) => {
          isDone = true;
          clearConnectPhaseTimer();
          if (isRejected) {
            rejected = true;
            onFinished();
            return;
          }
          const {
            data: data2
          } = response;
          if (data2 instanceof stream.Readable || data2 instanceof stream.Duplex) {
            const offListeners = stream.finished(data2, () => {
              offListeners();
              onFinished();
            });
          } else {
            onFinished();
          }
        });
        const fullPath = buildFullPath(own2("baseURL"), own2("url"), own2("allowAbsoluteUrls"), config);
        const urlBase = socketPath ? "http://localhost" : platform.hasBrowserEnv ? platform.origin : void 0;
        const parsed = new URL(fullPath, urlBase);
        const protocol = parsed.protocol || supportedProtocols[0];
        if (protocol === "data:") {
          if (maxContentLength > -1) {
            const dataUrl = String(own2("url") || fullPath || "");
            const estimated = estimateDataURLBufferAllocation(dataUrl);
            if (estimated > maxContentLength) {
              return reject(new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config));
            }
          }
          let convertedData;
          if (method !== "GET") {
            return settle(resolve, reject, {
              status: 405,
              statusText: "method not allowed",
              headers: {},
              config
            });
          }
          try {
            convertedData = fromDataURI(own2("url"), responseType === "blob", {
              Blob: config.env && config.env.Blob
            });
          } catch (err) {
            throw AxiosError.from(err, AxiosError.ERR_BAD_REQUEST, config);
          }
          if (responseType === "text") {
            convertedData = convertedData.toString(responseEncoding);
            if (!responseEncoding || responseEncoding === "utf8") {
              convertedData = utils$1.stripBOM(convertedData);
            }
          } else if (responseType === "stream") {
            convertedData = stream.Readable.from(convertedData);
          }
          return settle(resolve, reject, {
            data: convertedData,
            status: 200,
            statusText: "OK",
            headers: new AxiosHeaders(),
            config
          });
        }
        if (supportedProtocols.indexOf(protocol) === -1) {
          return reject(new AxiosError("Unsupported protocol " + protocol, AxiosError.ERR_BAD_REQUEST, config));
        }
        const headers = AxiosHeaders.from(config.headers).normalize();
        headers.set("User-Agent", "axios/" + VERSION, false);
        const {
          onUploadProgress,
          onDownloadProgress
        } = config;
        const maxRate = config.maxRate;
        let maxUploadRate = void 0;
        let maxDownloadRate = void 0;
        if (utils$1.isSpecCompliantForm(data)) {
          const userBoundary = headers.getContentType(/boundary=([-_\w\d]{10,70})/i);
          data = formDataToStream(data, (formHeaders) => {
            headers.set(formHeaders);
          }, {
            tag: `axios-${VERSION}-boundary`,
            boundary: userBoundary && userBoundary[1] || void 0
          });
        } else if (utils$1.isFormData(data) && utils$1.isFunction(data.getHeaders) && data.getHeaders !== Object.prototype.getHeaders) {
          setFormDataHeaders(headers, data.getHeaders(), own2("formDataHeaderPolicy"));
          if (!headers.hasContentLength()) {
            try {
              const knownLength = await util.promisify(data.getLength).call(data);
              Number.isFinite(knownLength) && knownLength >= 0 && headers.setContentLength(knownLength);
            } catch (e) {
            }
          }
        } else if (utils$1.isBlob(data) || utils$1.isFile(data)) {
          data.size && headers.setContentType(data.type || "application/octet-stream");
          headers.setContentLength(data.size || 0);
          data = stream.Readable.from(readBlob(data));
        } else if (data && !utils$1.isStream(data)) {
          if (Buffer.isBuffer(data)) ;
          else if (utils$1.isArrayBuffer(data)) {
            data = Buffer.from(new Uint8Array(data));
          } else if (utils$1.isString(data)) {
            data = Buffer.from(data, "utf-8");
          } else {
            return reject(new AxiosError("Data after transformation must be a string, an ArrayBuffer, a Buffer, or a Stream", AxiosError.ERR_BAD_REQUEST, config));
          }
          headers.setContentLength(data.length, false);
          if (maxBodyLength > -1 && data.length > maxBodyLength) {
            return reject(new AxiosError("Request body larger than maxBodyLength limit", AxiosError.ERR_BAD_REQUEST, config));
          }
        }
        const contentLength = utils$1.toFiniteNumber(headers.getContentLength());
        if (utils$1.isArray(maxRate)) {
          maxUploadRate = maxRate[0];
          maxDownloadRate = maxRate[1];
        } else {
          maxUploadRate = maxDownloadRate = maxRate;
        }
        if (data && (onUploadProgress || maxUploadRate)) {
          if (!utils$1.isStream(data)) {
            data = stream.Readable.from(data, {
              objectMode: false
            });
          }
          data = stream.pipeline([data, new AxiosTransformStream({
            maxRate: utils$1.toFiniteNumber(maxUploadRate)
          })], utils$1.noop);
          onUploadProgress && data.on("progress", flushOnFinish(data, progressEventDecorator(contentLength, progressEventReducer(asyncDecorator(onUploadProgress, scheduleProgress), false, 3))));
        }
        let auth = void 0;
        const configAuth = own2("auth");
        if (configAuth) {
          const username = utils$1.getSafeProp(configAuth, "username") || "";
          const password = utils$1.getSafeProp(configAuth, "password") || "";
          auth = username + ":" + password;
        }
        if (!auth && (parsed.username || parsed.password)) {
          const urlUsername = decodeURIComponentSafe$1(parsed.username);
          const urlPassword = decodeURIComponentSafe$1(parsed.password);
          auth = urlUsername + ":" + urlPassword;
        }
        auth && headers.delete("authorization");
        let path$1;
        try {
          path$1 = buildURL(parsed.pathname + parsed.search, own2("params"), own2("paramsSerializer")).replace(/^\?/, "");
        } catch (err) {
          return reject(AxiosError.from(err, AxiosError.ERR_BAD_REQUEST, config, null, null, {
            url: own2("url"),
            exists: true
          }));
        }
        headers.set("Accept-Encoding", utils$1.hasOwnProp(transitional, "advertiseZstdAcceptEncoding") && transitional.advertiseZstdAcceptEncoding === true ? ACCEPT_ENCODING_WITH_ZSTD : ACCEPT_ENCODING, false);
        if (isHttp2 && lookup) {
          http2Options = Object.assign(/* @__PURE__ */ Object.create(null), http2Options, {
            lookup
          });
        }
        const options = Object.assign(/* @__PURE__ */ Object.create(null), {
          path: path$1,
          method,
          headers: toByteStringHeaderObject(headers),
          agents: {
            http: httpAgent,
            https: httpsAgent
          },
          auth,
          protocol,
          family,
          beforeRedirect: dispatchBeforeRedirect,
          beforeRedirects: /* @__PURE__ */ Object.create(null),
          http2Options,
          createConnection: void 0
        });
        !utils$1.isUndefined(lookup) && (options.lookup = lookup);
        let proxyApplied = false;
        if (socketPath) {
          if (typeof socketPath !== "string") {
            return reject(new AxiosError("socketPath must be a string", AxiosError.ERR_BAD_OPTION_VALUE, config));
          }
          const allowedSocketPaths = own2("allowedSocketPaths");
          if (allowedSocketPaths != null) {
            const allowed = Array.isArray(allowedSocketPaths) ? allowedSocketPaths : [allowedSocketPaths];
            const resolvedSocket = path6.resolve(socketPath);
            const isAllowed = allowed.some((entry) => typeof entry === "string" && path6.resolve(entry) === resolvedSocket);
            if (!isAllowed) {
              return reject(new AxiosError(`socketPath "${socketPath}" is not permitted by allowedSocketPaths`, AxiosError.ERR_BAD_OPTION_VALUE, config));
            }
          }
          options.socketPath = socketPath;
        } else {
          options.hostname = parsed.hostname.startsWith("[") ? parsed.hostname.slice(1, -1) : parsed.hostname;
          options.port = parsed.port;
          proxyApplied = setProxy(
            options,
            configProxy,
            protocol + "//" + parsed.hostname + (parsed.port ? ":" + parsed.port : "") + options.path,
            false,
            httpsAgent,
            httpAgent,
            // The HTTP/2 transport connects independently of HTTP/1 agents, so it
            // cannot apply either axios-resolved or agent-local environment proxies.
            // Explicit proxy config is still processed and rejected below.
            !isHttp2
          );
        }
        let transport;
        let isNativeTransport = false;
        let transportEnforcesMaxBodyLength = false;
        const isHttpsRequest = isHttps.test(options.protocol);
        if (options.agent == null) {
          options.agent = isHttpsRequest ? httpsAgent : httpAgent;
        }
        if (isHttp2) {
          if (proxyApplied) {
            return reject(new AxiosError("HTTP/2 requests with a proxy are not supported", AxiosError.ERR_NOT_SUPPORT, config));
          }
          transport = http2Transport;
        } else {
          const configTransport = own2("transport");
          if (configTransport) {
            transport = configTransport;
          } else if (maxRedirects === 0) {
            transport = isHttpsRequest ? https : http2;
            isNativeTransport = true;
          } else {
            transportEnforcesMaxBodyLength = true;
            options.sensitiveHeaders = [];
            if (maxRedirects) {
              options.maxRedirects = maxRedirects;
            }
            const configBeforeRedirect = own2("beforeRedirect");
            if (configBeforeRedirect) {
              options.beforeRedirects.config = configBeforeRedirect;
            }
            if (auth) {
              const requestOrigin = parsed.origin;
              const authToRestore = auth;
              options.beforeRedirects.auth = function beforeRedirectAuth(redirectOptions) {
                try {
                  if (new URL(redirectOptions.href).origin === requestOrigin) {
                    redirectOptions.auth = authToRestore;
                  }
                } catch (e) {
                }
              };
            }
            const sensitiveHeaders = own2("sensitiveHeaders");
            if (sensitiveHeaders != null) {
              if (!utils$1.isArray(sensitiveHeaders)) {
                return reject(new AxiosError("sensitiveHeaders must be an array of strings", AxiosError.ERR_BAD_OPTION_VALUE, config));
              }
              const sensitiveSet = /* @__PURE__ */ new Set();
              for (const header of sensitiveHeaders) {
                if (!utils$1.isString(header)) {
                  return reject(new AxiosError("sensitiveHeaders must be an array of strings", AxiosError.ERR_BAD_OPTION_VALUE, config));
                }
                sensitiveSet.add(header.toLowerCase());
              }
              if (sensitiveSet.size) {
                options.sensitiveHeaders = Array.from(sensitiveSet);
                options.beforeRedirects.sensitiveHeaders = function beforeRedirectSensitiveHeaders(redirectOptions, requestDetails) {
                  if (!isSameOriginRedirect(redirectOptions, requestDetails)) {
                    stripMatchingHeaders(redirectOptions.headers, sensitiveSet);
                  }
                };
              }
            }
            transport = isHttpsRequest ? httpsFollow : httpFollow;
          }
        }
        if (maxBodyLength > -1) {
          options.maxBodyLength = maxBodyLength;
        } else {
          options.maxBodyLength = Infinity;
        }
        options.insecureHTTPParser = Boolean(own2("insecureHTTPParser"));
        req = transport.request(options, function handleResponse(res) {
          clearConnectPhaseTimer();
          if (req.destroyed) return;
          const streams = [res];
          const responseLength = utils$1.toFiniteNumber(res.headers["content-length"]);
          if (onDownloadProgress || maxDownloadRate) {
            const transformStream = new AxiosTransformStream({
              maxRate: utils$1.toFiniteNumber(maxDownloadRate)
            });
            onDownloadProgress && transformStream.on("progress", flushOnFinish(transformStream, progressEventDecorator(responseLength, progressEventReducer(asyncDecorator(onDownloadProgress, scheduleProgress), true, 3))));
            streams.push(transformStream);
          }
          let responseStream = res;
          const lastRequest = res.req || req;
          if (decompress !== false && res.headers["content-encoding"]) {
            if (method === "HEAD" || res.statusCode === 204) {
              delete res.headers["content-encoding"];
            }
            switch ((res.headers["content-encoding"] || "").toLowerCase()) {
              /*eslint default-case:0*/
              case "gzip":
              case "x-gzip":
              case "compress":
              case "x-compress":
                streams.push(zlib.createUnzip(zlibOptions));
                delete res.headers["content-encoding"];
                break;
              case "deflate":
                streams.push(new ZlibHeaderTransformStream());
                streams.push(zlib.createUnzip(zlibOptions));
                delete res.headers["content-encoding"];
                break;
              case "br":
                if (isBrotliSupported) {
                  streams.push(zlib.createBrotliDecompress(brotliOptions));
                  delete res.headers["content-encoding"];
                }
                break;
              case "zstd":
                if (isZstdSupported) {
                  streams.push(zlib.createZstdDecompress(zstdOptions));
                  delete res.headers["content-encoding"];
                }
                break;
            }
          }
          responseStream = streams.length > 1 ? stream.pipeline(streams, utils$1.noop) : streams[0];
          const response = {
            status: res.statusCode,
            statusText: res.statusMessage,
            headers: new AxiosHeaders(res.headers),
            config,
            request: lastRequest
          };
          if (responseType === "stream") {
            if (maxContentLength > -1) {
              const limit = maxContentLength;
              const source = responseStream;
              async function* enforceMaxContentLength() {
                let totalResponseBytes = 0;
                for await (const chunk of source) {
                  totalResponseBytes += chunk.length;
                  if (totalResponseBytes > limit) {
                    throw new AxiosError("maxContentLength size of " + limit + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, lastRequest);
                  }
                  yield chunk;
                }
              }
              responseStream = stream.Readable.from(enforceMaxContentLength(), {
                objectMode: false
              });
            }
            response.data = responseStream;
            settle(resolve, reject, response);
          } else {
            const responseBuffer = [];
            let totalResponseBytes = 0;
            responseStream.on("data", function handleStreamData(chunk) {
              responseBuffer.push(chunk);
              totalResponseBytes += chunk.length;
              if (maxContentLength > -1 && totalResponseBytes > maxContentLength) {
                rejected = true;
                responseStream.destroy();
                abort(new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, lastRequest));
              }
            });
            responseStream.on("aborted", function handlerStreamAborted() {
              if (rejected) {
                return;
              }
              const err = new AxiosError("stream has been aborted", AxiosError.ERR_BAD_RESPONSE, config, lastRequest, response);
              responseStream.destroy(err);
              reject(err);
            });
            responseStream.on("error", function handleStreamError(err) {
              if (rejected) return;
              reject(AxiosError.from(err, null, config, lastRequest, response));
            });
            responseStream.on("end", function handleStreamEnd() {
              try {
                let responseData = responseBuffer.length === 1 ? responseBuffer[0] : Buffer.concat(responseBuffer);
                if (responseType !== "arraybuffer") {
                  responseData = responseData.toString(responseEncoding);
                  if (!responseEncoding || responseEncoding === "utf8") {
                    responseData = utils$1.stripBOM(responseData);
                  }
                }
                response.data = responseData;
              } catch (err) {
                return reject(AxiosError.from(err, null, config, response.request, response));
              }
              settle(resolve, reject, response);
            });
          }
          abortEmitter.once("abort", (err) => {
            if (!responseStream.destroyed) {
              responseStream.emit("error", err);
              responseStream.destroy();
            }
          });
        });
        abortEmitter.once("abort", (err) => {
          if (req.close) {
            req.close();
          } else {
            req.destroy(err);
          }
        });
        req.on("error", function handleRequestError(err) {
          reject(AxiosError.from(err, null, config, req));
        });
        const boundSockets = /* @__PURE__ */ new Set();
        req.on("socket", function handleRequestSocket(socket) {
          if (typeof socket.setKeepAlive === "function") {
            socket.setKeepAlive(true, 1e3 * 60);
          }
          if (!socket[kAxiosSocketListener]) {
            socket.on("error", handleSocketError);
            socket[kAxiosSocketListener] = true;
          }
          socket[kAxiosCurrentReq] = req;
          boundSockets.add(socket);
        });
        req.once("close", function clearCurrentReq() {
          clearConnectPhaseTimer();
          for (const socket of boundSockets) {
            if (socket[kAxiosCurrentReq] === req) {
              socket[kAxiosCurrentReq] = null;
            }
          }
          boundSockets.clear();
        });
        if (own2("timeout")) {
          const timeout = parseInt(own2("timeout"), 10);
          if (Number.isNaN(timeout)) {
            abort(new AxiosError("error trying to parse `config.timeout` to int", AxiosError.ERR_BAD_OPTION_VALUE, config, req));
            return;
          }
          const handleTimeout = function handleTimeout2() {
            if (isDone) return;
            abort(createTimeoutError());
          };
          if (isNativeTransport && timeout > 0) {
            connectPhaseTimer = setTimeout(handleTimeout, timeout);
          }
          req.setTimeout(timeout, handleTimeout);
        } else {
          req.setTimeout(0);
        }
        if (utils$1.isStream(data)) {
          let ended = false;
          let errored = false;
          data.on("end", () => {
            ended = true;
          });
          data.once("error", (err) => {
            errored = true;
            req.destroy(err);
          });
          data.on("close", () => {
            if (!ended && !errored) {
              abort(new CanceledError("Request stream has been aborted", config, req));
            }
          });
          let uploadStream = data;
          if (maxBodyLength > -1 && !transportEnforcesMaxBodyLength) {
            const limit = maxBodyLength;
            let bytesSent = 0;
            uploadStream = stream.pipeline([data, new stream.Transform({
              transform(chunk, _enc, cb) {
                bytesSent += chunk.length;
                if (bytesSent > limit) {
                  return cb(new AxiosError("Request body larger than maxBodyLength limit", AxiosError.ERR_BAD_REQUEST, config, req));
                }
                cb(null, chunk);
              }
            })], utils$1.noop);
            uploadStream.on("error", (err) => {
              if (!req.destroyed) req.destroy(err);
            });
          }
          uploadStream.pipe(req);
        } else {
          data && req.write(data);
          req.end();
        }
      });
    };
    var isURLSameOrigin = platform.hasStandardBrowserEnv ? /* @__PURE__ */ ((origin2, isMSIE) => (url2) => {
      url2 = new URL(url2, platform.origin);
      return origin2.protocol === url2.protocol && origin2.host === url2.host && (isMSIE || origin2.port === url2.port);
    })(new URL(platform.origin), platform.navigator && /(msie|trident)/i.test(platform.navigator.userAgent)) : () => true;
    var cookies = platform.hasStandardBrowserEnv ? (
      // Standard browser envs support document.cookie
      {
        write(name, value, expires, path7, domain, secure, sameSite) {
          if (typeof document === "undefined") return;
          const cookie = [`${name}=${encodeURIComponent(value)}`];
          if (utils$1.isNumber(expires)) {
            cookie.push(`expires=${new Date(expires).toUTCString()}`);
          }
          if (utils$1.isString(path7)) {
            cookie.push(`path=${path7}`);
          }
          if (utils$1.isString(domain)) {
            cookie.push(`domain=${domain}`);
          }
          if (secure === true) {
            cookie.push("secure");
          }
          if (utils$1.isString(sameSite)) {
            cookie.push(`SameSite=${sameSite}`);
          }
          document.cookie = cookie.join("; ");
        },
        read(name) {
          if (typeof document === "undefined") return null;
          const cookies2 = document.cookie.split(";");
          for (let i = 0; i < cookies2.length; i++) {
            const cookie = cookies2[i].replace(/^\s+/, "");
            const eq = cookie.indexOf("=");
            if (eq !== -1 && cookie.slice(0, eq) === name) {
              try {
                return decodeURIComponent(cookie.slice(eq + 1));
              } catch (e) {
                return cookie.slice(eq + 1);
              }
            }
          }
          return null;
        },
        remove(name) {
          this.write(name, "", Date.now() - 864e5, "/");
        }
      }
    ) : (
      // Non-standard browser env (web workers, react-native) lack needed support.
      {
        write() {
        },
        read() {
          return null;
        },
        remove() {
        }
      }
    );
    var headersToObject = (thing) => thing instanceof AxiosHeaders ? {
      ...thing
    } : thing;
    var ownEnumerableKeys = (thing) => {
      if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) {
        return Object.keys(thing).concat(Object.getOwnPropertySymbols(thing).filter((symbol) => Object.getOwnPropertyDescriptor(thing, symbol).enumerable));
      }
      return Object.keys(thing);
    };
    function mergeConfig(config1, config2) {
      config1 = config1 || {};
      config2 = config2 || {};
      const config = /* @__PURE__ */ Object.create(null);
      Object.defineProperty(config, "hasOwnProperty", {
        // Null-proto descriptor so a polluted Object.prototype.get cannot turn
        // this data descriptor into an accessor descriptor on the way in.
        __proto__: null,
        value: Object.prototype.hasOwnProperty,
        enumerable: false,
        writable: true,
        configurable: true
      });
      function getMergedValue(target, source, prop, caseless) {
        if (utils$1.isPlainObject(target) && utils$1.isPlainObject(source)) {
          return utils$1.merge.call({
            caseless
          }, target, source);
        } else if (utils$1.isPlainObject(source)) {
          return utils$1.merge({}, source);
        } else if (utils$1.isArray(source)) {
          return source.slice();
        }
        return source;
      }
      function mergeDeepProperties(a, b, prop, caseless) {
        if (!utils$1.isUndefined(b)) {
          return getMergedValue(a, b, prop, caseless);
        } else if (!utils$1.isUndefined(a)) {
          return getMergedValue(void 0, a, prop, caseless);
        }
      }
      function valueFromConfig2(a, b) {
        if (!utils$1.isUndefined(b)) {
          return getMergedValue(void 0, b);
        }
      }
      function defaultToConfig2(a, b) {
        if (!utils$1.isUndefined(b)) {
          return getMergedValue(void 0, b);
        } else if (!utils$1.isUndefined(a)) {
          return getMergedValue(void 0, a);
        }
      }
      function getMergedTransitionalOption(prop) {
        const transitional2 = utils$1.hasOwnProp(config2, "transitional") ? config2.transitional : void 0;
        if (!utils$1.isUndefined(transitional2)) {
          if (utils$1.isPlainObject(transitional2)) {
            if (utils$1.hasOwnProp(transitional2, prop)) {
              return transitional2[prop];
            }
          } else {
            return void 0;
          }
        }
        const transitional1 = utils$1.hasOwnProp(config1, "transitional") ? config1.transitional : void 0;
        if (utils$1.isPlainObject(transitional1) && utils$1.hasOwnProp(transitional1, prop)) {
          return transitional1[prop];
        }
        return void 0;
      }
      function mergeDirectKeys(a, b, prop) {
        if (utils$1.hasOwnProp(config2, prop)) {
          return getMergedValue(a, b);
        } else if (utils$1.hasOwnProp(config1, prop)) {
          return getMergedValue(void 0, a);
        }
      }
      const mergeMap = {
        url: valueFromConfig2,
        method: valueFromConfig2,
        data: valueFromConfig2,
        baseURL: defaultToConfig2,
        transformRequest: defaultToConfig2,
        transformResponse: defaultToConfig2,
        paramsSerializer: defaultToConfig2,
        timeout: defaultToConfig2,
        timeoutErrorMessage: defaultToConfig2,
        withCredentials: defaultToConfig2,
        withXSRFToken: defaultToConfig2,
        adapter: defaultToConfig2,
        responseType: defaultToConfig2,
        xsrfCookieName: defaultToConfig2,
        xsrfHeaderName: defaultToConfig2,
        onUploadProgress: defaultToConfig2,
        onDownloadProgress: defaultToConfig2,
        decompress: defaultToConfig2,
        maxContentLength: defaultToConfig2,
        maxBodyLength: defaultToConfig2,
        beforeRedirect: defaultToConfig2,
        transport: defaultToConfig2,
        httpAgent: defaultToConfig2,
        httpsAgent: defaultToConfig2,
        cancelToken: defaultToConfig2,
        socketPath: defaultToConfig2,
        allowedSocketPaths: defaultToConfig2,
        responseEncoding: defaultToConfig2,
        validateStatus: mergeDirectKeys,
        headers: (a, b, prop) => mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true)
      };
      utils$1.forEach(ownEnumerableKeys({
        ...config1,
        ...config2
      }), function computeConfigValue(prop) {
        if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
        const merge2 = utils$1.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
        const a = utils$1.hasOwnProp(config1, prop) ? config1[prop] : void 0;
        const b = utils$1.hasOwnProp(config2, prop) ? config2[prop] : void 0;
        const configValue = merge2(a, b, prop);
        utils$1.isUndefined(configValue) && merge2 !== mergeDirectKeys || (config[prop] = configValue);
      });
      if (utils$1.hasOwnProp(config2, "validateStatus") && utils$1.isUndefined(config2.validateStatus) && getMergedTransitionalOption("validateStatusUndefinedResolves") === false) {
        if (utils$1.hasOwnProp(config1, "validateStatus")) {
          config.validateStatus = getMergedValue(void 0, config1.validateStatus);
        } else {
          delete config.validateStatus;
        }
      }
      return config;
    }
    var encodeUTF8$1 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
    function resolveConfig(config) {
      const newConfig = mergeConfig({}, config);
      const own2 = (key) => utils$1.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
      const data = own2("data");
      let withXSRFToken = own2("withXSRFToken");
      const xsrfHeaderName = own2("xsrfHeaderName");
      const xsrfCookieName = own2("xsrfCookieName");
      let headers = own2("headers");
      const auth = own2("auth");
      const baseURL = own2("baseURL");
      const allowAbsoluteUrls = own2("allowAbsoluteUrls");
      const url2 = own2("url");
      newConfig.headers = headers = AxiosHeaders.from(headers);
      newConfig.url = buildURL(buildFullPath(baseURL, url2, allowAbsoluteUrls, newConfig), own2("params"), own2("paramsSerializer"));
      if (auth) {
        const username = utils$1.getSafeProp(auth, "username") || "";
        const password = utils$1.getSafeProp(auth, "password") || "";
        try {
          headers.set("Authorization", "Basic " + btoa(username + ":" + (password ? encodeUTF8$1(password) : "")));
        } catch (e) {
          throw AxiosError.from(e, AxiosError.ERR_BAD_OPTION_VALUE, config);
        }
      }
      if (utils$1.isFormData(data)) {
        const getHeaders = utils$1.getSafeProp(data, "getHeaders");
        if (platform.hasStandardBrowserEnv || platform.hasStandardBrowserWebWorkerEnv || utils$1.isReactNative(data)) {
          headers.setContentType(void 0);
        } else if (utils$1.isFunction(getHeaders)) {
          setFormDataHeaders(headers, getHeaders.call(data), own2("formDataHeaderPolicy"));
        }
      }
      if (platform.hasStandardBrowserEnv) {
        if (utils$1.isFunction(withXSRFToken)) {
          withXSRFToken = withXSRFToken(newConfig);
        }
        const shouldSendXSRF = withXSRFToken === true || withXSRFToken == null && isURLSameOrigin(newConfig.url);
        if (shouldSendXSRF) {
          const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies.read(xsrfCookieName);
          if (xsrfValue) {
            headers.set(xsrfHeaderName, xsrfValue);
          }
        }
      }
      return newConfig;
    }
    var isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
    var xhrAdapter = isXHRAdapterSupported && function(config) {
      return new Promise(function dispatchXhrRequest(resolve, reject) {
        const _config = resolveConfig(config);
        let requestData = _config.data;
        const requestHeaders = AxiosHeaders.from(_config.headers).normalize();
        let {
          responseType,
          onUploadProgress,
          onDownloadProgress
        } = _config;
        let onCanceled;
        let uploadThrottled, downloadThrottled;
        let flushUpload, flushDownload, flushDownloadWithEvent;
        function done() {
          flushUpload && flushUpload();
          flushDownload && flushDownload();
          _config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
          _config.signal && _config.signal.removeEventListener("abort", onCanceled);
        }
        let request = new XMLHttpRequest();
        request.open(_config.method.toUpperCase(), _config.url, true);
        request.timeout = _config.timeout;
        function onloadend(event) {
          if (!request) {
            return;
          }
          if (request.status === 0 && (parseProtocol(normalizeURLForProtocolCheck(_config.url)) || parseProtocol(platform.origin)) !== "file" && !(request.responseURL && request.responseURL.startsWith("file:"))) {
            reject(new AxiosError("Request aborted", AxiosError.ECONNABORTED, config, request));
            done();
            request = null;
            return;
          }
          try {
            if (event) {
              flushDownloadWithEvent && flushDownloadWithEvent(event);
            } else {
              flushDownload && flushDownload();
            }
          } catch (err) {
            setTimeout(() => {
              throw err;
            });
          }
          if (!request) {
            return;
          }
          const responseHeaders = AxiosHeaders.from("getAllResponseHeaders" in request && request.getAllResponseHeaders());
          const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
          const response = {
            data: responseData,
            status: request.status,
            statusText: request.statusText,
            headers: responseHeaders,
            config,
            request
          };
          settle(function _resolve(value) {
            resolve(value);
            done();
          }, function _reject(err) {
            reject(err);
            done();
          }, response);
          request = null;
        }
        if ("onloadend" in request) {
          request.onloadend = onloadend;
        } else {
          request.onreadystatechange = function handleLoad() {
            if (!request || request.readyState !== 4) {
              return;
            }
            if (request.status === 0 && !(request.responseURL && request.responseURL.startsWith("file:"))) {
              return;
            }
            setTimeout(onloadend);
          };
        }
        request.onabort = function handleAbort() {
          if (!request) {
            return;
          }
          reject(new AxiosError("Request aborted", AxiosError.ECONNABORTED, config, request));
          done();
          request = null;
        };
        request.onerror = function handleError(event) {
          const msg = event && event.message ? event.message : "Network Error";
          const err = new AxiosError(msg, AxiosError.ERR_NETWORK, config, request);
          err.event = event || null;
          reject(err);
          done();
          request = null;
        };
        request.ontimeout = function handleTimeout() {
          let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
          const transitional = _config.transitional || transitionalDefaults;
          if (_config.timeoutErrorMessage) {
            timeoutErrorMessage = _config.timeoutErrorMessage;
          }
          reject(new AxiosError(timeoutErrorMessage, transitional.clarifyTimeoutError ? AxiosError.ETIMEDOUT : AxiosError.ECONNABORTED, config, request));
          done();
          request = null;
        };
        requestData === void 0 && requestHeaders.setContentType(null);
        if ("setRequestHeader" in request) {
          utils$1.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
            request.setRequestHeader(key, val);
          });
        }
        if (!utils$1.isUndefined(_config.withCredentials)) {
          request.withCredentials = !!_config.withCredentials;
        }
        if (responseType && responseType !== "json") {
          request.responseType = _config.responseType;
        }
        if (onDownloadProgress) {
          [downloadThrottled, flushDownload, flushDownloadWithEvent] = progressEventReducer(onDownloadProgress, true);
          request.addEventListener("progress", downloadThrottled);
        }
        if (onUploadProgress && request.upload) {
          [uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
          request.upload.addEventListener("progress", uploadThrottled);
          request.upload.addEventListener("loadend", flushUpload);
        }
        if (_config.cancelToken || _config.signal) {
          onCanceled = (cancel) => {
            if (!request) {
              return;
            }
            reject(!cancel || cancel.type ? new CanceledError(null, config, request) : cancel);
            request.abort();
            done();
            request = null;
          };
          _config.cancelToken && _config.cancelToken.subscribe(onCanceled);
          if (_config.signal) {
            _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
          }
        }
        const protocol = parseProtocol(_config.url);
        if (protocol && !platform.protocols.includes(protocol)) {
          reject(new AxiosError("Unsupported protocol " + protocol + ":", AxiosError.ERR_BAD_REQUEST, config));
          done();
          return;
        }
        request.send(requestData || null);
      });
    };
    var composeSignals = (signals, timeout) => {
      signals = signals ? signals.filter(Boolean) : [];
      if (!timeout && !signals.length) {
        return;
      }
      const controller = new AbortController();
      let aborted = false;
      const onabort = function(reason) {
        if (!aborted) {
          aborted = true;
          unsubscribe();
          const err = reason instanceof Error ? reason : this.reason;
          controller.abort(err instanceof AxiosError ? err : new CanceledError(err instanceof Error ? err.message : err));
        }
      };
      let timer = timeout && setTimeout(() => {
        timer = null;
        onabort(new AxiosError(`timeout of ${timeout}ms exceeded`, AxiosError.ETIMEDOUT));
      }, timeout);
      const unsubscribe = () => {
        if (!signals) {
          return;
        }
        timer && clearTimeout(timer);
        timer = null;
        signals.forEach((signal2) => {
          signal2.unsubscribe ? signal2.unsubscribe(onabort) : signal2.removeEventListener("abort", onabort);
        });
        signals = null;
      };
      signals.forEach((signal2) => {
        if (aborted) {
          return;
        }
        if (signal2.aborted) {
          onabort.call(signal2);
          return;
        }
        signal2.addEventListener("abort", onabort, {
          once: true
        });
      });
      const {
        signal
      } = controller;
      signal.unsubscribe = () => utils$1.asap(unsubscribe);
      return signal;
    };
    var streamChunk = function* (chunk, chunkSize) {
      let len = chunk.byteLength;
      if (len < chunkSize) {
        yield chunk;
        return;
      }
      let pos = 0;
      let end;
      while (pos < len) {
        end = pos + chunkSize;
        yield chunk.slice(pos, end);
        pos = end;
      }
    };
    var readBytes = async function* (iterable, chunkSize) {
      for await (const chunk of readStream(iterable)) {
        yield* streamChunk(chunk, chunkSize);
      }
    };
    var readStream = async function* (stream2) {
      if (stream2[Symbol.asyncIterator]) {
        yield* stream2;
        return;
      }
      const reader = stream2.getReader();
      try {
        for (; ; ) {
          const {
            done,
            value
          } = await reader.read();
          if (done) {
            break;
          }
          yield value;
        }
      } finally {
        await reader.cancel();
      }
    };
    var trackStream = (stream2, chunkSize, onProgress, onFinish) => {
      const iterator2 = readBytes(stream2, chunkSize);
      let bytes = 0;
      let done;
      let _onFinish = (e) => {
        if (!done) {
          done = true;
          onFinish && onFinish(e);
        }
      };
      return new ReadableStream({
        async pull(controller) {
          try {
            const {
              done: done2,
              value
            } = await iterator2.next();
            if (done2) {
              _onFinish();
              controller.close();
              return;
            }
            let len = value.byteLength;
            if (onProgress) {
              let loadedBytes = bytes += len;
              onProgress(loadedBytes);
            }
            controller.enqueue(new Uint8Array(value));
          } catch (err) {
            _onFinish(err);
            throw err;
          }
        },
        cancel(reason) {
          _onFinish(reason);
          return iterator2.return();
        }
      }, {
        highWaterMark: 2
      });
    };
    var DEFAULT_CHUNK_SIZE = 64 * 1024;
    var DEFAULT_REQUEST_OPTIONS = {
      cache: "default",
      redirect: "follow",
      referrer: "about:client",
      referrerPolicy: "",
      mode: "cors",
      integrity: "",
      keepalive: false,
      priority: "auto",
      window: null
    };
    var {
      isFunction
    } = utils$1;
    var encodeUTF8 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
    var decodeURIComponentSafe = (value) => {
      if (!utils$1.isString(value)) {
        return value;
      }
      try {
        return decodeURIComponent(value);
      } catch (error) {
        return value;
      }
    };
    var test = (fn, ...args) => {
      try {
        return !!fn(...args);
      } catch (e) {
        return false;
      }
    };
    var maybeWithAuthCredentials = (url2) => {
      const protocolIndex = url2.indexOf("://");
      let urlToCheck = url2;
      if (protocolIndex !== -1) {
        urlToCheck = urlToCheck.slice(protocolIndex + 3);
      }
      return urlToCheck.includes("@") || urlToCheck.includes(":");
    };
    var factory = (env) => {
      const globalObject = utils$1.global !== void 0 && utils$1.global !== null ? utils$1.global : globalThis;
      const {
        ReadableStream: ReadableStream2,
        TextEncoder: TextEncoder2
      } = globalObject;
      env = utils$1.merge.call({
        skipUndefined: true
      }, {
        Request: globalObject.Request,
        Response: globalObject.Response
      }, env);
      const {
        fetch: envFetch,
        Request,
        Response
      } = env;
      const isFetchSupported = envFetch ? isFunction(envFetch) : typeof fetch === "function";
      const isRequestSupported = isFunction(Request);
      const isResponseSupported = isFunction(Response);
      if (!isFetchSupported) {
        return false;
      }
      const isReadableStreamSupported = isFetchSupported && isFunction(ReadableStream2);
      const encodeText = isFetchSupported && (typeof TextEncoder2 === "function" ? /* @__PURE__ */ ((encoder) => (str) => encoder.encode(str))(new TextEncoder2()) : async (str) => new Uint8Array(await new Request(str).arrayBuffer()));
      const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
        let duplexAccessed = false;
        const request = new Request(platform.origin, {
          body: new ReadableStream2(),
          method: "POST",
          get duplex() {
            duplexAccessed = true;
            return "half";
          }
        });
        const hasContentType = request.headers.has("Content-Type");
        if (request.body != null) {
          request.body.cancel();
        }
        return duplexAccessed && !hasContentType;
      });
      const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils$1.isReadableStream(new Response("").body));
      const resolvers = {
        stream: supportsResponseStream && ((res) => res.body)
      };
      isFetchSupported && (() => {
        ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((type) => {
          !resolvers[type] && (resolvers[type] = (res, config) => {
            let method = res && res[type];
            if (method) {
              return method.call(res);
            }
            throw new AxiosError(`Response type '${type}' is not supported`, AxiosError.ERR_NOT_SUPPORT, config);
          });
        });
      })();
      const getBodyLength = async (body) => {
        if (body == null) {
          return 0;
        }
        if (utils$1.isBlob(body)) {
          return body.size;
        }
        if (utils$1.isSpecCompliantForm(body)) {
          const _request = new Request(platform.origin, {
            method: "POST",
            body
          });
          return (await _request.arrayBuffer()).byteLength;
        }
        if (utils$1.isArrayBufferView(body) || utils$1.isArrayBuffer(body)) {
          return body.byteLength;
        }
        if (utils$1.isURLSearchParams(body)) {
          body = body + "";
        }
        if (utils$1.isString(body)) {
          return (await encodeText(body)).byteLength;
        }
      };
      const resolveBodyLength = async (headers, body) => {
        const length = utils$1.toFiniteNumber(headers.getContentLength());
        return length == null ? getBodyLength(body) : length;
      };
      return async (config) => {
        let {
          url: url2,
          method,
          data,
          signal,
          cancelToken,
          timeout,
          onDownloadProgress,
          onUploadProgress,
          responseType,
          headers,
          withCredentials = "same-origin",
          fetchOptions,
          maxContentLength,
          maxBodyLength,
          maxRedirects
        } = resolveConfig(config);
        const hasMaxContentLength = utils$1.isNumber(maxContentLength) && maxContentLength > -1;
        const hasMaxBodyLength = utils$1.isNumber(maxBodyLength) && maxBodyLength > -1;
        const own2 = (key) => utils$1.hasOwnProp(config, key) ? config[key] : void 0;
        let _fetch = envFetch || fetch;
        responseType = responseType ? (responseType + "").toLowerCase() : "text";
        let composedSignal = composeSignals([signal, cancelToken && cancelToken.toAbortSignal()], timeout);
        let request = null;
        const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
          composedSignal.unsubscribe();
        });
        let requestContentLength;
        let pendingBodyError = null;
        const maxBodyLengthError = () => new AxiosError("Request body larger than maxBodyLength limit", AxiosError.ERR_BAD_REQUEST, config, request);
        try {
          let auth = void 0;
          const configAuth = own2("auth");
          if (configAuth) {
            const username = utils$1.getSafeProp(configAuth, "username") || "";
            const password = utils$1.getSafeProp(configAuth, "password") || "";
            auth = {
              username,
              password
            };
          }
          if (maybeWithAuthCredentials(url2)) {
            const parsedURL = new URL(url2, platform.origin);
            if (!auth && (parsedURL.username || parsedURL.password)) {
              const urlUsername = decodeURIComponentSafe(parsedURL.username);
              const urlPassword = decodeURIComponentSafe(parsedURL.password);
              auth = {
                username: urlUsername,
                password: urlPassword
              };
            }
            if (parsedURL.username || parsedURL.password) {
              parsedURL.username = "";
              parsedURL.password = "";
              url2 = parsedURL.href;
            }
          }
          if (auth) {
            headers.delete("authorization");
            headers.set("Authorization", "Basic " + btoa(encodeUTF8((auth.username || "") + ":" + (auth.password || ""))));
          }
          if (hasMaxContentLength && typeof url2 === "string" && url2.startsWith("data:")) {
            const estimated = estimateDataURLDecodedBytes(url2);
            if (estimated > maxContentLength) {
              throw new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, request);
            }
          }
          if (hasMaxBodyLength && method !== "get" && method !== "head") {
            const outboundLength = await getBodyLength(data);
            if (typeof outboundLength === "number" && isFinite(outboundLength)) {
              requestContentLength = outboundLength;
              if (outboundLength > maxBodyLength) {
                throw maxBodyLengthError();
              }
            }
          }
          const mustEnforceStreamBody = hasMaxBodyLength && (utils$1.isReadableStream(data) || utils$1.isStream(data));
          const trackRequestStream = (stream2, onProgress, flush) => trackStream(stream2, DEFAULT_CHUNK_SIZE, (loadedBytes) => {
            if (hasMaxBodyLength && loadedBytes > maxBodyLength) {
              throw pendingBodyError = maxBodyLengthError();
            }
            onProgress && onProgress(loadedBytes);
          }, flush);
          if (supportsRequestStream && method !== "get" && method !== "head" && (onUploadProgress || mustEnforceStreamBody)) {
            requestContentLength = requestContentLength == null ? await resolveBodyLength(headers, data) : requestContentLength;
            if (requestContentLength !== 0 || mustEnforceStreamBody) {
              let _request = new Request(url2, {
                method: "POST",
                body: data,
                duplex: "half"
              });
              let contentTypeHeader;
              if (utils$1.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) {
                headers.setContentType(contentTypeHeader);
              }
              if (_request.body) {
                const [onProgress, flush] = onUploadProgress && progressEventDecorator(requestContentLength, progressEventReducer(asyncDecorator(onUploadProgress))) || [];
                data = trackRequestStream(_request.body, onProgress, flush);
              }
            }
          } else if (mustEnforceStreamBody && !isRequestSupported && isReadableStreamSupported && method !== "get" && method !== "head") {
            data = trackRequestStream(data);
          } else if (mustEnforceStreamBody && isRequestSupported && !supportsRequestStream && method !== "get" && method !== "head") {
            throw new AxiosError("Stream request bodies are not supported by the current fetch implementation", AxiosError.ERR_NOT_SUPPORT, config, request);
          }
          if (!utils$1.isString(withCredentials)) {
            withCredentials = withCredentials ? "include" : "omit";
          }
          const isCredentialsSupported = isRequestSupported && "credentials" in Request.prototype;
          if (utils$1.isFormData(data)) {
            const contentType = headers.getContentType();
            if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) {
              headers.delete("content-type");
            }
          }
          headers.set("User-Agent", "axios/" + VERSION, false);
          const safeFetchOptions = fetchOptions == null ? fetchOptions : Object.assign(/* @__PURE__ */ Object.create(null), fetchOptions);
          if (safeFetchOptions) {
            delete safeFetchOptions.body;
            delete safeFetchOptions.headers;
            delete safeFetchOptions.method;
            delete safeFetchOptions.signal;
            delete safeFetchOptions.duplex;
            delete safeFetchOptions.credentials;
          }
          const resolvedOptions = Object.assign(/* @__PURE__ */ Object.create(null), safeFetchOptions, {
            signal: composedSignal,
            method: method.toUpperCase(),
            headers: toByteStringHeaderObject(headers.normalize()),
            body: data,
            duplex: "half",
            credentials: isCredentialsSupported ? withCredentials : void 0
          });
          if (isRequestSupported) {
            utils$1.forEach(DEFAULT_REQUEST_OPTIONS, (value, key) => {
              if (resolvedOptions[key] === void 0) {
                resolvedOptions[key] = value;
              }
            });
            if (resolvedOptions.signal === void 0) {
              resolvedOptions.signal = null;
            }
            if (resolvedOptions.body === void 0) {
              resolvedOptions.body = null;
            }
          }
          if (maxRedirects === 0) {
            resolvedOptions.redirect = "manual";
            if (safeFetchOptions) {
              safeFetchOptions.redirect = "manual";
            }
          }
          request = isRequestSupported && new Request(url2, resolvedOptions);
          let response = await (isRequestSupported ? _fetch(request, safeFetchOptions) : _fetch(url2, resolvedOptions));
          const responseHeaders = AxiosHeaders.from(response.headers);
          if (hasMaxContentLength) {
            const declaredLength = utils$1.toFiniteNumber(responseHeaders.getContentLength());
            if (declaredLength != null && declaredLength > maxContentLength) {
              throw new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, request);
            }
          }
          const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
          if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
            const options = {};
            ["status", "statusText", "headers"].forEach((prop) => {
              options[prop] = response[prop];
            });
            const responseContentLength = utils$1.toFiniteNumber(responseHeaders.getContentLength());
            const [onProgress, flush] = onDownloadProgress && progressEventDecorator(responseContentLength, progressEventReducer(asyncDecorator(onDownloadProgress), true)) || [];
            let bytesRead = 0;
            const onChunkProgress = (loadedBytes) => {
              if (hasMaxContentLength) {
                bytesRead = loadedBytes;
                if (bytesRead > maxContentLength) {
                  throw new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, request);
                }
              }
              onProgress && onProgress(loadedBytes);
            };
            response = new Response(trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
              flush && flush();
              unsubscribe && unsubscribe();
            }), options);
          }
          responseType = responseType || "text";
          let responseData = await resolvers[utils$1.findKey(resolvers, responseType) || "text"](response, config);
          if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
            let materializedSize;
            if (responseData != null) {
              if (typeof responseData.byteLength === "number") {
                materializedSize = responseData.byteLength;
              } else if (typeof responseData.size === "number") {
                materializedSize = responseData.size;
              } else if (typeof responseData === "string") {
                materializedSize = typeof TextEncoder2 === "function" ? new TextEncoder2().encode(responseData).byteLength : responseData.length;
              }
            }
            if (typeof materializedSize === "number" && materializedSize > maxContentLength) {
              throw new AxiosError("maxContentLength size of " + maxContentLength + " exceeded", AxiosError.ERR_BAD_RESPONSE, config, request);
            }
          }
          !isStreamResponse && unsubscribe && unsubscribe();
          return await new Promise((resolve, reject) => {
            settle(resolve, reject, {
              data: responseData,
              headers: AxiosHeaders.from(response.headers),
              status: response.status,
              statusText: response.statusText,
              config,
              request
            });
          });
        } catch (err) {
          unsubscribe && unsubscribe();
          if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError) {
            const canceledError = composedSignal.reason;
            canceledError.config = config;
            request && (canceledError.request = request);
            if (err !== canceledError) {
              Object.defineProperty(canceledError, "cause", {
                __proto__: null,
                value: err,
                writable: true,
                enumerable: false,
                configurable: true
              });
            }
            throw canceledError;
          }
          if (pendingBodyError) {
            request && !pendingBodyError.request && (pendingBodyError.request = request);
            throw pendingBodyError;
          }
          if (err instanceof AxiosError) {
            request && !err.request && (err.request = request);
            throw err;
          }
          if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
            const networkError = new AxiosError("Network Error", AxiosError.ERR_NETWORK, config, request, err && err.response);
            Object.defineProperty(networkError, "cause", {
              __proto__: null,
              value: err.cause || err,
              writable: true,
              enumerable: false,
              configurable: true
            });
            throw networkError;
          }
          throw AxiosError.from(err, err && err.code, config, request, err && err.response);
        }
      };
    };
    var seedCache = /* @__PURE__ */ new Map();
    var getFetch = (config) => {
      let env = config && config.env || {};
      const {
        fetch: fetch2,
        Request,
        Response
      } = env;
      const seeds = [Request, Response, fetch2];
      let len = seeds.length, i = len, seed, target, map = seedCache;
      while (i--) {
        seed = seeds[i];
        target = map.get(seed);
        target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
        map = target;
      }
      return target;
    };
    getFetch();
    var knownAdapters = {
      http: httpAdapter,
      xhr: xhrAdapter,
      fetch: {
        get: getFetch
      }
    };
    utils$1.forEach(knownAdapters, (fn, value) => {
      if (fn) {
        try {
          Object.defineProperty(fn, "name", {
            __proto__: null,
            value
          });
        } catch (e) {
        }
        Object.defineProperty(fn, "adapterName", {
          __proto__: null,
          value
        });
      }
    });
    var renderReason = (reason) => `- ${reason}`;
    var isResolvedHandle = (adapter) => utils$1.isFunction(adapter) || adapter === null || adapter === false;
    function getAdapter(adapters2, config) {
      adapters2 = utils$1.isArray(adapters2) ? adapters2 : [adapters2];
      const {
        length
      } = adapters2;
      let nameOrAdapter;
      let adapter;
      const rejectedReasons = {};
      for (let i = 0; i < length; i++) {
        nameOrAdapter = adapters2[i];
        let id;
        adapter = nameOrAdapter;
        if (!isResolvedHandle(nameOrAdapter)) {
          adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
          if (adapter === void 0) {
            throw new AxiosError(`Unknown adapter '${id}'`);
          }
        }
        if (adapter && (utils$1.isFunction(adapter) || (adapter = adapter.get(config)))) {
          break;
        }
        rejectedReasons[id || "#" + i] = adapter;
      }
      if (!adapter) {
        const reasons = Object.entries(rejectedReasons).map(([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build"));
        let s = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
        throw new AxiosError(`There is no suitable adapter to dispatch the request ` + s, AxiosError.ERR_NOT_SUPPORT);
      }
      return adapter;
    }
    var adapters = {
      /**
       * Resolve an adapter from a list of adapter names or functions.
       * @type {Function}
       */
      getAdapter,
      /**
       * Exposes all known adapters
       * @type {Object<string, Function|Object>}
       */
      adapters: knownAdapters
    };
    function throwIfCancellationRequested(config) {
      if (config.cancelToken) {
        config.cancelToken.throwIfRequested();
      }
      if (config.signal && config.signal.aborted) {
        throw new CanceledError(null, config);
      }
    }
    function dispatchRequest(_config) {
      const config = utils$1.toSafeFlatObject(_config);
      throwIfCancellationRequested(config);
      config.headers = AxiosHeaders.from(utils$1.getSafeProp(config, "headers"));
      config.data = transformData.call(config, config.transformRequest);
      if (["post", "put", "patch"].indexOf(config.method) !== -1) {
        config.headers.setContentType("application/x-www-form-urlencoded", false);
      }
      const adapter = adapters.getAdapter(config.adapter || defaults.adapter, config);
      return adapter(config).then(function onAdapterResolution(response) {
        throwIfCancellationRequested(config);
        config.response = response;
        try {
          response.data = transformData.call(config, config.transformResponse, response);
        } finally {
          delete config.response;
        }
        response.headers = AxiosHeaders.from(response.headers);
        return response;
      }, function onAdapterRejection(reason) {
        if (!isCancel(reason)) {
          throwIfCancellationRequested(config);
          if (reason && reason.response) {
            config.response = reason.response;
            try {
              reason.response.data = transformData.call(config, config.transformResponse, reason.response);
            } finally {
              delete config.response;
            }
            reason.response.headers = AxiosHeaders.from(reason.response.headers);
          }
        }
        return Promise.reject(reason);
      });
    }
    var validators$1 = {};
    ["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i) => {
      validators$1[type] = function validator2(thing) {
        return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
      };
    });
    var deprecatedWarnings = {};
    validators$1.transitional = function transitional(validator2, version, message) {
      function formatMessage(opt, desc) {
        return "[Axios v" + VERSION + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
      }
      return (value, opt, opts) => {
        if (validator2 === false) {
          throw new AxiosError(formatMessage(opt, " has been removed" + (version ? " in " + version : "")), AxiosError.ERR_DEPRECATED);
        }
        if (version && !deprecatedWarnings[opt]) {
          deprecatedWarnings[opt] = true;
          console.warn(formatMessage(opt, " has been deprecated since v" + version + " and will be removed in the near future"));
        }
        return validator2 ? validator2(value, opt, opts) : true;
      };
    };
    validators$1.spelling = function spelling(correctSpelling) {
      return (value, opt) => {
        console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
        return true;
      };
    };
    function assertOptions(options, schema, allowUnknown) {
      if (typeof options !== "object" || options === null) {
        throw new AxiosError("options must be an object", AxiosError.ERR_BAD_OPTION_VALUE);
      }
      const keys = Object.keys(options);
      let i = keys.length;
      while (i-- > 0) {
        const opt = keys[i];
        const validator2 = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
        if (validator2) {
          const value = options[opt];
          const result = value === void 0 || validator2(value, opt, options);
          if (result !== true) {
            throw new AxiosError("option " + opt + " must be " + result, AxiosError.ERR_BAD_OPTION_VALUE);
          }
          continue;
        }
        if (allowUnknown !== true) {
          throw new AxiosError("Unknown option " + opt, AxiosError.ERR_BAD_OPTION);
        }
      }
    }
    var validator = {
      assertOptions,
      validators: validators$1
    };
    var validators = validator.validators;
    var Axios = class {
      constructor(instanceConfig) {
        this.defaults = instanceConfig || {};
        this.interceptors = {
          request: new InterceptorManager(),
          response: new InterceptorManager()
        };
      }
      /**
       * Dispatch a request
       *
       * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
       * @param {?Object} config
       *
       * @returns {Promise} The Promise to be fulfilled
       */
      async request(configOrUrl, config) {
        try {
          return await this._request(configOrUrl, config);
        } catch (err) {
          if (err instanceof Error) {
            try {
              let dummy = {};
              Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = new Error();
              const dummyStack = dummy.stack;
              let stack = "";
              if (typeof dummyStack === "string") {
                const firstNewlineIndex = dummyStack.indexOf("\n");
                stack = firstNewlineIndex === -1 ? "" : dummyStack.slice(firstNewlineIndex + 1);
              }
              if (!err.stack) {
                err.stack = stack;
              } else if (stack) {
                const firstNewlineIndex = stack.indexOf("\n");
                const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
                const stackWithoutTwoTopLines = secondNewlineIndex === -1 ? "" : stack.slice(secondNewlineIndex + 1);
                if (!String(err.stack).endsWith(stackWithoutTwoTopLines)) {
                  err.stack += "\n" + stack;
                }
              }
            } catch (e) {
            }
          }
          throw err;
        }
      }
      _request(configOrUrl, config) {
        if (typeof configOrUrl === "string") {
          config = config || {};
          config.url = configOrUrl;
        } else {
          config = configOrUrl || {};
        }
        config = mergeConfig(this.defaults, config);
        const {
          transitional,
          paramsSerializer,
          headers
        } = config;
        if (transitional !== void 0) {
          validator.assertOptions(transitional, {
            silentJSONParsing: validators.transitional(validators.boolean),
            forcedJSONParsing: validators.transitional(validators.boolean),
            clarifyTimeoutError: validators.transitional(validators.boolean),
            legacyInterceptorReqResOrdering: validators.transitional(validators.boolean),
            advertiseZstdAcceptEncoding: validators.transitional(validators.boolean),
            validateStatusUndefinedResolves: validators.transitional(validators.boolean)
          }, false);
        }
        if (paramsSerializer != null) {
          if (utils$1.isFunction(paramsSerializer)) {
            config.paramsSerializer = {
              serialize: paramsSerializer
            };
          } else {
            validator.assertOptions(paramsSerializer, {
              encode: validators.function,
              serialize: validators.function
            }, true);
          }
        }
        if (config.allowAbsoluteUrls !== void 0) ;
        else if (this.defaults.allowAbsoluteUrls !== void 0) {
          config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
        } else {
          config.allowAbsoluteUrls = true;
        }
        validator.assertOptions(config, {
          baseUrl: validators.spelling("baseURL"),
          withXsrfToken: validators.spelling("withXSRFToken")
        }, true);
        config.method = (utils$1.getSafeProp(config, "method") || utils$1.getSafeProp(this.defaults, "method") || "get").toLowerCase();
        let contextHeaders = headers && utils$1.merge(headers.common, headers[config.method]);
        headers && utils$1.forEach(methodList.concat("common"), (method) => {
          delete headers[method];
        });
        config.headers = AxiosHeaders.concat(contextHeaders, headers);
        const requestInterceptorChain = [];
        let synchronousRequestInterceptors = true;
        this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
          if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) {
            return;
          }
          synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
          const transitional2 = config.transitional || transitionalDefaults;
          const legacyInterceptorReqResOrdering = transitional2 && transitional2.legacyInterceptorReqResOrdering;
          if (legacyInterceptorReqResOrdering) {
            requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
          } else {
            requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
          }
        });
        const responseInterceptorChain = [];
        this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
          responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
        });
        let promise;
        let i = 0;
        let len;
        if (!synchronousRequestInterceptors) {
          const chain = [dispatchRequest.bind(this), void 0];
          chain.unshift(...requestInterceptorChain);
          chain.push(...responseInterceptorChain);
          len = chain.length;
          promise = Promise.resolve(config);
          while (i < len) {
            promise = promise.then(chain[i++], chain[i++]);
          }
          return promise;
        }
        len = requestInterceptorChain.length;
        let newConfig = config;
        while (i < len) {
          const onFulfilled = requestInterceptorChain[i++];
          const onRejected = requestInterceptorChain[i++];
          try {
            newConfig = onFulfilled ? onFulfilled(newConfig) : newConfig;
          } catch (error) {
            if (!onRejected) {
              promise = Promise.reject(error);
              break;
            }
            try {
              const rejectedResult = onRejected.call(this, error);
              if (utils$1.isThenable(rejectedResult)) {
                promise = Promise.resolve(rejectedResult).then(() => dispatchRequest.call(this, newConfig));
              }
            } catch (rejectedError) {
              promise = Promise.reject(rejectedError);
            }
            break;
          }
        }
        if (!promise) {
          try {
            promise = dispatchRequest.call(this, newConfig);
          } catch (error) {
            promise = Promise.reject(error);
          }
        }
        i = 0;
        len = responseInterceptorChain.length;
        while (i < len) {
          promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
        }
        return promise;
      }
      getUri(config) {
        config = mergeConfig(this.defaults, config);
        const fullPath = buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls, config);
        return buildURL(fullPath, config.params, config.paramsSerializer);
      }
    };
    utils$1.forEach(["delete", "get", "head", "options"], function forEachMethodNoData(method) {
      Axios.prototype[method] = function(url2, config) {
        return this.request(mergeConfig(config || {}, {
          method,
          url: url2,
          data: config && utils$1.hasOwnProp(config, "data") ? config.data : void 0
        }));
      };
    });
    utils$1.forEach(["post", "put", "patch", "query"], function forEachMethodWithData(method) {
      function generateHTTPMethod(isForm) {
        return function httpMethod(url2, data, config) {
          return this.request(mergeConfig(config || {}, {
            method,
            headers: isForm ? {
              "Content-Type": "multipart/form-data"
            } : {},
            url: url2,
            data
          }));
        };
      }
      Axios.prototype[method] = generateHTTPMethod();
      if (method !== "query") {
        Axios.prototype[method + "Form"] = generateHTTPMethod(true);
      }
    });
    var CancelToken = class _CancelToken {
      constructor(executor) {
        if (typeof executor !== "function") {
          throw new TypeError("executor must be a function.");
        }
        let resolvePromise;
        this.promise = new Promise(function promiseExecutor(resolve) {
          resolvePromise = resolve;
        });
        const token = this;
        this.promise.then((cancel) => {
          if (!token._listeners) return;
          let i = token._listeners.length;
          while (i-- > 0) {
            token._listeners[i](cancel);
          }
          token._listeners = null;
        });
        this.promise.then = (onfulfilled) => {
          let _resolve;
          const promise = new Promise((resolve) => {
            token.subscribe(resolve);
            _resolve = resolve;
          }).then(onfulfilled);
          promise.cancel = function reject() {
            token.unsubscribe(_resolve);
          };
          return promise;
        };
        executor(function cancel(message, config, request) {
          if (token.reason) {
            return;
          }
          token.reason = new CanceledError(message, config, request);
          resolvePromise(token.reason);
        });
      }
      /**
       * Throws a `CanceledError` if cancellation has been requested.
       */
      throwIfRequested() {
        if (this.reason) {
          throw this.reason;
        }
      }
      /**
       * Subscribe to the cancel signal
       */
      subscribe(listener) {
        if (this.reason) {
          listener(this.reason);
          return;
        }
        if (this._listeners) {
          this._listeners.push(listener);
        } else {
          this._listeners = [listener];
        }
      }
      /**
       * Unsubscribe from the cancel signal
       */
      unsubscribe(listener) {
        if (!this._listeners) {
          return;
        }
        const index = this._listeners.indexOf(listener);
        if (index !== -1) {
          this._listeners.splice(index, 1);
        }
      }
      toAbortSignal() {
        const controller = new AbortController();
        const abort = (err) => {
          controller.abort(err);
        };
        this.subscribe(abort);
        controller.signal.unsubscribe = () => this.unsubscribe(abort);
        return controller.signal;
      }
      /**
       * Returns an object that contains a new `CancelToken` and a function that, when called,
       * cancels the `CancelToken`.
       */
      static source() {
        let cancel;
        const token = new _CancelToken(function executor(c) {
          cancel = c;
        });
        return {
          token,
          cancel
        };
      }
    };
    function spread(callback) {
      return function wrap(arr) {
        return callback.apply(null, arr);
      };
    }
    function isAxiosError(payload) {
      return utils$1.isObject(payload) && payload.isAxiosError === true;
    }
    var HttpStatusCode = {
      Continue: 100,
      SwitchingProtocols: 101,
      Processing: 102,
      EarlyHints: 103,
      Ok: 200,
      Created: 201,
      Accepted: 202,
      NonAuthoritativeInformation: 203,
      NoContent: 204,
      ResetContent: 205,
      PartialContent: 206,
      MultiStatus: 207,
      AlreadyReported: 208,
      ImUsed: 226,
      MultipleChoices: 300,
      MovedPermanently: 301,
      Found: 302,
      SeeOther: 303,
      NotModified: 304,
      UseProxy: 305,
      Unused: 306,
      TemporaryRedirect: 307,
      PermanentRedirect: 308,
      BadRequest: 400,
      Unauthorized: 401,
      PaymentRequired: 402,
      Forbidden: 403,
      NotFound: 404,
      MethodNotAllowed: 405,
      NotAcceptable: 406,
      ProxyAuthenticationRequired: 407,
      RequestTimeout: 408,
      Conflict: 409,
      Gone: 410,
      LengthRequired: 411,
      PreconditionFailed: 412,
      /**
       * @deprecated Use `ContentTooLarge` instead.
       */
      PayloadTooLarge: 413,
      ContentTooLarge: 413,
      UriTooLong: 414,
      UnsupportedMediaType: 415,
      RangeNotSatisfiable: 416,
      ExpectationFailed: 417,
      ImATeapot: 418,
      MisdirectedRequest: 421,
      /**
       * @deprecated Use `UnprocessableContent` instead.
       */
      UnprocessableEntity: 422,
      UnprocessableContent: 422,
      Locked: 423,
      FailedDependency: 424,
      TooEarly: 425,
      UpgradeRequired: 426,
      PreconditionRequired: 428,
      TooManyRequests: 429,
      RequestHeaderFieldsTooLarge: 431,
      UnavailableForLegalReasons: 451,
      InternalServerError: 500,
      NotImplemented: 501,
      BadGateway: 502,
      ServiceUnavailable: 503,
      GatewayTimeout: 504,
      HttpVersionNotSupported: 505,
      VariantAlsoNegotiates: 506,
      InsufficientStorage: 507,
      LoopDetected: 508,
      NotExtended: 510,
      NetworkAuthenticationRequired: 511,
      WebServerReturnsAnUnknownError: 520,
      WebServerIsDown: 521,
      ConnectionTimedOut: 522,
      OriginIsUnreachable: 523,
      TimeoutOccurred: 524,
      SslHandshakeFailed: 525,
      InvalidSslCertificate: 526
    };
    Object.entries(HttpStatusCode).forEach(([key, value]) => {
      if (HttpStatusCode[value] === void 0) {
        HttpStatusCode[value] = key;
      }
    });
    function createInstance(defaultConfig) {
      const context = new Axios(defaultConfig);
      const instance = bind(Axios.prototype.request, context);
      utils$1.extend(instance, Axios.prototype, context, {
        allOwnKeys: true
      });
      utils$1.extend(instance, context, null, {
        allOwnKeys: true
      });
      instance.create = function create(instanceConfig) {
        return createInstance(mergeConfig(defaultConfig, instanceConfig));
      };
      return instance;
    }
    var axios = createInstance(defaults);
    axios.Axios = Axios;
    axios.CanceledError = CanceledError;
    axios.CancelToken = CancelToken;
    axios.isCancel = isCancel;
    axios.VERSION = VERSION;
    axios.toFormData = toFormData;
    axios.AxiosError = AxiosError;
    axios.Cancel = axios.CanceledError;
    axios.all = function all(promises) {
      return Promise.all(promises);
    };
    axios.spread = spread;
    axios.isAxiosError = isAxiosError;
    axios.mergeConfig = mergeConfig;
    axios.AxiosHeaders = AxiosHeaders;
    axios.formToJSON = (thing) => formDataToJSON(utils$1.isHTMLForm(thing) ? new FormData(thing) : thing);
    axios.getAdapter = adapters.getAdapter;
    axios.HttpStatusCode = HttpStatusCode;
    axios.default = axios;
    module.exports = axios;
  }
});

// node_modules/razorpay/dist/utils/nodeify.js
var require_nodeify = __commonJS({
  "node_modules/razorpay/dist/utils/nodeify.js"(exports, module) {
    "use strict";
    var nodeify = function nodeify2(promise, cb) {
      if (!cb) {
        return promise.then(function(response) {
          return response.data;
        });
      }
      return promise.then(function(response) {
        cb(null, response.data);
      })["catch"](function(error) {
        cb(error, null);
      });
    };
    module.exports = nodeify;
  }
});

// node_modules/razorpay/dist/utils/razorpay-utils.js
var require_razorpay_utils = __commonJS({
  "node_modules/razorpay/dist/utils/razorpay-utils.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var crypto3 = __require("crypto");
    function getDateInSecs(date) {
      return +new Date(date) / 1e3;
    }
    function normalizeDate(date) {
      return isNumber(date) ? date : getDateInSecs(date);
    }
    function isNumber(num) {
      return !isNaN(Number(num));
    }
    function isNonNullObject(input) {
      return !!input && _typeof(input) === "object" && !Array.isArray(input);
    }
    function normalizeBoolean(bool) {
      if (bool === void 0) {
        return bool;
      }
      return bool ? 1 : 0;
    }
    function isDefined(value) {
      return typeof value !== "undefined";
    }
    function normalizeNotes() {
      var notes = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var normalizedNotes = {};
      for (var key in notes) {
        normalizedNotes["notes[".concat(key, "]")] = notes[key];
      }
      return normalizedNotes;
    }
    function prettify(val) {
      return JSON.stringify(val, null, 2);
    }
    function getTestError(summary, expectedVal, gotVal) {
      return new Error("\n".concat(summary, "\n") + "Expected(".concat(_typeof(expectedVal), ")\n").concat(prettify(expectedVal), "\n\n") + "Got(".concat(_typeof(gotVal), ")\n").concat(prettify(gotVal)));
    }
    function validateWebhookSignature(body, signature, secret) {
      var crypto4 = __require("crypto");
      if (!isDefined(body) || !isDefined(signature) || !isDefined(secret)) {
        throw Error("Invalid Parameters: Please give request body,signature sent in X-Razorpay-Signature header and webhook secret from dashboard as parameters");
      }
      body = body.toString();
      var expectedSignature = crypto4.createHmac("sha256", secret).update(body).digest("hex");
      return expectedSignature === signature;
    }
    function validatePaymentVerification() {
      var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var signature = arguments.length > 1 ? arguments[1] : void 0;
      var secret = arguments.length > 2 ? arguments[2] : void 0;
      var paymentId = params.payment_id;
      if (!secret) {
        throw new Error("secret is mandatory");
      }
      if (isDefined(params.order_id) === true) {
        var orderId = params.order_id;
        var payload = orderId + "|" + paymentId;
      } else if (isDefined(params.subscription_id) === true) {
        var subscriptionId = params.subscription_id;
        var payload = paymentId + "|" + subscriptionId;
      } else if (isDefined(params.payment_link_id) === true) {
        var paymentLinkId = params.payment_link_id;
        var paymentLinkRefId = params.payment_link_reference_id;
        var paymentLinkStatus = params.payment_link_status;
        var payload = paymentLinkId + "|" + paymentLinkRefId + "|" + paymentLinkStatus + "|" + paymentId;
      } else {
        throw new Error("Either order_id or subscription_id is mandatory");
      }
      return validateWebhookSignature(payload, signature, secret);
    }
    function generateOnboardingSignature() {
      var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var secret = arguments.length > 1 ? arguments[1] : void 0;
      var jsonStr = JSON.stringify(params);
      return encrypt(jsonStr, secret);
    }
    function encrypt(dataToEncrypt, secret) {
      try {
        var keyBytes = Buffer.from(secret.slice(0, 16), "utf8");
        var iv = crypto3.randomBytes(12);
        var cipher = crypto3.createCipheriv("aes-128-gcm", keyBytes, iv);
        var encryptedData = cipher.update(dataToEncrypt, "utf8");
        encryptedData = Buffer.concat([encryptedData, cipher["final"]()]);
        var authTag = cipher.getAuthTag();
        return Buffer.concat([iv, encryptedData, authTag]).toString("hex");
      } catch (err) {
        throw new Error("Encryption failed: ".concat(err.message));
      }
    }
    function isValidUrl(url) {
      try {
        new URL(url);
        return true;
      } catch (error) {
        return false;
      }
    }
    module.exports = {
      normalizeNotes,
      normalizeDate,
      normalizeBoolean,
      isNumber,
      getDateInSecs,
      prettify,
      isDefined,
      isNonNullObject,
      getTestError,
      validateWebhookSignature,
      validatePaymentVerification,
      isValidUrl,
      generateOnboardingSignature
    };
  }
});

// node_modules/razorpay/dist/api.js
var require_api = __commonJS({
  "node_modules/razorpay/dist/api.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _classCallCheck(a, n) {
      if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
    }
    function _defineProperties(e, r) {
      for (var t = 0; t < r.length; t++) {
        var o = r[t];
        o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey(o.key), o);
      }
    }
    function _createClass(e, r, t) {
      return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var axios = require_axios()["default"];
    var nodeify = require_nodeify();
    var _require = require_razorpay_utils();
    var isNonNullObject = _require.isNonNullObject;
    var allowedHeaders = {
      "X-Razorpay-Account": "",
      "Content-Type": "application/json"
    };
    function getValidHeaders(headers) {
      var result = {};
      if (!isNonNullObject(headers)) {
        return result;
      }
      return Object.keys(headers).reduce(function(result2, headerName) {
        if (allowedHeaders.hasOwnProperty(headerName)) {
          result2[headerName] = headers[headerName];
        }
        return result2;
      }, result);
    }
    function normalizeError(err) {
      throw {
        statusCode: err.response.status,
        error: err.response.data.error
      };
    }
    var API = /* @__PURE__ */ (function() {
      function API2(options) {
        _classCallCheck(this, API2);
        _defineProperty(this, "version", "v1");
        this.rq = axios.create(this._createConfig(options));
      }
      return _createClass(API2, [{
        key: "_createConfig",
        value: function _createConfig(options) {
          var config = {
            baseURL: options.hostUrl,
            headers: Object.assign({
              "User-Agent": options.ua
            }, getValidHeaders(options.headers))
          };
          if (options.key_id && options.key_secret) {
            config.auth = {
              username: options.key_id,
              password: options.key_secret
            };
          }
          if (options.oauthToken) {
            config.headers = _objectSpread({
              "Authorization": "Bearer ".concat(options.oauthToken)
            }, config.headers);
          }
          return config;
        }
      }, {
        key: "getEntityUrl",
        value: function getEntityUrl(params) {
          return params.hasOwnProperty("version") ? "/".concat(params.version).concat(params.url) : "/".concat(this.version).concat(params.url);
        }
      }, {
        key: "get",
        value: function get(params, cb) {
          return nodeify(this.rq.get(this.getEntityUrl(params), {
            params: params.data
          })["catch"](normalizeError), cb);
        }
      }, {
        key: "post",
        value: function post(params, cb) {
          return nodeify(this.rq.post(this.getEntityUrl(params), params.data)["catch"](normalizeError), cb);
        }
        // postFormData method for file uploads.
      }, {
        key: "postFormData",
        value: function postFormData(params, cb) {
          return nodeify(this.rq.post(this.getEntityUrl(params), params.formData, {
            "headers": {
              "Content-Type": "multipart/form-data"
            }
          })["catch"](normalizeError), cb);
        }
      }, {
        key: "put",
        value: function put(params, cb) {
          return nodeify(this.rq.put(this.getEntityUrl(params), params.data)["catch"](normalizeError), cb);
        }
      }, {
        key: "patch",
        value: function patch(params, cb) {
          return nodeify(this.rq.patch(this.getEntityUrl(params), params.data)["catch"](normalizeError), cb);
        }
      }, {
        key: "delete",
        value: function _delete(params, cb) {
          return nodeify(this.rq["delete"](this.getEntityUrl(params))["catch"](normalizeError), cb);
        }
      }]);
    })();
    module.exports = API;
  }
});

// node_modules/razorpay/package.json
var require_package = __commonJS({
  "node_modules/razorpay/package.json"(exports, module) {
    module.exports = {
      name: "razorpay",
      version: "2.9.8",
      description: "Official Node SDK for Razorpay API",
      main: "dist/razorpay",
      typings: "dist/razorpay",
      scripts: {
        prepublish: "npm test",
        clean: "rm -rf dist && mkdir dist",
        "cp-types": "mkdir dist/types && cp lib/types/* dist/types && cp lib/utils/*d.ts dist/utils",
        "cp-ts": "cp lib/razorpay.d.ts dist/ && cp lib/oAuthTokenClient.d.ts dist/ && npm run cp-types",
        "build:commonjs": "babel lib -d dist",
        build: "npm run clean && npm run build:commonjs && npm run cp-ts",
        debug: "npm run build && node-debug examples/index.js",
        test: "npm run build && mocha --recursive --require @babel/register test/ && nyc --reporter=text mocha",
        coverage: "nyc report --reporter=text-lcov > coverage.lcov"
      },
      repository: {
        type: "git",
        url: "https://github.com/razorpay/razorpay-node.git"
      },
      keywords: [
        "razorpay",
        "payments",
        "node",
        "nodejs",
        "razorpay-node"
      ],
      files: [
        "dist"
      ],
      mocha: {
        recursive: true,
        "full-trace": true
      },
      license: "MIT",
      devDependencies: {
        "@babel/cli": "^7.24.5",
        "@babel/core": "^7.24.5",
        "@babel/preset-env": "^7.24.5",
        "@babel/register": "^7.24.5",
        "@types/node": "^20.12.12",
        chai: "^4.3.4",
        "deep-equal": "^2.0.5",
        mocha: "^9.0.0",
        nock: "^13.1.1",
        nyc: "^15.1.0",
        typescript: "^4.9.4"
      },
      dependencies: {
        axios: "^1.18.1"
      }
    };
  }
});

// node_modules/razorpay/dist/resources/accounts.js
var require_accounts = __commonJS({
  "node_modules/razorpay/dist/resources/accounts.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["file"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    module.exports = function(api) {
      var BASE_URL = "/accounts";
      return {
        create: function create(params, callback) {
          return api.post({
            version: "v2",
            url: "".concat(BASE_URL),
            data: params
          }, callback);
        },
        edit: function edit(accountId, params, callback) {
          return api.patch({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId),
            data: params
          }, callback);
        },
        fetch: function fetch2(accountId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId)
          }, callback);
        },
        "delete": function _delete(accountId, callback) {
          return api["delete"]({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId)
          }, callback);
        },
        uploadAccountDoc: function uploadAccountDoc(accountId, params, callback) {
          var file = params.file, rest = _objectWithoutProperties(params, _excluded);
          return api.postFormData({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/documents"),
            formData: _objectSpread({
              file: file.value
            }, rest)
          }, callback);
        },
        fetchAccountDoc: function fetchAccountDoc(accountId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/documents")
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/stakeholders.js
var require_stakeholders = __commonJS({
  "node_modules/razorpay/dist/resources/stakeholders.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["file"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    module.exports = function(api) {
      var BASE_URL = "/accounts";
      return {
        create: function create(accountId, params, callback) {
          return api.post({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders"),
            data: params
          }, callback);
        },
        edit: function edit(accountId, stakeholderId, params, callback) {
          return api.patch({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders/").concat(stakeholderId),
            data: params
          }, callback);
        },
        fetch: function fetch2(accountId, stakeholderId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders/").concat(stakeholderId)
          }, callback);
        },
        all: function all(accountId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders")
          }, callback);
        },
        uploadStakeholderDoc: function uploadStakeholderDoc(accountId, stakeholderId, params, callback) {
          var file = params.file, rest = _objectWithoutProperties(params, _excluded);
          return api.postFormData({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders/").concat(stakeholderId, "/documents"),
            formData: _objectSpread({
              file: file.value
            }, rest)
          }, callback);
        },
        fetchStakeholderDoc: function fetchStakeholderDoc(accountId, stakeholderId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/stakeholders/").concat(stakeholderId, "/documents")
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/payments.js
var require_payments = __commonJS({
  "node_modules/razorpay/dist/resources/payments.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectDestructuringEmpty(t) {
      if (null == t) throw new TypeError("Cannot destructure " + t);
    }
    function _extends() {
      return _extends = Object.assign ? Object.assign.bind() : function(n) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];
          for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
        }
        return n;
      }, _extends.apply(null, arguments);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    var ID_REQUIRED_MSG = "`payment_id` is mandatory";
    var BASE_URL = "/payments";
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip;
          var expand;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          if (params.hasOwnProperty("expand[]")) {
            expand = {
              "expand[]": params["expand[]"]
            };
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url: "".concat(BASE_URL),
            data: {
              from,
              to,
              count,
              skip,
              expand
            }
          }, callback);
        },
        fetch: function fetch2(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var expand;
          if (!paymentId) {
            throw new Error("`payment_id` is mandatory");
          }
          if (params.hasOwnProperty("expand[]")) {
            expand = {
              "expand[]": params["expand[]"]
            };
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(paymentId),
            data: {
              expand
            }
          }, callback);
        },
        capture: function capture(paymentId, amount, currency, callback) {
          if (!paymentId) {
            throw new Error("`payment_id` is mandatory");
          }
          if (!amount) {
            throw new Error("`amount` is mandatory");
          }
          var payload = {
            amount
          };
          if (typeof currency === "function" && !callback) {
            callback = currency;
            currency = void 0;
          } else if (typeof currency === "string") {
            payload.currency = currency;
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/capture"),
            data: payload
          }, callback);
        },
        createPaymentJson: function createPaymentJson(params, callback) {
          var url = "".concat(BASE_URL, "/create/json"), rest = _extends({}, (_objectDestructuringEmpty(params), params)), data = Object.assign(rest);
          return api.post({
            url,
            data
          }, callback);
        },
        createRecurringPayment: function createRecurringPayment(params, callback) {
          return api.post({
            url: "".concat(BASE_URL, "/create/recurring"),
            data: params
          }, callback);
        },
        edit: function edit(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!paymentId) {
            throw new Error("`payment_id` is mandatory");
          }
          return api.patch({
            url: "".concat(BASE_URL, "/").concat(paymentId),
            data: params
          }, callback);
        },
        refund: function refund(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!paymentId) {
            throw new Error("`payment_id` is mandatory");
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/refund"),
            data: params
          }, callback);
        },
        fetchMultipleRefund: function fetchMultipleRefund(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = "".concat(BASE_URL, "/").concat(paymentId, "/refunds");
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        fetchRefund: function fetchRefund(paymentId, refundId, callback) {
          if (!paymentId) {
            throw new Error("payment Id` is mandatory");
          }
          if (!refundId) {
            throw new Error("refund Id` is mandatory");
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/refunds/").concat(refundId)
          }, callback);
        },
        fetchTransfer: function fetchTransfer(paymentId, callback) {
          if (!paymentId) {
            throw new Error("payment Id` is mandatory");
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/transfers")
          }, callback);
        },
        transfer: function transfer(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!paymentId) {
            throw new Error("`payment_id` is mandatory");
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/transfers"),
            data: params
          }, callback);
        },
        bankTransfer: function bankTransfer(paymentId, callback) {
          if (!paymentId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/bank_transfer")
          }, callback);
        },
        fetchCardDetails: function fetchCardDetails(paymentId, callback) {
          if (!paymentId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/card")
          }, callback);
        },
        fetchPaymentDowntime: function fetchPaymentDowntime(callback) {
          return api.get({
            url: "".concat(BASE_URL, "/downtimes")
          }, callback);
        },
        fetchPaymentDowntimeById: function fetchPaymentDowntimeById(downtimeId, callback) {
          if (!downtimeId) {
            return Promise.reject("Downtime Id is mandatory");
          }
          return api.get({
            url: "".concat(BASE_URL, "/downtimes/").concat(downtimeId)
          }, callback);
        },
        otpGenerate: function otpGenerate(paymentId, callback) {
          if (!paymentId) {
            return Promise.reject("payment Id is mandatory");
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/otp_generate")
          }, callback);
        },
        otpSubmit: function otpSubmit(paymentId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!paymentId) {
            return Promise.reject("payment Id is mandatory");
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/otp/submit"),
            data: params
          }, callback);
        },
        otpResend: function otpResend(paymentId, callback) {
          if (!paymentId) {
            return Promise.reject("payment Id is mandatory");
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(paymentId, "/otp/resend")
          }, callback);
        },
        createUpi: function createUpi() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = "".concat(BASE_URL, "/create/upi"), rest = _extends({}, (_objectDestructuringEmpty(params), params)), data = Object.assign(rest);
          return api.post({
            url,
            data
          }, callback);
        },
        validateVpa: function validateVpa() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = "".concat(BASE_URL, "/validate/vpa"), rest = _extends({}, (_objectDestructuringEmpty(params), params)), data = Object.assign(rest);
          return api.post({
            url,
            data
          }, callback);
        },
        fetchPaymentMethods: function fetchPaymentMethods(callback) {
          var url = "/methods";
          return api.get({
            url
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/refunds.js
var require_refunds = __commonJS({
  "node_modules/razorpay/dist/resources/refunds.js"(exports, module) {
    "use strict";
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    var normalizeNotes = _require.normalizeNotes;
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, payment_id = params.payment_id;
          var url = "/refunds";
          if (payment_id) {
            url = "/payments/".concat(payment_id, "/refunds");
          }
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: {
              from,
              to,
              count,
              skip
            }
          }, callback);
        },
        edit: function edit(refundId, params, callback) {
          if (!refundId) {
            throw new Error("refund Id is mandatory");
          }
          return api.patch({
            url: "/refunds/".concat(refundId),
            data: params
          }, callback);
        },
        fetch: function fetch2(refundId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var payment_id = params.payment_id;
          if (!refundId) {
            throw new Error("`refund_id` is mandatory");
          }
          var url = "/refunds/".concat(refundId);
          if (payment_id) {
            url = "/payments/".concat(payment_id).concat(url);
          }
          return api.get({
            url
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/orders.js
var require_orders = __commonJS({
  "node_modules/razorpay/dist/resources/orders.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["currency"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, authorized = params.authorized, receipt = params.receipt;
          var expand;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          if (params.hasOwnProperty("expand[]")) {
            expand = {
              "expand[]": params["expand[]"]
            };
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          authorized = authorized;
          return api.get({
            url: "/orders",
            data: {
              from,
              to,
              count,
              skip,
              authorized,
              receipt,
              expand
            }
          }, callback);
        },
        fetch: function fetch2(orderId, callback) {
          if (!orderId) {
            throw new Error("`order_id` is mandatory");
          }
          return api.get({
            url: "/orders/".concat(orderId)
          }, callback);
        },
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var currency = params.currency, otherParams = _objectWithoutProperties(params, _excluded);
          currency = currency || "INR";
          var data = Object.assign(_objectSpread({
            currency
          }, otherParams));
          return api.post({
            url: "/orders",
            data
          }, callback);
        },
        edit: function edit(orderId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!orderId) {
            throw new Error("`order_id` is mandatory");
          }
          return api.patch({
            url: "/orders/".concat(orderId),
            data: params
          }, callback);
        },
        fetchPayments: function fetchPayments(orderId, callback) {
          if (!orderId) {
            throw new Error("`order_id` is mandatory");
          }
          return api.get({
            url: "/orders/".concat(orderId, "/payments")
          }, callback);
        },
        fetchTransferOrder: function fetchTransferOrder(orderId, callback) {
          if (!orderId) {
            throw new Error("`order_id` is mandatory");
          }
          return api.get({
            url: "/orders/".concat(orderId, "/?expand[]=transfers&status")
          }, callback);
        },
        viewRtoReview: function viewRtoReview(orderId, callback) {
          return api.post({
            url: "/orders/".concat(orderId, "/rto_review")
          }, callback);
        },
        editFulfillment: function editFulfillment(orderId) {
          var param = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          return api.post({
            url: "/orders/".concat(orderId, "/fulfillment"),
            data: param
          });
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/customers.js
var require_customers = __commonJS({
  "node_modules/razorpay/dist/resources/customers.js"(exports, module) {
    "use strict";
    module.exports = function(api) {
      return {
        create: function create(params, callback) {
          return api.post({
            url: "/customers",
            data: params
          }, callback);
        },
        edit: function edit(customerId, params, callback) {
          return api.put({
            url: "/customers/".concat(customerId),
            data: params
          }, callback);
        },
        fetch: function fetch2(customerId, callback) {
          return api.get({
            url: "/customers/".concat(customerId)
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var count = params.count, skip = params.skip;
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url: "/customers",
            data: {
              count,
              skip
            }
          }, callback);
        },
        fetchTokens: function fetchTokens(customerId, callback) {
          return api.get({
            url: "/customers/".concat(customerId, "/tokens")
          }, callback);
        },
        fetchToken: function fetchToken(customerId, tokenId, callback) {
          return api.get({
            url: "/customers/".concat(customerId, "/tokens/").concat(tokenId)
          }, callback);
        },
        deleteToken: function deleteToken(customerId, tokenId, callback) {
          return api["delete"]({
            url: "/customers/".concat(customerId, "/tokens/").concat(tokenId)
          }, callback);
        },
        addBankAccount: function addBankAccount(customerId, params, callback) {
          return api.post({
            url: "/customers/".concat(customerId, "/bank_account"),
            data: params
          }, callback);
        },
        deleteBankAccount: function deleteBankAccount(customerId, bankId, callback) {
          return api["delete"]({
            url: "/customers/".concat(customerId, "/bank_account/").concat(bankId)
          }, callback);
        },
        requestEligibilityCheck: function requestEligibilityCheck(params, callback) {
          return api.post({
            url: "/customers/eligibility",
            data: params
          }, callback);
        },
        fetchEligibility: function fetchEligibility(eligibilityId, callback) {
          return api.get({
            url: "/customers/eligibility/".concat(eligibilityId)
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/transfers.js
var require_transfers = __commonJS({
  "node_modules/razorpay/dist/resources/transfers.js"(exports, module) {
    "use strict";
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, payment_id = params.payment_id, recipient_settlement_id = params.recipient_settlement_id;
          var url = "/transfers";
          if (payment_id) {
            url = "/payments/".concat(payment_id, "/transfers");
          }
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: {
              from,
              to,
              count,
              skip,
              recipient_settlement_id
            }
          }, callback);
        },
        fetch: function fetch2(transferId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var payment_id = params.payment_id;
          if (!transferId) {
            throw new Error("`transfer_id` is mandatory");
          }
          var url = "/transfers/".concat(transferId);
          return api.get({
            url
          }, callback);
        },
        create: function create(params, callback) {
          return api.post({
            url: "/transfers",
            data: params
          }, callback);
        },
        edit: function edit(transferId, params, callback) {
          return api.patch({
            url: "/transfers/".concat(transferId),
            data: params
          }, callback);
        },
        reverse: function reverse(transferId, params, callback) {
          if (!transferId) {
            throw new Error("`transfer_id` is mandatory");
          }
          var url = "/transfers/".concat(transferId, "/reversals");
          return api.post({
            url,
            data: params
          }, callback);
        },
        fetchSettlements: function fetchSettlements(callback) {
          return api.get({
            url: "/transfers?expand[]=recipient_settlement"
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/tokens.js
var require_tokens = __commonJS({
  "node_modules/razorpay/dist/resources/tokens.js"(exports, module) {
    "use strict";
    var _require = require_razorpay_utils();
    var normalizeNotes = _require.normalizeNotes;
    module.exports = function(api) {
      var BASE_URL = "/tokens";
      return {
        create: function create(params, callback) {
          return api.post({
            url: "".concat(BASE_URL),
            data: params
          }, callback);
        },
        fetch: function fetch2(params, callback) {
          return api.post({
            url: "".concat(BASE_URL, "/fetch"),
            data: params
          }, callback);
        },
        "delete": function _delete(params, callback) {
          return api.post({
            url: "".concat(BASE_URL, "/delete"),
            data: params
          }, callback);
        },
        processPaymentOnAlternatePAorPG: function processPaymentOnAlternatePAorPG(params, callback) {
          return api.post({
            url: "".concat(BASE_URL, "/service_provider_tokens/token_transactional_data"),
            data: params
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/virtualAccounts.js
var require_virtualAccounts = __commonJS({
  "node_modules/razorpay/dist/resources/virtualAccounts.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["from", "to", "count", "skip"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    var normalizeNotes = _require.normalizeNotes;
    var BASE_URL = "/virtual_accounts";
    var ID_REQUIRED_MSG = "`virtual_account_id` is mandatory";
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, otherParams = _objectWithoutProperties(params, _excluded);
          var url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread({
              from,
              to,
              count,
              skip
            }, otherParams)
          }, callback);
        },
        fetch: function fetch2(virtualAccountId, callback) {
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          var url = "".concat(BASE_URL, "/").concat(virtualAccountId);
          return api.get({
            url
          }, callback);
        },
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          return api.post({
            url: BASE_URL,
            data: params
          }, callback);
        },
        close: function close(virtualAccountId, callback) {
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(virtualAccountId, "/close")
          }, callback);
        },
        fetchPayments: function fetchPayments(virtualAccountId, callback) {
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          var url = "".concat(BASE_URL, "/").concat(virtualAccountId, "/payments");
          return api.get({
            url
          }, callback);
        },
        addReceiver: function addReceiver(virtualAccountId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(virtualAccountId, "/receivers"),
            data: params
          }, callback);
        },
        allowedPayer: function allowedPayer(virtualAccountId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          return api.post({
            url: "".concat(BASE_URL, "/").concat(virtualAccountId, "/allowed_payers"),
            data: params
          }, callback);
        },
        deleteAllowedPayer: function deleteAllowedPayer(virtualAccountId, allowedPayerId, callback) {
          if (!virtualAccountId) {
            return Promise.reject(ID_REQUIRED_MSG);
          }
          if (!allowedPayerId) {
            return Promise.reject("allowed payer id is mandatory");
          }
          return api["delete"]({
            url: "".concat(BASE_URL, "/").concat(virtualAccountId, "/allowed_payers/").concat(allowedPayerId)
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/invoices.js
var require_invoices = __commonJS({
  "node_modules/razorpay/dist/resources/invoices.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function invoicesApi(api) {
      var BASE_URL = "/invoices", MISSING_ID_ERROR = "Invoice ID is mandatory";
      return {
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = BASE_URL;
          return api.post({
            url,
            data: params
          }, callback);
        },
        edit: function edit(invoiceId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var url = "".concat(BASE_URL, "/").concat(invoiceId);
          if (!invoiceId) {
            return Promise.reject("Invoice ID is mandatory");
          }
          return api.patch({
            url,
            data: params
          }, callback);
        },
        issue: function issue(invoiceId, callback) {
          if (!invoiceId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(invoiceId, "/issue");
          return api.post({
            url
          }, callback);
        },
        "delete": function _delete(invoiceId, callback) {
          if (!invoiceId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(invoiceId);
          return api["delete"]({
            url
          }, callback);
        },
        cancel: function cancel(invoiceId, callback) {
          if (!invoiceId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(invoiceId, "/cancel");
          return api.post({
            url
          }, callback);
        },
        fetch: function fetch2(invoiceId, callback) {
          if (!invoiceId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(invoiceId);
          return api.get({
            url
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        notifyBy: function notifyBy(invoiceId, medium, callback) {
          if (!invoiceId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          if (!medium) {
            return Promise.reject("`medium` is required");
          }
          var url = "".concat(BASE_URL, "/").concat(invoiceId, "/notify_by/").concat(medium);
          return api.post({
            url
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/iins.js
var require_iins = __commonJS({
  "node_modules/razorpay/dist/resources/iins.js"(exports, module) {
    "use strict";
    module.exports = function(api) {
      var BASE_URL = "/iins";
      return {
        fetch: function fetch2(tokenIin, callback) {
          return api.get({
            url: "".concat(BASE_URL, "/").concat(tokenIin)
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          return api.get({
            url: "".concat(BASE_URL, "/list"),
            data: params
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/paymentLink.js
var require_paymentLink = __commonJS({
  "node_modules/razorpay/dist/resources/paymentLink.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function paymentLinkApi(api) {
      var BASE_URL = "/payment_links", MISSING_ID_ERROR = "Payment Link ID is mandatory";
      return {
        create: function create(params, callback) {
          var url = BASE_URL;
          return api.post({
            url,
            data: params
          }, callback);
        },
        cancel: function cancel(paymentLinkId, callback) {
          if (!paymentLinkId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(paymentLinkId, "/cancel");
          return api.post({
            url
          }, callback);
        },
        fetch: function fetch2(paymentLinkId, callback) {
          if (!paymentLinkId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(paymentLinkId);
          return api.get({
            url
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        edit: function edit(paymentLinkId, params, callback) {
          return api.patch({
            url: "".concat(BASE_URL, "/").concat(paymentLinkId),
            data: params
          }, callback);
        },
        notifyBy: function notifyBy(paymentLinkId, medium, callback) {
          if (!paymentLinkId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          if (!medium) {
            return Promise.reject("`medium` is required");
          }
          var url = "".concat(BASE_URL, "/").concat(paymentLinkId, "/notify_by/").concat(medium);
          return api.post({
            url
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/plans.js
var require_plans = __commonJS({
  "node_modules/razorpay/dist/resources/plans.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function plansApi(api) {
      var BASE_URL = "/plans", MISSING_ID_ERROR = "Plan ID is mandatory";
      return {
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = BASE_URL;
          return api.post({
            url,
            data: params
          }, callback);
        },
        fetch: function fetch2(planId, callback) {
          if (!planId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(planId);
          return api.get({
            url
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/products.js
var require_products = __commonJS({
  "node_modules/razorpay/dist/resources/products.js"(exports, module) {
    "use strict";
    module.exports = function(api) {
      var BASE_URL = "/accounts";
      return {
        requestProductConfiguration: function requestProductConfiguration(accountId, params, callback) {
          return api.post({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/products"),
            data: params
          }, callback);
        },
        edit: function edit(accountId, productId, params, callback) {
          return api.patch({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/products/").concat(productId),
            data: params
          }, callback);
        },
        fetch: function fetch2(accountId, productId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/products/").concat(productId)
          }, callback);
        },
        fetchTnc: function fetchTnc(productName, callback) {
          return api.get({
            version: "v2",
            url: "/products/".concat(productName, "/tnc")
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/subscriptions.js
var require_subscriptions = __commonJS({
  "node_modules/razorpay/dist/resources/subscriptions.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function subscriptionsApi(api) {
      var BASE_URL = "/subscriptions", MISSING_ID_ERROR = "Subscription ID is mandatory";
      return {
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = BASE_URL;
          return api.post({
            url,
            data: params
          }, callback);
        },
        fetch: function fetch2(subscriptionId, callback) {
          if (!subscriptionId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(subscriptionId);
          return api.get({
            url
          }, callback);
        },
        update: function update(subscriptionId, params, callback) {
          var url = "".concat(BASE_URL, "/").concat(subscriptionId);
          if (!subscriptionId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          return api.patch({
            url,
            data: params
          }, callback);
        },
        pendingUpdate: function pendingUpdate(subscriptionId, callback) {
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/retrieve_scheduled_changes");
          if (!subscriptionId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          return api.get({
            url
          }, callback);
        },
        cancelScheduledChanges: function cancelScheduledChanges(subscriptionId, callback) {
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/cancel_scheduled_changes");
          if (!subscriptionId) {
            return Promise.reject("Subscription Id is mandatory");
          }
          return api.post({
            url
          }, callback);
        },
        pause: function pause(subscriptionId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/pause");
          if (!subscriptionId) {
            return Promise.reject("Subscription Id is mandatory");
          }
          return api.post({
            url,
            data: params
          }, callback);
        },
        resume: function resume(subscriptionId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/resume");
          if (!subscriptionId) {
            return Promise.reject("Subscription Id is mandatory");
          }
          return api.post({
            url,
            data: params
          }, callback);
        },
        deleteOffer: function deleteOffer(subscriptionId, offerId, callback) {
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/").concat(offerId);
          if (!subscriptionId) {
            return Promise.reject("Subscription Id is mandatory");
          }
          return api["delete"]({
            url
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        cancel: function cancel(subscriptionId) {
          var cancelAtCycleEnd = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/cancel");
          if (!subscriptionId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          return api.post(_objectSpread({
            url
          }, cancelAtCycleEnd && {
            data: {
              cancel_at_cycle_end: 1
            }
          }), callback);
        },
        createAddon: function createAddon(subscriptionId, params, callback) {
          var url = "".concat(BASE_URL, "/").concat(subscriptionId, "/addons");
          if (!subscriptionId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          return api.post({
            url,
            data: _objectSpread({}, params)
          }, callback);
        },
        createRegistrationLink: function createRegistrationLink() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          return api.post({
            url: "/subscription_registration/auth_links",
            data: params
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/addons.js
var require_addons = __commonJS({
  "node_modules/razorpay/dist/resources/addons.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function(api) {
      var BASE_URL = "/addons", MISSING_ID_ERROR = "Addon ID is mandatory";
      return {
        fetch: function fetch2(addonId, callback) {
          if (!addonId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(addonId);
          return api.get({
            url
          }, callback);
        },
        "delete": function _delete(addonId, callback) {
          if (!addonId) {
            return Promise.reject(MISSING_ID_ERROR);
          }
          var url = "".concat(BASE_URL, "/").concat(addonId);
          return api["delete"]({
            url
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments[1];
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/settlements.js
var require_settlements = __commonJS({
  "node_modules/razorpay/dist/resources/settlements.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    module.exports = function(api) {
      var BASE_URL = "/settlements";
      return {
        createOndemandSettlement: function createOndemandSettlement() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = "".concat(BASE_URL, "/ondemand");
          return api.post({
            url,
            data: params
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        fetch: function fetch2(settlementId, callback) {
          if (!settlementId) {
            return Promise.reject("settlement Id is mandatroy");
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(settlementId)
          }, callback);
        },
        fetchOndemandSettlementById: function fetchOndemandSettlementById(settlementId) {
          var param = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var expand;
          if (!settlementId) {
            return Promise.reject("settlment Id is mandatroy");
          }
          if (param.hasOwnProperty("expand[]")) {
            expand = {
              "expand[]": param["expand[]"]
            };
          }
          return api.get({
            url: "".concat(BASE_URL, "/ondemand/").concat(settlementId),
            data: {
              expand
            }
          }, callback);
        },
        fetchAllOndemandSettlement: function fetchAllOndemandSettlement() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var expand;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = "".concat(BASE_URL, "/ondemand");
          if (params.hasOwnProperty("expand[]")) {
            expand = {
              "expand[]": params["expand[]"]
            };
          }
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip,
              expand
            })
          }, callback);
        },
        reports: function reports() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var day = params.day, count = params.count, skip = params.skip, url = "".concat(BASE_URL, "/recon/combined");
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              day,
              count,
              skip
            })
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/qrCode.js
var require_qrCode = __commonJS({
  "node_modules/razorpay/dist/resources/qrCode.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    module.exports = function(api) {
      var BASE_URL = "/payments/qr_codes";
      return {
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var url = BASE_URL;
          return api.post({
            url,
            data: params
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = BASE_URL;
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        fetchAllPayments: function fetchAllPayments(qrCodeId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, url = "".concat(BASE_URL, "/").concat(qrCodeId, "/payments");
          return api.get({
            url,
            data: _objectSpread(_objectSpread({}, params), {}, {
              from,
              to,
              count,
              skip
            })
          }, callback);
        },
        fetch: function fetch2(qrCodeId, callback) {
          if (!qrCodeId) {
            return Promise.reject("qrCode Id is mandatroy");
          }
          return api.get({
            url: "".concat(BASE_URL, "/").concat(qrCodeId)
          }, callback);
        },
        close: function close(qrCodeId, callback) {
          if (!qrCodeId) {
            return Promise.reject("qrCode Id is mandatroy");
          }
          var url = "".concat(BASE_URL, "/").concat(qrCodeId, "/close");
          return api.post({
            url
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/fundAccount.js
var require_fundAccount = __commonJS({
  "node_modules/razorpay/dist/resources/fundAccount.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    module.exports = function(api) {
      return {
        create: function create(params, callback) {
          return api.post({
            url: "/fund_accounts",
            data: _objectSpread({}, params)
          }, callback);
        },
        fetch: function fetch2(customerId, callback) {
          if (!customerId) {
            return Promise.reject("Customer Id is mandatroy");
          }
          return api.get({
            url: "/fund_accounts?customer_id=".concat(customerId)
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/items.js
var require_items = __commonJS({
  "node_modules/razorpay/dist/resources/items.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["amount", "currency"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function(api) {
      return {
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip, authorized = params.authorized, receipt = params.receipt;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url: "/items",
            data: {
              from,
              to,
              count,
              skip,
              authorized,
              receipt
            }
          }, callback);
        },
        fetch: function fetch2(itemId, callback) {
          if (!itemId) {
            throw new Error("`item_id` is mandatory");
          }
          return api.get({
            url: "/items/".concat(itemId)
          }, callback);
        },
        create: function create() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var amount = params.amount, currency = params.currency, rest = _objectWithoutProperties(params, _excluded);
          currency = currency || "INR";
          if (!amount) {
            throw new Error("`amount` is mandatory");
          }
          var data = Object.assign(_objectSpread({
            currency,
            amount
          }, rest));
          return api.post({
            url: "/items",
            data
          }, callback);
        },
        edit: function edit(itemId) {
          var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          if (!itemId) {
            throw new Error("`item_id` is mandatory");
          }
          var url = "/items/".concat(itemId);
          return api.patch({
            url,
            data: params
          }, callback);
        },
        "delete": function _delete(itemId, callback) {
          if (!itemId) {
            throw new Error("`item_id` is mandatory");
          }
          return api["delete"]({
            url: "/items/" + itemId
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/cards.js
var require_cards = __commonJS({
  "node_modules/razorpay/dist/resources/cards.js"(exports, module) {
    "use strict";
    module.exports = function(api) {
      return {
        fetch: function fetch2(itemId, callback) {
          if (!itemId) {
            throw new Error("`card_id` is mandatory");
          }
          return api.get({
            url: "/cards/".concat(itemId)
          }, callback);
        },
        requestCardReference: function requestCardReference(params, callback) {
          return api.post({
            url: "/cards/fingerprints",
            data: params
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/webhooks.js
var require_webhooks = __commonJS({
  "node_modules/razorpay/dist/resources/webhooks.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var _require = require_razorpay_utils();
    var normalizeDate = _require.normalizeDate;
    module.exports = function(api) {
      var BASE_URL = "/accounts";
      return {
        create: function create(params, accountId, callback) {
          var payload = {
            url: "/webhooks",
            data: params
          };
          if (accountId) {
            payload = {
              version: "v2",
              url: "".concat(BASE_URL, "/").concat(accountId, "/webhooks"),
              data: params
            };
          }
          return api.post(payload, callback);
        },
        edit: function edit(params, webhookId, accountId, callback) {
          if (accountId && webhookId) {
            return api.patch({
              version: "v2",
              url: "".concat(BASE_URL, "/").concat(accountId, "/webhooks/").concat(webhookId),
              data: params
            }, callback);
          }
          return api.put({
            url: "/webhooks/".concat(webhookId),
            data: params
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var accountId = arguments.length > 1 ? arguments[1] : void 0;
          var callback = arguments.length > 2 ? arguments[2] : void 0;
          var from = params.from, to = params.to, count = params.count, skip = params.skip;
          if (from) {
            from = normalizeDate(from);
          }
          if (to) {
            to = normalizeDate(to);
          }
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          var data = _objectSpread(_objectSpread({}, params), {}, {
            from,
            to,
            count,
            skip
          });
          if (accountId) {
            return api.get({
              version: "v2",
              url: "".concat(BASE_URL, "/").concat(accountId, "/webhooks/"),
              data
            }, callback);
          }
          return api.get({
            url: "/webhooks",
            data
          }, callback);
        },
        fetch: function fetch2(webhookId, accountId, callback) {
          return api.get({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/webhooks/").concat(webhookId)
          }, callback);
        },
        "delete": function _delete(webhookId, accountId, callback) {
          return api["delete"]({
            version: "v2",
            url: "".concat(BASE_URL, "/").concat(accountId, "/webhooks/").concat(webhookId)
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/documents.js
var require_documents = __commonJS({
  "node_modules/razorpay/dist/resources/documents.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    var _excluded = ["file"];
    function ownKeys(e, r) {
      var t = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r2) {
          return Object.getOwnPropertyDescriptor(e, r2).enumerable;
        })), t.push.apply(t, o);
      }
      return t;
    }
    function _objectSpread(e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
          _defineProperty(e, r2, t[r2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
          Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
        });
      }
      return e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _objectWithoutProperties(e, t) {
      if (null == e) return {};
      var o, r, i = _objectWithoutPropertiesLoose(e, t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
      }
      return i;
    }
    function _objectWithoutPropertiesLoose(r, e) {
      if (null == r) return {};
      var t = {};
      for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
      }
      return t;
    }
    module.exports = function(api) {
      var BASE_URL = "/documents";
      return {
        create: function create(params, callback) {
          var file = params.file, rest = _objectWithoutProperties(params, _excluded);
          return api.postFormData({
            url: "".concat(BASE_URL),
            formData: _objectSpread({
              file: file.value
            }, rest)
          }, callback);
        },
        fetch: function fetch2(documentId, callback) {
          return api.get({
            url: "".concat(BASE_URL, "/").concat(documentId)
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/resources/disputes.js
var require_disputes = __commonJS({
  "node_modules/razorpay/dist/resources/disputes.js"(exports, module) {
    "use strict";
    module.exports = function(api) {
      var BASE_URL = "/disputes";
      return {
        fetch: function fetch2(disputeId, callback) {
          return api.get({
            url: "".concat(BASE_URL, "/").concat(disputeId)
          }, callback);
        },
        all: function all() {
          var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          var callback = arguments.length > 1 ? arguments[1] : void 0;
          var count = params.count, skip = params.skip;
          count = Number(count) || 10;
          skip = Number(skip) || 0;
          return api.get({
            url: "".concat(BASE_URL),
            data: {
              count,
              skip
            }
          }, callback);
        },
        accept: function accept(disputeId, callback) {
          return api.post({
            url: "".concat(BASE_URL, "/").concat(disputeId, "/accept")
          }, callback);
        },
        contest: function contest(disputeId, param, callback) {
          return api.patch({
            url: "".concat(BASE_URL, "/").concat(disputeId, "/contest"),
            data: param
          }, callback);
        }
      };
    };
  }
});

// node_modules/razorpay/dist/razorpay.js
var require_razorpay = __commonJS({
  "node_modules/razorpay/dist/razorpay.js"(exports, module) {
    "use strict";
    function _typeof(o) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, _typeof(o);
    }
    function _classCallCheck(a, n) {
      if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
    }
    function _defineProperties(e, r) {
      for (var t = 0; t < r.length; t++) {
        var o = r[t];
        o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey(o.key), o);
      }
    }
    function _createClass(e, r, t) {
      return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
    }
    function _defineProperty(e, r, t) {
      return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    function _toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    var API = require_api();
    var pkg = require_package();
    var _require = require_razorpay_utils();
    var _validateWebhookSignature = _require.validateWebhookSignature;
    var Razorpay2 = /* @__PURE__ */ (function() {
      function Razorpay3() {
        var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        _classCallCheck(this, Razorpay3);
        var key_id = options.key_id, key_secret = options.key_secret, oauthToken = options.oauthToken, headers = options.headers;
        if (!key_id && !oauthToken) {
          throw new Error("`key_id` or `oauthToken` is mandatory");
        }
        this.key_id = key_id;
        this.key_secret = key_secret;
        this.oauthToken = oauthToken;
        this.api = new API({
          hostUrl: "https://api.razorpay.com",
          ua: "razorpay-node@".concat(Razorpay3.VERSION),
          key_id,
          key_secret,
          headers,
          oauthToken
        });
        this.addResources();
      }
      return _createClass(Razorpay3, [{
        key: "addResources",
        value: function addResources() {
          Object.assign(this, {
            accounts: require_accounts()(this.api),
            stakeholders: require_stakeholders()(this.api),
            payments: require_payments()(this.api),
            refunds: require_refunds()(this.api),
            orders: require_orders()(this.api),
            customers: require_customers()(this.api),
            transfers: require_transfers()(this.api),
            tokens: require_tokens()(this.api),
            virtualAccounts: require_virtualAccounts()(this.api),
            invoices: require_invoices()(this.api),
            iins: require_iins()(this.api),
            paymentLink: require_paymentLink()(this.api),
            plans: require_plans()(this.api),
            products: require_products()(this.api),
            subscriptions: require_subscriptions()(this.api),
            addons: require_addons()(this.api),
            settlements: require_settlements()(this.api),
            qrCode: require_qrCode()(this.api),
            fundAccount: require_fundAccount()(this.api),
            items: require_items()(this.api),
            cards: require_cards()(this.api),
            webhooks: require_webhooks()(this.api),
            documents: require_documents()(this.api),
            disputes: require_disputes()(this.api)
          });
        }
      }], [{
        key: "validateWebhookSignature",
        value: function validateWebhookSignature() {
          return _validateWebhookSignature.apply(void 0, arguments);
        }
      }]);
    })();
    _defineProperty(Razorpay2, "VERSION", pkg.version);
    module.exports = Razorpay2;
  }
});

// server/index.ts
import http from "node:http";
import fs5 from "node:fs";
import path5 from "node:path";

// server/db.ts
import { DatabaseSync } from "node:sqlite";
import crypto2 from "node:crypto";
import fs2 from "node:fs";
import path2 from "node:path";

// server/security.ts
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
try {
  const envPath = path.join(process.cwd(), ".env");
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, "utf8");
    for (const line of content.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim().replace(/^['"]|['"]$/g, "");
      if (key && process.env[key] === void 0) {
        process.env[key] = val;
      }
    }
  }
} catch {
}
var JWT_SECRET = process.env.JWT_SECRET || "society-saas-super-secret-jwt-key-2026-production-grade";
var RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "";
var RAZORPAY_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || "";
function getRazorpayKeyId() {
  return process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || "";
}
function getRazorpayKeySecret() {
  return process.env.RAZORPAY_KEY_SECRET || "";
}
function normalizeFlatNumber(flatNumber) {
  return String(flatNumber || "").trim().toUpperCase().replace(/\s*-\s*/g, "-").replace(/\s+/g, " ");
}
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}
function verifyPassword(password, storedHash) {
  const [salt, key] = (storedHash || "").split(":");
  if (!salt || !key) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(key, "hex");
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}
function signJwt(payload, ttlSeconds = 86400) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const fullPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1e3) + ttlSeconds
  };
  const body = Buffer.from(JSON.stringify(fullPayload)).toString("base64url");
  const signature = crypto.createHmac("sha256", JWT_SECRET).update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${signature}`;
}
function verifyJwt(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const [header, body, sig] = parts;
    const expectedSig = crypto.createHmac("sha256", JWT_SECRET).update(`${header}.${body}`).digest("base64url");
    const sigBuf = Buffer.from(sig);
    const expectedBuf = Buffer.from(expectedSig);
    if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
      return null;
    }
    const decoded = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (!decoded.exp || decoded.exp < Math.floor(Date.now() / 1e3)) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}
function extractBearerToken(req) {
  const authHeader = req.headers["authorization"];
  if (!authHeader || typeof authHeader !== "string") return null;
  if (!authHeader.startsWith("Bearer ")) return null;
  return authHeader.slice(7).trim();
}
function createRazorpayPaymentSignature(orderId, paymentId, secret = RAZORPAY_KEY_SECRET) {
  return crypto.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
}
function verifyRazorpayPaymentSignature(orderId, paymentId, signature, secret = RAZORPAY_KEY_SECRET) {
  if (!orderId || !paymentId || !signature) return false;
  const expected = createRazorpayPaymentSignature(orderId, paymentId, secret);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function maskDocumentNumber(docType, rawNumber) {
  const cleaned = String(rawNumber || "").replace(/\s+/g, "");
  if (cleaned.length <= 4) return "XXXX";
  const last4 = cleaned.slice(-4);
  if (docType.toUpperCase().includes("AADHAAR")) {
    return `XXXX-XXXX-${last4}`;
  }
  return `${"X".repeat(Math.max(4, cleaned.length - 4))}${last4}`;
}
var rateLimitStore = /* @__PURE__ */ new Map();
function checkRateLimit(key, maxRequests = 60, windowMs = 6e4) {
  const now = Date.now();
  const entry = rateLimitStore.get(key);
  if (!entry || entry.resetAt < now) {
    rateLimitStore.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (entry.count >= maxRequests) {
    return false;
  }
  entry.count += 1;
  return true;
}

// server/db.ts
var isServerless = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
var defaultDbPath = isServerless ? path2.join("/tmp", "society_saas.db") : path2.join(process.cwd(), "data", "society_saas.db");
var DB_PATH = process.env.SQLITE_DB_PATH || defaultDbPath;
try {
  fs2.mkdirSync(path2.dirname(DB_PATH), { recursive: true });
} catch {
}
var defaultUploadsDir = isServerless ? path2.join("/tmp", "uploads") : path2.join(process.cwd(), "data", "uploads");
try {
  fs2.mkdirSync(defaultUploadsDir, { recursive: true });
} catch {
}
var db = new DatabaseSync(DB_PATH);
try {
  if (isServerless) {
    db.exec("PRAGMA journal_mode = DELETE;");
  } else {
    db.exec("PRAGMA journal_mode = WAL;");
  }
} catch {
  try {
    db.exec("PRAGMA journal_mode = DELETE;");
  } catch {
  }
}
try {
  db.exec("PRAGMA foreign_keys = ON;");
} catch {
}
function uuid() {
  return crypto2.randomUUID();
}
function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS platform_settings (
      id TEXT PRIMARY KEY,
      platform_name TEXT NOT NULL DEFAULT 'SocietyOS Enterprise SaaS',
      support_email TEXT NOT NULL DEFAULT 'owner@societyos.com',
      support_phone TEXT NOT NULL DEFAULT '+91-98765-00001',
      default_trial_enabled INTEGER NOT NULL DEFAULT 1,
      default_trial_days INTEGER NOT NULL DEFAULT 14,
      default_grace_period_days INTEGER NOT NULL DEFAULT 7,
      auto_approve_paid_societies INTEGER NOT NULL DEFAULT 1,
      auto_approve_trial_societies INTEGER NOT NULL DEFAULT 1,
      reminder_days_before_expiry INTEGER NOT NULL DEFAULT 5,
      razorpay_key_id TEXT NOT NULL DEFAULT 'rzp_test_platform_demo_key',
      razorpay_sandbox_mode INTEGER NOT NULL DEFAULT 1,
      welcome_email_template TEXT NOT NULL DEFAULT 'Welcome to SocietyOS! Your society account is ready.',
      invoice_email_template TEXT NOT NULL DEFAULT 'A new society bill has been generated for your household.',
      overdue_email_template TEXT NOT NULL DEFAULT 'Reminder: Your society maintenance payment is overdue.',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'SOCIETY_ADMIN', 'STAFF', 'MEMBER')),
      society_id TEXT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      email_verified INTEGER NOT NULL DEFAULT 1,
      reset_token_hash TEXT NULL,
      reset_token_expires_at TEXT NULL,
      last_login_at TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS user_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      society_id TEXT NULL,
      full_name TEXT NOT NULL,
      avatar_url TEXT NULL,
      preferred_language TEXT NOT NULL DEFAULT 'en',
      address TEXT NULL,
      emergency_contact_name TEXT NULL,
      emergency_contact_phone TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS subscription_plans (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      description TEXT NULL,
      billing_period TEXT NOT NULL CHECK (billing_period IN ('MONTHLY', 'QUARTERLY', 'ANNUAL', 'CUSTOM')),
      duration_days INTEGER NOT NULL,
      price_amount REAL NOT NULL,
      tax_percent REAL NOT NULL DEFAULT 18.0,
      max_households INTEGER NOT NULL DEFAULT 500,
      trial_enabled INTEGER NOT NULL DEFAULT 1,
      trial_days INTEGER NOT NULL DEFAULT 14,
      grace_period_days INTEGER NOT NULL DEFAULT 7,
      auto_approve_after_payment INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS societies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      enrollment_code TEXT NOT NULL UNIQUE,
      logo_url TEXT NULL,
      address TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT '',
      state TEXT NOT NULL DEFAULT 'Punjab',
      pincode TEXT NOT NULL DEFAULT '',
      contact_email TEXT NOT NULL,
      contact_phone TEXT NOT NULL,
      registration_number TEXT NULL,
      admin_user_id TEXT NULL REFERENCES users(id) ON DELETE SET NULL,
      subscription_plan_id TEXT NULL REFERENCES subscription_plans(id),
      subscription_status TEXT NOT NULL DEFAULT 'TRIAL'
        CHECK (subscription_status IN ('TRIAL', 'ACTIVE', 'GRACE_PERIOD', 'EXPIRED', 'PENDING_PAYMENT', 'SUSPENDED')),
      approval_status TEXT NOT NULL DEFAULT 'APPROVED'
        CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED')),
      account_status TEXT NOT NULL DEFAULT 'ACTIVE'
        CHECK (account_status IN ('ACTIVE', 'SUSPENDED', 'ARCHIVED')),
      payment_status TEXT NOT NULL DEFAULT 'TRIAL'
        CHECK (payment_status IN ('TRIAL', 'PAID', 'PENDING', 'FAILED', 'OVERDUE', 'REFUNDED')),
      trial_starts_at TEXT NULL,
      trial_ends_at TEXT NULL,
      subscription_starts_at TEXT NULL,
      subscription_ends_at TEXT NULL,
      grace_period_ends_at TEXT NULL,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS society_settings (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL UNIQUE REFERENCES societies(id) ON DELETE CASCADE,
      upi_enabled INTEGER NOT NULL DEFAULT 1,
      gpay_upi_enabled INTEGER NOT NULL DEFAULT 1,
      paytm_enabled INTEGER NOT NULL DEFAULT 1,
      razorpay_enabled INTEGER NOT NULL DEFAULT 1,
      bank_transfer_enabled INTEGER NOT NULL DEFAULT 1,
      upi_id TEXT NULL,
      upi_payee_name TEXT NULL,
      upi_qr_url TEXT NULL,
      bank_name TEXT NULL,
      bank_account_number TEXT NULL,
      bank_ifsc TEXT NULL,
      razorpay_key_id TEXT NULL,
      razorpay_key_secret_encrypted TEXT NULL,
      bill_due_day INTEGER NOT NULL DEFAULT 10,
      late_fee_amount REAL NOT NULL DEFAULT 100.0,
      allow_member_staff_contacts INTEGER NOT NULL DEFAULT 1,
      custom_enrollment_fields TEXT NOT NULL DEFAULT '[]',
      email_notifications_enabled INTEGER NOT NULL DEFAULT 1,
      sms_notifications_enabled INTEGER NOT NULL DEFAULT 0,
      whatsapp_notifications_enabled INTEGER NOT NULL DEFAULT 0,
      brand_primary_color TEXT NOT NULL DEFAULT '#0f766e',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS society_subscriptions (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      plan_id TEXT NOT NULL REFERENCES subscription_plans(id),
      status TEXT NOT NULL CHECK (status IN ('TRIAL', 'ACTIVE', 'EXPIRED', 'CANCELLED', 'PENDING_PAYMENT')),
      starts_at TEXT NOT NULL,
      ends_at TEXT NOT NULL,
      is_trial INTEGER NOT NULL DEFAULT 0,
      extended_reason TEXT NULL,
      extended_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS subscription_payments (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      subscription_id TEXT NULL REFERENCES society_subscriptions(id) ON DELETE SET NULL,
      plan_id TEXT NOT NULL REFERENCES subscription_plans(id),
      invoice_number TEXT NOT NULL UNIQUE,
      amount REAL NOT NULL,
      tax_amount REAL NOT NULL DEFAULT 0,
      total_amount REAL NOT NULL,
      payment_gateway TEXT NOT NULL DEFAULT 'RAZORPAY',
      gateway_order_id TEXT NULL,
      gateway_payment_id TEXT NULL,
      gateway_signature TEXT NULL,
      verified_by_webhook INTEGER NOT NULL DEFAULT 0,
      verified_by_user_id TEXT NULL REFERENCES users(id),
      status TEXT NOT NULL CHECK (status IN ('CREATED', 'PAID', 'FAILED', 'CANCELLED', 'REFUNDED')),
      refund_reason TEXT NULL,
      paid_at TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS apartment_blocks (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      total_floors INTEGER NOT NULL DEFAULT 10,
      description TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, name)
    );

    CREATE TABLE IF NOT EXISTS households (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      block_id TEXT NULL REFERENCES apartment_blocks(id) ON DELETE SET NULL,
      block_name TEXT NOT NULL DEFAULT 'A',
      floor_number TEXT NOT NULL DEFAULT '1',
      flat_number TEXT NOT NULL,
      normalized_flat_number TEXT NOT NULL,
      occupancy_type TEXT NOT NULL DEFAULT 'OWNER' CHECK (occupancy_type IN ('OWNER', 'TENANT', 'VACANT')),
      area_sqft REAL NOT NULL DEFAULT 1200,
      status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('PENDING', 'ACTIVE', 'BLOCKED', 'ARCHIVED')),
      primary_member_id TEXT NULL,
      opening_balance REAL NOT NULL DEFAULT 0,
      opening_balance_notes TEXT NULL,
      opening_balance_date TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_household_per_society
      ON households (society_id, normalized_flat_number)
      WHERE status != 'ARCHIVED';

    CREATE TABLE IF NOT EXISTS society_members (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE RESTRICT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      photo_url TEXT NULL,
      relationship_to_primary TEXT NOT NULL DEFAULT 'PRIMARY',
      is_primary_member INTEGER NOT NULL DEFAULT 1,
      ownership_type TEXT NOT NULL DEFAULT 'OWNER' CHECK (ownership_type IN ('OWNER', 'TENANT', 'FAMILY')),
      emergency_contact TEXT NULL,
      custom_fields TEXT NOT NULL DEFAULT '{}',
      approval_status TEXT NOT NULL DEFAULT 'APPROVED' CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED')),
      account_status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (account_status IN ('ACTIVE', 'BLOCKED', 'ARCHIVED')),
      joined_at TEXT NOT NULL DEFAULT (datetime('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS member_invitations (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      token TEXT NOT NULL UNIQUE,
      email TEXT NULL,
      phone TEXT NULL,
      flat_number TEXT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT NULL,
      created_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS charge_categories (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      description TEXT NULL,
      default_amount REAL NOT NULL DEFAULT 0,
      billing_frequency TEXT NOT NULL DEFAULT 'MONTHLY'
        CHECK (billing_frequency IN ('MONTHLY', 'QUARTERLY', 'ANNUAL', 'ONE_TIME')),
      applicable_flats TEXT NOT NULL DEFAULT 'ALL',
      due_day INTEGER NOT NULL DEFAULT 10,
      is_single_charge_per_period INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, code)
    );

    CREATE TABLE IF NOT EXISTS member_bills (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE RESTRICT,
      member_id TEXT NULL REFERENCES society_members(id) ON DELETE SET NULL,
      bill_number TEXT NOT NULL UNIQUE,
      billing_month INTEGER NOT NULL CHECK (billing_month BETWEEN 1 AND 12),
      billing_year INTEGER NOT NULL CHECK (billing_year BETWEEN 2020 AND 2100),
      bill_type TEXT NOT NULL DEFAULT 'REGULAR'
        CHECK (bill_type IN ('REGULAR', 'SUPPLEMENTARY', 'ADJUSTMENT', 'OPENING_BALANCE')),
      adjustment_reason TEXT NULL,
      status TEXT NOT NULL DEFAULT 'UNPAID'
        CHECK (status IN ('DRAFT', 'PUBLISHED', 'UNPAID', 'PAYMENT_SUBMITTED', 'PENDING_VERIFICATION', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'CANCELLED')),
      subtotal_amount REAL NOT NULL DEFAULT 0,
      previous_balance REAL NOT NULL DEFAULT 0,
      penalty_amount REAL NOT NULL DEFAULT 0,
      credit_amount REAL NOT NULL DEFAULT 0,
      total_amount REAL NOT NULL DEFAULT 0,
      paid_amount REAL NOT NULL DEFAULT 0,
      balance_amount REAL NOT NULL DEFAULT 0,
      due_date TEXT NOT NULL,
      issued_at TEXT NULL,
      created_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_regular_bill_per_household_period
      ON member_bills (society_id, household_id, billing_month, billing_year)
      WHERE bill_type = 'REGULAR' AND status != 'CANCELLED';

    CREATE TABLE IF NOT EXISTS bill_items (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      bill_id TEXT NOT NULL REFERENCES member_bills(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE RESTRICT,
      charge_category_id TEXT NOT NULL REFERENCES charge_categories(id) ON DELETE RESTRICT,
      category_name TEXT NOT NULL,
      billing_month INTEGER NOT NULL,
      billing_year INTEGER NOT NULL,
      description TEXT NULL,
      amount REAL NOT NULL,
      is_adjustment INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_charge_per_flat_period
      ON bill_items (society_id, household_id, billing_month, billing_year, charge_category_id)
      WHERE is_adjustment = 0;

    CREATE TABLE IF NOT EXISTS bill_adjustments (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      bill_id TEXT NOT NULL REFERENCES member_bills(id) ON DELETE CASCADE,
      adjustment_type TEXT NOT NULL CHECK (adjustment_type IN ('CREDIT', 'DEBIT', 'PENALTY_WAIVER', 'SUPPLEMENTARY')),
      amount REAL NOT NULL,
      reason TEXT NOT NULL,
      created_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE RESTRICT,
      member_id TEXT NOT NULL REFERENCES society_members(id) ON DELETE RESTRICT,
      payment_method TEXT NOT NULL
        CHECK (payment_method IN ('UPI', 'GPAY_UPI', 'PAYTM', 'RAZORPAY', 'BANK_TRANSFER', 'CASH', 'OTHER')),
      amount REAL NOT NULL CHECK (amount > 0),
      payment_date TEXT NOT NULL,
      reference_number TEXT NOT NULL,
      proof_url TEXT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING_VERIFICATION'
        CHECK (status IN ('PAYMENT_SUBMITTED', 'PENDING_VERIFICATION', 'CONFIRMED', 'REJECTED', 'PARTIALLY_PAID', 'REFUNDED')),
      verification_notes TEXT NULL,
      verified_by TEXT NULL REFERENCES users(id),
      verified_at TEXT NULL,
      ledger_posted INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payment_allocations (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      payment_id TEXT NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
      bill_id TEXT NOT NULL REFERENCES member_bills(id) ON DELETE RESTRICT,
      allocated_amount REAL NOT NULL CHECK (allocated_amount > 0),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (payment_id, bill_id)
    );

    CREATE TABLE IF NOT EXISTS payment_receipts (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      payment_id TEXT NOT NULL UNIQUE REFERENCES payments(id) ON DELETE RESTRICT,
      receipt_number TEXT NOT NULL UNIQUE,
      issued_to_name TEXT NOT NULL,
      flat_number TEXT NOT NULL,
      amount REAL NOT NULL,
      payment_method TEXT NOT NULL,
      reference_number TEXT NOT NULL,
      issued_by TEXT NULL REFERENCES users(id),
      issued_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff_roles (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      is_office_bearer INTEGER NOT NULL DEFAULT 0,
      is_system_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, name)
    );

    CREATE TABLE IF NOT EXISTS role_permissions (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      role_id TEXT NOT NULL UNIQUE REFERENCES staff_roles(id) ON DELETE CASCADE,
      view_members INTEGER NOT NULL DEFAULT 0,
      manage_members INTEGER NOT NULL DEFAULT 0,
      generate_bills INTEGER NOT NULL DEFAULT 0,
      verify_payments INTEGER NOT NULL DEFAULT 0,
      manage_expenses INTEGER NOT NULL DEFAULT 0,
      view_financial_reports INTEGER NOT NULL DEFAULT 0,
      manage_complaints INTEGER NOT NULL DEFAULT 0,
      manage_events INTEGER NOT NULL DEFAULT 0,
      manage_staff INTEGER NOT NULL DEFAULT 0,
      change_society_settings INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      user_id TEXT NULL REFERENCES users(id) ON DELETE SET NULL,
      role_id TEXT NOT NULL REFERENCES staff_roles(id) ON DELETE RESTRICT,
      full_name TEXT NOT NULL,
      photo_url TEXT NULL,
      phone TEXT NOT NULL,
      email TEXT NULL,
      address TEXT NULL,
      designation TEXT NOT NULL,
      joining_date TEXT NOT NULL,
      wage_type TEXT NOT NULL DEFAULT 'MONTHLY' CHECK (wage_type IN ('MONTHLY', 'DAILY')),
      salary_amount REAL NOT NULL DEFAULT 0,
      employment_status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (employment_status IN ('ACTIVE', 'INACTIVE', 'TERMINATED')),
      is_on_duty INTEGER NOT NULL DEFAULT 0,
      duty_schedule TEXT NULL,
      assigned_duties TEXT NULL,
      show_contact_to_members INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff_documents (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      staff_id TEXT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
      document_type TEXT NOT NULL,
      masked_document_number TEXT NOT NULL,
      document_url TEXT NOT NULL,
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff_duty_records (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      staff_id TEXT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
      duty_status TEXT NOT NULL CHECK (duty_status IN ('ON_DUTY', 'OFF_DUTY')),
      shift_notes TEXT NULL,
      changed_by TEXT NULL REFERENCES users(id),
      changed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS attendance_records (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      staff_id TEXT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
      attendance_date TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('PRESENT', 'ABSENT', 'HALF_DAY', 'LEAVE')),
      check_in_time TEXT NULL,
      check_out_time TEXT NULL,
      salary_paid REAL NOT NULL DEFAULT 0,
      notes TEXT NULL,
      recorded_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, staff_id, attendance_date)
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      complaint_number TEXT NOT NULL UNIQUE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      member_id TEXT NOT NULL REFERENCES society_members(id) ON DELETE CASCADE,
      flat_number TEXT NOT NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'URGENT')),
      status TEXT NOT NULL DEFAULT 'SUBMITTED'
        CHECK (status IN ('SUBMITTED', 'IN_PROGRESS', 'RESOLVED', 'REJECTED')),
      assigned_staff_id TEXT NULL REFERENCES staff(id) ON DELETE SET NULL,
      resolution_notes TEXT NULL,
      resolution_image_url TEXT NULL,
      resolved_at TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS complaint_attachments (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      complaint_id TEXT NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
      file_url TEXT NOT NULL,
      file_type TEXT NOT NULL DEFAULT 'image/png',
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS complaint_comments (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      complaint_id TEXT NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
      author_user_id TEXT NOT NULL REFERENCES users(id),
      author_name TEXT NOT NULL,
      comment_text TEXT NOT NULL,
      is_internal INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS suggestions (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      member_id TEXT NOT NULL REFERENCES society_members(id) ON DELETE CASCADE,
      flat_number TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED', 'UNDER_REVIEW', 'ACKNOWLEDGED', 'IMPLEMENTED')),
      admin_response TEXT NULL,
      responded_by TEXT NULL REFERENCES users(id),
      responded_at TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS society_events (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      event_type TEXT NOT NULL DEFAULT 'GENERAL',
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      event_date TEXT NOT NULL,
      event_time TEXT NOT NULL,
      venue TEXT NOT NULL,
      image_url TEXT NULL,
      publication_status TEXT NOT NULL DEFAULT 'PUBLISHED' CHECK (publication_status IN ('DRAFT', 'PUBLISHED', 'ARCHIVED')),
      created_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      category TEXT NOT NULL DEFAULT 'GENERAL'
        CHECK (category IN ('MEETING', 'FESTIVAL', 'MAINTENANCE', 'EMERGENCY', 'WATER_INTERRUPTION', 'SECURITY_ALERT', 'GENERAL')),
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      image_url TEXT NULL,
      publication_status TEXT NOT NULL DEFAULT 'PUBLISHED' CHECK (publication_status IN ('DRAFT', 'PUBLISHED', 'ARCHIVED')),
      send_email INTEGER NOT NULL DEFAULT 1,
      created_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS financial_accounts (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      account_type TEXT NOT NULL CHECK (account_type IN ('CASH', 'BANK')),
      account_name TEXT NOT NULL,
      opening_balance REAL NOT NULL DEFAULT 0,
      current_balance REAL NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, account_type)
    );

    CREATE TABLE IF NOT EXISTS expense_categories (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      description TEXT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, name)
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      expense_category_id TEXT NOT NULL REFERENCES expense_categories(id) ON DELETE RESTRICT,
      category_name TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL CHECK (amount > 0),
      expense_date TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      account_type TEXT NOT NULL CHECK (account_type IN ('CASH', 'BANK')),
      vendor_name TEXT NOT NULL,
      invoice_url TEXT NULL,
      status TEXT NOT NULL DEFAULT 'APPROVED' CHECK (status IN ('APPROVED', 'REVERSED')),
      entered_by TEXT NOT NULL REFERENCES users(id),
      approved_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS ledger_entries (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
      transaction_code TEXT NOT NULL UNIQUE,
      entry_date TEXT NOT NULL,
      entry_type TEXT NOT NULL
        CHECK (entry_type IN ('INCOME', 'EXPENSE', 'TRANSFER', 'RECEIVABLE', 'LIABILITY', 'REFUND', 'REVERSAL', 'ADJUSTMENT')),
      account_type TEXT NOT NULL CHECK (account_type IN ('CASH', 'BANK', 'RECEIVABLE', 'NONE')),
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      direction TEXT NOT NULL CHECK (direction IN ('CREDIT', 'DEBIT')),
      reference_type TEXT NOT NULL,
      reference_id TEXT NOT NULL,
      household_id TEXT NULL REFERENCES households(id) ON DELETE SET NULL,
      flat_number TEXT NULL,
      member_id TEXT NULL REFERENCES society_members(id) ON DELETE SET NULL,
      payment_method TEXT NULL,
      reversal_of_entry_id TEXT NULL REFERENCES ledger_entries(id),
      created_by TEXT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (society_id, reference_type, reference_id, entry_type)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      society_id TEXT NULL REFERENCES societies(id) ON DELETE CASCADE,
      user_id TEXT NULL REFERENCES users(id) ON DELETE CASCADE,
      notification_type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK (channel IN ('IN_APP', 'EMAIL', 'SMS', 'WHATSAPP')),
      dedup_key TEXT NULL UNIQUE,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      society_id TEXT NULL REFERENCES societies(id) ON DELETE CASCADE,
      actor_user_id TEXT NULL REFERENCES users(id) ON DELETE SET NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NULL,
      details TEXT NOT NULL DEFAULT '{}',
      ip_address TEXT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  const safeAlterColumns = [
    "ALTER TABLE society_settings ADD COLUMN razorpay_webhook_secret_encrypted TEXT NULL",
    "ALTER TABLE society_settings ADD COLUMN paytm_merchant_id TEXT NULL",
    "ALTER TABLE society_settings ADD COLUMN paytm_merchant_key_encrypted TEXT NULL",
    "ALTER TABLE society_settings ADD COLUMN custom_gateway_name TEXT NULL",
    "ALTER TABLE society_settings ADD COLUMN custom_gateway_api_key TEXT NULL",
    "ALTER TABLE society_settings ADD COLUMN custom_gateway_secret_encrypted TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN razorpay_key_secret_encrypted TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN razorpay_webhook_secret_encrypted TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN paytm_merchant_id TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN paytm_merchant_key_encrypted TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN custom_gateway_name TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN custom_gateway_api_key TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN custom_gateway_secret_encrypted TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN upi_id TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN upi_payee_name TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN bank_name TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN bank_account_number TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN bank_ifsc TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN subscription_tax_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE platform_settings ADD COLUMN subscription_tax_name TEXT NOT NULL DEFAULT 'GST'",
    "ALTER TABLE platform_settings ADD COLUMN subscription_tax_percent REAL NOT NULL DEFAULT 18.0",
    "ALTER TABLE subscription_plans ADD COLUMN tax_name TEXT NOT NULL DEFAULT 'GST'",
    "ALTER TABLE platform_settings ADD COLUMN razorpay_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE platform_settings ADD COLUMN upi_payment_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE platform_settings ADD COLUMN paytm_enabled INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE platform_settings ADD COLUMN custom_gateway_enabled INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE platform_settings ADD COLUMN meta_title TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN meta_description TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN meta_keywords TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN meta_author TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN meta_og_image TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN favicon_url TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN google_adsense_enabled INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE platform_settings ADD COLUMN google_adsense_client_id TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN google_ad_slot_header TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN google_ad_slot_sidebar TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN google_ad_slot_footer TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN google_analytics_id TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN custom_header_scripts TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN logo_url TEXT NULL",
    "ALTER TABLE platform_settings ADD COLUMN dark_logo_url TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN receipt_url TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN notes TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN rejection_reason TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN refund_amount REAL NULL",
    "ALTER TABLE subscription_payments ADD COLUMN refund_reference TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN refunded_at TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN refund_notes TEXT NULL",
    "ALTER TABLE subscription_payments ADD COLUMN refund_gateway TEXT NULL",
    "ALTER TABLE households ADD COLUMN opening_balance REAL NOT NULL DEFAULT 0",
    "ALTER TABLE households ADD COLUMN opening_balance_notes TEXT NULL",
    "ALTER TABLE households ADD COLUMN opening_balance_date TEXT NULL"
  ];
  for (const sql of safeAlterColumns) {
    try {
      db.exec(sql);
    } catch {
    }
  }
  try {
    const billTableSql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='member_bills'").get();
    if (billTableSql?.sql && !billTableSql.sql.includes("OPENING_BALANCE")) {
      db.exec("PRAGMA foreign_keys = OFF;");
      db.exec(`
        CREATE TABLE member_bills_temp_migration (
          id TEXT PRIMARY KEY,
          society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
          household_id TEXT NOT NULL REFERENCES households(id) ON DELETE RESTRICT,
          member_id TEXT NULL REFERENCES society_members(id) ON DELETE SET NULL,
          bill_number TEXT NOT NULL UNIQUE,
          billing_month INTEGER NOT NULL CHECK (billing_month BETWEEN 1 AND 12),
          billing_year INTEGER NOT NULL CHECK (billing_year BETWEEN 2020 AND 2100),
          bill_type TEXT NOT NULL DEFAULT 'REGULAR'
            CHECK (bill_type IN ('REGULAR', 'SUPPLEMENTARY', 'ADJUSTMENT', 'OPENING_BALANCE')),
          adjustment_reason TEXT NULL,
          status TEXT NOT NULL DEFAULT 'UNPAID'
            CHECK (status IN ('DRAFT', 'PUBLISHED', 'UNPAID', 'PAYMENT_SUBMITTED', 'PENDING_VERIFICATION', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'CANCELLED')),
          subtotal_amount REAL NOT NULL DEFAULT 0,
          previous_balance REAL NOT NULL DEFAULT 0,
          penalty_amount REAL NOT NULL DEFAULT 0,
          credit_amount REAL NOT NULL DEFAULT 0,
          total_amount REAL NOT NULL DEFAULT 0,
          paid_amount REAL NOT NULL DEFAULT 0,
          balance_amount REAL NOT NULL DEFAULT 0,
          due_date TEXT NOT NULL,
          issued_at TEXT NULL,
          created_by TEXT NULL REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO member_bills_temp_migration SELECT * FROM member_bills;
        DROP TABLE member_bills;
        ALTER TABLE member_bills_temp_migration RENAME TO member_bills;
        CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_regular_bill_per_household_period
          ON member_bills (society_id, household_id, billing_month, billing_year)
          WHERE bill_type = 'REGULAR' AND status != 'CANCELLED';
      `);
      db.exec("PRAGMA foreign_keys = ON;");
    }
  } catch (migrationErr) {
    console.error("[Migration Warning] Failed to update member_bills check constraint:", migrationErr);
  }
}
function bootstrapSocietyDefaults(societyId, societyName) {
  const existingSettings = db.prepare("SELECT id FROM society_settings WHERE society_id = ?").get(societyId);
  if (!existingSettings) {
    const slug = societyName.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 14) || "society";
    db.prepare(`
      INSERT INTO society_settings (
        id, society_id, upi_enabled, gpay_upi_enabled, paytm_enabled, razorpay_enabled, bank_transfer_enabled,
        upi_id, upi_payee_name, bank_name, bank_account_number, bank_ifsc, bill_due_day, late_fee_amount
      ) VALUES (?, ?, 1, 1, 1, 1, 1, ?, ?, 'HDFC Bank Ltd', '50200089412210', 'HDFC0001245', 10, 150)
    `).run(uuid(), societyId, `${slug}@hdfcbank`, `${societyName} RWA`);
  }
  for (const accType of ["CASH", "BANK"]) {
    const exists = db.prepare("SELECT id FROM financial_accounts WHERE society_id = ? AND account_type = ?").get(societyId, accType);
    if (!exists) {
      db.prepare(`
        INSERT INTO financial_accounts (id, society_id, account_type, account_name, opening_balance, current_balance)
        VALUES (?, ?, ?, ?, 0, 0)
      `).run(
        uuid(),
        societyId,
        accType,
        accType === "CASH" ? "Society Petty Cash Account" : "Society Main RWA Bank Account"
      );
    }
  }
  for (const blockName of ["Block A", "Block B", "Block C"]) {
    const exists = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = ?").get(societyId, blockName);
    if (!exists) {
      db.prepare(`
        INSERT INTO apartment_blocks (id, society_id, name, total_floors, description)
        VALUES (?, ?, ?, 10, ?)
      `).run(uuid(), societyId, blockName, `Residential ${blockName}`);
    }
  }
  const defaultCharges = [
    { name: "Monthly maintenance", code: "MONTHLY_MAINTENANCE", amount: 2500, freq: "MONTHLY" },
    { name: "Water charges", code: "WATER_CHARGES", amount: 400, freq: "MONTHLY" },
    { name: "Electricity charges", code: "ELECTRICITY_CHARGES", amount: 600, freq: "MONTHLY" },
    { name: "Parking charges", code: "PARKING_CHARGES", amount: 300, freq: "MONTHLY" },
    { name: "Security charges", code: "SECURITY_CHARGES", amount: 500, freq: "MONTHLY" },
    { name: "Cleaning charges", code: "CLEANING_CHARGES", amount: 250, freq: "MONTHLY" },
    { name: "Repair and maintenance", code: "REPAIR_MAINTENANCE", amount: 350, freq: "ONE_TIME" },
    { name: "Late payment fees", code: "LATE_PAYMENT_FEES", amount: 150, freq: "ONE_TIME" },
    { name: "Special assessments", code: "SPECIAL_ASSESSMENTS", amount: 1e3, freq: "ONE_TIME" },
    { name: "Other charges", code: "OTHER_CHARGES", amount: 200, freq: "ONE_TIME" }
  ];
  for (const ch of defaultCharges) {
    const exists = db.prepare("SELECT id FROM charge_categories WHERE society_id = ? AND code = ?").get(societyId, ch.code);
    if (!exists) {
      db.prepare(`
        INSERT INTO charge_categories (
          id, society_id, name, code, description, default_amount, billing_frequency, applicable_flats, due_day, is_single_charge_per_period, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ALL', 10, 1, 1)
      `).run(uuid(), societyId, ch.name, ch.code, `${ch.name} for society households`, ch.amount, ch.freq);
    }
  }
  const defaultExpenseCategories = [
    "Security Services & Guards",
    "Housekeeping & Sanitation",
    "Common Area Electricity Bill",
    "Water Tanker & Pump Repair",
    "Lift AMC & Maintenance",
    "Garden & Landscaping",
    "Diesel for Generator",
    "Office Stationery & Admin",
    "Festival & Community Events"
  ];
  for (const expName of defaultExpenseCategories) {
    const exists = db.prepare("SELECT id FROM expense_categories WHERE society_id = ? AND name = ?").get(societyId, expName);
    if (!exists) {
      db.prepare(`
        INSERT INTO expense_categories (id, society_id, name, description, is_active)
        VALUES (?, ?, ?, ?, 1)
      `).run(uuid(), societyId, expName, `Standard expense head: ${expName}`);
    }
  }
  const defaultRoles = [
    {
      name: "President",
      isOfficeBearer: 1,
      perms: {
        view_members: 1,
        manage_members: 1,
        generate_bills: 1,
        verify_payments: 1,
        manage_expenses: 1,
        view_financial_reports: 1,
        manage_complaints: 1,
        manage_events: 1,
        manage_staff: 1,
        change_society_settings: 1
      }
    },
    {
      name: "Vice President",
      isOfficeBearer: 1,
      perms: {
        view_members: 1,
        manage_members: 1,
        generate_bills: 1,
        verify_payments: 1,
        manage_expenses: 1,
        view_financial_reports: 1,
        manage_complaints: 1,
        manage_events: 1,
        manage_staff: 1,
        change_society_settings: 0
      }
    },
    {
      name: "Secretary",
      isOfficeBearer: 1,
      perms: {
        view_members: 1,
        manage_members: 1,
        generate_bills: 1,
        verify_payments: 0,
        manage_expenses: 1,
        view_financial_reports: 1,
        manage_complaints: 1,
        manage_events: 1,
        manage_staff: 1,
        change_society_settings: 1
      }
    },
    {
      name: "Joint Secretary",
      isOfficeBearer: 1,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 0,
        manage_expenses: 0,
        view_financial_reports: 1,
        manage_complaints: 1,
        manage_events: 1,
        manage_staff: 1,
        change_society_settings: 0
      }
    },
    {
      name: "Treasurer",
      isOfficeBearer: 1,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 1,
        verify_payments: 1,
        manage_expenses: 1,
        view_financial_reports: 1,
        manage_complaints: 0,
        manage_events: 0,
        manage_staff: 0,
        change_society_settings: 0
      }
    },
    {
      name: "Cashier",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 1,
        manage_expenses: 0,
        view_financial_reports: 1,
        manage_complaints: 0,
        manage_events: 0,
        manage_staff: 0,
        change_society_settings: 0
      }
    },
    {
      name: "Accountant",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 1,
        verify_payments: 1,
        manage_expenses: 1,
        view_financial_reports: 1,
        manage_complaints: 0,
        manage_events: 0,
        manage_staff: 0,
        change_society_settings: 0
      }
    },
    {
      name: "Maintenance Supervisor",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 0,
        manage_expenses: 1,
        view_financial_reports: 0,
        manage_complaints: 1,
        manage_events: 0,
        manage_staff: 1,
        change_society_settings: 0
      }
    },
    {
      name: "Security Supervisor",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 0,
        manage_expenses: 0,
        view_financial_reports: 0,
        manage_complaints: 1,
        manage_events: 0,
        manage_staff: 1,
        change_society_settings: 0
      }
    },
    {
      name: "Security Guard",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 0,
        manage_expenses: 0,
        view_financial_reports: 0,
        manage_complaints: 0,
        manage_events: 0,
        manage_staff: 0,
        change_society_settings: 0
      }
    },
    {
      name: "Maintenance Staff",
      isOfficeBearer: 0,
      perms: {
        view_members: 0,
        manage_members: 0,
        generate_bills: 0,
        verify_payments: 0,
        manage_expenses: 0,
        view_financial_reports: 0,
        manage_complaints: 1,
        manage_events: 0,
        manage_staff: 0,
        change_society_settings: 0
      }
    },
    {
      name: "Office Administrator",
      isOfficeBearer: 0,
      perms: {
        view_members: 1,
        manage_members: 1,
        generate_bills: 1,
        verify_payments: 0,
        manage_expenses: 0,
        view_financial_reports: 0,
        manage_complaints: 1,
        manage_events: 1,
        manage_staff: 1,
        change_society_settings: 0
      }
    }
  ];
  for (const r of defaultRoles) {
    let roleRow = db.prepare("SELECT id FROM staff_roles WHERE society_id = ? AND name = ?").get(societyId, r.name);
    if (!roleRow) {
      const roleId = uuid();
      db.prepare(`
        INSERT INTO staff_roles (id, society_id, name, is_office_bearer, is_system_default)
        VALUES (?, ?, ?, ?, 1)
      `).run(roleId, societyId, r.name, r.isOfficeBearer);
      db.prepare(`
        INSERT INTO role_permissions (
          id, society_id, role_id, view_members, manage_members, generate_bills, verify_payments,
          manage_expenses, view_financial_reports, manage_complaints, manage_events, manage_staff, change_society_settings
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        uuid(),
        societyId,
        roleId,
        r.perms.view_members,
        r.perms.manage_members,
        r.perms.generate_bills,
        r.perms.verify_payments,
        r.perms.manage_expenses,
        r.perms.view_financial_reports,
        r.perms.manage_complaints,
        r.perms.manage_events,
        r.perms.manage_staff,
        r.perms.change_society_settings
      );
    }
  }
}
function logAudit(params) {
  db.prepare(`
    INSERT INTO audit_logs (id, society_id, actor_user_id, actor_role, action, entity_type, entity_id, details, ip_address)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    uuid(),
    params.societyId ?? null,
    params.actorUserId ?? null,
    params.actorRole,
    params.action,
    params.entityType,
    params.entityId ?? null,
    JSON.stringify(params.details ?? {}),
    params.ipAddress ?? null
  );
}
function sendNotification(params) {
  if (params.dedupKey) {
    const existing = db.prepare("SELECT id FROM notifications WHERE dedup_key = ?").get(params.dedupKey);
    if (existing) {
      return false;
    }
  }
  db.prepare(`
    INSERT INTO notifications (id, society_id, user_id, notification_type, title, message, channel, dedup_key)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    uuid(),
    params.societyId ?? null,
    params.userId ?? null,
    params.notificationType,
    params.title,
    params.message,
    params.channel ?? "IN_APP",
    params.dedupKey ?? null
  );
  return true;
}
function seedInitialDataIfEmpty() {
  const envRazorpayKeyId = process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || "";
  const existingPlatform = db.prepare("SELECT id, razorpay_key_id FROM platform_settings LIMIT 1").get();
  if (!existingPlatform) {
    db.prepare(`
      INSERT INTO platform_settings (
        id, platform_name, support_email, support_phone, default_trial_enabled, default_trial_days,
        default_grace_period_days, auto_approve_paid_societies, auto_approve_trial_societies, razorpay_key_id
      ) VALUES ('default', 'SocietyOS Enterprise SaaS', 'superadmin@societyos.com', '+91-98765-00001', 1, 14, 7, 1, 1, ?)
    `).run(envRazorpayKeyId);
  } else if (envRazorpayKeyId && (!existingPlatform.razorpay_key_id || existingPlatform.razorpay_key_id.startsWith("rzp_test_platform_demo_key"))) {
    db.prepare("UPDATE platform_settings SET razorpay_key_id = ? WHERE id = 'default'").run(envRazorpayKeyId);
  }
  const planCount = db.prepare("SELECT COUNT(*) as cnt FROM subscription_plans").get().cnt;
  const planMonthlyId = "plan-monthly-standard";
  const planQuarterlyId = "plan-quarterly-growth";
  const planAnnualId = "plan-annual-enterprise";
  if (planCount === 0) {
    db.prepare(`
      INSERT INTO subscription_plans (
        id, code, name, description, billing_period, duration_days, price_amount, tax_percent,
        max_households, trial_enabled, trial_days, grace_period_days, auto_approve_after_payment, is_active
      ) VALUES
      (?, 'MONTHLY_STARTER', 'Starter Monthly Plan', 'Ideal for small societies and apartments up to 100 flats.', 'MONTHLY', 30, 1999, 18, 100, 1, 14, 7, 1, 1),
      (?, 'QUARTERLY_GROWTH', 'Growth Quarterly Plan', 'Complete billing, accounting, and staff portal for up to 300 flats.', 'QUARTERLY', 90, 5499, 18, 300, 1, 14, 7, 1, 1),
      (?, 'ANNUAL_ENTERPRISE', 'Enterprise Annual RWA Suite', 'Full multi-block suite with unlimited reports, priority support & up to 1000 flats.', 'ANNUAL', 365, 19999, 18, 1000, 1, 14, 10, 1, 1)
    `).run(planMonthlyId, planQuarterlyId, planAnnualId);
  }
  const superAdminExists = db.prepare("SELECT id FROM users WHERE role = 'SUPER_ADMIN' LIMIT 1").get();
  if (!superAdminExists) {
    const superAdminId = "user-super-admin";
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES (?, 'superadmin@societyos.com', '+91-98765-00001', ?, 'SUPER_ADMIN', NULL, 1, 1)
    `).run(superAdminId, hashPassword("SuperAdmin@123"));
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language)
      VALUES (?, ?, NULL, 'Platform Owner (Super Admin)', 'en')
    `).run(uuid(), superAdminId);
  }
  const societyCount = db.prepare("SELECT COUNT(*) as cnt FROM societies").get().cnt;
  if (societyCount === 0) {
    const soc1Id = "soc-green-valley";
    const soc2Id = "soc-royal-palms";
    const admin1Id = "user-admin-green-valley";
    const admin2Id = "user-admin-royal-palms";
    db.prepare(`
      INSERT INTO societies (
        id, name, slug, enrollment_code, address, city, state, pincode,
        contact_email, contact_phone, registration_number, subscription_plan_id,
        subscription_status, approval_status, account_status, payment_status,
        subscription_starts_at, subscription_ends_at, is_demo
      ) VALUES (
        ?, 'Green Valley Residency (Demo)', 'green-valley-residency', 'GVR-2026',
        'Sector 68, Airport Road, Mohali', 'Mohali', 'Punjab', '160062',
        'admin@greenvalley.com', '+91-98150-11223', 'PB-MOH-RWA-2021-089', ?,
        'ACTIVE', 'APPROVED', 'ACTIVE', 'PAID',
        datetime('now', '-30 days'), datetime('now', '+335 days'), 1
      )
    `).run(soc1Id, planAnnualId);
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES (?, 'admin@greenvalley.com', '+91-98150-11223', ?, 'SOCIETY_ADMIN', ?, 1, 1)
    `).run(admin1Id, hashPassword("Admin@123"), soc1Id);
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language)
      VALUES (?, ?, ?, 'Harpreet Singh Gill (RWA President)', 'en')
    `).run(uuid(), admin1Id, soc1Id);
    db.prepare("UPDATE societies SET admin_user_id = ? WHERE id = ?").run(admin1Id, soc1Id);
    const sub1Id = uuid();
    db.prepare(`
      INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial)
      VALUES (?, ?, ?, 'ACTIVE', datetime('now', '-30 days'), datetime('now', '+335 days'), 0)
    `).run(sub1Id, soc1Id, planAnnualId);
    db.prepare(`
      INSERT INTO subscription_payments (
        id, society_id, subscription_id, plan_id, invoice_number, amount, tax_amount, total_amount,
        payment_gateway, gateway_order_id, gateway_payment_id, verified_by_webhook, status, paid_at
      ) VALUES (?, ?, ?, ?, 'SUB-INV-2026-0001', 19999, 3599.82, 23598.82, 'RAZORPAY', 'order_demo_gvr_01', 'pay_demo_gvr_01', 1, 'PAID', datetime('now', '-30 days'))
    `).run(uuid(), soc1Id, sub1Id, planAnnualId);
    bootstrapSocietyDefaults(soc1Id, "Green Valley Residency");
    db.prepare(`
      INSERT INTO societies (
        id, name, slug, enrollment_code, address, city, state, pincode,
        contact_email, contact_phone, registration_number, subscription_plan_id,
        subscription_status, approval_status, account_status, payment_status,
        trial_starts_at, trial_ends_at, is_demo
      ) VALUES (
        ?, 'Royal Palms Enclave (Demo)', 'royal-palms-enclave', 'RPE-2026',
        'Pakhowal Road, Civil Lines, Ludhiana', 'Ludhiana', 'Punjab', '141001',
        'admin@royalpalms.com', '+91-98720-44556', 'PB-LDH-RWA-2024-112', ?,
        'TRIAL', 'APPROVED', 'ACTIVE', 'TRIAL',
        datetime('now', '-3 days'), datetime('now', '+11 days'), 1
      )
    `).run(soc2Id, planQuarterlyId);
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES (?, 'admin@royalpalms.com', '+91-98720-44556', ?, 'SOCIETY_ADMIN', ?, 1, 1)
    `).run(admin2Id, hashPassword("Admin@123"), soc2Id);
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language)
      VALUES (?, ?, ?, 'Gur\u092A\u094D\u0930\u0940\u0924 Kaur Sandhu (Secretary)', 'en')
    `).run(uuid(), admin2Id, soc2Id);
    db.prepare("UPDATE societies SET admin_user_id = ? WHERE id = ?").run(admin2Id, soc2Id);
    const sub2Id = uuid();
    db.prepare(`
      INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial)
      VALUES (?, ?, ?, 'TRIAL', datetime('now', '-3 days'), datetime('now', '+11 days'), 1)
    `).run(sub2Id, soc2Id, planQuarterlyId);
    bootstrapSocietyDefaults(soc2Id, "Royal Palms Enclave");
    const blockA = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = 'Block A'").get(soc1Id);
    const blockB = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = 'Block B'").get(soc1Id);
    const hh1Id = "hh-gvr-a101";
    const hh2Id = "hh-gvr-a102";
    const hh3Id = "hh-gvr-b201";
    const mem1UserId = "user-member-a101";
    const mem2UserId = "user-member-a102";
    const mem3UserId = "user-member-b201";
    const mem1Id = "member-gvr-a101";
    const mem2Id = "member-gvr-a102";
    const mem3Id = "member-gvr-b201";
    db.prepare(`
      INSERT INTO households (id, society_id, block_id, block_name, floor_number, flat_number, normalized_flat_number, occupancy_type, area_sqft, status, primary_member_id)
      VALUES
      (?, ?, ?, 'Block A', '1', 'A-101', ?, 'OWNER', 1450, 'ACTIVE', ?),
      (?, ?, ?, 'Block A', '1', 'A-102', ?, 'TENANT', 1450, 'ACTIVE', ?),
      (?, ?, ?, 'Block B', '2', 'B-201', ?, 'OWNER', 1650, 'ACTIVE', ?)
    `).run(
      hh1Id,
      soc1Id,
      blockA.id,
      normalizeFlatNumber("A-101"),
      mem1Id,
      hh2Id,
      soc1Id,
      blockA.id,
      normalizeFlatNumber("A-102"),
      mem2Id,
      hh3Id,
      soc1Id,
      blockB.id,
      normalizeFlatNumber("B-201"),
      mem3Id
    );
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES
      (?, 'resident@greenvalley.com', '+91-98151-10101', ?, 'MEMBER', ?, 1, 1),
      (?, 'simran@greenvalley.com', '+91-98151-10102', ?, 'MEMBER', ?, 1, 1),
      (?, 'rajesh@greenvalley.com', '+91-98151-20101', ?, 'MEMBER', ?, 1, 1)
    `).run(
      mem1UserId,
      hashPassword("Member@123"),
      soc1Id,
      mem2UserId,
      hashPassword("Member@123"),
      soc1Id,
      mem3UserId,
      hashPassword("Member@123"),
      soc1Id
    );
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language, address, emergency_contact_name, emergency_contact_phone)
      VALUES
      (?, ?, ?, 'Manpreet Singh Brar', 'en', 'Flat A-101, Block A, Green Valley Residency', 'Kuldeep Kaur', '+91-98151-99991'),
      (?, ?, ?, 'Simranjit Kaur Dhillon', 'pa', 'Flat A-102, Block A, Green Valley Residency', 'Navjot Singh', '+91-98151-99992'),
      (?, ?, ?, 'Rajesh Kumar Sharma', 'en', 'Flat B-201, Block B, Green Valley Residency', 'Anita Sharma', '+91-98151-99993')
    `).run(uuid(), mem1UserId, soc1Id, uuid(), mem2UserId, soc1Id, uuid(), mem3UserId, soc1Id);
    db.prepare(`
      INSERT INTO society_members (
        id, society_id, household_id, user_id, full_name, email, phone,
        relationship_to_primary, is_primary_member, ownership_type, emergency_contact, approval_status, account_status
      ) VALUES
      (?, ?, ?, ?, 'Manpreet Singh Brar', 'resident@greenvalley.com', '+91-98151-10101', 'PRIMARY', 1, 'OWNER', 'Kuldeep Kaur (+91-98151-99991)', 'APPROVED', 'ACTIVE'),
      (?, ?, ?, ?, 'Simranjit Kaur Dhillon', 'simran@greenvalley.com', '+91-98151-10102', 'PRIMARY', 1, 'TENANT', 'Navjot Singh (+91-98151-99992)', 'APPROVED', 'ACTIVE'),
      (?, ?, ?, ?, 'Rajesh Kumar Sharma', 'rajesh@greenvalley.com', '+91-98151-20101', 'PRIMARY', 1, 'OWNER', 'Anita Sharma (+91-98151-99993)', 'APPROVED', 'ACTIVE')
    `).run(
      mem1Id,
      soc1Id,
      hh1Id,
      mem1UserId,
      mem2Id,
      soc1Id,
      hh2Id,
      mem2UserId,
      mem3Id,
      soc1Id,
      hh3Id,
      mem3UserId
    );
    const soc2BlockA = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = 'Block A'").get(soc2Id);
    const hhSoc2Id = "hh-rpe-a101";
    const memSoc2UserId = "user-member-rpe-a101";
    const memSoc2Id = "member-rpe-a101";
    db.prepare(`
      INSERT INTO households (id, society_id, block_id, block_name, floor_number, flat_number, normalized_flat_number, occupancy_type, area_sqft, status, primary_member_id)
      VALUES (?, ?, ?, 'Block A', '1', 'A-101', ?, 'OWNER', 1800, 'ACTIVE', ?)
    `).run(hhSoc2Id, soc2Id, soc2BlockA.id, normalizeFlatNumber("A-101"), memSoc2Id);
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES (?, 'resident@royalpalms.com', '+91-98720-10101', ?, 'MEMBER', ?, 1, 1)
    `).run(memSoc2UserId, hashPassword("Member@123"), soc2Id);
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language, address)
      VALUES (?, ?, ?, 'Amanpreet Singh Grewal', 'en', 'Flat A-101, Royal Palms Enclave')
    `).run(uuid(), memSoc2UserId, soc2Id);
    db.prepare(`
      INSERT INTO society_members (
        id, society_id, household_id, user_id, full_name, email, phone,
        relationship_to_primary, is_primary_member, ownership_type, approval_status, account_status
      ) VALUES (?, ?, ?, ?, 'Amanpreet Singh Grewal', 'resident@royalpalms.com', '+91-98720-10101', 'PRIMARY', 1, 'OWNER', 'APPROVED', 'ACTIVE')
    `).run(memSoc2Id, soc2Id, hhSoc2Id, memSoc2UserId);
    const cashierRole = db.prepare("SELECT id FROM staff_roles WHERE society_id = ? AND name = 'Cashier'").get(soc1Id);
    const guardRole = db.prepare("SELECT id FROM staff_roles WHERE society_id = ? AND name = 'Security Guard'").get(soc1Id);
    const maintRole = db.prepare("SELECT id FROM staff_roles WHERE society_id = ? AND name = 'Maintenance Staff'").get(soc1Id);
    const cashierUserId = "user-staff-cashier-gvr";
    db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
      VALUES (?, 'cashier@greenvalley.com', '+91-98152-33445', ?, 'STAFF', ?, 1, 1)
    `).run(cashierUserId, hashPassword("Staff@123"), soc1Id);
    db.prepare(`
      INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language)
      VALUES (?, ?, ?, 'Balwinder Singh (Cashier)', 'en')
    `).run(uuid(), cashierUserId, soc1Id);
    const staffCashierId = "staff-gvr-cashier";
    const staffGuardId = "staff-gvr-guard";
    const staffMaintId = "staff-gvr-plumber";
    db.prepare(`
      INSERT INTO staff (
        id, society_id, user_id, role_id, full_name, phone, email, address, designation,
        joining_date, wage_type, salary_amount, employment_status, is_on_duty, duty_schedule, assigned_duties, show_contact_to_members
      ) VALUES
      (?, ?, ?, ?, 'Balwinder Singh', '+91-98152-33445', 'cashier@greenvalley.com', 'Phase 7, Mohali', 'Society Cashier', '2024-01-15', 'MONTHLY', 22000, 'ACTIVE', 1, 'Mon-Sat 09:00 AM - 05:00 PM', 'Payment verification, receipt generation & collection desk', 1),
      (?, ?, NULL, ?, 'Sukhdev Singh', '+91-98152-77889', 'sukhdev.guard@greenvalley.com', 'Sohana, Mohali', 'Head Security Guard', '2023-06-01', 'MONTHLY', 18500, 'ACTIVE', 1, 'Daily 08:00 AM - 08:00 PM (Gate 1)', 'Main Gate Entry/Exit & Visitor Verification', 1),
      (?, ?, NULL, ?, 'Rameshwar Prasad', '+91-98152-99001', NULL, 'Kharar, Mohali', 'Plumber & Electrician', '2024-03-10', 'MONTHLY', 19500, 'ACTIVE', 1, 'Daily 09:00 AM - 06:00 PM', 'Water supply, electrical panel & pump room maintenance', 1)
    `).run(
      staffCashierId,
      soc1Id,
      cashierUserId,
      cashierRole.id,
      staffGuardId,
      soc1Id,
      guardRole.id,
      staffMaintId,
      soc1Id,
      maintRole.id
    );
    const maintCat = db.prepare("SELECT id, name FROM charge_categories WHERE society_id = ? AND code = 'MONTHLY_MAINTENANCE'").get(soc1Id);
    const waterCat = db.prepare("SELECT id, name FROM charge_categories WHERE society_id = ? AND code = 'WATER_CHARGES'").get(soc1Id);
    const secCat = db.prepare("SELECT id, name FROM charge_categories WHERE society_id = ? AND code = 'SECURITY_CHARGES'").get(soc1Id);
    const bill1Id = "bill-gvr-2026-10-a101";
    const bill2Id = "bill-gvr-2026-10-a102";
    const bill3Id = "bill-gvr-2026-10-b201";
    const bill0Id = "bill-gvr-2026-09-a101";
    db.prepare(`
      INSERT INTO member_bills (
        id, society_id, household_id, member_id, bill_number, billing_month, billing_year,
        bill_type, status, subtotal_amount, previous_balance, penalty_amount, credit_amount,
        total_amount, paid_amount, balance_amount, due_date, issued_at, created_by
      ) VALUES
      (?, ?, ?, ?, 'GVR-202609-A101', 9, 2026, 'REGULAR', 'PAID', 3400, 0, 0, 0, 3400, 3400, 0, '2026-09-10', datetime('now', '-40 days'), ?),
      (?, ?, ?, ?, 'GVR-202610-A101', 10, 2026, 'REGULAR', 'UNPAID', 3400, 0, 0, 0, 3400, 0, 3400, '2026-10-25', datetime('now', '-5 days'), ?),
      (?, ?, ?, ?, 'GVR-202610-A102', 10, 2026, 'REGULAR', 'PENDING_VERIFICATION', 3400, 0, 0, 0, 3400, 0, 3400, '2026-10-25', datetime('now', '-5 days'), ?),
      (?, ?, ?, ?, 'GVR-202610-B201', 10, 2026, 'REGULAR', 'PAID', 3400, 0, 0, 0, 3400, 3400, 0, '2026-10-25', datetime('now', '-5 days'), ?)
    `).run(
      bill0Id,
      soc1Id,
      hh1Id,
      mem1Id,
      admin1Id,
      bill1Id,
      soc1Id,
      hh1Id,
      mem1Id,
      admin1Id,
      bill2Id,
      soc1Id,
      hh2Id,
      mem2Id,
      admin1Id,
      bill3Id,
      soc1Id,
      hh3Id,
      mem3Id,
      admin1Id
    );
    const insertItem = db.prepare(`
      INSERT INTO bill_items (id, society_id, bill_id, household_id, charge_category_id, category_name, billing_month, billing_year, description, amount, is_adjustment)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `);
    for (const [bId, hhId, m, y] of [
      [bill0Id, hh1Id, 9, 2026],
      [bill1Id, hh1Id, 10, 2026],
      [bill2Id, hh2Id, 10, 2026],
      [bill3Id, hh3Id, 10, 2026]
    ]) {
      insertItem.run(uuid(), soc1Id, bId, hhId, maintCat.id, maintCat.name, m, y, "Monthly Maintenance Charges", 2500);
      insertItem.run(uuid(), soc1Id, bId, hhId, waterCat.id, waterCat.name, m, y, "Water Supply Charges", 400);
      insertItem.run(uuid(), soc1Id, bId, hhId, secCat.id, secCat.name, m, y, "24x7 Security Charges", 500);
    }
    const pay0Id = "pay-gvr-sep-a101";
    const pay2Id = "pay-gvr-oct-a102-pending";
    const pay3Id = "pay-gvr-oct-b201-confirmed";
    db.prepare(`
      INSERT INTO payments (
        id, society_id, household_id, member_id, payment_method, amount, payment_date,
        reference_number, status, verification_notes, verified_by, verified_at, ledger_posted
      ) VALUES
      (?, ?, ?, ?, 'UPI', 3400, '2026-09-08', 'UPI-425188992011', 'CONFIRMED', 'Verified against HDFC bank statement', ?, datetime('now', '-38 days'), 1),
      (?, ?, ?, ?, 'GPAY_UPI', 3400, '2026-10-16', 'GPAY-628910443120', 'PENDING_VERIFICATION', NULL, NULL, NULL, 0),
      (?, ?, ?, ?, 'RAZORPAY', 3400, '2026-10-14', 'pay_OctB201Rzp991', 'CONFIRMED', 'Verified via Razorpay settlement', ?, datetime('now', '-3 days'), 1)
    `).run(
      pay0Id,
      soc1Id,
      hh1Id,
      mem1Id,
      admin1Id,
      pay2Id,
      soc1Id,
      hh2Id,
      mem2Id,
      pay3Id,
      soc1Id,
      hh3Id,
      mem3Id,
      admin1Id
    );
    db.prepare(`
      INSERT INTO payment_allocations (id, society_id, payment_id, bill_id, allocated_amount)
      VALUES
      (?, ?, ?, ?, 3400),
      (?, ?, ?, ?, 3400),
      (?, ?, ?, ?, 3400)
    `).run(
      uuid(),
      soc1Id,
      pay0Id,
      bill0Id,
      uuid(),
      soc1Id,
      pay2Id,
      bill2Id,
      uuid(),
      soc1Id,
      pay3Id,
      bill3Id
    );
    db.prepare(`
      INSERT INTO payment_receipts (id, society_id, payment_id, receipt_number, issued_to_name, flat_number, amount, payment_method, reference_number, issued_by)
      VALUES
      (?, ?, ?, 'RCP-GVR-2026-0001', 'Manpreet Singh Brar', 'A-101', 3400, 'UPI', 'UPI-425188992011', ?),
      (?, ?, ?, 'RCP-GVR-2026-0002', 'Rajesh Kumar Sharma', 'B-201', 3400, 'RAZORPAY', 'pay_OctB201Rzp991', ?)
    `).run(
      uuid(),
      soc1Id,
      pay0Id,
      admin1Id,
      uuid(),
      soc1Id,
      pay3Id,
      admin1Id
    );
    db.prepare(`
      INSERT INTO ledger_entries (
        id, society_id, transaction_code, entry_date, entry_type, account_type, category,
        description, amount, direction, reference_type, reference_id, household_id, flat_number, member_id, payment_method, created_by
      ) VALUES
      (?, ?, 'TXN-GVR-2026-0001', '2026-09-08', 'INCOME', 'BANK', 'Maintenance Collection', 'Bill payment RCP-GVR-2026-0001 (Flat A-101)', 3400, 'CREDIT', 'PAYMENT', ?, ?, 'A-101', ?, 'UPI', ?),
      (?, ?, 'TXN-GVR-2026-0002', '2026-10-14', 'INCOME', 'BANK', 'Maintenance Collection', 'Bill payment RCP-GVR-2026-0002 (Flat B-201)', 3400, 'CREDIT', 'PAYMENT', ?, ?, 'B-201', ?, 'RAZORPAY', ?)
    `).run(
      uuid(),
      soc1Id,
      pay0Id,
      hh1Id,
      mem1Id,
      admin1Id,
      uuid(),
      soc1Id,
      pay3Id,
      hh3Id,
      mem3Id,
      admin1Id
    );
    const expCatSec = db.prepare("SELECT id, name FROM expense_categories WHERE society_id = ? AND name = 'Security Services & Guards'").get(soc1Id);
    const exp1Id = "exp-gvr-oct-01";
    db.prepare(`
      INSERT INTO expenses (
        id, society_id, expense_category_id, category_name, description, amount, expense_date,
        payment_method, account_type, vendor_name, status, entered_by, approved_by
      ) VALUES (?, ?, ?, ?, 'Main Gate Security Guard Duty Settlement (First Half Oct)', 1800, '2026-10-15', 'BANK_TRANSFER', 'BANK', 'ShieldForce Security Pvt Ltd', 'APPROVED', ?, ?)
    `).run(exp1Id, soc1Id, expCatSec.id, expCatSec.name, admin1Id, admin1Id);
    db.prepare(`
      INSERT INTO ledger_entries (
        id, society_id, transaction_code, entry_date, entry_type, account_type, category,
        description, amount, direction, reference_type, reference_id, payment_method, created_by
      ) VALUES (?, ?, 'TXN-GVR-2026-0003', '2026-10-15', 'EXPENSE', 'BANK', ?, 'Main Gate Security Guard Duty Settlement (First Half Oct)', 1800, 'DEBIT', 'EXPENSE', ?, 'BANK_TRANSFER', ?)
    `).run(uuid(), soc1Id, expCatSec.name, exp1Id, admin1Id);
    db.prepare("UPDATE financial_accounts SET opening_balance = 25000, current_balance = 30000 WHERE society_id = ? AND account_type = 'BANK'").run(soc1Id);
    db.prepare("UPDATE financial_accounts SET opening_balance = 5000, current_balance = 5000 WHERE society_id = ? AND account_type = 'CASH'").run(soc1Id);
    const comp1Id = "comp-gvr-001";
    db.prepare(`
      INSERT INTO complaints (
        id, society_id, complaint_number, household_id, member_id, flat_number,
        title, category, description, priority, status, assigned_staff_id
      ) VALUES (?, ?, 'CMP-GVR-1001', ?, ?, 'A-101', 'Low water pressure in Block A morning supply', 'Water supply', 'Water pressure on 1st floor has been low between 7 AM and 8:30 AM for the past two days.', 'HIGH', 'IN_PROGRESS', ?)
    `).run(comp1Id, soc1Id, hh1Id, mem1Id, staffMaintId);
    db.prepare(`
      INSERT INTO complaint_comments (id, society_id, complaint_id, author_user_id, author_name, comment_text, is_internal)
      VALUES (?, ?, ?, ?, 'Harpreet Singh Gill (RWA President)', 'Assigned Plumber Rameshwar Prasad to inspect Block A overhead booster valve today.', 0)
    `).run(uuid(), soc1Id, comp1Id, admin1Id);
    db.prepare(`
      INSERT INTO suggestions (id, society_id, household_id, member_id, flat_number, title, description, status, admin_response, responded_by, responded_at)
      VALUES (?, ?, ?, ?, 'A-101', 'Install EV Charging Point in Visitor Parking Zone', 'Many residents are buying electric two-wheelers and cars. A shared metered EV charging bay would benefit everyone.', 'ACKNOWLEDGED', 'Great suggestion! Added to the agenda for the upcoming General Body Meeting.', ?, datetime('now', '-2 days'))
    `).run(uuid(), soc1Id, hh1Id, mem1Id, admin1Id);
    db.prepare(`
      INSERT INTO society_events (id, society_id, event_type, title, description, event_date, event_time, venue, publication_status, created_by)
      VALUES
      (?, ?, 'MEETING', 'Annual General Body Meeting (AGM) 2026', 'Review of annual society accounts, security upgrade approval, and solar rooftop proposal.', '2026-10-25', '11:00 AM', 'Society Community Hall, Block A', 'PUBLISHED', ?),
      (?, ?, 'FESTIVAL', 'Grand Diwali & Bandi Chhor Divas Mela', 'Cultural evening, langar, lights competition, and community dinner for all residents.', '2026-11-01', '06:30 PM', 'Central Lawn & Amphitheatre', 'PUBLISHED', ?)
    `).run(uuid(), soc1Id, admin1Id, uuid(), soc1Id, admin1Id);
    db.prepare(`
      INSERT INTO announcements (id, society_id, category, title, content, publication_status, send_email, created_by)
      VALUES
      (?, ?, 'WATER_INTERRUPTION', 'Overhead Water Tank Cleaning Schedule \u2014 Block A & B', 'Overhead water tanks will be hygienically cleaned on Sunday from 10:00 AM to 01:00 PM. Please store water accordingly.', 'PUBLISHED', 1, ?),
      (?, ?, 'SECURITY_ALERT', 'Mandatory Sticker Verification for Resident Vehicles', 'All residents are requested to collect their 2026 RFID vehicle stickers from the RWA office between 9 AM and 5 PM.', 'PUBLISHED', 1, ?)
    `).run(uuid(), soc1Id, admin1Id, uuid(), soc1Id, admin1Id);
  }
  sendNotification({
    societyId: "soc-royal-palms",
    userId: "user-admin-royal-palms",
    notificationType: "SUBSCRIPTION_PAYMENT_DUE",
    title: "Subscription Payment Due for Approval \u2014 Growth Quarterly Plan (\u20B96,488.82)",
    message: "Super Admin Notice: Your society free trial is ending in 11 days. Please complete your subscription payment of \u20B96,488.82 (\u20B95,499 + 18% GST) for continued active approval and uninterrupted portal access.",
    channel: "IN_APP",
    dedupKey: "seed:sub-due:soc-royal-palms"
  });
  sendNotification({
    societyId: "soc-green-valley",
    userId: "user-admin-green-valley",
    notificationType: "SUBSCRIPTION_PAYMENT_CONFIRMED",
    title: "Enterprise Annual Subscription Active & Verified",
    message: "Super Admin Notice: Your Enterprise Annual RWA Suite subscription is active and fully approved. Next renewal is scheduled in 335 days.",
    channel: "IN_APP",
    dedupKey: "seed:sub-active:soc-green-valley"
  });
}

// server/mysql.ts
import fs3 from "node:fs";
import path3 from "node:path";
var MYSQL_TABLES = [
  "platform_settings",
  "users",
  "user_profiles",
  "subscription_plans",
  "societies",
  "society_settings",
  "society_subscriptions",
  "subscription_payments",
  "apartment_blocks",
  "households",
  "society_members",
  "member_invitations",
  "charge_categories",
  "member_bills",
  "bill_items",
  "bill_adjustments",
  "payments",
  "payment_allocations",
  "payment_receipts",
  "staff_roles",
  "role_permissions",
  "staff",
  "staff_documents",
  "staff_duty_records",
  "attendance_records",
  "complaints",
  "complaint_attachments",
  "complaint_comments",
  "suggestions",
  "society_events",
  "announcements",
  "financial_accounts",
  "expense_categories",
  "expenses",
  "ledger_entries",
  "notifications",
  "audit_logs"
];
var mysqlPool = null;
var mysqlConnected = false;
var lastSyncTime = null;
var lastMysqlError = null;
var syncInProgress = false;
function getMysqlConfig() {
  return {
    driver: (process.env.DB_DRIVER || (process.env.MYSQL_DATABASE ? "mysql" : "sqlite")).toLowerCase(),
    host: process.env.MYSQL_HOST || "127.0.0.1",
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || "",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || ""
  };
}
function isMysqlEnabled() {
  const cfg = getMysqlConfig();
  return cfg.driver === "mysql" && Boolean(cfg.database && cfg.user);
}
function getDatabaseHealth() {
  const cfg = getMysqlConfig();
  return {
    driver: isMysqlEnabled() ? "mysql" : "sqlite",
    mysqlConfigured: isMysqlEnabled(),
    mysqlConnected,
    mysqlHost: isMysqlEnabled() ? cfg.host : null,
    mysqlDatabase: isMysqlEnabled() ? cfg.database : null,
    lastSyncedAt: lastSyncTime,
    lastError: lastMysqlError
  };
}
async function initMysqlBackend() {
  if (!isMysqlEnabled()) {
    return;
  }
  const cfg = getMysqlConfig();
  try {
    const mysqlModuleName = "mysql2/promise";
    const mysql = await import(
      /* @vite-ignore */
      mysqlModuleName
    );
    mysqlPool = mysql.createPool({
      host: cfg.host,
      port: cfg.port,
      user: cfg.user,
      password: cfg.password,
      database: cfg.database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      multipleStatements: true,
      charset: "utf8mb4"
    });
    const conn = await mysqlPool.getConnection();
    try {
      await conn.ping();
      mysqlConnected = true;
      lastMysqlError = null;
      console.log(`[MySQL Backend] Connected to Hostinger MySQL database "${cfg.database}" at ${cfg.host}:${cfg.port}`);
      const [tables] = await conn.query("SHOW TABLES LIKE 'users'");
      if (!Array.isArray(tables) || tables.length === 0) {
        const schemaPath = path3.join(process.cwd(), "database", "mysql_schema.sql");
        if (fs3.existsSync(schemaPath)) {
          console.log("[MySQL Backend] Initializing MySQL schema from database/mysql_schema.sql...");
          const sqlContent = fs3.readFileSync(schemaPath, "utf8");
          await conn.query(sqlContent);
        }
      }
      const [userCountRows] = await conn.query("SELECT COUNT(*) as cnt FROM `users`");
      const mysqlUserCount = Number(userCountRows?.[0]?.cnt || 0);
      if (mysqlUserCount > 0) {
        await pullAllTablesFromMysql(conn);
      } else {
        await pushAllTablesToMysql(conn);
      }
      lastSyncTime = (/* @__PURE__ */ new Date()).toISOString();
    } finally {
      conn.release();
    }
  } catch (err) {
    mysqlConnected = false;
    lastMysqlError = err?.message || String(err);
    console.error("[MySQL Backend Warning] Could not connect to MySQL, continuing with local embedded DB fallback:", lastMysqlError);
  }
}
async function pullAllTablesFromMysql(conn) {
  db.exec("PRAGMA foreign_keys = OFF;");
  db.exec("BEGIN IMMEDIATE");
  try {
    for (const table of MYSQL_TABLES) {
      const [rows] = await conn.query(`SELECT * FROM \`${table}\``);
      if (!Array.isArray(rows)) continue;
      db.prepare(`DELETE FROM ${table}`).run();
      if (rows.length === 0) continue;
      const cols = Object.keys(rows[0]);
      const placeholders = cols.map(() => "?").join(", ");
      const colList = cols.join(", ");
      const insertStmt = db.prepare(`INSERT OR REPLACE INTO ${table} (${colList}) VALUES (${placeholders})`);
      for (const row of rows) {
        const vals = cols.map((c) => {
          const v = row[c];
          if (v instanceof Date) return v.toISOString();
          return v ?? null;
        });
        insertStmt.run(...vals);
      }
    }
    db.exec("COMMIT");
    console.log("[MySQL Backend] Loaded all records from Hostinger MySQL into runtime engine.");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  } finally {
    db.exec("PRAGMA foreign_keys = ON;");
  }
}
async function pushAllTablesToMysql(conn) {
  await conn.query("SET FOREIGN_KEY_CHECKS = 0;");
  try {
    for (const table of MYSQL_TABLES) {
      const rows = db.prepare(`SELECT * FROM ${table}`).all();
      if (rows.length === 0) continue;
      const cols = Object.keys(rows[0]);
      const colNames = cols.map((c) => `\`${c}\``).join(", ");
      const placeholders = cols.map(() => "?").join(", ");
      const updateCols = cols.filter((c) => c !== "id").map((c) => `\`${c}\` = VALUES(\`${c}\`)`).join(", ");
      const sql = `INSERT INTO \`${table}\` (${colNames}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${updateCols}`;
      for (const row of rows) {
        const vals = cols.map((c) => row[c] ?? null);
        await conn.query(sql, vals);
      }
    }
    lastSyncTime = (/* @__PURE__ */ new Date()).toISOString();
  } finally {
    await conn.query("SET FOREIGN_KEY_CHECKS = 1;");
  }
}
async function syncToMysqlAfterWrite() {
  if (!isMysqlEnabled() || !mysqlPool || !mysqlConnected || syncInProgress) {
    return;
  }
  syncInProgress = true;
  try {
    const conn = await mysqlPool.getConnection();
    try {
      await pushAllTablesToMysql(conn);
    } finally {
      conn.release();
    }
  } catch (err) {
    lastMysqlError = err?.message || String(err);
    console.error("[MySQL Sync Error]", lastMysqlError);
  } finally {
    syncInProgress = false;
  }
}

// server/routes.ts
var import_razorpay = __toESM(require_razorpay(), 1);
import fs4 from "node:fs";
import path4 from "node:path";
function resolveRazorpayCredentials(societyId) {
  if (societyId) {
    const socSettings = db.prepare("SELECT razorpay_key_id, razorpay_key_secret_encrypted FROM society_settings WHERE society_id = ?").get(societyId);
    if (socSettings?.razorpay_key_id && socSettings?.razorpay_key_secret_encrypted) {
      const secret = String(socSettings.razorpay_key_secret_encrypted).replace(/^enc_/, "");
      return {
        keyId: String(socSettings.razorpay_key_id).trim(),
        keySecret: secret.trim()
      };
    }
  }
  const platform = db.prepare("SELECT razorpay_key_id, razorpay_key_secret_encrypted FROM platform_settings LIMIT 1").get();
  const envKeyId = getRazorpayKeyId();
  const envKeySecret = getRazorpayKeySecret();
  const dbSecret = platform?.razorpay_key_secret_encrypted ? String(platform.razorpay_key_secret_encrypted).replace(/^enc_/, "").trim() : "";
  const rawDbKeyId = platform?.razorpay_key_id ? String(platform.razorpay_key_id).replace("rzp_test_platform_demo_key", "").trim() : "";
  if (rawDbKeyId && dbSecret) {
    return {
      keyId: rawDbKeyId,
      keySecret: dbSecret
    };
  }
  return {
    keyId: envKeyId || rawDbKeyId,
    keySecret: envKeySecret || dbSecret
  };
}
function isValid10DigitPhone(phone) {
  if (!phone) return false;
  const digits = String(phone).replace(/\D/g, "");
  const tenDigits = digits.length === 12 && digits.startsWith("91") ? digits.slice(2) : digits;
  return /^[6-9]\d{9}$/.test(tenDigits);
}
function sendJson(res, status, data) {
  const payload = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(payload);
}
function getStaffPermissions(userId, societyId) {
  const row = db.prepare(`
    SELECT rp.*
    FROM staff s
    JOIN role_permissions rp ON rp.role_id = s.role_id
    WHERE s.user_id = ? AND s.society_id = ? AND s.employment_status = 'ACTIVE'
    LIMIT 1
  `).get(userId, societyId);
  if (!row) return null;
  return {
    view_members: Boolean(row.view_members),
    manage_members: Boolean(row.manage_members),
    generate_bills: Boolean(row.generate_bills),
    verify_payments: Boolean(row.verify_payments),
    manage_expenses: Boolean(row.manage_expenses),
    view_financial_reports: Boolean(row.view_financial_reports),
    manage_complaints: Boolean(row.manage_complaints),
    manage_events: Boolean(row.manage_events),
    manage_staff: Boolean(row.manage_staff),
    change_society_settings: Boolean(row.change_society_settings)
  };
}
function hasSocietyAccess(auth, requiredPermission) {
  if (!auth) {
    return { ok: false, status: 401, error: "Authentication required." };
  }
  if (auth.role === "SUPER_ADMIN") {
    return {
      ok: false,
      status: 403,
      error: "Super Admin panel is strictly separated from society administrator and member portals."
    };
  }
  if (!auth.societyId) {
    return { ok: false, status: 403, error: "No society associated with this account." };
  }
  const society = db.prepare("SELECT id, account_status, approval_status, subscription_status FROM societies WHERE id = ?").get(auth.societyId);
  if (!society) {
    return { ok: false, status: 404, error: "Society not found." };
  }
  if (society.account_status === "SUSPENDED" || society.account_status === "ARCHIVED") {
    return { ok: false, status: 403, error: `Society account is currently ${society.account_status}.` };
  }
  if (auth.role === "SOCIETY_ADMIN") {
    return { ok: true, status: 200, societyId: auth.societyId };
  }
  if (auth.role === "STAFF") {
    if (!requiredPermission) {
      return { ok: true, status: 200, societyId: auth.societyId };
    }
    const perms = getStaffPermissions(auth.userId, auth.societyId);
    if (!perms || !perms[requiredPermission]) {
      return {
        ok: false,
        status: 403,
        error: `Access denied: your staff role does not have the '${requiredPermission}' permission.`
      };
    }
    return { ok: true, status: 200, societyId: auth.societyId };
  }
  return { ok: false, status: 403, error: "Administrative or authorized staff role required." };
}
async function handleApiRequest(ctx) {
  const { res, url, method, body, auth, req } = ctx;
  const pathname = url.pathname;
  const clientIp = req.headers?.["x-forwarded-for"] || req.socket?.remoteAddress || "127.0.0.1";
  try {
    if (pathname === "/api/health" && method === "GET") {
      return sendJson(res, 200, {
        status: "ok",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        database: getDatabaseHealth()
      });
    }
    if (pathname === "/api/upload" && method === "POST") {
      const { fileName, mimeType, base64Data } = body;
      if (!fileName || !base64Data) {
        return sendJson(res, 400, { error: "fileName and base64Data are required." });
      }
      const allowedMime = ["image/png", "image/jpeg", "image/jpg", "image/webp", "image/svg+xml", "image/gif", "application/pdf"];
      const cleanMime = String(mimeType || "image/png").toLowerCase();
      if (!allowedMime.includes(cleanMime)) {
        return sendJson(res, 400, { error: "Unsupported file type. Allowed: PNG, JPG, WEBP, SVG, GIF, PDF." });
      }
      const rawBase64 = String(base64Data).replace(/^data:[^;]+;base64,/, "");
      const buffer = Buffer.from(rawBase64, "base64");
      if (buffer.byteLength > 10 * 1024 * 1024) {
        return sendJson(res, 400, { error: "File exceeds maximum allowed size of 10 MB." });
      }
      const ext = path4.extname(String(fileName)).replace(/[^a-zA-Z0-9.]/g, "") || (cleanMime === "image/svg+xml" ? ".svg" : ".png");
      const cleanBase = path4.basename(String(fileName), ext).replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 40) || "upload";
      const safeName = `${cleanBase}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext}`;
      const isServerless2 = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
      const uploadDir = isServerless2 ? path4.join("/tmp", "uploads") : path4.join(process.cwd(), "data", "uploads");
      fs4.mkdirSync(uploadDir, { recursive: true });
      fs4.writeFileSync(path4.join(uploadDir, safeName), buffer);
      return sendJson(res, 201, { url: `/uploads/${safeName}`, fileName: safeName, size: buffer.byteLength });
    }
    if (pathname === "/api/create-order" && method === "POST") {
      const rawAmount = body.amount;
      const amountPaise = Math.round(Number(rawAmount));
      const currency = String(body.currency || "INR").trim().toUpperCase();
      const receipt = String(body.receipt || `rcpt_${Date.now()}`).trim().slice(0, 40);
      if (rawAmount === void 0 || rawAmount === null || !Number.isFinite(amountPaise) || amountPaise < 100) {
        return sendJson(res, 400, {
          error: "Invalid amount: minimum order amount is 100 paise (\u20B91.00)."
        });
      }
      const usePlatformCreds = Boolean(body.isSubscription);
      const { keyId, keySecret } = resolveRazorpayCredentials(usePlatformCreds ? null : auth?.societyId);
      if (!keyId || !keySecret) {
        return sendJson(res, 401, {
          error: "Razorpay API credentials are not configured."
        });
      }
      let resolvedSubPaymentId = body.subscriptionPaymentId ? String(body.subscriptionPaymentId) : "";
      const targetSocietyId = String(body.societyId || auth?.societyId || "").trim();
      if (usePlatformCreds && !resolvedSubPaymentId && targetSocietyId) {
        const existingPending = db.prepare("SELECT id FROM subscription_payments WHERE society_id = ? AND status = 'CREATED' ORDER BY created_at DESC LIMIT 1").get(targetSocietyId);
        if (existingPending) {
          resolvedSubPaymentId = existingPending.id;
        } else {
          const socRow = db.prepare("SELECT * FROM societies WHERE id = ?").get(targetSocietyId);
          const targetPlanId = String(body.planId || socRow?.subscription_plan_id || "plan_growth");
          const planRow = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(targetPlanId);
          if (socRow && planRow) {
            const baseAmt = Number(planRow.price_amount || 0);
            const taxAmt = Number((baseAmt * Number(planRow.tax_percent || 18) / 100).toFixed(2));
            const totAmt = Number((baseAmt + taxAmt).toFixed(2));
            resolvedSubPaymentId = uuid();
            const invNo = `SUB-INV-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e4 + Math.random() * 9e4)}`;
            db.prepare(`
              INSERT INTO subscription_payments (
                id, society_id, plan_id, invoice_number, amount, tax_amount, total_amount,
                payment_gateway, gateway_order_id, status
              ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RAZORPAY', ?, 'CREATED')
            `).run(resolvedSubPaymentId, socRow.id, planRow.id, invNo, baseAmt, taxAmt, totAmt, `pending_${resolvedSubPaymentId.slice(0, 8)}`);
          }
        }
      }
      try {
        const razorpay = new import_razorpay.default({
          key_id: keyId,
          key_secret: keySecret
        });
        const order = await razorpay.orders.create({
          amount: amountPaise,
          currency,
          receipt
        });
        if (resolvedSubPaymentId) {
          db.prepare("UPDATE subscription_payments SET gateway_order_id = ? WHERE id = ?").run(
            order.id,
            resolvedSubPaymentId
          );
        } else if (body.legacyOrderId) {
          db.prepare("UPDATE subscription_payments SET gateway_order_id = ? WHERE gateway_order_id = ?").run(
            order.id,
            String(body.legacyOrderId)
          );
        }
        return sendJson(res, 200, {
          order_id: order.id,
          amount: order.amount,
          currency: order.currency,
          receipt: order.receipt,
          key_id: keyId,
          subscription_payment_id: resolvedSubPaymentId || void 0,
          sandbox: false
        });
      } catch (err) {
        const platform = db.prepare("SELECT razorpay_sandbox_mode FROM platform_settings LIMIT 1").get();
        const isSandboxEnabled = Boolean(platform?.razorpay_sandbox_mode ?? 1);
        if (isSandboxEnabled && keyId.startsWith("rzp_test_") && !body.strictAuth) {
          const sandboxOrderId = `order_${uuid().replace(/-/g, "").slice(0, 14)}`;
          if (resolvedSubPaymentId) {
            db.prepare("UPDATE subscription_payments SET gateway_order_id = ? WHERE id = ?").run(
              sandboxOrderId,
              resolvedSubPaymentId
            );
          } else if (body.legacyOrderId) {
            db.prepare("UPDATE subscription_payments SET gateway_order_id = ? WHERE gateway_order_id = ?").run(
              sandboxOrderId,
              String(body.legacyOrderId)
            );
          }
          return sendJson(res, 200, {
            order_id: sandboxOrderId,
            amount: amountPaise,
            currency,
            receipt,
            key_id: keyId,
            subscription_payment_id: resolvedSubPaymentId || void 0,
            sandbox: true
          });
        }
        const statusCode = Number(err?.statusCode) === 401 ? 401 : 500;
        const rawMsg = String(err?.error?.description || err?.message || "");
        const message = rawMsg.includes("reading 'status'") ? "Unable to reach Razorpay API server (https://api.razorpay.com). Please check network connectivity." : rawMsg || (statusCode === 401 ? "Razorpay authentication failed." : "Failed to create Razorpay order.");
        return sendJson(res, statusCode, { error: message });
      }
    }
    if (pathname === "/api/verify-payment" && method === "POST") {
      const orderId = String(body.razorpay_order_id || body.order_id || body.orderId || "").trim();
      const paymentId = String(body.razorpay_payment_id || body.payment_id || body.paymentId || "").trim();
      const signature = String(body.razorpay_signature || body.signature || "").trim();
      if (!orderId || !paymentId || !signature) {
        return sendJson(res, 400, {
          error: "Missing required fields: razorpay_order_id, razorpay_payment_id, and razorpay_signature are required."
        });
      }
      const { keySecret: primarySecret } = resolveRazorpayCredentials(auth?.societyId);
      const platformSecret = getRazorpayKeySecret();
      const isValidPrimary = primarySecret ? verifyRazorpayPaymentSignature(orderId, paymentId, signature, primarySecret) : false;
      const isValidPlatform = !isValidPrimary && platformSecret ? verifyRazorpayPaymentSignature(orderId, paymentId, signature, platformSecret) : false;
      if (!isValidPrimary && !isValidPlatform) {
        return sendJson(res, 400, {
          error: "Invalid payment signature. Signature verification failed."
        });
      }
      let updatedSociety;
      let receiptRecord = null;
      const lookupOrderId = String(body.subscriptionOrderId || orderId);
      const subPayment = db.prepare("SELECT * FROM subscription_payments WHERE gateway_order_id = ? OR id = ?").get(orderId, lookupOrderId);
      if (subPayment && subPayment.status !== "PAID") {
        const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(subPayment.plan_id);
        const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
        const autoApprove = Boolean(plan?.auto_approve_after_payment && platform?.auto_approve_paid_societies);
        const nowIso = (/* @__PURE__ */ new Date()).toISOString();
        const endsIso = new Date(Date.now() + Number(plan?.duration_days || 30) * 864e5).toISOString();
        const graceEndsIso = new Date(
          Date.now() + (Number(plan?.duration_days || 30) + Number(plan?.grace_period_days || 7)) * 864e5
        ).toISOString();
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            UPDATE subscription_payments
            SET gateway_order_id = ?, gateway_payment_id = ?, gateway_signature = ?, verified_by_webhook = 1, status = 'PAID', paid_at = ?
            WHERE id = ?
          `).run(orderId, paymentId, signature, nowIso, subPayment.id);
          db.prepare(`
            INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial)
            VALUES (?, ?, ?, 'ACTIVE', ?, ?, 0)
          `).run(uuid(), subPayment.society_id, subPayment.plan_id, nowIso, endsIso);
          db.prepare(`
            UPDATE societies
            SET subscription_plan_id = ?,
                subscription_status = 'ACTIVE',
                payment_status = 'PAID',
                approval_status = CASE WHEN ? = 1 THEN 'APPROVED' ELSE approval_status END,
                subscription_starts_at = ?,
                subscription_ends_at = ?,
                grace_period_ends_at = ?,
                updated_at = datetime('now')
            WHERE id = ?
          `).run(subPayment.plan_id, autoApprove ? 1 : 0, nowIso, endsIso, graceEndsIso, subPayment.society_id);
          db.prepare(`
            UPDATE notifications
            SET is_read = 1
            WHERE society_id = ? AND notification_type IN ('SUBSCRIPTION_PAYMENT_DUE', 'SUBSCRIPTION_RENEWAL', 'TRIAL_EXPIRY')
          `).run(subPayment.society_id);
          sendNotification({
            societyId: subPayment.society_id,
            notificationType: "SUBSCRIPTION_PAYMENT_CONFIRMED",
            title: `Subscription Renewed & Active \u2014 ${plan?.name || "Society Plan"}`,
            message: `Subscription payment of \u20B9${Number(subPayment.total_amount).toLocaleString("en-IN")} (Ref: ${paymentId}) is verified. Your society subscription is ACTIVE until ${new Date(endsIso).toLocaleDateString("en-IN")}.`,
            channel: "IN_APP"
          });
          logAudit({
            societyId: subPayment.society_id,
            actorRole: "RAZORPAY_CHECKOUT",
            action: "SUBSCRIPTION_PAYMENT_VERIFIED",
            entityType: "SUBSCRIPTION_PAYMENT",
            entityId: subPayment.id,
            details: { orderId, paymentId, autoApprove }
          });
          db.exec("COMMIT");
          updatedSociety = db.prepare("SELECT * FROM societies WHERE id = ?").get(subPayment.society_id);
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (Array.isArray(body.billIds) && body.billIds.length > 0 && auth?.role === "MEMBER" && auth?.societyId) {
        const societyId = auth.societyId;
        const member = db.prepare(`
          SELECT sm.*, h.flat_number
          FROM society_members sm
          JOIN households h ON h.id = sm.household_id
          WHERE sm.user_id = ? AND sm.society_id = ?
        `).get(auth.userId, societyId);
        if (member) {
          const billIds = body.billIds;
          const targetBills = [];
          let computedTotal = 0;
          for (const bId of billIds) {
            const bill = db.prepare("SELECT * FROM member_bills WHERE id = ? AND society_id = ? AND household_id = ?").get(bId, societyId, member.household_id);
            if (bill && bill.status !== "PAID" && Number(bill.balance_amount) > 0) {
              targetBills.push(bill);
              computedTotal += Number(bill.balance_amount);
            }
          }
          const paidRupees = Number(body.amount) > 0 ? Number(body.amount) : computedTotal;
          if (targetBills.length > 0 && paidRupees > 0) {
            const internalPaymentId = uuid();
            const dateStr = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
            db.exec("BEGIN IMMEDIATE");
            try {
              db.prepare(`
                INSERT INTO payments (
                  id, society_id, household_id, member_id, payment_method, amount, payment_date,
                  reference_number, status, verification_notes, verified_at, ledger_posted
                ) VALUES (?, ?, ?, ?, 'RAZORPAY', ?, ?, ?, 'CONFIRMED', ?, datetime('now'), 1)
              `).run(
                internalPaymentId,
                societyId,
                member.household_id,
                member.id,
                paidRupees,
                dateStr,
                paymentId,
                `Verified via Razorpay Standard Checkout (Order: ${orderId})`
              );
              let remaining = paidRupees;
              for (const bill of targetBills) {
                if (remaining <= 0) break;
                const billBal = Number(bill.balance_amount);
                const allocAmt = Math.min(remaining, billBal);
                if (allocAmt <= 0) continue;
                db.prepare(`
                  INSERT INTO payment_allocations (id, society_id, payment_id, bill_id, allocated_amount)
                  VALUES (?, ?, ?, ?, ?)
                `).run(uuid(), societyId, internalPaymentId, bill.id, allocAmt);
                const newPaid = Number((Number(bill.paid_amount) + allocAmt).toFixed(2));
                const newBal = Math.max(0, Number((Number(bill.total_amount) - newPaid).toFixed(2)));
                const newStatus = newBal === 0 ? "PAID" : "PARTIALLY_PAID";
                db.prepare(`
                  UPDATE member_bills
                  SET paid_amount = ?, balance_amount = ?, status = ?, updated_at = datetime('now')
                  WHERE id = ?
                `).run(newPaid, newBal, newStatus, bill.id);
                remaining = Math.max(0, Number((remaining - allocAmt).toFixed(2)));
              }
              const receiptNumber = `RCP-${(/* @__PURE__ */ new Date()).getFullYear()}-${internalPaymentId.slice(0, 6).toUpperCase()}`;
              const receiptId = uuid();
              db.prepare(`
                INSERT INTO payment_receipts (
                  id, society_id, payment_id, receipt_number, issued_to_name, flat_number,
                  amount, payment_method, reference_number
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RAZORPAY', ?)
              `).run(
                receiptId,
                societyId,
                internalPaymentId,
                receiptNumber,
                member.full_name,
                member.flat_number,
                paidRupees,
                paymentId
              );
              const txnCode = `TXN-RZP-${Date.now()}-${internalPaymentId.slice(0, 4).toUpperCase()}`;
              db.prepare(`
                INSERT INTO ledger_entries (
                  id, society_id, transaction_code, entry_date, entry_type, account_type,
                  category, description, amount, direction, reference_type, reference_id,
                  household_id, flat_number, member_id, payment_method
                ) VALUES (?, ?, ?, ?, 'INCOME', 'BANK', 'Maintenance Collection', ?, ?, 'CREDIT', 'PAYMENT', ?, ?, ?, ?, 'RAZORPAY')
              `).run(
                uuid(),
                societyId,
                txnCode,
                dateStr,
                `Razorpay online payment ${receiptNumber} (Flat ${member.flat_number}, Payment ID: ${paymentId})`,
                paidRupees,
                internalPaymentId,
                member.household_id,
                member.flat_number,
                member.id
              );
              db.exec("COMMIT");
              receiptRecord = {
                id: receiptId,
                receiptNumber,
                amount: paidRupees,
                paymentId,
                orderId
              };
            } catch (err) {
              db.exec("ROLLBACK");
              throw err;
            }
          }
        }
      }
      return sendJson(res, 200, {
        success: true,
        verified: true,
        order_id: orderId,
        payment_id: paymentId,
        society: updatedSociety,
        receipt: receiptRecord,
        message: "Payment signature verified successfully!"
      });
    }
    if (pathname === "/api/public/plans" && method === "GET") {
      const plans = db.prepare("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price_amount ASC").all();
      const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
      if (platform) {
        delete platform.razorpay_key_secret_encrypted;
        delete platform.razorpay_webhook_secret_encrypted;
        delete platform.paytm_merchant_key_encrypted;
        delete platform.custom_gateway_secret_encrypted;
      }
      return sendJson(res, 200, { plans, platform });
    }
    if (pathname === "/api/public/register-society" && method === "POST") {
      if (!checkRateLimit(`reg:${clientIp}`, 30, 6e4)) {
        return sendJson(res, 429, { error: "Too many registration requests. Please try again shortly." });
      }
      const {
        adminName,
        email,
        phone,
        password,
        societyName,
        address,
        city = "",
        state = "Punjab",
        pincode = "",
        registrationNumber = "",
        planId,
        startWithTrial = true
      } = body;
      if (!adminName || !email || !phone || !password || !societyName || !address || !planId) {
        return sendJson(res, 400, { error: "All mandatory society and administrator fields are required." });
      }
      if (!isValid10DigitPhone(phone)) {
        return sendJson(res, 400, { error: "Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9." });
      }
      const cleanEmail = String(email).trim().toLowerCase();
      const existingUser = db.prepare("SELECT id FROM users WHERE email = ?").get(cleanEmail);
      if (existingUser) {
        return sendJson(res, 409, { error: "An account with this email address already exists." });
      }
      const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1").get(planId);
      if (!plan) {
        return sendJson(res, 404, { error: "Selected subscription plan is invalid or inactive." });
      }
      const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
      const useTrial = Boolean(startWithTrial && plan.trial_enabled && platform.default_trial_enabled);
      const societyId = uuid();
      const adminUserId = uuid();
      const baseSlug = String(societyName).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "society";
      const slug = `${baseSlug}-${societyId.slice(0, 6)}`;
      const enrollmentCode = `${baseSlug.slice(0, 4).toUpperCase()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
      const trialDays = Number(plan.trial_days || platform.default_trial_days || 14);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const trialEndsIso = new Date(Date.now() + trialDays * 864e5).toISOString();
      const subscriptionStatus = useTrial ? "TRIAL" : "PENDING_PAYMENT";
      const paymentStatus = useTrial ? "TRIAL" : "PENDING";
      const approvalStatus = useTrial ? platform.auto_approve_trial_societies ? "APPROVED" : "PENDING" : "PENDING";
      db.exec("BEGIN IMMEDIATE");
      try {
        db.prepare(`
          INSERT INTO societies (
            id, name, slug, enrollment_code, address, city, state, pincode,
            contact_email, contact_phone, registration_number, subscription_plan_id,
            subscription_status, approval_status, account_status, payment_status,
            trial_starts_at, trial_ends_at, is_demo
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, 0)
        `).run(
          societyId,
          String(societyName).trim(),
          slug,
          enrollmentCode,
          String(address).trim(),
          String(city).trim(),
          String(state).trim(),
          String(pincode).trim(),
          cleanEmail,
          String(phone).trim(),
          String(registrationNumber).trim(),
          plan.id,
          subscriptionStatus,
          approvalStatus,
          paymentStatus,
          useTrial ? nowIso : null,
          useTrial ? trialEndsIso : null
        );
        db.prepare(`
          INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
          VALUES (?, ?, ?, ?, 'SOCIETY_ADMIN', ?, 1, 1)
        `).run(adminUserId, cleanEmail, String(phone).trim(), hashPassword(String(password)), societyId);
        db.prepare(`
          INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language, address)
          VALUES (?, ?, ?, ?, 'en', ?)
        `).run(uuid(), adminUserId, societyId, String(adminName).trim(), String(address).trim());
        db.prepare("UPDATE societies SET admin_user_id = ? WHERE id = ?").run(adminUserId, societyId);
        const subscriptionId = uuid();
        db.prepare(`
          INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(
          subscriptionId,
          societyId,
          plan.id,
          useTrial ? "TRIAL" : "PENDING_PAYMENT",
          nowIso,
          useTrial ? trialEndsIso : new Date(Date.now() + Number(plan.duration_days) * 864e5).toISOString(),
          useTrial ? 1 : 0
        );
        let paymentOrder = null;
        if (!useTrial) {
          const amount = Number(plan.price_amount);
          const taxAmount = Number((amount * Number(plan.tax_percent || 18) / 100).toFixed(2));
          const totalAmount = Number((amount + taxAmount).toFixed(2));
          const orderId = `order_${uuid().replace(/-/g, "").slice(0, 14)}`;
          const subPayId = uuid();
          const invoiceNumber = `SUB-INV-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e4 + Math.random() * 9e4)}`;
          db.prepare(`
            INSERT INTO subscription_payments (
              id, society_id, subscription_id, plan_id, invoice_number, amount, tax_amount,
              total_amount, payment_gateway, gateway_order_id, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'RAZORPAY', ?, 'CREATED')
          `).run(subPayId, societyId, subscriptionId, plan.id, invoiceNumber, amount, taxAmount, totalAmount, orderId);
          paymentOrder = {
            subscriptionPaymentId: subPayId,
            orderId,
            invoiceNumber,
            amount,
            taxAmount,
            totalAmount,
            currency: "INR",
            razorpayKeyId: platform.razorpay_key_id
          };
        }
        bootstrapSocietyDefaults(societyId, String(societyName).trim());
        sendNotification({
          societyId,
          userId: adminUserId,
          notificationType: "SOCIETY_REGISTERED",
          title: useTrial ? "Free Trial Activated \u2014 Welcome to SocietyOS!" : "Society Registration Created \u2014 Complete Subscription Payment",
          message: useTrial ? `Your ${trialDays}-day free trial for ${societyName} is active until ${trialEndsIso.slice(0, 10)}.` : `Please complete your subscription payment to activate ${societyName}.`,
          channel: "EMAIL",
          dedupKey: `soc-reg:${societyId}`
        });
        logAudit({
          societyId,
          actorUserId: adminUserId,
          actorRole: "SOCIETY_ADMIN",
          action: "SOCIETY_REGISTERED",
          entityType: "SOCIETY",
          entityId: societyId,
          details: { societyName, planCode: plan.code, useTrial },
          ipAddress: clientIp
        });
        db.exec("COMMIT");
        const token = signJwt({
          userId: adminUserId,
          email: cleanEmail,
          role: "SOCIETY_ADMIN",
          societyId
        });
        const createdSociety = db.prepare("SELECT * FROM societies WHERE id = ?").get(societyId);
        return sendJson(res, 201, {
          token,
          society: createdSociety,
          paymentOrder,
          message: useTrial ? `Society registered with ${trialDays}-day free trial!` : "Society registered. Complete subscription payment to activate."
        });
      } catch (err) {
        db.exec("ROLLBACK");
        throw err;
      }
    }
    if (pathname === "/api/public/subscription-payment/create-order" && method === "POST") {
      const { societyId, planId } = body;
      if (!societyId || !planId) {
        return sendJson(res, 400, { error: "societyId and planId are required." });
      }
      const society = db.prepare("SELECT * FROM societies WHERE id = ?").get(societyId);
      const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(planId);
      if (!society || !plan) {
        return sendJson(res, 404, { error: "Society or subscription plan not found." });
      }
      const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
      const amount = Number(plan.price_amount);
      const taxAmount = Number((amount * Number(plan.tax_percent || 18) / 100).toFixed(2));
      const totalAmount = Number((amount + taxAmount).toFixed(2));
      const orderId = `order_${uuid().replace(/-/g, "").slice(0, 14)}`;
      const subPayId = uuid();
      const invoiceNumber = `SUB-INV-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e4 + Math.random() * 9e4)}`;
      db.prepare(`
        INSERT INTO subscription_payments (
          id, society_id, plan_id, invoice_number, amount, tax_amount, total_amount,
          payment_gateway, gateway_order_id, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RAZORPAY', ?, 'CREATED')
      `).run(subPayId, society.id, plan.id, invoiceNumber, amount, taxAmount, totalAmount, orderId);
      return sendJson(res, 201, {
        subscriptionPaymentId: subPayId,
        orderId,
        invoiceNumber,
        amount,
        taxAmount,
        totalAmount,
        currency: "INR",
        razorpayKeyId: platform.razorpay_key_id
      });
    }
    if (pathname === "/api/public/razorpay-sandbox/simulate-settlement" && method === "POST") {
      const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
      if (!platform.razorpay_sandbox_mode) {
        return sendJson(res, 403, { error: "Razorpay Sandbox Mode is disabled." });
      }
      const { orderId } = body;
      if (!orderId) {
        return sendJson(res, 400, { error: "orderId is required." });
      }
      const { keySecret } = resolveRazorpayCredentials(auth?.societyId);
      const paymentId = `pay_${uuid().replace(/-/g, "").slice(0, 14)}`;
      const signature = createRazorpayPaymentSignature(orderId, paymentId, keySecret || void 0);
      return sendJson(res, 200, {
        razorpay_order_id: orderId,
        razorpay_payment_id: paymentId,
        razorpay_signature: signature
      });
    }
    if (pathname === "/api/public/subscription-payment/verify" && method === "POST") {
      const { orderId, paymentId, signature } = body;
      if (!orderId || !paymentId || !signature) {
        return sendJson(res, 400, {
          error: "Subscription cannot be marked paid based only on a redirect or reference. Trusted gateway orderId, paymentId, and cryptographic signature are required."
        });
      }
      if (!verifyRazorpayPaymentSignature(String(orderId), String(paymentId), String(signature))) {
        return sendJson(res, 400, {
          error: "Invalid payment gateway cryptographic signature. Payment verification rejected."
        });
      }
      const subPayment = db.prepare("SELECT * FROM subscription_payments WHERE gateway_order_id = ?").get(String(orderId));
      if (!subPayment) {
        return sendJson(res, 404, { error: "Subscription payment order not found." });
      }
      if (subPayment.status === "PAID") {
        const society = db.prepare("SELECT * FROM societies WHERE id = ?").get(subPayment.society_id);
        return sendJson(res, 200, { message: "Subscription payment already verified.", society });
      }
      const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(subPayment.plan_id);
      const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
      const autoApprove = Boolean(plan.auto_approve_after_payment && platform.auto_approve_paid_societies);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const endsIso = new Date(Date.now() + Number(plan.duration_days || 30) * 864e5).toISOString();
      const graceEndsIso = new Date(
        Date.now() + (Number(plan.duration_days || 30) + Number(plan.grace_period_days || 7)) * 864e5
      ).toISOString();
      db.exec("BEGIN IMMEDIATE");
      try {
        db.prepare(`
          UPDATE subscription_payments
          SET gateway_payment_id = ?, gateway_signature = ?, verified_by_webhook = 1, status = 'PAID', paid_at = ?
          WHERE id = ?
        `).run(String(paymentId), String(signature), nowIso, subPayment.id);
        const newSubId = uuid();
        db.prepare(`
          INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial)
          VALUES (?, ?, ?, 'ACTIVE', ?, ?, 0)
        `).run(newSubId, subPayment.society_id, plan.id, nowIso, endsIso);
        db.prepare(`
          UPDATE societies
          SET subscription_plan_id = ?,
              subscription_status = 'ACTIVE',
              payment_status = 'PAID',
              approval_status = CASE WHEN ? = 1 THEN 'APPROVED' ELSE approval_status END,
              subscription_starts_at = ?,
              subscription_ends_at = ?,
              grace_period_ends_at = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(plan.id, autoApprove ? 1 : 0, nowIso, endsIso, graceEndsIso, subPayment.society_id);
        logAudit({
          societyId: subPayment.society_id,
          actorRole: "SYSTEM_WEBHOOK",
          action: "SUBSCRIPTION_PAYMENT_VERIFIED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayment.id,
          details: { orderId, paymentId, autoApprove, planCode: plan.code }
        });
        db.exec("COMMIT");
        const updatedSociety = db.prepare("SELECT * FROM societies WHERE id = ?").get(subPayment.society_id);
        return sendJson(res, 200, {
          verified: true,
          autoApproved: autoApprove,
          society: updatedSociety,
          message: autoApprove ? "Payment verified! Society subscription is now ACTIVE and APPROVED." : "Payment verified! Society is awaiting manual approval by Super Admin."
        });
      } catch (err) {
        db.exec("ROLLBACK");
        throw err;
      }
    }
    const enrollMatch = pathname.match(/^\/api\/public\/enroll\/([^/]+)$/);
    if (enrollMatch && method === "GET") {
      const code = decodeURIComponent(enrollMatch[1]);
      const society = db.prepare(`
        SELECT id, name, slug, enrollment_code, logo_url, address, city, state, pincode, contact_email, contact_phone
        FROM societies
        WHERE (enrollment_code = ? OR slug = ?) AND account_status = 'ACTIVE'
      `).get(code, code);
      if (!society) {
        return sendJson(res, 404, { error: "Invalid or inactive society enrolment link." });
      }
      const blocks = db.prepare("SELECT id, name, total_floors FROM apartment_blocks WHERE society_id = ? ORDER BY name ASC").all(society.id);
      const settings = db.prepare("SELECT custom_enrollment_fields, brand_primary_color FROM society_settings WHERE society_id = ?").get(society.id);
      const households = db.prepare(`
        SELECT id, block_name, floor_number, flat_number, normalized_flat_number
        FROM households
        WHERE society_id = ? AND status != 'ARCHIVED'
        ORDER BY normalized_flat_number ASC
      `).all(society.id);
      return sendJson(res, 200, {
        society,
        blocks,
        households,
        customFields: settings ? JSON.parse(settings.custom_enrollment_fields || "[]") : []
      });
    }
    const checkFlatMatch = pathname.match(/^\/api\/public\/enroll\/([^/]+)\/check-flat$/);
    if (checkFlatMatch && method === "POST") {
      const code = decodeURIComponent(checkFlatMatch[1]);
      const society = db.prepare("SELECT id FROM societies WHERE (enrollment_code = ? OR slug = ?) AND account_status = 'ACTIVE'").get(code, code);
      if (!society) {
        return sendJson(res, 404, { error: "Society not found." });
      }
      const normalized = normalizeFlatNumber(body.flatNumber || "");
      if (!normalized) {
        return sendJson(res, 400, { error: "Flat/house number is required." });
      }
      const existing = db.prepare(`
        SELECT id, flat_number, block_name, status
        FROM households
        WHERE society_id = ? AND normalized_flat_number = ? AND status != 'ARCHIVED'
      `).get(society.id, normalized);
      if (existing) {
        return sendJson(res, 200, {
          exists: true,
          normalizedFlatNumber: normalized,
          household: existing,
          message: "This flat/house number is already registered in this society."
        });
      }
      return sendJson(res, 200, { exists: false, normalizedFlatNumber: normalized });
    }
    if (enrollMatch && method === "POST") {
      if (!checkRateLimit(`enroll:${clientIp}`, 30, 6e4)) {
        return sendJson(res, 429, { error: "Too many enrolment requests. Please wait a moment." });
      }
      const code = decodeURIComponent(enrollMatch[1]);
      const society = db.prepare(`
        SELECT id, name FROM societies
        WHERE (enrollment_code = ? OR slug = ?) AND account_status = 'ACTIVE'
      `).get(code, code);
      if (!society) {
        return sendJson(res, 404, { error: "Invalid or inactive society enrolment link." });
      }
      const {
        fullName,
        email,
        phone,
        password = "Member@123",
        address = "",
        flatNumber,
        floorNumber = "1",
        blockName = "Block A",
        photoUrl = null,
        ownershipType = "OWNER",
        emergencyContact = "",
        customFields = {},
        enrolmentMode = "NEW_HOUSEHOLD",
        // 'NEW_HOUSEHOLD' or 'FAMILY_MEMBER'
        existingHouseholdId = null,
        relationshipToPrimary = "PRIMARY"
      } = body;
      if (!fullName || !email || !phone || !flatNumber) {
        return sendJson(res, 400, { error: "Full name, email, mobile number, and flat/house number are required." });
      }
      if (!isValid10DigitPhone(phone)) {
        return sendJson(res, 400, { error: "Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9." });
      }
      const cleanEmail = String(email).trim().toLowerCase();
      const existingUser = db.prepare("SELECT id FROM users WHERE email = ?").get(cleanEmail);
      if (existingUser) {
        return sendJson(res, 409, { error: "A user with this email address is already registered." });
      }
      const normalizedFlat = normalizeFlatNumber(String(flatNumber));
      if (!normalizedFlat) {
        return sendJson(res, 400, { error: "Valid flat/house number is required." });
      }
      db.exec("BEGIN IMMEDIATE");
      try {
        let householdId;
        let isPrimary = 1;
        if (enrolmentMode === "FAMILY_MEMBER") {
          const targetHh = db.prepare(`
            SELECT id FROM households
            WHERE society_id = ? AND (id = ? OR normalized_flat_number = ?) AND status != 'ARCHIVED'
          `).get(society.id, existingHouseholdId, normalizedFlat);
          if (!targetHh) {
            db.exec("ROLLBACK");
            return sendJson(res, 404, { error: "Registered household not found for linking family member." });
          }
          householdId = targetHh.id;
          isPrimary = 0;
        } else {
          const duplicateFlat = db.prepare(`
            SELECT id FROM households
            WHERE society_id = ? AND normalized_flat_number = ? AND status != 'ARCHIVED'
          `).get(society.id, normalizedFlat);
          if (duplicateFlat) {
            db.exec("ROLLBACK");
            return sendJson(res, 409, {
              error: "This flat/house number is already registered in this society."
            });
          }
          householdId = uuid();
          const blockRow = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = ?").get(society.id, blockName);
          db.prepare(`
            INSERT INTO households (
              id, society_id, block_id, block_name, floor_number, flat_number,
              normalized_flat_number, occupancy_type, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE')
          `).run(
            householdId,
            society.id,
            blockRow?.id ?? null,
            String(blockName).trim(),
            String(floorNumber).trim(),
            String(flatNumber).trim(),
            normalizedFlat,
            ownershipType === "TENANT" ? "TENANT" : "OWNER"
          );
        }
        const userId = uuid();
        const memberId = uuid();
        db.prepare(`
          INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
          VALUES (?, ?, ?, ?, 'MEMBER', ?, 1, 1)
        `).run(userId, cleanEmail, String(phone).trim(), hashPassword(String(password)), society.id);
        db.prepare(`
          INSERT INTO user_profiles (id, user_id, society_id, full_name, avatar_url, address, emergency_contact_name)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(
          uuid(),
          userId,
          society.id,
          String(fullName).trim(),
          photoUrl,
          String(address || `${flatNumber}, ${blockName}`).trim(),
          String(emergencyContact).trim()
        );
        db.prepare(`
          INSERT INTO society_members (
            id, society_id, household_id, user_id, full_name, email, phone, photo_url,
            relationship_to_primary, is_primary_member, ownership_type, emergency_contact,
            custom_fields, approval_status, account_status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 'ACTIVE')
        `).run(
          memberId,
          society.id,
          householdId,
          userId,
          String(fullName).trim(),
          cleanEmail,
          String(phone).trim(),
          photoUrl,
          isPrimary ? "PRIMARY" : String(relationshipToPrimary || "FAMILY"),
          isPrimary,
          isPrimary ? ownershipType === "TENANT" ? "TENANT" : "OWNER" : "FAMILY",
          String(emergencyContact).trim(),
          JSON.stringify(customFields || {})
        );
        if (isPrimary) {
          db.prepare("UPDATE households SET primary_member_id = ? WHERE id = ?").run(memberId, householdId);
        }
        sendNotification({
          societyId: society.id,
          userId,
          notificationType: "NEW_MEMBER_ENROLMENT",
          title: `Enrolment Received \u2014 Flat ${normalizedFlat}`,
          message: `${fullName} enrolled for Flat ${normalizedFlat} in ${society.name}.`,
          channel: "IN_APP",
          dedupKey: `enroll:${memberId}`
        });
        logAudit({
          societyId: society.id,
          actorUserId: userId,
          actorRole: "MEMBER",
          action: "PUBLIC_MEMBER_ENROLLED",
          entityType: "SOCIETY_MEMBER",
          entityId: memberId,
          details: { flatNumber: normalizedFlat, enrolmentMode },
          ipAddress: clientIp
        });
        db.exec("COMMIT");
        return sendJson(res, 201, {
          memberId,
          householdId,
          normalizedFlatNumber: normalizedFlat,
          message: "Enrolment submitted successfully! You can now sign in to your resident portal."
        });
      } catch (err) {
        db.exec("ROLLBACK");
        if (String(err?.message || "").includes("UNIQUE constraint failed")) {
          return sendJson(res, 409, {
            error: "This flat/house number is already registered in this society."
          });
        }
        throw err;
      }
    }
    if (pathname === "/api/auth/login" && method === "GET") {
      const accept = String(req.headers["accept"] || "");
      if (accept.includes("text/html")) {
        res.writeHead(302, { Location: "/" });
        return res.end();
      }
      return sendJson(res, 405, {
        error: 'Method Not Allowed. /api/auth/login expects a POST request with JSON credentials: {"email": "...", "password": "..."}. To open the login portal in your browser, visit http://localhost:4000/ or /'
      });
    }
    if (pathname === "/api/auth/login" && method === "POST") {
      if (!checkRateLimit(`login:${clientIp}`, 40, 6e4)) {
        return sendJson(res, 429, { error: "Too many login attempts. Please wait a minute." });
      }
      const { email, password } = body;
      if (!email || !password) {
        return sendJson(res, 400, { error: "Email and password are required." });
      }
      const user = db.prepare("SELECT * FROM users WHERE email = ?").get(String(email).trim().toLowerCase());
      if (!user || !verifyPassword(String(password), user.password_hash)) {
        return sendJson(res, 401, { error: "Invalid email or password." });
      }
      if (!user.is_active) {
        return sendJson(res, 403, { error: "Your user account has been deactivated or blocked." });
      }
      let society = null;
      if (user.society_id) {
        society = db.prepare("SELECT * FROM societies WHERE id = ?").get(user.society_id) || null;
        if (society && society.account_status === "SUSPENDED") {
          return sendJson(res, 403, { error: "This society account is currently suspended by the platform owner." });
        }
      }
      if (user.role === "MEMBER") {
        const memberRecord = db.prepare("SELECT account_status, approval_status FROM society_members WHERE user_id = ?").get(user.id);
        if (memberRecord && memberRecord.account_status === "BLOCKED") {
          return sendJson(res, 403, { error: "Your member account has been blocked by society management." });
        }
      }
      db.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?").run(user.id);
      const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(user.id);
      const permissions = user.role === "STAFF" && user.society_id ? getStaffPermissions(user.id, user.society_id) : null;
      const token = signJwt({
        userId: user.id,
        email: user.email,
        role: user.role,
        societyId: user.society_id
      });
      return sendJson(res, 200, {
        token,
        user: {
          id: user.id,
          email: user.email,
          phone: user.phone,
          role: user.role,
          societyId: user.society_id,
          fullName: profile?.full_name || user.email,
          preferredLanguage: profile?.preferred_language || "en",
          avatarUrl: profile?.avatar_url || null
        },
        society,
        permissions
      });
    }
    if (pathname === "/api/auth/forgot-password" && method === "POST") {
      const cleanEmail = String(body.email || "").trim().toLowerCase();
      const user = db.prepare("SELECT id, email, society_id FROM users WHERE email = ?").get(cleanEmail);
      if (!user) {
        return sendJson(res, 200, { message: "If that email exists, a password reset token has been generated." });
      }
      const rawToken = `RST-${Math.floor(1e5 + Math.random() * 9e5)}`;
      const expiresIso = new Date(Date.now() + 30 * 6e4).toISOString();
      db.prepare("UPDATE users SET reset_token_hash = ?, reset_token_expires_at = ? WHERE id = ?").run(
        hashPassword(rawToken),
        expiresIso,
        user.id
      );
      sendNotification({
        societyId: user.society_id,
        userId: user.id,
        notificationType: "PASSWORD_RESET",
        title: "Password Reset Requested",
        message: `Your password reset verification code is ${rawToken} (valid for 30 minutes).`,
        channel: "EMAIL"
      });
      return sendJson(res, 200, {
        message: "Password reset token generated and sent.",
        resetTokenPreview: rawToken
        // Returned in dev mode so user can complete flow without external SMTP server
      });
    }
    if (pathname === "/api/auth/reset-password" && method === "POST") {
      const { email, resetToken, newPassword } = body;
      if (!email || !resetToken || !newPassword) {
        return sendJson(res, 400, { error: "email, resetToken, and newPassword are required." });
      }
      const user = db.prepare("SELECT * FROM users WHERE email = ?").get(String(email).trim().toLowerCase());
      if (!user || !user.reset_token_hash || !user.reset_token_expires_at) {
        return sendJson(res, 400, { error: "Invalid or expired password reset token." });
      }
      if (new Date(user.reset_token_expires_at).getTime() < Date.now()) {
        return sendJson(res, 400, { error: "Password reset token has expired." });
      }
      if (!verifyPassword(String(resetToken), user.reset_token_hash)) {
        return sendJson(res, 400, { error: "Invalid password reset token." });
      }
      db.prepare(`
        UPDATE users
        SET password_hash = ?, reset_token_hash = NULL, reset_token_expires_at = NULL, updated_at = datetime('now')
        WHERE id = ?
      `).run(hashPassword(String(newPassword)), user.id);
      return sendJson(res, 200, { message: "Password has been reset successfully. You can now log in." });
    }
    if (pathname === "/api/auth/me" && method === "GET") {
      if (!auth) {
        return sendJson(res, 401, { error: "Not authenticated." });
      }
      const user = db.prepare("SELECT * FROM users WHERE id = ?").get(auth.userId);
      if (!user) {
        return sendJson(res, 401, { error: "User not found." });
      }
      const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(user.id);
      const society = user.society_id ? db.prepare("SELECT * FROM societies WHERE id = ?").get(user.society_id) : null;
      const permissions = user.role === "STAFF" && user.society_id ? getStaffPermissions(user.id, user.society_id) : null;
      const notifications = db.prepare(`
        SELECT * FROM notifications
        WHERE (user_id = ? OR (society_id = ? AND user_id IS NULL))
        ORDER BY created_at DESC LIMIT 30
      `).all(user.id, user.society_id);
      return sendJson(res, 200, {
        user: {
          id: user.id,
          email: user.email,
          phone: user.phone,
          role: user.role,
          societyId: user.society_id,
          fullName: profile?.full_name || user.email,
          preferredLanguage: profile?.preferred_language || "en",
          avatarUrl: profile?.avatar_url || null,
          address: profile?.address || "",
          emergencyContactName: profile?.emergency_contact_name || "",
          emergencyContactPhone: profile?.emergency_contact_phone || ""
        },
        society,
        permissions,
        notifications
      });
    }
    if (pathname === "/api/auth/profile" && method === "PUT") {
      if (!auth) return sendJson(res, 401, { error: "Not authenticated." });
      const { fullName, phone, preferredLanguage, address, emergencyContactName, emergencyContactPhone, avatarUrl } = body;
      if (phone) {
        db.prepare("UPDATE users SET phone = ?, updated_at = datetime('now') WHERE id = ?").run(String(phone).trim(), auth.userId);
      }
      db.prepare(`
        UPDATE user_profiles
        SET full_name = COALESCE(?, full_name),
            preferred_language = COALESCE(?, preferred_language),
            address = COALESCE(?, address),
            emergency_contact_name = COALESCE(?, emergency_contact_name),
            emergency_contact_phone = COALESCE(?, emergency_contact_phone),
            avatar_url = COALESCE(?, avatar_url),
            updated_at = datetime('now')
        WHERE user_id = ?
      `).run(
        fullName ?? null,
        preferredLanguage ?? null,
        address ?? null,
        emergencyContactName ?? null,
        emergencyContactPhone ?? null,
        avatarUrl ?? null,
        auth.userId
      );
      if (auth.role === "MEMBER") {
        db.prepare(`
          UPDATE society_members
          SET full_name = COALESCE(?, full_name),
              phone = COALESCE(?, phone),
              photo_url = COALESCE(?, photo_url),
              emergency_contact = COALESCE(?, emergency_contact),
              updated_at = datetime('now')
          WHERE user_id = ?
        `).run(
          fullName ?? null,
          phone ?? null,
          avatarUrl ?? null,
          emergencyContactName ? `${emergencyContactName} (${emergencyContactPhone || ""})` : null,
          auth.userId
        );
      }
      return sendJson(res, 200, { message: "Profile updated successfully." });
    }
    if (pathname === "/api/notifications/mark-read" && method === "POST") {
      if (!auth) return sendJson(res, 401, { error: "Not authenticated." });
      const targetReadState = body.isRead === false ? 0 : 1;
      if (body.notificationId) {
        db.prepare("UPDATE notifications SET is_read = ? WHERE id = ?").run(targetReadState, body.notificationId);
      } else {
        db.prepare("UPDATE notifications SET is_read = ? WHERE user_id = ? OR society_id = ?").run(
          targetReadState,
          auth.userId,
          auth.societyId
        );
      }
      return sendJson(res, 200, {
        message: targetReadState === 1 ? "Notification marked as read and moved to the Notifications page." : "Notification restored as unread."
      });
    }
    if (pathname.startsWith("/api/super-admin")) {
      if (!auth || auth.role !== "SUPER_ADMIN") {
        return sendJson(res, 403, {
          error: "Forbidden: Only the Platform Super Admin can access Super Admin functions."
        });
      }
      if (pathname === "/api/super-admin/dashboard" && method === "GET") {
        const search = (url.searchParams.get("search") || "").trim().toLowerCase();
        const statusFilter = url.searchParams.get("status") || "";
        const planFilter = url.searchParams.get("planId") || "";
        const paymentFilter = url.searchParams.get("paymentStatus") || "";
        const rawSocieties = db.prepare(`
          SELECT s.*,
                 u.email as admin_email,
                 u.phone as admin_phone,
                 up.full_name as admin_name,
                 sp.name as plan_name,
                 sp.code as plan_code,
                 sp.price_amount as plan_price,
                 sp.tax_percent as plan_tax_percent,
                 sp.billing_period as plan_billing_period,
                 sp.duration_days as plan_duration_days,
                 (SELECT COUNT(*) FROM households h WHERE h.society_id = s.id AND h.status != 'ARCHIVED') as household_count
          FROM societies s
          LEFT JOIN users u ON u.id = s.admin_user_id
          LEFT JOIN user_profiles up ON up.user_id = s.admin_user_id
          LEFT JOIN subscription_plans sp ON sp.id = s.subscription_plan_id
          ORDER BY s.created_at DESC
        `).all();
        const allSocieties = rawSocieties.map((s) => {
          const basePrice = Number(s.plan_price || 0);
          const taxPct = Number(s.plan_tax_percent ?? 18);
          const taxAmt = Number((basePrice * taxPct / 100).toFixed(2));
          const totalAmountDue = Number((basePrice + taxAmt).toFixed(2));
          const targetEnd = s.subscription_ends_at || s.trial_ends_at;
          const daysRemaining = targetEnd ? Math.ceil((new Date(targetEnd).getTime() - Date.now()) / 864e5) : 14;
          return {
            ...s,
            tax_amount: taxAmt,
            total_amount_due: totalAmountDue,
            days_remaining: daysRemaining,
            renewal_due_date: targetEnd
          };
        });
        const filteredSocieties = allSocieties.filter((s) => {
          if (search) {
            const hay = `${s.name} ${s.admin_name || ""} ${s.contact_email} ${s.contact_phone} ${s.city}`.toLowerCase();
            if (!hay.includes(search)) return false;
          }
          if (statusFilter && s.subscription_status !== statusFilter && s.account_status !== statusFilter && s.approval_status !== statusFilter) {
            return false;
          }
          if (planFilter && s.subscription_plan_id !== planFilter) return false;
          if (paymentFilter && s.payment_status !== paymentFilter) return false;
          return true;
        });
        const confirmedRevenue = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as total FROM subscription_payments WHERE status = 'PAID'").get().total;
        const pendingRevenue = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as total FROM subscription_payments WHERE status = 'CREATED'").get().total;
        const failedPaymentsCount = db.prepare("SELECT COUNT(*) as cnt FROM subscription_payments WHERE status = 'FAILED'").get().cnt;
        const monthlyRevenue = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as total FROM subscription_payments WHERE status = 'PAID' AND paid_at >= datetime('now', '-30 days')").get().total;
        const annualRevenue = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as total FROM subscription_payments WHERE status = 'PAID' AND paid_at >= datetime('now', '-365 days')").get().total;
        const kpis = {
          totalSocieties: allSocieties.length,
          activeSocieties: allSocieties.filter((s) => s.subscription_status === "ACTIVE" && s.account_status === "ACTIVE").length,
          trialSocieties: allSocieties.filter((s) => s.subscription_status === "TRIAL").length,
          pendingApprovals: allSocieties.filter((s) => s.approval_status === "PENDING").length,
          suspendedSocieties: allSocieties.filter((s) => s.account_status === "SUSPENDED").length,
          expiredSubscriptions: allSocieties.filter((s) => s.subscription_status === "EXPIRED").length,
          renewalsDue: allSocieties.filter((s) => {
            const end = s.subscription_ends_at || s.trial_ends_at;
            if (!end) return false;
            const diffDays = (new Date(end).getTime() - Date.now()) / 864e5;
            return diffDays >= 0 && diffDays <= 15;
          }).length,
          confirmedSubscriptionRevenue: confirmedRevenue,
          pendingSubscriptionPayments: pendingRevenue,
          monthlyRevenueSummary: monthlyRevenue,
          annualRevenueSummary: annualRevenue,
          newRegistrationsThisMonth: allSocieties.length,
          failedSubscriptionPayments: failedPaymentsCount
        };
        const plans = db.prepare("SELECT * FROM subscription_plans ORDER BY price_amount ASC").all();
        const subscriptionPayments = db.prepare(`
          SELECT sp.*, s.name as society_name, p.name as plan_name
          FROM subscription_payments sp
          JOIN societies s ON s.id = sp.society_id
          JOIN subscription_plans p ON p.id = sp.plan_id
          ORDER BY sp.created_at DESC
        `).all();
        const platformSettings = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
        if (platformSettings) {
          platformSettings.has_razorpay_secret = Boolean(platformSettings.razorpay_key_secret_encrypted);
          platformSettings.has_razorpay_webhook_secret = Boolean(platformSettings.razorpay_webhook_secret_encrypted);
          platformSettings.has_paytm_secret = Boolean(platformSettings.paytm_merchant_key_encrypted);
          platformSettings.has_custom_gateway_secret = Boolean(platformSettings.custom_gateway_secret_encrypted);
          delete platformSettings.razorpay_key_secret_encrypted;
          delete platformSettings.razorpay_webhook_secret_encrypted;
          delete platformSettings.paytm_merchant_key_encrypted;
          delete platformSettings.custom_gateway_secret_encrypted;
        }
        const auditLogs = db.prepare("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100").all();
        return sendJson(res, 200, {
          kpis,
          societies: filteredSocieties,
          plans,
          subscriptionPayments,
          platformSettings,
          auditLogs
        });
      }
      if (pathname === "/api/super-admin/societies" && method === "POST") {
        const {
          societyName,
          adminName,
          email,
          phone,
          password = "Admin@123",
          address,
          city = "",
          state = "Punjab",
          pincode = "",
          planId,
          subscriptionStatus = "TRIAL",
          approvalStatus = "APPROVED"
        } = body;
        if (!societyName || !adminName || !email || !phone || !address || !planId) {
          return sendJson(res, 400, { error: "Required society fields are missing." });
        }
        const cleanEmail = String(email).trim().toLowerCase();
        if (db.prepare("SELECT id FROM users WHERE email = ?").get(cleanEmail)) {
          return sendJson(res, 409, { error: "Administrator email already exists." });
        }
        const societyId = uuid();
        const adminId = uuid();
        const slug = `${String(societyName).toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${societyId.slice(0, 5)}`;
        const enrollmentCode = `SOC-${Math.floor(1e3 + Math.random() * 9e3)}`;
        const nowIso = (/* @__PURE__ */ new Date()).toISOString();
        const endsIso = new Date(Date.now() + 14 * 864e5).toISOString();
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO societies (
              id, name, slug, enrollment_code, address, city, state, pincode,
              contact_email, contact_phone, subscription_plan_id, subscription_status,
              approval_status, account_status, payment_status, trial_starts_at, trial_ends_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?)
          `).run(
            societyId,
            societyName,
            slug,
            enrollmentCode,
            address,
            city,
            state,
            pincode,
            cleanEmail,
            phone,
            planId,
            subscriptionStatus,
            approvalStatus,
            subscriptionStatus === "ACTIVE" ? "PAID" : "TRIAL",
            nowIso,
            endsIso
          );
          db.prepare(`
            INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
            VALUES (?, ?, ?, ?, 'SOCIETY_ADMIN', ?, 1, 1)
          `).run(adminId, cleanEmail, phone, hashPassword(password), societyId);
          db.prepare(`
            INSERT INTO user_profiles (id, user_id, society_id, full_name, preferred_language)
            VALUES (?, ?, ?, ?, 'en')
          `).run(uuid(), adminId, societyId, adminName);
          db.prepare("UPDATE societies SET admin_user_id = ? WHERE id = ?").run(adminId, societyId);
          bootstrapSocietyDefaults(societyId, societyName);
          logAudit({
            societyId,
            actorUserId: auth.userId,
            actorRole: "SUPER_ADMIN",
            action: "SUPER_ADMIN_CREATED_SOCIETY",
            entityType: "SOCIETY",
            entityId: societyId,
            details: { societyName, email: cleanEmail }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { societyId, message: "Society created by Super Admin." });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      const saSocMatch = pathname.match(/^\/api\/super-admin\/societies\/([^/]+)$/);
      if (saSocMatch && method === "PUT") {
        const targetSocId = saSocMatch[1];
        const society = db.prepare("SELECT * FROM societies WHERE id = ?").get(targetSocId);
        if (!society) return sendJson(res, 404, { error: "Society not found." });
        const {
          action,
          // 'APPROVE', 'REJECT', 'SUSPEND', 'REACTIVATE', 'ARCHIVE', 'EXTEND_TRIAL', 'CHANGE_PLAN', 'EDIT'
          name,
          address,
          contactEmail,
          contactPhone,
          planId,
          extendDays,
          reason
        } = body;
        if (action === "APPROVE") {
          db.prepare("UPDATE societies SET approval_status = 'APPROVED', updated_at = datetime('now') WHERE id = ?").run(targetSocId);
        } else if (action === "REJECT") {
          db.prepare("UPDATE societies SET approval_status = 'REJECTED', updated_at = datetime('now') WHERE id = ?").run(targetSocId);
        } else if (action === "SUSPEND") {
          db.prepare("UPDATE societies SET account_status = 'SUSPENDED', subscription_status = 'SUSPENDED', updated_at = datetime('now') WHERE id = ?").run(targetSocId);
        } else if (action === "REACTIVATE") {
          db.prepare("UPDATE societies SET account_status = 'ACTIVE', subscription_status = CASE WHEN payment_status = 'PAID' THEN 'ACTIVE' ELSE 'TRIAL' END, updated_at = datetime('now') WHERE id = ?").run(targetSocId);
        } else if (action === "ARCHIVE") {
          db.prepare("UPDATE societies SET account_status = 'ARCHIVED', updated_at = datetime('now') WHERE id = ?").run(targetSocId);
        } else if (action === "EXTEND_TRIAL") {
          if (!reason) {
            return sendJson(res, 400, { error: "A recorded reason is required when extending a society free trial." });
          }
          const days = Number(extendDays || 7);
          const currentEnd = society.trial_ends_at ? new Date(society.trial_ends_at).getTime() : Date.now();
          const newEndIso = new Date(Math.max(currentEnd, Date.now()) + days * 864e5).toISOString();
          db.prepare(`
            UPDATE societies
            SET trial_ends_at = ?, subscription_status = 'TRIAL', updated_at = datetime('now')
            WHERE id = ?
          `).run(newEndIso, targetSocId);
          db.prepare(`
            INSERT INTO society_subscriptions (id, society_id, plan_id, status, starts_at, ends_at, is_trial, extended_reason, extended_by)
            VALUES (?, ?, ?, 'TRIAL', datetime('now'), ?, 1, ?, ?)
          `).run(uuid(), targetSocId, society.subscription_plan_id, newEndIso, String(reason), auth.userId);
        } else if (action === "CHANGE_PLAN" && planId) {
          db.prepare("UPDATE societies SET subscription_plan_id = ?, updated_at = datetime('now') WHERE id = ?").run(planId, targetSocId);
        } else {
          db.prepare(`
            UPDATE societies
            SET name = COALESCE(?, name),
                address = COALESCE(?, address),
                contact_email = COALESCE(?, contact_email),
                contact_phone = COALESCE(?, contact_phone),
                subscription_plan_id = COALESCE(?, subscription_plan_id),
                updated_at = datetime('now')
            WHERE id = ?
          `).run(name ?? null, address ?? null, contactEmail ?? null, contactPhone ?? null, planId ?? null, targetSocId);
        }
        logAudit({
          societyId: targetSocId,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: `SUPER_ADMIN_${action || "EDIT"}_SOCIETY`,
          entityType: "SOCIETY",
          entityId: targetSocId,
          details: { action, reason, extendDays, planId }
        });
        const updated = db.prepare("SELECT * FROM societies WHERE id = ?").get(targetSocId);
        return sendJson(res, 200, { society: updated, message: `Society action (${action || "EDIT"}) completed.` });
      }
      const saNotifyMatch = pathname.match(/^\/api\/super-admin\/societies\/([^/]+)\/notify$/);
      if (saNotifyMatch && method === "POST") {
        const targetSocId = saNotifyMatch[1];
        const society = db.prepare(`
          SELECT s.*, sp.name as plan_name, sp.price_amount as plan_price, sp.tax_percent as plan_tax_percent
          FROM societies s
          LEFT JOIN subscription_plans sp ON sp.id = s.subscription_plan_id
          WHERE s.id = ?
        `).get(targetSocId);
        if (!society) return sendJson(res, 404, { error: "Society not found." });
        const {
          title,
          message,
          notificationType = "SUBSCRIPTION_PAYMENT_DUE",
          amountDue,
          daysPending,
          createInvoice = true
        } = body;
        if (!title || !message) return sendJson(res, 400, { error: "Title and message are required." });
        if (notificationType === "SUBSCRIPTION_PAYMENT_DUE" && createInvoice) {
          const basePrice = Number(society.plan_price || 5499);
          const taxPct = Number(society.plan_tax_percent ?? 18);
          const taxAmt = Number((basePrice * taxPct / 100).toFixed(2));
          const computedTotal = Number(amountDue) > 0 ? Number(amountDue) : Number((basePrice + taxAmt).toFixed(2));
          const existingCreated = db.prepare("SELECT id FROM subscription_payments WHERE society_id = ? AND status = 'CREATED' ORDER BY created_at DESC LIMIT 1").get(targetSocId);
          if (!existingCreated) {
            const subPayId = uuid();
            const invNo = `SUB-INV-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e4 + Math.random() * 9e4)}`;
            db.prepare(`
              INSERT INTO subscription_payments (
                id, society_id, plan_id, invoice_number, amount, tax_amount, total_amount,
                payment_gateway, gateway_order_id, status
              ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RAZORPAY', ?, 'CREATED')
            `).run(
              subPayId,
              targetSocId,
              society.subscription_plan_id || "plan_growth",
              invNo,
              basePrice,
              taxAmt,
              computedTotal,
              `order_due_${subPayId.slice(0, 8)}`
            );
          }
        }
        sendNotification({
          societyId: targetSocId,
          userId: society.admin_user_id,
          notificationType,
          title,
          message,
          channel: "IN_APP"
        });
        logAudit({
          societyId: targetSocId,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUPER_ADMIN_SENT_NOTIFICATION",
          entityType: "NOTIFICATION",
          entityId: targetSocId,
          details: { title, notificationType, amountDue, daysPending }
        });
        return sendJson(res, 200, { message: "Subscription payment due & approval notification sent to Society Admin dashboard." });
      }
      if (pathname === "/api/super-admin/plans" && method === "POST") {
        const {
          code,
          name,
          description = "",
          billingPeriod = "MONTHLY",
          durationDays = 30,
          priceAmount,
          taxPercent = 18,
          taxName = "GST",
          maxHouseholds = 500,
          trialEnabled = true,
          trialDays = 14,
          gracePeriodDays = 7,
          autoApproveAfterPayment = true
        } = body;
        if (!code || !name || priceAmount === void 0) {
          return sendJson(res, 400, { error: "code, name, and priceAmount are required." });
        }
        const id = uuid();
        db.prepare(`
          INSERT INTO subscription_plans (
            id, code, name, description, billing_period, duration_days, price_amount, tax_percent, tax_name,
            max_households, trial_enabled, trial_days, grace_period_days, auto_approve_after_payment, is_active
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        `).run(
          id,
          String(code).toUpperCase().trim(),
          name,
          description,
          billingPeriod,
          Number(durationDays),
          Number(priceAmount),
          Number(taxPercent),
          String(taxName || "GST"),
          Number(maxHouseholds),
          trialEnabled ? 1 : 0,
          Number(trialDays),
          Number(gracePeriodDays),
          autoApproveAfterPayment ? 1 : 0
        );
        logAudit({
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "CREATED_SUBSCRIPTION_PLAN",
          entityType: "SUBSCRIPTION_PLAN",
          entityId: id,
          details: { code, name, priceAmount }
        });
        return sendJson(res, 201, { id, message: "Subscription plan created." });
      }
      const planMatch = pathname.match(/^\/api\/super-admin\/plans\/([^/]+)$/);
      if (planMatch && method === "PUT") {
        const planId = planMatch[1];
        const {
          name,
          priceAmount,
          taxPercent,
          maxHouseholds,
          trialEnabled,
          trialDays,
          gracePeriodDays,
          autoApproveAfterPayment,
          isActive
        } = body;
        db.prepare(`
          UPDATE subscription_plans
          SET name = COALESCE(?, name),
              price_amount = COALESCE(?, price_amount),
              tax_percent = COALESCE(?, tax_percent),
              max_households = COALESCE(?, max_households),
              trial_enabled = COALESCE(?, trial_enabled),
              trial_days = COALESCE(?, trial_days),
              grace_period_days = COALESCE(?, grace_period_days),
              auto_approve_after_payment = COALESCE(?, auto_approve_after_payment),
              is_active = COALESCE(?, is_active),
              updated_at = datetime('now')
          WHERE id = ?
        `).run(
          name ?? null,
          priceAmount !== void 0 ? Number(priceAmount) : null,
          taxPercent !== void 0 ? Number(taxPercent) : null,
          maxHouseholds !== void 0 ? Number(maxHouseholds) : null,
          trialEnabled !== void 0 ? trialEnabled ? 1 : 0 : null,
          trialDays !== void 0 ? Number(trialDays) : null,
          gracePeriodDays !== void 0 ? Number(gracePeriodDays) : null,
          autoApproveAfterPayment !== void 0 ? autoApproveAfterPayment ? 1 : 0 : null,
          isActive !== void 0 ? isActive ? 1 : 0 : null,
          planId
        );
        return sendJson(res, 200, { message: "Subscription plan updated." });
      }
      if (pathname === "/api/super-admin/settings" && method === "PUT") {
        const platformName = body.platformName ?? body.platform_name;
        const supportEmail = body.supportEmail ?? body.support_email;
        const supportPhone = body.supportPhone ?? body.support_phone;
        const defaultTrialEnabled = body.defaultTrialEnabled ?? body.default_trial_enabled;
        const defaultTrialDays = body.defaultTrialDays ?? body.default_trial_days;
        const defaultGracePeriodDays = body.defaultGracePeriodDays ?? body.default_grace_period_days;
        const autoApprovePaidSocieties = body.autoApprovePaidSocieties ?? body.auto_approve_paid_societies;
        const autoApproveTrialSocieties = body.autoApproveTrialSocieties ?? body.auto_approve_trial_societies;
        const reminderDaysBeforeExpiry = body.reminderDaysBeforeExpiry ?? body.reminder_days_before_expiry;
        const razorpayKeyId = body.razorpayKeyId ?? body.razorpay_key_id;
        const razorpayKeySecret = body.razorpayKeySecret ?? body.razorpay_key_secret;
        const razorpayWebhookSecret = body.razorpayWebhookSecret ?? body.razorpay_webhook_secret;
        const paytmMerchantId = body.paytmMerchantId ?? body.paytm_merchant_id;
        const paytmMerchantKey = body.paytmMerchantKey ?? body.paytm_merchant_key;
        const customGatewayName = body.customGatewayName ?? body.custom_gateway_name;
        const customGatewayApiKey = body.customGatewayApiKey ?? body.custom_gateway_api_key;
        const customGatewaySecret = body.customGatewaySecret ?? body.custom_gateway_secret;
        const upiId = body.upiId ?? body.upi_id;
        const upiPayeeName = body.upiPayeeName ?? body.upi_payee_name;
        const bankName = body.bankName ?? body.bank_name;
        const bankAccountNumber = body.bankAccountNumber ?? body.bank_account_number;
        const bankIfsc = body.bankIfsc ?? body.bank_ifsc;
        const razorpaySandboxMode = body.razorpaySandboxMode ?? body.razorpay_sandbox_mode;
        const welcomeEmailTemplate = body.welcomeEmailTemplate ?? body.welcome_email_template;
        const invoiceEmailTemplate = body.invoiceEmailTemplate ?? body.invoice_email_template;
        const overdueEmailTemplate = body.overdueEmailTemplate ?? body.overdue_email_template;
        const subscriptionTaxEnabled = body.subscriptionTaxEnabled ?? body.subscription_tax_enabled;
        const subscriptionTaxName = body.subscriptionTaxName ?? body.subscription_tax_name;
        const subscriptionTaxPercent = body.subscriptionTaxPercent ?? body.subscription_tax_percent;
        const razorpayEnabled = body.razorpayEnabled ?? body.razorpay_enabled;
        const upiPaymentEnabled = body.upiPaymentEnabled ?? body.upi_payment_enabled;
        const paytmEnabled = body.paytmEnabled ?? body.paytm_enabled;
        const customGatewayEnabled = body.customGatewayEnabled ?? body.custom_gateway_enabled;
        const metaTitle = body.metaTitle ?? body.meta_title;
        const metaDescription = body.metaDescription ?? body.meta_description;
        const metaKeywords = body.metaKeywords ?? body.meta_keywords;
        const metaAuthor = body.metaAuthor ?? body.meta_author;
        const metaOgImage = body.metaOgImage ?? body.meta_og_image;
        const faviconUrl = body.faviconUrl ?? body.favicon_url;
        const googleAdsenseEnabled = body.googleAdsenseEnabled ?? body.google_adsense_enabled;
        const googleAdsenseClientId = body.googleAdsenseClientId ?? body.google_adsense_client_id;
        const googleAdSlotHeader = body.googleAdSlotHeader ?? body.google_ad_slot_header;
        const googleAdSlotSidebar = body.googleAdSlotSidebar ?? body.google_ad_slot_sidebar;
        const googleAdSlotFooter = body.googleAdSlotFooter ?? body.google_ad_slot_footer;
        const googleAnalyticsId = body.googleAnalyticsId ?? body.google_analytics_id;
        const customHeaderScripts = body.customHeaderScripts ?? body.custom_header_scripts;
        const logoUrl = body.logoUrl ?? body.logo_url;
        const darkLogoUrl = body.darkLogoUrl ?? body.dark_logo_url;
        db.prepare(`
          UPDATE platform_settings
          SET platform_name = COALESCE(?, platform_name),
              support_email = COALESCE(?, support_email),
              support_phone = COALESCE(?, support_phone),
              default_trial_enabled = COALESCE(?, default_trial_enabled),
              default_trial_days = COALESCE(?, default_trial_days),
              default_grace_period_days = COALESCE(?, default_grace_period_days),
              auto_approve_paid_societies = COALESCE(?, auto_approve_paid_societies),
              auto_approve_trial_societies = COALESCE(?, auto_approve_trial_societies),
              reminder_days_before_expiry = COALESCE(?, reminder_days_before_expiry),
              razorpay_key_id = COALESCE(?, razorpay_key_id),
              razorpay_key_secret_encrypted = COALESCE(?, razorpay_key_secret_encrypted),
              razorpay_webhook_secret_encrypted = COALESCE(?, razorpay_webhook_secret_encrypted),
              paytm_merchant_id = COALESCE(?, paytm_merchant_id),
              paytm_merchant_key_encrypted = COALESCE(?, paytm_merchant_key_encrypted),
              custom_gateway_name = COALESCE(?, custom_gateway_name),
              custom_gateway_api_key = COALESCE(?, custom_gateway_api_key),
              custom_gateway_secret_encrypted = COALESCE(?, custom_gateway_secret_encrypted),
              upi_id = COALESCE(?, upi_id),
              upi_payee_name = COALESCE(?, upi_payee_name),
              bank_name = COALESCE(?, bank_name),
              bank_account_number = COALESCE(?, bank_account_number),
              bank_ifsc = COALESCE(?, bank_ifsc),
              razorpay_sandbox_mode = COALESCE(?, razorpay_sandbox_mode),
              welcome_email_template = COALESCE(?, welcome_email_template),
              invoice_email_template = COALESCE(?, invoice_email_template),
              overdue_email_template = COALESCE(?, overdue_email_template),
              subscription_tax_enabled = COALESCE(?, subscription_tax_enabled),
              subscription_tax_name = COALESCE(?, subscription_tax_name),
              subscription_tax_percent = COALESCE(?, subscription_tax_percent),
              razorpay_enabled = COALESCE(?, razorpay_enabled),
              upi_payment_enabled = COALESCE(?, upi_payment_enabled),
              paytm_enabled = COALESCE(?, paytm_enabled),
              custom_gateway_enabled = COALESCE(?, custom_gateway_enabled),
              meta_title = COALESCE(?, meta_title),
              meta_description = COALESCE(?, meta_description),
              meta_keywords = COALESCE(?, meta_keywords),
              meta_author = COALESCE(?, meta_author),
              meta_og_image = COALESCE(?, meta_og_image),
              favicon_url = COALESCE(?, favicon_url),
              google_adsense_enabled = COALESCE(?, google_adsense_enabled),
              google_adsense_client_id = COALESCE(?, google_adsense_client_id),
              google_ad_slot_header = COALESCE(?, google_ad_slot_header),
              google_ad_slot_sidebar = COALESCE(?, google_ad_slot_sidebar),
              google_ad_slot_footer = COALESCE(?, google_ad_slot_footer),
              google_analytics_id = COALESCE(?, google_analytics_id),
              custom_header_scripts = COALESCE(?, custom_header_scripts),
              logo_url = COALESCE(?, logo_url),
              dark_logo_url = COALESCE(?, dark_logo_url),
              updated_at = datetime('now')
          WHERE id = 'default'
        `).run(
          platformName !== void 0 ? platformName : null,
          supportEmail !== void 0 ? supportEmail : null,
          supportPhone !== void 0 ? supportPhone : null,
          defaultTrialEnabled !== void 0 ? defaultTrialEnabled ? 1 : 0 : null,
          defaultTrialDays !== void 0 ? Number(defaultTrialDays) : null,
          defaultGracePeriodDays !== void 0 ? Number(defaultGracePeriodDays) : null,
          autoApprovePaidSocieties !== void 0 ? autoApprovePaidSocieties ? 1 : 0 : null,
          autoApproveTrialSocieties !== void 0 ? autoApproveTrialSocieties ? 1 : 0 : null,
          reminderDaysBeforeExpiry !== void 0 ? Number(reminderDaysBeforeExpiry) : null,
          razorpayKeyId !== void 0 ? razorpayKeyId : null,
          razorpayKeySecret ? `enc_${razorpayKeySecret}` : null,
          razorpayWebhookSecret ? `enc_${razorpayWebhookSecret}` : null,
          paytmMerchantId !== void 0 ? paytmMerchantId : null,
          paytmMerchantKey ? `enc_${paytmMerchantKey}` : null,
          customGatewayName !== void 0 ? customGatewayName : null,
          customGatewayApiKey !== void 0 ? customGatewayApiKey : null,
          customGatewaySecret ? `enc_${customGatewaySecret}` : null,
          upiId !== void 0 ? upiId : null,
          upiPayeeName !== void 0 ? upiPayeeName : null,
          bankName !== void 0 ? bankName : null,
          bankAccountNumber !== void 0 ? bankAccountNumber : null,
          bankIfsc !== void 0 ? bankIfsc : null,
          razorpaySandboxMode !== void 0 ? razorpaySandboxMode ? 1 : 0 : null,
          welcomeEmailTemplate !== void 0 ? welcomeEmailTemplate : null,
          invoiceEmailTemplate !== void 0 ? invoiceEmailTemplate : null,
          overdueEmailTemplate !== void 0 ? overdueEmailTemplate : null,
          subscriptionTaxEnabled !== void 0 ? subscriptionTaxEnabled ? 1 : 0 : null,
          subscriptionTaxName !== void 0 ? subscriptionTaxName : null,
          subscriptionTaxPercent !== void 0 ? Number(subscriptionTaxPercent) : null,
          razorpayEnabled !== void 0 ? razorpayEnabled ? 1 : 0 : null,
          upiPaymentEnabled !== void 0 ? upiPaymentEnabled ? 1 : 0 : null,
          paytmEnabled !== void 0 ? paytmEnabled ? 1 : 0 : null,
          customGatewayEnabled !== void 0 ? customGatewayEnabled ? 1 : 0 : null,
          metaTitle !== void 0 ? metaTitle : null,
          metaDescription !== void 0 ? metaDescription : null,
          metaKeywords !== void 0 ? metaKeywords : null,
          metaAuthor !== void 0 ? metaAuthor : null,
          metaOgImage !== void 0 ? metaOgImage : null,
          faviconUrl !== void 0 ? faviconUrl : null,
          googleAdsenseEnabled !== void 0 ? googleAdsenseEnabled ? 1 : 0 : null,
          googleAdsenseClientId !== void 0 ? googleAdsenseClientId : null,
          googleAdSlotHeader !== void 0 ? googleAdSlotHeader : null,
          googleAdSlotSidebar !== void 0 ? googleAdSlotSidebar : null,
          googleAdSlotFooter !== void 0 ? googleAdSlotFooter : null,
          googleAnalyticsId !== void 0 ? googleAnalyticsId : null,
          customHeaderScripts !== void 0 ? customHeaderScripts : null,
          logoUrl !== void 0 ? logoUrl : null,
          darkLogoUrl !== void 0 ? darkLogoUrl : null
        );
        syncToMysqlAfterWrite();
        logAudit({
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "UPDATED_PLATFORM_SETTINGS",
          entityType: "PLATFORM_SETTINGS",
          entityId: "default"
        });
        return sendJson(res, 200, { message: "Platform settings, payment gateways, taxes, and customization updated successfully." });
      }
      const approveMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/(approve|mark-paid)$/);
      if (approveMatch && method === "POST") {
        const subPayId = approveMatch[1];
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(sp.plan_id);
        const durationDays = Number(plan?.duration_days || 30);
        const startsAt = (/* @__PURE__ */ new Date()).toISOString();
        const endsAt = new Date(Date.now() + durationDays * 864e5).toISOString();
        db.prepare(`
          UPDATE subscription_payments
          SET status = 'PAID',
              paid_at = datetime('now'),
              verified_by_user_id = ?,
              refund_reason = NULL,
              refund_amount = NULL,
              refund_reference = NULL,
              refunded_at = NULL,
              refund_notes = NULL
          WHERE id = ?
        `).run(auth.userId, subPayId);
        db.prepare(`
          UPDATE societies
          SET subscription_plan_id = ?,
              subscription_status = 'ACTIVE',
              approval_status = 'APPROVED',
              payment_status = 'PAID',
              subscription_starts_at = ?,
              subscription_ends_at = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(sp.plan_id, startsAt, endsAt, sp.society_id);
        sendNotification({
          userId: null,
          societyId: sp.society_id,
          title: `Subscription Payment Confirmed (${sp.invoice_number})`,
          message: `Subscription payment of \u20B9${sp.total_amount} confirmed! Society is active and approved until ${endsAt.slice(0, 10)}.`,
          type: "SUBSCRIPTION_PAYMENT_CONFIRMED",
          linkUrl: "/society-admin?tab=NOTIFICATIONS"
        });
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_PAYMENT_APPROVED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId
        });
        return sendJson(res, 200, { message: "Subscription payment verified and approved. Society is now Active & Approved." });
      }
      const autoVerifyMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/auto-verify$/);
      if (autoVerifyMatch && method === "POST") {
        const subPayId = autoVerifyMatch[1];
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        const ref = (sp.gateway_payment_id || "").trim();
        if (ref.length < 6) {
          return sendJson(res, 400, { error: "Payment reference UTR is too short for automated verification. Please inspect proof and confirm manually." });
        }
        const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(sp.plan_id);
        const durationDays = Number(plan?.duration_days || 30);
        const startsAt = (/* @__PURE__ */ new Date()).toISOString();
        const endsAt = new Date(Date.now() + durationDays * 864e5).toISOString();
        db.prepare(`
          UPDATE subscription_payments
          SET status = 'PAID',
              paid_at = datetime('now'),
              verified_by_user_id = ?,
              refund_reason = NULL,
              refund_amount = NULL,
              refund_reference = NULL,
              refunded_at = NULL,
              refund_notes = NULL
          WHERE id = ?
        `).run(auth.userId, subPayId);
        db.prepare(`
          UPDATE societies
          SET subscription_plan_id = ?,
              subscription_status = 'ACTIVE',
              approval_status = 'APPROVED',
              payment_status = 'PAID',
              subscription_starts_at = ?,
              subscription_ends_at = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(sp.plan_id, startsAt, endsAt, sp.society_id);
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_PAYMENT_AUTO_VERIFIED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId
        });
        return sendJson(res, 200, { message: "Subscription payment automatically verified via UTR algorithm! Society activated." });
      }
      const rejectMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/reject$/);
      if (rejectMatch && method === "POST") {
        const subPayId = rejectMatch[1];
        const { reason = "Payment reference could not be verified by Super Admin" } = body;
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        db.prepare(`
          UPDATE subscription_payments
          SET status = 'FAILED', rejection_reason = ?
          WHERE id = ?
        `).run(reason, subPayId);
        db.prepare("UPDATE societies SET payment_status = 'FAILED', updated_at = datetime('now') WHERE id = ?").run(sp.society_id);
        sendNotification({
          userId: null,
          societyId: sp.society_id,
          title: `Subscription Payment Rejected (${sp.invoice_number})`,
          message: `Your payment for invoice ${sp.invoice_number} could not be verified. Reason: ${reason}. Please resubmit valid payment details.`,
          type: "SUBSCRIPTION_PAYMENT_DUE",
          linkUrl: "/society-admin?tab=NOTIFICATIONS"
        });
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_PAYMENT_REJECTED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId,
          details: { reason }
        });
        return sendJson(res, 200, { message: "Subscription payment marked as rejected." });
      }
      const markUnpaidMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/mark-unpaid$/);
      if (markUnpaidMatch && method === "POST") {
        const subPayId = markUnpaidMatch[1];
        const { notes = "Payment marked as unpaid by Super Admin" } = body;
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        db.prepare(`
          UPDATE subscription_payments
          SET status = 'CREATED',
              paid_at = NULL,
              notes = ?,
              refund_reason = NULL,
              refund_amount = NULL,
              refund_reference = NULL,
              refunded_at = NULL,
              refund_notes = NULL
          WHERE id = ?
        `).run(notes, subPayId);
        db.prepare(`
          UPDATE societies
          SET payment_status = 'PENDING',
              subscription_status = 'PENDING_PAYMENT',
              approval_status = 'PENDING',
              updated_at = datetime('now')
          WHERE id = ?
        `).run(sp.society_id);
        sendNotification({
          userId: null,
          societyId: sp.society_id,
          title: `Subscription Marked Unpaid (${sp.invoice_number})`,
          message: `Your subscription invoice ${sp.invoice_number} is currently marked as unpaid. Please complete payment of \u20B9${sp.total_amount} to activate society services.`,
          type: "SUBSCRIPTION_PAYMENT_DUE",
          linkUrl: "/society-admin?tab=NOTIFICATIONS"
        });
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_PAYMENT_MARKED_UNPAID",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId,
          details: { notes }
        });
        return sendJson(res, 200, { message: "Subscription payment marked as Unpaid. Society status set to Pending Payment." });
      }
      const refundMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/refund$/);
      if (refundMatch && method === "POST") {
        const subPayId = refundMatch[1];
        const {
          reason = "Refund approved by Super Admin",
          refundAmount,
          refundReference = "",
          refundGateway = "UPI",
          refundNotes = ""
        } = body;
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        const finalRefundAmt = Number(refundAmount) > 0 ? Number(refundAmount) : Number(sp.total_amount);
        db.prepare(`
          UPDATE subscription_payments
          SET status = 'REFUNDED',
              refund_reason = ?,
              refund_amount = ?,
              refund_reference = ?,
              refund_gateway = ?,
              refund_notes = ?,
              refunded_at = datetime('now')
          WHERE id = ?
        `).run(reason, finalRefundAmt, refundReference || null, refundGateway, refundNotes || null, subPayId);
        db.prepare(`
          UPDATE societies
          SET payment_status = 'REFUNDED',
              subscription_status = 'EXPIRED',
              approval_status = 'PENDING',
              updated_at = datetime('now')
          WHERE id = ?
        `).run(sp.society_id);
        sendNotification({
          userId: null,
          societyId: sp.society_id,
          title: `Subscription Refund Issued (${sp.invoice_number})`,
          message: `A refund of \u20B9${finalRefundAmt} has been processed for invoice ${sp.invoice_number} (Ref: ${refundReference || "N/A"}). Reason: ${reason}. Your subscription is currently suspended until renewed.`,
          type: "SUBSCRIPTION_PAYMENT_DUE",
          linkUrl: "/society-admin?tab=NOTIFICATIONS"
        });
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_PAYMENT_REFUNDED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId,
          details: { reason, refundAmount: finalRefundAmt, refundReference, refundGateway }
        });
        return sendJson(res, 200, { message: `Subscription payment marked as refunded (\u20B9${finalRefundAmt} issued). Society status set to suspended/unpaid.` });
      }
      const updateRefundMatch = pathname.match(/^\/api\/super-admin\/subscription-payments\/([^/]+)\/update-refund$/);
      if (updateRefundMatch && method === "POST") {
        const subPayId = updateRefundMatch[1];
        const {
          reason,
          refundAmount,
          refundReference,
          refundGateway,
          refundNotes
        } = body;
        const sp = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(subPayId);
        if (!sp) return sendJson(res, 404, { error: "Subscription payment not found." });
        const finalRefundAmt = refundAmount !== void 0 ? Number(refundAmount) : sp.refund_amount || sp.total_amount;
        db.prepare(`
          UPDATE subscription_payments
          SET refund_reason = COALESCE(?, refund_reason),
              refund_amount = ?,
              refund_reference = COALESCE(?, refund_reference),
              refund_gateway = COALESCE(?, refund_gateway),
              refund_notes = COALESCE(?, refund_notes),
              refunded_at = COALESCE(refunded_at, datetime('now'))
          WHERE id = ?
        `).run(reason || null, finalRefundAmt, refundReference || null, refundGateway || null, refundNotes || null, subPayId);
        syncToMysqlAfterWrite();
        logAudit({
          societyId: sp.society_id,
          actorUserId: auth.userId,
          actorRole: "SUPER_ADMIN",
          action: "SUBSCRIPTION_REFUND_UPDATED",
          entityType: "SUBSCRIPTION_PAYMENT",
          entityId: subPayId,
          details: { reason, refundAmount: finalRefundAmt, refundReference }
        });
        return sendJson(res, 200, { message: "Refund issue details updated successfully." });
      }
    }
    if (pathname.startsWith("/api/society")) {
      let syncHouseholdOpeningBalance2 = function(socId, hhId, openingBalance, notes, creatorUserId) {
        const hh = db.prepare("SELECT * FROM households WHERE id = ? AND society_id = ?").get(hhId, socId);
        if (!hh) throw new Error("Household not found.");
        const opBal = Math.max(0, Number(Number(openingBalance || 0).toFixed(2)));
        const cleanNotes = notes ? String(notes).trim() : null;
        db.prepare(`
          UPDATE households
          SET opening_balance = ?,
              opening_balance_notes = ?,
              opening_balance_date = COALESCE(opening_balance_date, datetime('now')),
              updated_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(opBal, cleanNotes, hhId, socId);
        let cat = db.prepare("SELECT * FROM charge_categories WHERE society_id = ? AND code = 'OPENING_BALANCE'").get(socId);
        if (!cat) {
          const catId = uuid();
          db.prepare(`
            INSERT INTO charge_categories (
              id, society_id, name, code, description, default_amount, billing_frequency, applicable_flats, due_day, is_single_charge_per_period, is_active
            ) VALUES (?, ?, 'Opening Balance Dues', 'OPENING_BALANCE', 'Prior outstanding ledger balance before system onboarding', 0, 'ONE_TIME', 'ALL', 10, 1, 1)
          `).run(catId, socId);
          cat = { id: catId, name: "Opening Balance Dues", code: "OPENING_BALANCE" };
        }
        const existingBill = db.prepare(`
          SELECT * FROM member_bills
          WHERE society_id = ? AND household_id = ?
            AND (bill_type = 'OPENING_BALANCE' OR (bill_type = 'ADJUSTMENT' AND adjustment_reason = 'OPENING_BALANCE') OR bill_number LIKE 'OP-BAL-%')
            AND status != 'CANCELLED'
          LIMIT 1
        `).get(socId, hhId);
        if (opBal > 0) {
          if (existingBill) {
            const paid = Number(existingBill.paid_amount || 0);
            const newBal = Math.max(0, Number((opBal - paid).toFixed(2)));
            const newStatus = newBal === 0 ? "PAID" : paid > 0 ? "PARTIALLY_PAID" : "UNPAID";
            db.prepare(`
              UPDATE member_bills
              SET subtotal_amount = ?,
                  total_amount = ?,
                  balance_amount = ?,
                  status = ?,
                  adjustment_reason = 'OPENING_BALANCE',
                  updated_at = datetime('now')
              WHERE id = ?
            `).run(opBal, opBal, newBal, newStatus, existingBill.id);
            db.prepare(`
              UPDATE bill_items
              SET amount = ?, description = ?
              WHERE bill_id = ?
            `).run(opBal, cleanNotes || "Prior Outstanding Dues / Ledger Opening Balance", existingBill.id);
            return { billId: existingBill.id, balanceAmount: newBal };
          } else {
            const now = /* @__PURE__ */ new Date();
            const m = now.getMonth() + 1;
            const y = now.getFullYear();
            const billId = uuid();
            const billNumber = `OP-BAL-${hh.normalized_flat_number.replace(/[^A-Z0-9]/g, "")}-${billId.slice(0, 4).toUpperCase()}`;
            const dueDate = `${y}-${String(m).padStart(2, "0")}-28`;
            let insertBillType = "OPENING_BALANCE";
            try {
              db.prepare(`
                INSERT INTO member_bills (
                  id, society_id, household_id, member_id, bill_number, billing_month, billing_year,
                  bill_type, adjustment_reason, status, subtotal_amount, previous_balance, penalty_amount,
                  credit_amount, total_amount, paid_amount, balance_amount, due_date, issued_at, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OPENING_BALANCE', 'UNPAID', ?, 0, 0, 0, ?, 0, ?, ?, datetime('now'), ?)
              `).run(
                billId,
                socId,
                hh.id,
                hh.primary_member_id,
                billNumber,
                m,
                y,
                insertBillType,
                opBal,
                opBal,
                opBal,
                dueDate,
                creatorUserId ?? null
              );
            } catch (insErr) {
              if (String(insErr?.message || "").includes("CHECK constraint failed")) {
                insertBillType = "ADJUSTMENT";
                db.prepare(`
                  INSERT INTO member_bills (
                    id, society_id, household_id, member_id, bill_number, billing_month, billing_year,
                    bill_type, adjustment_reason, status, subtotal_amount, previous_balance, penalty_amount,
                    credit_amount, total_amount, paid_amount, balance_amount, due_date, issued_at, created_by
                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OPENING_BALANCE', 'UNPAID', ?, 0, 0, 0, ?, 0, ?, ?, datetime('now'), ?)
                `).run(
                  billId,
                  socId,
                  hh.id,
                  hh.primary_member_id,
                  billNumber,
                  m,
                  y,
                  insertBillType,
                  opBal,
                  opBal,
                  opBal,
                  dueDate,
                  creatorUserId ?? null
                );
              } else {
                throw insErr;
              }
            }
            db.prepare(`
              INSERT INTO bill_items (
                id, society_id, bill_id, household_id, charge_category_id, category_name,
                billing_month, billing_year, description, amount, is_adjustment
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            `).run(
              uuid(),
              socId,
              billId,
              hh.id,
              cat.id,
              cat.name,
              m,
              y,
              cleanNotes || "Prior Outstanding Dues / Ledger Opening Balance",
              opBal
            );
            return { billId, balanceAmount: opBal };
          }
        } else {
          if (existingBill && Number(existingBill.paid_amount || 0) === 0) {
            db.prepare("UPDATE member_bills SET status = 'CANCELLED', balance_amount = 0, updated_at = datetime('now') WHERE id = ?").run(existingBill.id);
          }
          return { balanceAmount: 0 };
        }
      };
      var syncHouseholdOpeningBalance = syncHouseholdOpeningBalance2;
      let reqPerm;
      if (pathname.startsWith("/api/society/members") || pathname.startsWith("/api/society/households") || pathname.startsWith("/api/society/blocks")) {
        reqPerm = method === "GET" ? "view_members" : "manage_members";
      } else if (pathname.startsWith("/api/society/charge-categories") || pathname.startsWith("/api/society/bills")) {
        reqPerm = method === "GET" ? void 0 : "generate_bills";
      } else if (pathname.startsWith("/api/society/payments")) {
        reqPerm = method === "GET" ? void 0 : "verify_payments";
      } else if (pathname.startsWith("/api/society/expenses") || pathname.startsWith("/api/society/expense-categories")) {
        reqPerm = method === "GET" ? "view_financial_reports" : "manage_expenses";
      } else if (pathname.startsWith("/api/society/reports")) {
        reqPerm = "view_financial_reports";
      } else if (pathname.startsWith("/api/society/complaints") || pathname.startsWith("/api/society/suggestions")) {
        reqPerm = method === "GET" ? void 0 : "manage_complaints";
      } else if (pathname.startsWith("/api/society/events") || pathname.startsWith("/api/society/announcements")) {
        reqPerm = method === "GET" ? void 0 : "manage_events";
      } else if (pathname.startsWith("/api/society/staff") || pathname.startsWith("/api/society/roles") || pathname.startsWith("/api/society/attendance")) {
        reqPerm = method === "GET" ? void 0 : "manage_staff";
      } else if (pathname.startsWith("/api/society/settings") || pathname === "/api/society/reset-data") {
        reqPerm = method === "GET" ? void 0 : "change_society_settings";
      }
      const access = hasSocietyAccess(auth, reqPerm);
      if (!access.ok || !access.societyId) {
        return sendJson(res, access.status, { error: access.error });
      }
      const societyId = access.societyId;
      if (pathname === "/api/society/dashboard" && method === "GET") {
        const currentMonth = Number(url.searchParams.get("month") || (/* @__PURE__ */ new Date()).getMonth() + 1);
        const currentYear = Number(url.searchParams.get("year") || (/* @__PURE__ */ new Date()).getFullYear());
        const totalHouseholds = db.prepare("SELECT COUNT(*) as c FROM households WHERE society_id = ? AND status != 'ARCHIVED'").get(societyId).c;
        const activeMembers = db.prepare("SELECT COUNT(*) as c FROM society_members WHERE society_id = ? AND account_status = 'ACTIVE' AND approval_status = 'APPROVED'").get(societyId).c;
        const pendingEnrolments = db.prepare("SELECT COUNT(*) as c FROM society_members WHERE society_id = ? AND approval_status = 'PENDING'").get(societyId).c;
        const blockedMembers = db.prepare("SELECT COUNT(*) as c FROM society_members WHERE society_id = ? AND account_status = 'BLOCKED'").get(societyId).c;
        const billsThisMonth = db.prepare("SELECT COUNT(*) as c FROM member_bills WHERE society_id = ? AND billing_month = ? AND billing_year = ? AND status != 'CANCELLED'").get(societyId, currentMonth, currentYear).c;
        const totalBilledAmount = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as s FROM member_bills WHERE society_id = ? AND status != 'CANCELLED' AND status != 'DRAFT'").get(societyId).s;
        const totalCollectedAmount = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE society_id = ? AND status = 'CONFIRMED'").get(societyId).s;
        const pendingVerificationAmount = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE society_id = ? AND status IN ('PENDING_VERIFICATION', 'PAYMENT_SUBMITTED')").get(societyId).s;
        const rejectedPaymentsAmount = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE society_id = ? AND status = 'REJECTED'").get(societyId).s;
        const totalOutstandingDues = db.prepare("SELECT COALESCE(SUM(balance_amount), 0) as s FROM member_bills WHERE society_id = ? AND status NOT IN ('PAID', 'CANCELLED', 'DRAFT')").get(societyId).s;
        const overdueBillsCount = db.prepare("SELECT COUNT(*) as c FROM member_bills WHERE society_id = ? AND balance_amount > 0 AND (status = 'OVERDUE' OR due_date < date('now')) AND status NOT IN ('PAID', 'CANCELLED', 'DRAFT')").get(societyId).c;
        const partialBillsCount = db.prepare("SELECT COUNT(*) as c FROM member_bills WHERE society_id = ? AND status = 'PARTIALLY_PAID'").get(societyId).c;
        const monthPrefix = `${currentYear}-${String(currentMonth).padStart(2, "0")}`;
        const monthlyIncome = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM ledger_entries WHERE society_id = ? AND entry_type = 'INCOME' AND entry_date LIKE ?").get(societyId, `${monthPrefix}%`).s;
        const monthlyExpenses = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM expenses WHERE society_id = ? AND status = 'APPROVED' AND expense_date LIKE ?").get(societyId, `${monthPrefix}%`).s;
        const cashAcc = db.prepare("SELECT current_balance FROM financial_accounts WHERE society_id = ? AND account_type = 'CASH'").get(societyId);
        const bankAcc = db.prepare("SELECT current_balance FROM financial_accounts WHERE society_id = ? AND account_type = 'BANK'").get(societyId);
        const openComplaints = db.prepare("SELECT COUNT(*) as c FROM complaints WHERE society_id = ? AND status IN ('SUBMITTED', 'IN_PROGRESS')").get(societyId).c;
        const resolvedComplaints = db.prepare("SELECT COUNT(*) as c FROM complaints WHERE society_id = ? AND status = 'RESOLVED'").get(societyId).c;
        const onDutyStaffCount = db.prepare("SELECT COUNT(*) as c FROM staff WHERE society_id = ? AND employment_status = 'ACTIVE' AND is_on_duty = 1").get(societyId).c;
        const recentPayments = db.prepare(`
          SELECT p.*, sm.full_name as member_name, h.flat_number
          FROM payments p
          JOIN society_members sm ON sm.id = p.member_id
          JOIN households h ON h.id = p.household_id
          WHERE p.society_id = ?
          ORDER BY p.created_at DESC LIMIT 8
        `).all(societyId);
        const recentEnrolments = db.prepare(`
          SELECT sm.*, h.flat_number, h.block_name, h.floor_number
          FROM society_members sm
          JOIN households h ON h.id = sm.household_id
          WHERE sm.society_id = ?
          ORDER BY sm.created_at DESC LIMIT 6
        `).all(societyId);
        const recentComplaints = db.prepare(`
          SELECT c.*, sm.full_name as member_name, st.full_name as assigned_staff_name
          FROM complaints c
          JOIN society_members sm ON sm.id = c.member_id
          LEFT JOIN staff st ON st.id = c.assigned_staff_id
          WHERE c.society_id = ?
          ORDER BY c.created_at DESC LIMIT 6
        `).all(societyId);
        const complaintAttachments = db.prepare("SELECT * FROM complaint_attachments WHERE society_id = ?").all(societyId);
        const complaintComments = db.prepare("SELECT * FROM complaint_comments WHERE society_id = ? ORDER BY created_at ASC").all(societyId);
        const enrichedRecentComplaints = recentComplaints.map((c) => ({
          ...c,
          attachments: complaintAttachments.filter((a) => a.complaint_id === c.id),
          comments: complaintComments.filter((cm) => cm.complaint_id === c.id)
        }));
        const recentExpenses = db.prepare(`
          SELECT * FROM expenses WHERE society_id = ? ORDER BY expense_date DESC, created_at DESC LIMIT 6
        `).all(societyId);
        const upcomingEvents = db.prepare(`
          SELECT * FROM society_events WHERE society_id = ? AND publication_status = 'PUBLISHED' ORDER BY event_date ASC LIMIT 5
        `).all(societyId);
        const society = db.prepare(`
          SELECT s.*,
                 sp.name as plan_name,
                 sp.code as plan_code,
                 sp.price_amount as plan_price,
                 sp.tax_percent as plan_tax_percent,
                 sp.billing_period as plan_billing_period,
                 sp.duration_days as plan_duration_days
          FROM societies s
          LEFT JOIN subscription_plans sp ON sp.id = s.subscription_plan_id
          WHERE s.id = ?
        `).get(societyId);
        const baseAmount = Number(society?.plan_price || 5499);
        const taxPercent = Number(society?.plan_tax_percent ?? 18);
        const taxAmount = Number((baseAmount * taxPercent / 100).toFixed(2));
        const totalAmountDue = Number((baseAmount + taxAmount).toFixed(2));
        const expiryDate = society?.subscription_ends_at || society?.trial_ends_at || null;
        const daysRemaining = expiryDate ? Math.ceil((new Date(expiryDate).getTime() - Date.now()) / 864e5) : 14;
        const pendingInvoice = db.prepare("SELECT * FROM subscription_payments WHERE society_id = ? AND status = 'CREATED' ORDER BY created_at DESC LIMIT 1").get(societyId);
        const superAdminNotifications = db.prepare(`
          SELECT * FROM notifications
          WHERE society_id = ? AND notification_type IN (
            'SUBSCRIPTION_PAYMENT_DUE',
            'PLATFORM_NOTICE',
            'SUBSCRIPTION_RENEWAL',
            'TRIAL_EXPIRY',
            'SUBSCRIPTION_PAYMENT_CONFIRMED'
          )
          ORDER BY created_at DESC LIMIT 50
        `).all(societyId);
        const allSocietyNotifications = db.prepare(`
          SELECT * FROM notifications
          WHERE society_id = ? OR user_id = ?
          ORDER BY created_at DESC LIMIT 100
        `).all(societyId, auth.userId);
        const subscriptionInvoices = db.prepare(`
          SELECT sp.*, p.name as plan_name, p.code as plan_code, p.billing_period as plan_billing_period
          FROM subscription_payments sp
          LEFT JOIN subscription_plans p ON p.id = sp.plan_id
          WHERE sp.society_id = ?
          ORDER BY sp.created_at DESC
        `).all(societyId);
        const latestSubPayment = subscriptionInvoices[0] || null;
        const isRefunded = latestSubPayment?.status === "REFUNDED";
        const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
        const subscriptionSummary = {
          planId: society?.subscription_plan_id || "plan_growth",
          planName: society?.plan_name || "Growth Society",
          planCode: society?.plan_code || "GROWTH_MONTHLY",
          billingPeriod: society?.plan_billing_period || "MONTHLY",
          durationDays: Number(society?.plan_duration_days || 30),
          baseAmount,
          taxPercent,
          taxAmount,
          totalAmountDue: pendingInvoice ? Number(pendingInvoice.total_amount) : totalAmountDue,
          subscriptionStatus: society?.subscription_status || "TRIAL",
          approvalStatus: society?.approval_status || "PENDING",
          paymentStatus: society?.payment_status || "TRIAL",
          expiryDate,
          daysRemaining,
          pendingInvoice: pendingInvoice || null,
          isRefunded,
          refundDetails: isRefunded ? {
            reason: latestSubPayment?.refund_reason,
            amount: latestSubPayment?.refund_amount || latestSubPayment?.total_amount,
            reference: latestSubPayment?.refund_reference,
            date: latestSubPayment?.refunded_at || latestSubPayment?.created_at,
            gateway: latestSubPayment?.refund_gateway,
            notes: latestSubPayment?.refund_notes
          } : null,
          platformUpiId: platform?.upi_id || "",
          platformUpiPayeeName: platform?.upi_payee_name || "SocietyOS Platform",
          platformBankName: platform?.bank_name || "",
          platformBankAccountNumber: platform?.bank_account_number || "",
          platformBankIfsc: platform?.bank_ifsc || "",
          razorpayEnabled: Boolean(platform?.razorpay_enabled ?? 1),
          upiPaymentEnabled: Boolean(platform?.upi_payment_enabled ?? 1),
          paytmEnabled: Boolean(platform?.paytm_enabled ?? 0),
          customGatewayEnabled: Boolean(platform?.custom_gateway_enabled ?? 0),
          subscriptionTaxEnabled: Boolean(platform?.subscription_tax_enabled ?? 1),
          subscriptionTaxName: platform?.subscription_tax_name || "GST",
          subscriptionTaxPercent: Number(platform?.subscription_tax_percent ?? 18)
        };
        return sendJson(res, 200, {
          society: society ? {
            ...society,
            tax_amount: taxAmount,
            total_amount_due: subscriptionSummary.totalAmountDue,
            days_remaining: daysRemaining
          } : null,
          subscriptionSummary,
          subscriptionInvoices,
          superAdminNotifications,
          allSocietyNotifications,
          kpis: {
            totalRegisteredHouseholds: totalHouseholds,
            activeMembers,
            pendingEnrolmentApprovals: pendingEnrolments,
            blockedMembers,
            billsIssuedThisMonth: billsThisMonth,
            totalBilledAmount,
            totalCollectedAmount,
            pendingPaymentVerification: pendingVerificationAmount,
            rejectedPaymentsAmount,
            totalOutstandingDues,
            overdueBills: overdueBillsCount,
            partialPaymentsCount: partialBillsCount,
            monthlyIncome,
            monthlyExpenses,
            currentCashBalance: cashAcc?.current_balance ?? 0,
            currentBankBalance: bankAcc?.current_balance ?? 0,
            openComplaints,
            resolvedComplaints,
            onDutyStaff: onDutyStaffCount
          },
          recentPayments,
          recentEnrolments,
          recentComplaints: enrichedRecentComplaints,
          recentExpenses,
          upcomingEvents
        });
      }
      if (pathname === "/api/society/notifications" && method === "GET") {
        const notifications = db.prepare(`
          SELECT * FROM notifications
          WHERE society_id = ? OR user_id = ?
          ORDER BY created_at DESC LIMIT 150
        `).all(societyId, auth.userId);
        return sendJson(res, 200, { notifications });
      }
      if (pathname === "/api/society/subscription/invoices" && method === "GET") {
        const invoices = db.prepare(`
          SELECT sp.*, p.name as plan_name, p.code as plan_code, p.billing_period as plan_billing_period
          FROM subscription_payments sp
          LEFT JOIN subscription_plans p ON p.id = sp.plan_id
          WHERE sp.society_id = ?
          ORDER BY sp.created_at DESC
        `).all(societyId);
        return sendJson(res, 200, { invoices });
      }
      if (pathname === "/api/society/subscription/submit-upi" && method === "POST") {
        const { utr, transactionReference, planId, amount, receiptUrl, notes } = body;
        const ref = String(utr || transactionReference || "").trim();
        if (!ref) {
          return sendJson(res, 400, { error: "UPI transaction reference / UTR is required." });
        }
        const soc = db.prepare("SELECT * FROM societies WHERE id = ?").get(societyId);
        const targetPlanId = planId || soc?.subscription_plan_id || "plan-quarterly-growth";
        const plan = db.prepare("SELECT * FROM subscription_plans WHERE id = ?").get(targetPlanId);
        const platform = db.prepare("SELECT * FROM platform_settings LIMIT 1").get();
        const basePrice = Number(plan?.price_amount || 5499);
        const taxEnabled = Boolean(platform?.subscription_tax_enabled ?? 1);
        const taxPct = taxEnabled ? Number(plan?.tax_percent ?? platform?.subscription_tax_percent ?? 18) : 0;
        const taxAmt = taxEnabled ? Number((basePrice * taxPct / 100).toFixed(2)) : 0;
        const totalAmt = Number(amount) > 0 ? Number(amount) : Number((basePrice + taxAmt).toFixed(2));
        const subPayId = uuid();
        const invNo = `SUB-INV-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e4 + Math.random() * 9e4)}`;
        db.prepare(`
          INSERT INTO subscription_payments (
            id, society_id, plan_id, invoice_number, amount, tax_amount, total_amount,
            payment_gateway, gateway_order_id, gateway_payment_id, receipt_url, notes, status, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'UPI', 'UPI_DIRECT_TRANSFER', ?, ?, ?, 'PENDING_APPROVAL', datetime('now'))
        `).run(subPayId, societyId, targetPlanId, invNo, basePrice, taxAmt, totalAmt, ref, receiptUrl || null, notes || null);
        db.prepare("UPDATE societies SET payment_status = 'PENDING', updated_at = datetime('now') WHERE id = ?").run(societyId);
        sendNotification({
          userId: "usr_super_admin",
          societyId: null,
          title: `New Subscription Payment Proof (${invNo})`,
          message: `${soc?.name || "A society"} submitted UPI payment of \u20B9${totalAmt} (UTR: ${ref}) for verification.`,
          type: "PAYMENT_RECEIVED",
          linkUrl: "/super-admin?tab=PAYMENTS"
        });
        syncToMysqlAfterWrite();
        return sendJson(res, 201, {
          id: subPayId,
          invoiceNumber: invNo,
          message: "UPI payment reference and receipt proof submitted successfully. Super Admin will verify and activate your subscription."
        });
      }
      if (pathname === "/api/society/members" && method === "GET") {
        const search = (url.searchParams.get("search") || "").trim().toLowerCase();
        const status = url.searchParams.get("status") || "";
        const block = url.searchParams.get("block") || "";
        const members = db.prepare(`
          SELECT sm.*, h.flat_number, h.normalized_flat_number, h.block_name, h.floor_number, h.occupancy_type, h.area_sqft,
                 h.opening_balance, h.opening_balance_notes, h.opening_balance_date,
                 COALESCE((
                   SELECT SUM(mb.balance_amount)
                   FROM member_bills mb
                   WHERE mb.household_id = h.id
                     AND (mb.bill_type = 'OPENING_BALANCE' OR (mb.bill_type = 'ADJUSTMENT' AND mb.adjustment_reason = 'OPENING_BALANCE') OR mb.bill_number LIKE 'OP-BAL-%')
                     AND mb.status NOT IN ('PAID', 'CANCELLED', 'DRAFT')
                 ), 0) as opening_balance_dues
          FROM society_members sm
          JOIN households h ON h.id = sm.household_id
          WHERE sm.society_id = ?
          ORDER BY h.normalized_flat_number ASC, sm.is_primary_member DESC
        `).all(societyId);
        const filtered = members.filter((m) => {
          if (search) {
            const hay = `${m.full_name} ${m.email} ${m.phone} ${m.flat_number} ${m.block_name}`.toLowerCase();
            if (!hay.includes(search)) return false;
          }
          if (status && m.account_status !== status && m.approval_status !== status) return false;
          if (block && m.block_name !== block) return false;
          return true;
        });
        const households = db.prepare(`
          SELECT h.*,
                 COALESCE((
                   SELECT SUM(mb.balance_amount)
                   FROM member_bills mb
                   WHERE mb.household_id = h.id
                     AND (mb.bill_type = 'OPENING_BALANCE' OR (mb.bill_type = 'ADJUSTMENT' AND mb.adjustment_reason = 'OPENING_BALANCE') OR mb.bill_number LIKE 'OP-BAL-%')
                     AND mb.status NOT IN ('PAID', 'CANCELLED', 'DRAFT')
                 ), 0) as opening_balance_dues
          FROM households h
          WHERE h.society_id = ? AND h.status != 'ARCHIVED'
          ORDER BY h.normalized_flat_number ASC
        `).all(societyId);
        const blocks = db.prepare("SELECT * FROM apartment_blocks WHERE society_id = ? ORDER BY name ASC").all(societyId);
        return sendJson(res, 200, { members: filtered, households, blocks });
      }
      if (pathname === "/api/society/blocks" && method === "GET") {
        const blocks = db.prepare("SELECT * FROM apartment_blocks WHERE society_id = ? ORDER BY name ASC").all(societyId);
        return sendJson(res, 200, { blocks });
      }
      if (pathname === "/api/society/blocks" && method === "POST") {
        const { name, totalFloors = 10, description = "" } = body;
        if (!name || !String(name).trim()) return sendJson(res, 400, { error: "Block name is required." });
        const blockName = String(name).trim();
        const existing = db.prepare("SELECT id, name FROM apartment_blocks WHERE society_id = ? AND LOWER(name) = LOWER(?) LIMIT 1").get(societyId, blockName);
        if (existing) {
          return sendJson(res, 200, { id: existing.id, name: existing.name, message: "Apartment block already exists." });
        }
        const id = uuid();
        db.prepare(`
          INSERT INTO apartment_blocks (id, society_id, name, total_floors, description)
          VALUES (?, ?, ?, ?, ?)
        `).run(id, societyId, blockName, Number(totalFloors), description);
        syncToMysqlAfterWrite();
        return sendJson(res, 201, { id, name: blockName, message: "Apartment block added." });
      }
      const editBlockMatch = pathname.match(/^\/api\/society\/blocks\/([^/]+)$/);
      if ((editBlockMatch || pathname === "/api/society/blocks") && method === "PUT") {
        const blockId = editBlockMatch ? editBlockMatch[1] : body.id;
        const { name, totalFloors, description } = body;
        if (!name || !String(name).trim()) return sendJson(res, 400, { error: "Block name is required." });
        const newBlockName = String(name).trim();
        const existing = db.prepare("SELECT * FROM apartment_blocks WHERE id = ? AND society_id = ?").get(blockId, societyId);
        if (!existing) return sendJson(res, 404, { error: "Block not found." });
        const duplicate = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND LOWER(name) = LOWER(?) AND id != ? LIMIT 1").get(societyId, newBlockName, blockId);
        if (duplicate) return sendJson(res, 400, { error: "Another block with this name already exists in your society." });
        const oldName = existing.name;
        db.prepare(`
          UPDATE apartment_blocks
          SET name = ?,
              total_floors = COALESCE(?, total_floors),
              description = COALESCE(?, description)
          WHERE id = ? AND society_id = ?
        `).run(newBlockName, totalFloors !== void 0 ? Number(totalFloors) : null, description !== void 0 ? String(description) : null, blockId, societyId);
        db.prepare("UPDATE households SET block_name = ? WHERE society_id = ? AND (block_id = ? OR block_name = ?)").run(newBlockName, societyId, blockId, oldName);
        syncToMysqlAfterWrite();
        return sendJson(res, 200, { message: `Block updated to '${newBlockName}'. Associated flats synced.` });
      }
      if (pathname === "/api/society/members" && method === "POST") {
        const {
          fullName,
          email,
          phone,
          password = "Member@123",
          flatNumber,
          blockName = "Block A",
          floorNumber = "1",
          areaSqft = 1200,
          ownershipType = "OWNER",
          emergencyContact = "",
          photoUrl = null,
          enrolmentMode = "NEW_HOUSEHOLD",
          // 'NEW_HOUSEHOLD' or 'FAMILY_MEMBER'
          existingHouseholdId = null,
          relationshipToPrimary = "PRIMARY",
          openingBalance = 0,
          openingBalanceNotes = ""
        } = body;
        if (!fullName || !email || !phone || !flatNumber) {
          return sendJson(res, 400, { error: "Full name, email, phone, and flat number are required." });
        }
        if (!isValid10DigitPhone(phone)) {
          return sendJson(res, 400, { error: "Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9." });
        }
        if (!fullName || !email || !phone || !flatNumber) {
          return sendJson(res, 400, { error: "Full name, email, phone, and flat/house number are required." });
        }
        const cleanEmail = String(email).trim().toLowerCase();
        if (db.prepare("SELECT id FROM users WHERE email = ?").get(cleanEmail)) {
          return sendJson(res, 409, { error: "Email address is already registered." });
        }
        const normalizedFlat = normalizeFlatNumber(String(flatNumber));
        if (!normalizedFlat) {
          return sendJson(res, 400, { error: "Valid flat/house number is required." });
        }
        db.exec("BEGIN IMMEDIATE");
        try {
          let householdId;
          let isPrimary = 1;
          if (enrolmentMode === "FAMILY_MEMBER") {
            const targetHh = db.prepare(`
              SELECT id FROM households
              WHERE society_id = ? AND (id = ? OR normalized_flat_number = ?) AND status != 'ARCHIVED'
            `).get(societyId, existingHouseholdId, normalizedFlat);
            if (!targetHh) {
              db.exec("ROLLBACK");
              return sendJson(res, 404, { error: "Household not found to link family member." });
            }
            householdId = targetHh.id;
            isPrimary = 0;
          } else {
            const existingHh = db.prepare(`
              SELECT id FROM households
              WHERE society_id = ? AND normalized_flat_number = ? AND status != 'ARCHIVED'
            `).get(societyId, normalizedFlat);
            if (existingHh) {
              db.exec("ROLLBACK");
              return sendJson(res, 409, {
                error: "This flat/house number is already registered in this society."
              });
            }
            householdId = uuid();
            const blockRow = db.prepare("SELECT id FROM apartment_blocks WHERE society_id = ? AND name = ?").get(societyId, blockName);
            db.prepare(`
              INSERT INTO households (
                id, society_id, block_id, block_name, floor_number, flat_number,
                normalized_flat_number, occupancy_type, area_sqft, status
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE')
            `).run(
              householdId,
              societyId,
              blockRow?.id ?? null,
              String(blockName).trim(),
              String(floorNumber).trim(),
              String(flatNumber).trim(),
              normalizedFlat,
              ownershipType === "TENANT" ? "TENANT" : "OWNER",
              Number(areaSqft || 1200)
            );
          }
          const userId = uuid();
          const memberId = uuid();
          db.prepare(`
            INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
            VALUES (?, ?, ?, ?, 'MEMBER', ?, 1, 1)
          `).run(userId, cleanEmail, String(phone).trim(), hashPassword(String(password)), societyId);
          db.prepare(`
            INSERT INTO user_profiles (id, user_id, society_id, full_name, avatar_url, address, emergency_contact_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `).run(uuid(), userId, societyId, String(fullName).trim(), photoUrl, `${flatNumber}, ${blockName}`, String(emergencyContact).trim());
          db.prepare(`
            INSERT INTO society_members (
              id, society_id, household_id, user_id, full_name, email, phone, photo_url,
              relationship_to_primary, is_primary_member, ownership_type, emergency_contact,
              approval_status, account_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'APPROVED', 'ACTIVE')
          `).run(
            memberId,
            societyId,
            householdId,
            userId,
            String(fullName).trim(),
            cleanEmail,
            String(phone).trim(),
            photoUrl,
            isPrimary ? "PRIMARY" : String(relationshipToPrimary || "FAMILY"),
            isPrimary,
            isPrimary ? ownershipType === "TENANT" ? "TENANT" : "OWNER" : "FAMILY",
            String(emergencyContact).trim()
          );
          if (isPrimary) {
            db.prepare("UPDATE households SET primary_member_id = ? WHERE id = ?").run(memberId, householdId);
          }
          const opBalNum = Number(openingBalance || 0);
          if (opBalNum > 0 || openingBalanceNotes && String(openingBalanceNotes).trim()) {
            syncHouseholdOpeningBalance2(societyId, householdId, opBalNum, openingBalanceNotes, auth?.userId);
          }
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "MEMBER_CREATED",
            entityType: "SOCIETY_MEMBER",
            entityId: memberId,
            details: { flatNumber: normalizedFlat, fullName, enrolmentMode }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { memberId, householdId, normalizedFlatNumber: normalizedFlat, message: "Member enrolled successfully." });
        } catch (err) {
          console.error("[RESET ERROR]", err);
          db.exec("ROLLBACK");
          if (String(err?.message || "").includes("UNIQUE constraint failed")) {
            return sendJson(res, 409, { error: "This flat/house number is already registered in this society." });
          }
          throw err;
        }
      }
      const memberActionMatch = pathname.match(/^\/api\/society\/members\/([^/]+)$/);
      if (memberActionMatch && method === "PUT") {
        const memberId = memberActionMatch[1];
        const member = db.prepare("SELECT * FROM society_members WHERE id = ? AND society_id = ?").get(memberId, societyId);
        if (!member) return sendJson(res, 404, { error: "Member not found in your society." });
        const { action, fullName, phone, ownershipType, emergencyContact } = body;
        if (action === "APPROVE") {
          db.prepare("UPDATE society_members SET approval_status = 'APPROVED', account_status = 'ACTIVE', updated_at = datetime('now') WHERE id = ?").run(memberId);
          sendNotification({
            societyId,
            userId: member.user_id,
            notificationType: "ENROLMENT_APPROVED",
            title: "Your Society Enrolment is Approved",
            message: "Welcome! Your society membership has been approved by the administrator."
          });
        } else if (action === "REJECT") {
          db.prepare("UPDATE society_members SET approval_status = 'REJECTED', account_status = 'ARCHIVED', updated_at = datetime('now') WHERE id = ?").run(memberId);
        } else if (action === "BLOCK") {
          db.prepare("UPDATE society_members SET account_status = 'BLOCKED', updated_at = datetime('now') WHERE id = ?").run(memberId);
          db.prepare("UPDATE users SET is_active = 0 WHERE id = ?").run(member.user_id);
        } else if (action === "REACTIVATE") {
          db.prepare("UPDATE society_members SET account_status = 'ACTIVE', updated_at = datetime('now') WHERE id = ?").run(memberId);
          db.prepare("UPDATE users SET is_active = 1 WHERE id = ?").run(member.user_id);
        } else if (action === "ARCHIVE") {
          db.prepare("UPDATE society_members SET account_status = 'ARCHIVED', updated_at = datetime('now') WHERE id = ?").run(memberId);
          db.prepare("UPDATE households SET status = 'ARCHIVED', updated_at = datetime('now') WHERE id = ? AND primary_member_id = ?").run(member.household_id, memberId);
        } else {
          db.prepare(`
            UPDATE society_members
            SET full_name = COALESCE(?, full_name),
                phone = COALESCE(?, phone),
                ownership_type = COALESCE(?, ownership_type),
                emergency_contact = COALESCE(?, emergency_contact),
                updated_at = datetime('now')
            WHERE id = ? AND society_id = ?
          `).run(fullName ?? null, phone ?? null, ownershipType ?? null, emergencyContact ?? null, memberId, societyId);
        }
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: `MEMBER_${action || "UPDATED"}`,
          entityType: "SOCIETY_MEMBER",
          entityId: memberId
        });
        return sendJson(res, 200, { message: "Member record updated." });
      }
      if (memberActionMatch && method === "DELETE") {
        const memberId = memberActionMatch[1];
        const member = db.prepare("SELECT * FROM society_members WHERE id = ? AND society_id = ?").get(memberId, societyId);
        if (!member) return sendJson(res, 404, { error: "Member not found in your society." });
        db.exec("BEGIN IMMEDIATE");
        try {
          const hhId = member.household_id;
          const otherMembers = db.prepare("SELECT id FROM society_members WHERE household_id = ? AND id != ?").all(hhId, memberId);
          if (otherMembers.length === 0) {
            db.prepare("DELETE FROM member_bills WHERE household_id = ? AND society_id = ?").run(hhId, societyId);
            db.prepare("DELETE FROM payments WHERE household_id = ? AND society_id = ?").run(hhId, societyId);
            db.prepare("DELETE FROM households WHERE id = ? AND society_id = ?").run(hhId, societyId);
          } else {
            if (member.is_primary_member) {
              const newPrimaryId = otherMembers[0].id;
              db.prepare("UPDATE society_members SET is_primary_member = 1 WHERE id = ?").run(newPrimaryId);
              db.prepare("UPDATE households SET primary_member_id = ? WHERE id = ?").run(newPrimaryId, hhId);
            }
          }
          db.prepare("DELETE FROM complaint_attachments WHERE uploaded_by = ? AND society_id = ?").run(member.user_id, societyId);
          db.prepare("DELETE FROM complaints WHERE member_id = ? AND society_id = ?").run(memberId, societyId);
          db.prepare("DELETE FROM suggestions WHERE member_id = ? AND society_id = ?").run(memberId, societyId);
          db.prepare("DELETE FROM society_members WHERE id = ? AND society_id = ?").run(memberId, societyId);
          if (member.user_id) {
            const u = db.prepare("SELECT role FROM users WHERE id = ?").get(member.user_id);
            if (u && u.role === "MEMBER") {
              db.prepare("DELETE FROM users WHERE id = ?").run(member.user_id);
            }
          }
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "MEMBER_DELETED",
            entityType: "SOCIETY_MEMBER",
            entityId: memberId,
            details: { memberName: member.full_name, flatNumber: member.flat_number }
          });
          db.exec("COMMIT");
          syncToMysqlAfterWrite();
          return sendJson(res, 200, { message: `Member ${member.full_name} (Flat ${member.flat_number}) deleted successfully.` });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      const transferHhMatch = pathname.match(/^\/api\/society\/households\/([^/]+)\/transfer$/);
      if (transferHhMatch && method === "POST") {
        const hhId = transferHhMatch[1];
        const hh = db.prepare("SELECT * FROM households WHERE id = ? AND society_id = ?").get(hhId, societyId);
        if (!hh) return sendJson(res, 404, { error: "Household not found." });
        const { newFlatNumber, newBlockName, newFloorNumber, reason } = body;
        if (!newFlatNumber || !reason) {
          return sendJson(res, 400, { error: "newFlatNumber and reason are required for a logged household transfer/correction." });
        }
        const normalizedNew = normalizeFlatNumber(String(newFlatNumber));
        const conflict = db.prepare(`
          SELECT id FROM households
          WHERE society_id = ? AND normalized_flat_number = ? AND id != ? AND status != 'ARCHIVED'
        `).get(societyId, normalizedNew, hhId);
        if (conflict) {
          return sendJson(res, 409, { error: "This flat/house number is already registered in this society." });
        }
        db.prepare(`
          UPDATE households
          SET flat_number = ?, normalized_flat_number = ?,
              block_name = COALESCE(?, block_name),
              floor_number = COALESCE(?, floor_number),
              updated_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(String(newFlatNumber).trim(), normalizedNew, newBlockName ?? null, newFloorNumber ?? null, hhId, societyId);
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: "HOUSEHOLD_REGISTRATION_TRANSFERRED",
          entityType: "HOUSEHOLD",
          entityId: hhId,
          details: { previousFlat: hh.normalized_flat_number, newFlat: normalizedNew, reason }
        });
        return sendJson(res, 200, { message: `Household updated to ${normalizedNew} and logged in audit trail.` });
      }
      const openingBalMatch = pathname.match(/^\/api\/society\/households\/([^/]+)\/opening-balance$/);
      if (openingBalMatch && method === "POST") {
        const hhId = openingBalMatch[1];
        const hh = db.prepare("SELECT * FROM households WHERE id = ? AND society_id = ?").get(hhId, societyId);
        if (!hh) return sendJson(res, 404, { error: "Household not found." });
        const { openingBalance, notes } = body;
        if (openingBalance === void 0 || openingBalance === null || isNaN(Number(openingBalance)) || Number(openingBalance) < 0) {
          return sendJson(res, 400, { error: "A valid non-negative opening balance amount is required." });
        }
        const result = syncHouseholdOpeningBalance2(societyId, hhId, Number(openingBalance), notes, auth?.userId);
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: "HOUSEHOLD_OPENING_BALANCE_UPDATED",
          entityType: "HOUSEHOLD",
          entityId: hhId,
          details: { flatNumber: hh.normalized_flat_number, openingBalance: Number(openingBalance), notes }
        });
        return sendJson(res, 200, {
          success: true,
          message: `Opening balance for Flat ${hh.normalized_flat_number} updated to \u20B9${Number(openingBalance).toFixed(2)}.`,
          ...result
        });
      }
      if (pathname === "/api/society/charge-categories" && method === "GET") {
        const categories = db.prepare("SELECT * FROM charge_categories WHERE society_id = ? ORDER BY created_at ASC").all(societyId);
        return sendJson(res, 200, { categories });
      }
      if (pathname === "/api/society/charge-categories" && method === "POST") {
        const {
          name,
          description = "",
          defaultAmount,
          billingFrequency = "MONTHLY",
          applicableFlats = "ALL",
          dueDay = 10,
          isActive = true
        } = body;
        if (!name || defaultAmount === void 0) {
          return sendJson(res, 400, { error: "Category name and default amount are required." });
        }
        const code = String(name).toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "");
        const existing = db.prepare("SELECT id FROM charge_categories WHERE society_id = ? AND code = ?").get(societyId, code);
        if (existing) {
          return sendJson(res, 409, { error: "A charge category with this name already exists in your society." });
        }
        const id = uuid();
        db.prepare(`
          INSERT INTO charge_categories (
            id, society_id, name, code, description, default_amount, billing_frequency,
            applicable_flats, due_day, is_single_charge_per_period, is_active
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        `).run(
          id,
          societyId,
          String(name).trim(),
          code,
          description,
          Number(defaultAmount),
          billingFrequency,
          applicableFlats || "ALL",
          Number(dueDay || 10),
          isActive ? 1 : 0
        );
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: "CHARGE_CATEGORY_CREATED",
          entityType: "CHARGE_CATEGORY",
          entityId: id,
          details: { name, defaultAmount, billingFrequency }
        });
        return sendJson(res, 201, { id, message: "Custom charge category added." });
      }
      const catMatch = pathname.match(/^\/api\/society\/charge-categories\/([^/]+)$/);
      if (catMatch && method === "PUT") {
        const catId = catMatch[1];
        const { name, description, defaultAmount, billingFrequency, applicableFlats, dueDay, isActive } = body;
        db.prepare(`
          UPDATE charge_categories
          SET name = COALESCE(?, name),
              description = COALESCE(?, description),
              default_amount = COALESCE(?, default_amount),
              billing_frequency = COALESCE(?, billing_frequency),
              applicable_flats = COALESCE(?, applicable_flats),
              due_day = COALESCE(?, due_day),
              is_active = COALESCE(?, is_active),
              updated_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(
          name ?? null,
          description ?? null,
          defaultAmount !== void 0 ? Number(defaultAmount) : null,
          billingFrequency ?? null,
          applicableFlats ?? null,
          dueDay !== void 0 ? Number(dueDay) : null,
          isActive !== void 0 ? isActive ? 1 : 0 : null,
          catId,
          societyId
        );
        return sendJson(res, 200, { message: "Charge category updated." });
      }
      if (pathname === "/api/society/bills" && method === "GET") {
        const month = url.searchParams.get("month");
        const year = url.searchParams.get("year");
        const status = url.searchParams.get("status");
        const search = (url.searchParams.get("search") || "").trim().toLowerCase();
        const bills = db.prepare(`
          SELECT mb.*,
                 COALESCE(h.flat_number, '') as flat_number,
                 COALESCE(h.normalized_flat_number, '') as normalized_flat_number,
                 COALESCE(h.block_name, 'A') as block_name,
                 COALESCE(sm.full_name, 'Household Member') as member_name,
                 COALESCE(sm.full_name, 'Household Member') as primary_member_name,
                 sm.email as member_email,
                 sm.phone as member_phone
          FROM member_bills mb
          LEFT JOIN households h ON h.id = mb.household_id
          LEFT JOIN society_members sm ON sm.id = mb.member_id
          WHERE mb.society_id = ?
          ORDER BY mb.billing_year DESC, mb.billing_month DESC, mb.created_at DESC
        `).all(societyId);
        const items = db.prepare("SELECT * FROM bill_items WHERE society_id = ?").all(societyId);
        const itemsByBill = /* @__PURE__ */ new Map();
        for (const item of items) {
          const list = itemsByBill.get(item.bill_id) || [];
          list.push(item);
          itemsByBill.set(item.bill_id, list);
        }
        const enriched = bills.map((b) => ({ ...b, items: itemsByBill.get(b.id) || [] })).filter((b) => {
          if (month && Number(b.billing_month) !== Number(month)) return false;
          if (year && Number(b.billing_year) !== Number(year)) return false;
          if (status && b.status !== status) return false;
          if (search) {
            const hay = `${b.bill_number} ${b.flat_number} ${b.member_name || ""}`.toLowerCase();
            if (!hay.includes(search)) return false;
          }
          return true;
        });
        return sendJson(res, 200, { bills: enriched });
      }
      const singleBillMatch = pathname.match(/^\/api\/society\/bills\/([^/]+)$/);
      if (singleBillMatch && method === "GET") {
        const billId = singleBillMatch[1];
        const bill = db.prepare(`
          SELECT mb.*,
                 COALESCE(h.flat_number, '') as flat_number,
                 COALESCE(h.normalized_flat_number, '') as normalized_flat_number,
                 COALESCE(h.block_name, 'A') as block_name,
                 COALESCE(sm.full_name, 'Household Member') as member_name,
                 COALESCE(sm.full_name, 'Household Member') as primary_member_name,
                 sm.email as member_email,
                 sm.phone as member_phone
          FROM member_bills mb
          LEFT JOIN households h ON h.id = mb.household_id
          LEFT JOIN society_members sm ON sm.id = mb.member_id
          WHERE mb.id = ? AND mb.society_id = ?
        `).get(billId, societyId);
        if (!bill) {
          return sendJson(res, 404, { error: "Bill not found." });
        }
        const items = db.prepare("SELECT * FROM bill_items WHERE bill_id = ? AND society_id = ? ORDER BY created_at ASC").all(billId, societyId);
        return sendJson(res, 200, { bill: { ...bill, items }, items });
      }
      if (pathname === "/api/society/bills/generate" && method === "POST") {
        const {
          billingMonth,
          billingYear,
          householdId = null,
          // null = bulk for all eligible active households
          chargeCategoryIds = [],
          customAmounts = {},
          // optional map of categoryId -> amount
          penaltyAmount = 0,
          creditAmount = 0,
          asDraft = false,
          dueDate,
          overwriteExisting = false,
          regenerate = false
        } = body;
        const m = Number(billingMonth);
        const y = Number(billingYear);
        if (!m || m < 1 || m > 12 || !y || y < 2020) {
          return sendJson(res, 400, { error: "Valid billingMonth (1-12) and billingYear are required." });
        }
        let categories = db.prepare("SELECT * FROM charge_categories WHERE society_id = ? AND is_active = 1").all(societyId);
        if (categories.length === 0) {
          const defaultCatId = uuid();
          db.prepare(`
            INSERT INTO charge_categories (id, society_id, name, code, description, default_amount, billing_frequency, applicable_flats, due_day, is_single_charge_per_period, is_active)
            VALUES (?, ?, 'Monthly Maintenance', 'MAINTENANCE', 'Standard monthly society maintenance charges', 1500, 'MONTHLY', 'ALL', 10, 1, 1)
          `).run(defaultCatId, societyId);
          categories = db.prepare("SELECT * FROM charge_categories WHERE society_id = ? AND is_active = 1").all(societyId);
        }
        const selectedCategories = Array.isArray(chargeCategoryIds) && chargeCategoryIds.length > 0 ? categories.filter((c) => chargeCategoryIds.includes(c.id)) : categories;
        if (selectedCategories.length === 0) {
          return sendJson(res, 400, { error: "Please select at least one valid charge category to generate bills." });
        }
        const targetHouseholds = householdId ? db.prepare("SELECT * FROM households WHERE id = ? AND society_id = ? AND status = 'ACTIVE'").all(householdId, societyId) : db.prepare("SELECT * FROM households WHERE society_id = ? AND status = 'ACTIVE'").all(societyId);
        if (targetHouseholds.length === 0) {
          return sendJson(res, 404, { error: "No active households found for bill generation." });
        }
        const billDueDate = dueDate || `${y}-${String(m).padStart(2, "0")}-10`;
        const createdBills = [];
        const skippedDuplicates = [];
        db.exec("BEGIN IMMEDIATE");
        try {
          for (const hh of targetHouseholds) {
            const applicableCats = selectedCategories.filter((cat) => {
              if (!cat.applicable_flats || cat.applicable_flats === "ALL") return true;
              const allowed = String(cat.applicable_flats).split(",").map((f) => normalizeFlatNumber(f));
              return allowed.includes(hh.normalized_flat_number);
            });
            if (applicableCats.length === 0) continue;
            const existingRegular = db.prepare(`
              SELECT id FROM member_bills
              WHERE society_id = ? AND household_id = ? AND billing_month = ? AND billing_year = ?
                AND bill_type = 'REGULAR' AND status != 'CANCELLED'
            `).get(societyId, hh.id, m, y);
            const duplicateCatCheck = db.prepare(`
              SELECT id, category_name FROM bill_items
              WHERE society_id = ? AND household_id = ? AND billing_month = ? AND billing_year = ?
                AND charge_category_id = ? AND is_adjustment = 0
            `);
            let hasDuplicateCharge = false;
            for (const cat of applicableCats) {
              const dup = duplicateCatCheck.get(societyId, hh.id, m, y, cat.id);
              if (dup) {
                hasDuplicateCharge = true;
                break;
              }
            }
            if (existingRegular || hasDuplicateCharge) {
              if (overwriteExisting || regenerate) {
                const existingRegularBill = existingRegular ? db.prepare("SELECT id, status FROM member_bills WHERE id = ?").get(existingRegular.id) : null;
                if (existingRegularBill && ["PAID", "PARTIALLY_PAID"].includes(existingRegularBill.status)) {
                  skippedDuplicates.push(`${hh.normalized_flat_number} (Already Paid)`);
                  continue;
                }
                if (existingRegular) {
                  db.prepare("DELETE FROM bill_items WHERE bill_id = ?").run(existingRegular.id);
                  db.prepare("DELETE FROM bill_adjustments WHERE bill_id = ?").run(existingRegular.id);
                  db.prepare("DELETE FROM member_bills WHERE id = ?").run(existingRegular.id);
                } else {
                  for (const cat of applicableCats) {
                    db.prepare("DELETE FROM bill_items WHERE society_id = ? AND household_id = ? AND billing_month = ? AND billing_year = ? AND charge_category_id = ? AND is_adjustment = 0").run(societyId, hh.id, m, y, cat.id);
                  }
                }
              } else {
                skippedDuplicates.push(hh.normalized_flat_number);
                if (householdId) {
                  db.exec("ROLLBACK");
                  return sendJson(res, 409, {
                    error: `Duplicate bill prevented: A regular bill or charge for Flat ${hh.normalized_flat_number} in ${m}/${y} already exists. To update it, check 'Regenerate / Overwrite existing unpaid bills' or use 'Issue Adjustment / Supplementary Bill'.`
                  });
                }
                continue;
              }
            }
            const prevRow = db.prepare(`
              SELECT COALESCE(SUM(balance_amount), 0) as prev
              FROM member_bills
              WHERE society_id = ? AND household_id = ? AND status NOT IN ('PAID', 'CANCELLED', 'DRAFT')
                AND bill_type = 'REGULAR'
                AND (billing_year < ? OR (billing_year = ? AND billing_month < ?))
            `).get(societyId, hh.id, y, y, m);
            const subtotal = applicableCats.reduce((sum, cat) => {
              const amt = customAmounts[cat.id] !== void 0 ? Number(customAmounts[cat.id]) : Number(cat.default_amount);
              return sum + amt;
            }, 0);
            const previousBalance = Number(prevRow?.prev || 0);
            const pen = Number(penaltyAmount || 0);
            const cred = Number(creditAmount || 0);
            const totalAmount = Math.max(0, Number((subtotal + previousBalance + pen - cred).toFixed(2)));
            const billId = uuid();
            const billNumber = `BILL-${y}${String(m).padStart(2, "0")}-${hh.normalized_flat_number.replace(/[^A-Z0-9]/g, "")}-${billId.slice(0, 4).toUpperCase()}`;
            db.prepare(`
              INSERT INTO member_bills (
                id, society_id, household_id, member_id, bill_number, billing_month, billing_year,
                bill_type, status, subtotal_amount, previous_balance, penalty_amount, credit_amount,
                total_amount, paid_amount, balance_amount, due_date, issued_at, created_by
              ) VALUES (?, ?, ?, ?, ?, ?, ?, 'REGULAR', ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
            `).run(
              billId,
              societyId,
              hh.id,
              hh.primary_member_id,
              billNumber,
              m,
              y,
              asDraft ? "DRAFT" : "UNPAID",
              subtotal,
              previousBalance,
              pen,
              cred,
              totalAmount,
              totalAmount,
              billDueDate,
              asDraft ? null : (/* @__PURE__ */ new Date()).toISOString(),
              auth?.userId ?? null
            );
            for (const cat of applicableCats) {
              const amt = customAmounts[cat.id] !== void 0 ? Number(customAmounts[cat.id]) : Number(cat.default_amount);
              db.prepare(`
                INSERT INTO bill_items (
                  id, society_id, bill_id, household_id, charge_category_id, category_name,
                  billing_month, billing_year, description, amount, is_adjustment
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
              `).run(uuid(), societyId, billId, hh.id, cat.id, cat.name, m, y, `${cat.name} (${m}/${y})`, amt);
            }
            if (!asDraft && hh.primary_member_id) {
              const memUser = db.prepare("SELECT user_id FROM society_members WHERE id = ?").get(hh.primary_member_id);
              sendNotification({
                societyId,
                userId: memUser?.user_id,
                notificationType: "NEW_MONTHLY_BILL",
                title: `New Monthly Bill Issued: ${billNumber}`,
                message: `Your society bill for ${m}/${y} of \u20B9${totalAmount} is due by ${billDueDate}.`,
                channel: "EMAIL",
                dedupKey: `bill-issued:${billId}`
              });
            }
            createdBills.push(billId);
          }
          if (createdBills.length === 0 && skippedDuplicates.length > 0) {
            db.exec("ROLLBACK");
            return sendJson(res, 409, {
              error: `Duplicate bills prevented: All target flat(s) (${skippedDuplicates.join(", ")}) already have regular bills for ${m}/${y}. To add extra charges, please use 'Issue Adjustment / Supplementary Bill'.`
            });
          }
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "BILLS_GENERATED",
            entityType: "MEMBER_BILL",
            details: { billingMonth: m, billingYear: y, createdCount: createdBills.length, skippedDuplicates }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, {
            createdCount: createdBills.length,
            createdBillIds: createdBills,
            skippedDuplicates,
            message: `Generated ${createdBills.length} bill(s) for ${m}/${y}.${skippedDuplicates.length ? ` Skipped ${skippedDuplicates.length} already-billed flat(s).` : ""}`
          });
        } catch (err) {
          console.error("[RESET ERROR]", err);
          db.exec("ROLLBACK");
          if (String(err?.message || "").includes("UNIQUE constraint failed")) {
            return sendJson(res, 409, {
              error: "Duplicate bill prevented by database constraint for the same flat, period, and charge category."
            });
          }
          throw err;
        }
      }
      const deleteBillMatch = pathname.match(/^\/api\/society\/bills\/([^/]+)$/);
      if (deleteBillMatch && method === "DELETE") {
        const billId = deleteBillMatch[1];
        const bill = db.prepare("SELECT * FROM member_bills WHERE id = ? AND society_id = ?").get(billId, societyId);
        if (!bill) return sendJson(res, 404, { error: "Bill not found." });
        if (bill.status === "PAID") {
          return sendJson(res, 400, { error: "Cannot delete a paid bill. Issue a credit adjustment instead." });
        }
        db.prepare("DELETE FROM bill_items WHERE bill_id = ? AND society_id = ?").run(billId, societyId);
        db.prepare("DELETE FROM bill_adjustments WHERE bill_id = ? AND society_id = ?").run(billId, societyId);
        db.prepare("DELETE FROM member_bills WHERE id = ? AND society_id = ?").run(billId, societyId);
        return sendJson(res, 200, { message: "Bill deleted successfully." });
      }
      const publishBillMatch = pathname.match(/^\/api\/society\/bills\/([^/]+)\/publish$/);
      if (publishBillMatch && method === "POST") {
        const billId = publishBillMatch[1];
        const bill = db.prepare("SELECT * FROM member_bills WHERE id = ? AND society_id = ?").get(billId, societyId);
        if (!bill) return sendJson(res, 404, { error: "Bill not found." });
        db.prepare("UPDATE member_bills SET status = 'UNPAID', issued_at = datetime('now'), updated_at = datetime('now') WHERE id = ?").run(billId);
        return sendJson(res, 200, { message: "Draft bill published and issued to member." });
      }
      if (pathname === "/api/society/bills/adjustment" && method === "POST") {
        const { householdId, billingMonth, billingYear, chargeCategoryId, amount, reason, dueDate } = body;
        if (!householdId || !billingMonth || !billingYear || !chargeCategoryId || !amount || !reason) {
          return sendJson(res, 400, {
            error: "householdId, billingMonth, billingYear, chargeCategoryId, amount, and reason are required for an adjustment/supplementary bill."
          });
        }
        const hh = db.prepare("SELECT * FROM households WHERE id = ? AND society_id = ?").get(householdId, societyId);
        const cat = db.prepare("SELECT * FROM charge_categories WHERE id = ? AND society_id = ?").get(chargeCategoryId, societyId);
        if (!hh || !cat) return sendJson(res, 404, { error: "Household or charge category not found." });
        const billId = uuid();
        const m = Number(billingMonth);
        const y = Number(billingYear);
        const amt = Number(amount);
        const billNumber = `SUPP-${y}${String(m).padStart(2, "0")}-${hh.normalized_flat_number.replace(/[^A-Z0-9]/g, "")}-${billId.slice(0, 4).toUpperCase()}`;
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO member_bills (
              id, society_id, household_id, member_id, bill_number, billing_month, billing_year,
              bill_type, adjustment_reason, status, subtotal_amount, total_amount, paid_amount, balance_amount,
              due_date, issued_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'SUPPLEMENTARY', ?, 'UNPAID', ?, ?, 0, ?, ?, datetime('now'), ?)
          `).run(
            billId,
            societyId,
            hh.id,
            hh.primary_member_id,
            billNumber,
            m,
            y,
            String(reason).trim(),
            amt,
            amt,
            amt,
            dueDate || `${y}-${String(m).padStart(2, "0")}-20`,
            auth?.userId ?? null
          );
          db.prepare(`
            INSERT INTO bill_items (
              id, society_id, bill_id, household_id, charge_category_id, category_name,
              billing_month, billing_year, description, amount, is_adjustment
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
          `).run(uuid(), societyId, billId, hh.id, cat.id, cat.name, m, y, `Supplementary: ${reason}`, amt);
          db.prepare(`
            INSERT INTO bill_adjustments (id, society_id, bill_id, adjustment_type, amount, reason, created_by)
            VALUES (?, ?, ?, 'SUPPLEMENTARY', ?, ?, ?)
          `).run(uuid(), societyId, billId, amt, String(reason).trim(), auth?.userId ?? "");
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "SUPPLEMENTARY_BILL_ISSUED",
            entityType: "MEMBER_BILL",
            entityId: billId,
            details: { flatNumber: hh.normalized_flat_number, amount: amt, reason }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { billId, billNumber, message: "Supplementary/Adjustment bill issued with audit trail." });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (pathname === "/api/society/payments" && method === "GET") {
        const status = url.searchParams.get("status") || "";
        const search = (url.searchParams.get("search") || "").trim().toLowerCase();
        const includeManualContext = url.searchParams.get("includeManualContext") === "1";
        const payments = db.prepare(`
          SELECT p.*, sm.full_name as member_name, h.flat_number, h.block_name,
                 pr.receipt_number
          FROM payments p
          JOIN society_members sm ON sm.id = p.member_id
          JOIN households h ON h.id = p.household_id
          LEFT JOIN payment_receipts pr ON pr.payment_id = p.id
          WHERE p.society_id = ?
          ORDER BY p.created_at DESC
        `).all(societyId);
        const allocations = db.prepare(`
          SELECT pa.*, mb.bill_number, mb.billing_month, mb.billing_year
          FROM payment_allocations pa
          JOIN member_bills mb ON mb.id = pa.bill_id
          WHERE pa.society_id = ?
        `).all(societyId);
        const allocByPayment = /* @__PURE__ */ new Map();
        for (const al of allocations) {
          const arr = allocByPayment.get(al.payment_id) || [];
          arr.push(al);
          allocByPayment.set(al.payment_id, arr);
        }
        const filtered = payments.map((p) => ({ ...p, allocations: allocByPayment.get(p.id) || [] })).filter((p) => {
          if (status && p.status !== status) return false;
          if (search) {
            const hay = `${p.reference_number} ${p.member_name} ${p.flat_number} ${p.receipt_number || ""}`.toLowerCase();
            if (!hay.includes(search)) return false;
          }
          return true;
        });
        if (includeManualContext) {
          const households = db.prepare(`
            SELECT h.*, sm.full_name as primary_member_name, sm.phone as primary_member_phone, sm.email as primary_member_email
            FROM households h
            LEFT JOIN society_members sm ON sm.id = h.primary_member_id
            WHERE h.society_id = ? AND h.status != 'ARCHIVED'
            ORDER BY h.normalized_flat_number ASC
          `).all(societyId);
          const members = db.prepare(`
            SELECT sm.id, sm.household_id, sm.full_name, sm.phone, sm.email, sm.is_primary_member, h.flat_number, h.normalized_flat_number, h.block_name
            FROM society_members sm
            JOIN households h ON h.id = sm.household_id
            WHERE sm.society_id = ? AND sm.account_status = 'ACTIVE'
            ORDER BY h.normalized_flat_number ASC, sm.is_primary_member DESC
          `).all(societyId);
          const unpaidBills = db.prepare(`
            SELECT mb.*, h.flat_number, h.block_name, sm.full_name as member_name
            FROM member_bills mb
            JOIN households h ON h.id = mb.household_id
            LEFT JOIN society_members sm ON sm.id = mb.member_id
            WHERE mb.society_id = ? AND mb.status NOT IN ('PAID', 'CANCELLED', 'DRAFT') AND mb.balance_amount > 0
            ORDER BY mb.due_date ASC, mb.billing_year ASC, mb.billing_month ASC
          `).all(societyId);
          return sendJson(res, 200, { payments: filtered, households, members, unpaidBills });
        }
        return sendJson(res, 200, { payments: filtered });
      }
      if (pathname === "/api/society/payments/manual" && method === "POST") {
        const {
          householdId,
          memberId,
          billIds = [],
          amount,
          paymentDate,
          paymentMethod = "CASH",
          referenceNumber,
          notes = "",
          proofUrl = null,
          autoConfirm = true
        } = body;
        if (!householdId || !amount || Number(amount) <= 0) {
          return sendJson(res, 400, {
            error: "Household/Flat selection and a positive payment amount are required."
          });
        }
        const household = db.prepare(`
          SELECT * FROM households WHERE id = ? AND society_id = ? AND status != 'ARCHIVED'
        `).get(householdId, societyId);
        if (!household) {
          return sendJson(res, 404, { error: "Selected flat/household was not found in this society." });
        }
        let member = memberId ? db.prepare("SELECT * FROM society_members WHERE id = ? AND society_id = ? AND household_id = ?").get(memberId, societyId, householdId) : void 0;
        if (!member && household.primary_member_id) {
          member = db.prepare("SELECT * FROM society_members WHERE id = ? AND society_id = ?").get(household.primary_member_id, societyId);
        }
        if (!member) {
          member = db.prepare("SELECT * FROM society_members WHERE household_id = ? AND society_id = ? ORDER BY is_primary_member DESC LIMIT 1").get(householdId, societyId);
        }
        if (!member) {
          return sendJson(res, 400, { error: "No active resident member is linked to this flat." });
        }
        const paymentId = uuid();
        const totalPaidInput = Number(Number(amount).toFixed(2));
        const dateStr = paymentDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const cleanRef = String(referenceNumber || "").trim() || `${paymentMethod}-${dateStr.replace(/-/g, "")}-${paymentId.slice(0, 4).toUpperCase()}`;
        const verificationNote = String(notes || "").trim() || `Manual payment received at society office (${paymentMethod})`;
        let targetBills = [];
        if (Array.isArray(billIds) && billIds.length > 0) {
          for (const bId of billIds) {
            const b = db.prepare("SELECT * FROM member_bills WHERE id = ? AND society_id = ? AND household_id = ?").get(bId, societyId, householdId);
            if (b) targetBills.push(b);
          }
        } else {
          targetBills = db.prepare(`
            SELECT * FROM member_bills
            WHERE society_id = ? AND household_id = ? AND status NOT IN ('PAID', 'CANCELLED', 'DRAFT') AND balance_amount > 0
            ORDER BY due_date ASC, billing_year ASC, billing_month ASC
          `).all(societyId, householdId);
        }
        db.exec("BEGIN IMMEDIATE");
        try {
          const initialStatus = autoConfirm ? "CONFIRMED" : "PENDING_VERIFICATION";
          const ledgerPosted = autoConfirm ? 1 : 0;
          db.prepare(`
            INSERT INTO payments (
              id, society_id, household_id, member_id, payment_method, amount, payment_date,
              reference_number, proof_url, status, verification_notes, verified_by, verified_at, ledger_posted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ${autoConfirm ? "datetime('now')" : "NULL"}, ?)
          `).run(
            paymentId,
            societyId,
            householdId,
            member.id,
            paymentMethod,
            totalPaidInput,
            dateStr,
            cleanRef,
            proofUrl,
            initialStatus,
            verificationNote,
            autoConfirm ? auth?.userId ?? null : null,
            ledgerPosted
          );
          let remainingToAllocate = totalPaidInput;
          for (const bill of targetBills) {
            if (remainingToAllocate <= 0) break;
            const billBalance = Number(bill.balance_amount ?? bill.total_amount);
            const allocAmt = Math.min(remainingToAllocate, billBalance > 0 ? billBalance : remainingToAllocate);
            if (allocAmt <= 0) continue;
            db.prepare(`
              INSERT INTO payment_allocations (id, society_id, payment_id, bill_id, allocated_amount)
              VALUES (?, ?, ?, ?, ?)
            `).run(uuid(), societyId, paymentId, bill.id, allocAmt);
            if (autoConfirm) {
              const newPaid = Number((Number(bill.paid_amount) + allocAmt).toFixed(2));
              const newBalance = Math.max(0, Number((Number(bill.total_amount) - newPaid).toFixed(2)));
              const newBillStatus = newBalance === 0 ? "PAID" : "PARTIALLY_PAID";
              db.prepare(`
                UPDATE member_bills
                SET paid_amount = ?, balance_amount = ?, status = ?, updated_at = datetime('now')
                WHERE id = ?
              `).run(newPaid, newBalance, newBillStatus, bill.id);
            } else if (bill.status === "UNPAID" || bill.status === "OVERDUE") {
              db.prepare("UPDATE member_bills SET status = 'PENDING_VERIFICATION', updated_at = datetime('now') WHERE id = ?").run(bill.id);
            }
            remainingToAllocate = Math.max(0, Number((remainingToAllocate - allocAmt).toFixed(2)));
          }
          let receiptRecord = null;
          if (autoConfirm) {
            const receiptNumber = `RCP-${(/* @__PURE__ */ new Date()).getFullYear()}-${paymentId.slice(0, 6).toUpperCase()}`;
            const receiptId = uuid();
            db.prepare(`
              INSERT INTO payment_receipts (
                id, society_id, payment_id, receipt_number, issued_to_name, flat_number,
                amount, payment_method, reference_number, issued_by
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
              receiptId,
              societyId,
              paymentId,
              receiptNumber,
              member.full_name,
              household.flat_number,
              totalPaidInput,
              paymentMethod,
              cleanRef,
              auth?.userId ?? null
            );
            const accountType = paymentMethod === "CASH" ? "CASH" : "BANK";
            const txnCode = `TXN-INC-${Date.now()}-${paymentId.slice(0, 4).toUpperCase()}`;
            db.prepare(`
              INSERT INTO ledger_entries (
                id, society_id, transaction_code, entry_date, entry_type, account_type,
                category, description, amount, direction, reference_type, reference_id,
                household_id, flat_number, member_id, payment_method, created_by
              ) VALUES (?, ?, ?, ?, 'INCOME', ?, 'Maintenance Collection', ?, ?, 'CREDIT', 'PAYMENT', ?, ?, ?, ?, ?, ?)
            `).run(
              uuid(),
              societyId,
              txnCode,
              dateStr,
              accountType,
              `Manual payment received ${receiptNumber} (Flat ${household.flat_number}, Ref: ${cleanRef})`,
              totalPaidInput,
              paymentId,
              householdId,
              household.flat_number,
              member.id,
              paymentMethod,
              auth?.userId ?? null
            );
            db.prepare(`
              UPDATE financial_accounts
              SET current_balance = current_balance + ?, updated_at = datetime('now')
              WHERE society_id = ? AND account_type = ?
            `).run(totalPaidInput, societyId, accountType);
            sendNotification({
              societyId,
              userId: member.user_id,
              notificationType: "PAYMENT_CONFIRMED",
              title: `Payment Received \u2014 Receipt ${receiptNumber}`,
              message: `Your payment of \u20B9${totalPaidInput} (${paymentMethod}, Ref: ${cleanRef}) has been recorded by society management. Receipt #${receiptNumber} is ready.`,
              channel: "EMAIL",
              dedupKey: `pay-man-conf:${paymentId}`
            });
            receiptRecord = {
              id: paymentId,
              receipt_id: receiptId,
              receipt_number: receiptNumber,
              flat_number: household.flat_number,
              member_name: member.full_name,
              amount: totalPaidInput,
              payment_date: dateStr,
              payment_method: paymentMethod,
              reference_number: cleanRef
            };
          }
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: autoConfirm ? "MANUAL_PAYMENT_RECEIVED_CONFIRMED" : "MANUAL_PAYMENT_RECORDED_PENDING",
            entityType: "PAYMENT",
            entityId: paymentId,
            details: {
              flatNumber: household.flat_number,
              memberName: member.full_name,
              amount: totalPaidInput,
              paymentMethod,
              referenceNumber: cleanRef,
              autoConfirm,
              receiptNumber: receiptRecord?.receipt_number || null
            }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, {
            id: paymentId,
            status: initialStatus,
            receipt: receiptRecord,
            message: autoConfirm ? `Manual payment of \u20B9${totalPaidInput} recorded & confirmed! Receipt ${receiptRecord?.receipt_number} generated.` : `Manual payment of \u20B9${totalPaidInput} recorded as Pending Verification.`
          });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      const verifyPaymentMatch = pathname.match(/^\/api\/society\/payments\/([^/]+)\/verify$/);
      if (verifyPaymentMatch && method === "POST") {
        const paymentId = verifyPaymentMatch[1];
        const { decision, notes = "" } = body;
        if (decision !== "CONFIRM" && decision !== "REJECT") {
          return sendJson(res, 400, { error: "decision must be 'CONFIRM' or 'REJECT'." });
        }
        const payment = db.prepare(`
          SELECT p.*, sm.full_name as member_name, sm.user_id as member_user_id, h.flat_number
          FROM payments p
          JOIN society_members sm ON sm.id = p.member_id
          JOIN households h ON h.id = p.household_id
          WHERE p.id = ? AND p.society_id = ?
        `).get(paymentId, societyId);
        if (!payment) {
          return sendJson(res, 404, { error: "Payment record not found in your society." });
        }
        if (decision === "CONFIRM" && (payment.status === "CONFIRMED" || payment.ledger_posted === 1)) {
          const existingReceipt = db.prepare("SELECT * FROM payment_receipts WHERE payment_id = ?").get(paymentId);
          return sendJson(res, 200, {
            alreadyConfirmed: true,
            receipt: existingReceipt,
            message: "Payment was already confirmed. Duplicate ledger entry prevented."
          });
        }
        db.exec("BEGIN IMMEDIATE");
        try {
          if (decision === "REJECT") {
            db.prepare(`
              UPDATE payments
              SET status = 'REJECTED', verification_notes = ?, verified_by = ?, verified_at = datetime('now'), updated_at = datetime('now')
              WHERE id = ? AND society_id = ?
            `).run(String(notes || "Payment reference could not be verified"), auth?.userId ?? null, paymentId, societyId);
            const allocs2 = db.prepare("SELECT * FROM payment_allocations WHERE payment_id = ?").all(paymentId);
            for (const al of allocs2) {
              const b = db.prepare("SELECT * FROM member_bills WHERE id = ?").get(al.bill_id);
              if (b && b.status === "PENDING_VERIFICATION") {
                const revertedStatus = Number(b.paid_amount) > 0 ? "PARTIALLY_PAID" : "UNPAID";
                db.prepare("UPDATE member_bills SET status = ?, updated_at = datetime('now') WHERE id = ?").run(revertedStatus, b.id);
              }
            }
            sendNotification({
              societyId,
              userId: payment.member_user_id,
              notificationType: "PAYMENT_REJECTED",
              title: "Payment Verification Rejected",
              message: `Your payment of \u20B9${payment.amount} (Ref: ${payment.reference_number}) was rejected. Reason: ${notes || "Reference mismatch"}.`,
              channel: "EMAIL",
              dedupKey: `pay-rej:${paymentId}`
            });
            logAudit({
              societyId,
              actorUserId: auth?.userId,
              actorRole: auth?.role || "SOCIETY_ADMIN",
              action: "PAYMENT_REJECTED",
              entityType: "PAYMENT",
              entityId: paymentId,
              details: { notes, referenceNumber: payment.reference_number }
            });
            db.exec("COMMIT");
            return sendJson(res, 200, { status: "REJECTED", message: "Payment rejected and member notified." });
          }
          db.prepare(`
            UPDATE payments
            SET status = 'CONFIRMED', verification_notes = ?, verified_by = ?, verified_at = datetime('now'),
                ledger_posted = 1, updated_at = datetime('now')
            WHERE id = ? AND society_id = ?
          `).run(String(notes || "Verified and confirmed"), auth?.userId ?? null, paymentId, societyId);
          const allocs = db.prepare("SELECT * FROM payment_allocations WHERE payment_id = ?").all(paymentId);
          let remainingToAllocate = Number(payment.amount);
          for (const al of allocs) {
            const bill = db.prepare("SELECT * FROM member_bills WHERE id = ? AND society_id = ?").get(al.bill_id, societyId);
            if (!bill) continue;
            const allocAmt = Math.min(remainingToAllocate, Number(al.allocated_amount));
            const newPaid = Number((Number(bill.paid_amount) + allocAmt).toFixed(2));
            const newBalance = Math.max(0, Number((Number(bill.total_amount) - newPaid).toFixed(2)));
            const newBillStatus = newBalance === 0 ? "PAID" : "PARTIALLY_PAID";
            db.prepare(`
              UPDATE member_bills
              SET paid_amount = ?, balance_amount = ?, status = ?, updated_at = datetime('now')
              WHERE id = ?
            `).run(newPaid, newBalance, newBillStatus, bill.id);
            remainingToAllocate = Math.max(0, Number((remainingToAllocate - allocAmt).toFixed(2)));
          }
          const receiptNumber = `RCP-${(/* @__PURE__ */ new Date()).getFullYear()}-${paymentId.slice(0, 6).toUpperCase()}`;
          const receiptId = uuid();
          db.prepare(`
            INSERT INTO payment_receipts (
              id, society_id, payment_id, receipt_number, issued_to_name, flat_number,
              amount, payment_method, reference_number, issued_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            receiptId,
            societyId,
            paymentId,
            receiptNumber,
            payment.member_name,
            payment.flat_number,
            Number(payment.amount),
            payment.payment_method,
            payment.reference_number,
            auth?.userId ?? null
          );
          const accountType = payment.payment_method === "CASH" ? "CASH" : "BANK";
          const txnCode = `TXN-INC-${Date.now()}-${paymentId.slice(0, 4).toUpperCase()}`;
          db.prepare(`
            INSERT INTO ledger_entries (
              id, society_id, transaction_code, entry_date, entry_type, account_type,
              category, description, amount, direction, reference_type, reference_id,
              household_id, flat_number, member_id, payment_method, created_by
            ) VALUES (?, ?, ?, ?, 'INCOME', ?, 'Maintenance Collection', ?, ?, 'CREDIT', 'PAYMENT', ?, ?, ?, ?, ?, ?)
          `).run(
            uuid(),
            societyId,
            txnCode,
            payment.payment_date,
            accountType,
            `Confirmed payment ${receiptNumber} (Flat ${payment.flat_number}, Ref: ${payment.reference_number})`,
            Number(payment.amount),
            paymentId,
            payment.household_id,
            payment.flat_number,
            payment.member_id,
            payment.payment_method,
            auth?.userId ?? null
          );
          db.prepare(`
            UPDATE financial_accounts
            SET current_balance = current_balance + ?, updated_at = datetime('now')
            WHERE society_id = ? AND account_type = ?
          `).run(Number(payment.amount), societyId, accountType);
          sendNotification({
            societyId,
            userId: payment.member_user_id,
            notificationType: "PAYMENT_CONFIRMED",
            title: `Payment Confirmed \u2014 Receipt ${receiptNumber}`,
            message: `Your payment of \u20B9${payment.amount} has been verified and confirmed. Receipt #${receiptNumber} is now available for download.`,
            channel: "EMAIL",
            dedupKey: `pay-conf:${paymentId}`
          });
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "PAYMENT_CONFIRMED",
            entityType: "PAYMENT",
            entityId: paymentId,
            details: { receiptNumber, amount: payment.amount, accountType }
          });
          db.exec("COMMIT");
          const receipt = db.prepare("SELECT * FROM payment_receipts WHERE id = ?").get(receiptId);
          return sendJson(res, 200, { status: "CONFIRMED", receipt, message: `Payment confirmed and Receipt ${receiptNumber} generated.` });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (pathname === "/api/society/roles" && method === "GET") {
        const roles = db.prepare(`
          SELECT sr.*,
                 rp.view_members, rp.manage_members, rp.generate_bills, rp.verify_payments,
                 rp.manage_expenses, rp.view_financial_reports, rp.manage_complaints,
                 rp.manage_events, rp.manage_staff, rp.change_society_settings
          FROM staff_roles sr
          LEFT JOIN role_permissions rp ON rp.role_id = sr.id
          WHERE sr.society_id = ?
          ORDER BY sr.is_office_bearer DESC, sr.name ASC
        `).all(societyId);
        return sendJson(res, 200, { roles });
      }
      if (pathname === "/api/society/roles" && method === "POST") {
        const { name, isOfficeBearer = false, permissions = {} } = body;
        if (!name) return sendJson(res, 400, { error: "Role name is required." });
        const roleId = uuid();
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO staff_roles (id, society_id, name, is_office_bearer, is_system_default)
            VALUES (?, ?, ?, ?, 0)
          `).run(roleId, societyId, String(name).trim(), isOfficeBearer ? 1 : 0);
          db.prepare(`
            INSERT INTO role_permissions (
              id, society_id, role_id, view_members, manage_members, generate_bills, verify_payments,
              manage_expenses, view_financial_reports, manage_complaints, manage_events, manage_staff, change_society_settings
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            uuid(),
            societyId,
            roleId,
            permissions.view_members ? 1 : 0,
            permissions.manage_members ? 1 : 0,
            permissions.generate_bills ? 1 : 0,
            permissions.verify_payments ? 1 : 0,
            permissions.manage_expenses ? 1 : 0,
            permissions.view_financial_reports ? 1 : 0,
            permissions.manage_complaints ? 1 : 0,
            permissions.manage_events ? 1 : 0,
            permissions.manage_staff ? 1 : 0,
            permissions.change_society_settings ? 1 : 0
          );
          db.exec("COMMIT");
          return sendJson(res, 201, { roleId, message: "Custom staff/office-bearer role created." });
        } catch (err) {
          console.error("[RESET ERROR]", err);
          db.exec("ROLLBACK");
          if (String(err?.message || "").includes("UNIQUE")) {
            return sendJson(res, 409, { error: "A role with this name already exists in your society." });
          }
          throw err;
        }
      }
      const rolePermMatch = pathname.match(/^\/api\/society\/roles\/([^/]+)\/permissions$/);
      if (rolePermMatch && method === "PUT") {
        const roleId = rolePermMatch[1];
        const p = body.permissions || body;
        db.prepare(`
          UPDATE role_permissions
          SET view_members = ?, manage_members = ?, generate_bills = ?, verify_payments = ?,
              manage_expenses = ?, view_financial_reports = ?, manage_complaints = ?,
              manage_events = ?, manage_staff = ?, change_society_settings = ?,
              updated_at = datetime('now')
          WHERE role_id = ? AND society_id = ?
        `).run(
          p.view_members ? 1 : 0,
          p.manage_members ? 1 : 0,
          p.generate_bills ? 1 : 0,
          p.verify_payments ? 1 : 0,
          p.manage_expenses ? 1 : 0,
          p.view_financial_reports ? 1 : 0,
          p.manage_complaints ? 1 : 0,
          p.manage_events ? 1 : 0,
          p.manage_staff ? 1 : 0,
          p.change_society_settings ? 1 : 0,
          roleId,
          societyId
        );
        return sendJson(res, 200, { message: "Role permissions updated." });
      }
      if (pathname === "/api/society/staff" && method === "GET") {
        const staffList = db.prepare(`
          SELECT st.*, sr.name as role_name, sr.is_office_bearer
          FROM staff st
          JOIN staff_roles sr ON sr.id = st.role_id
          WHERE st.society_id = ?
          ORDER BY st.is_on_duty DESC, st.full_name ASC
        `).all(societyId);
        const docs = db.prepare(`
          SELECT id, staff_id, document_type, masked_document_number, document_url, created_at
          FROM staff_documents
          WHERE society_id = ?
        `).all(societyId);
        const docsByStaff = /* @__PURE__ */ new Map();
        for (const d of docs) {
          const arr = docsByStaff.get(d.staff_id) || [];
          arr.push(d);
          docsByStaff.set(d.staff_id, arr);
        }
        const attendance = db.prepare(`
          SELECT ar.*, st.full_name as staff_name
          FROM attendance_records ar
          JOIN staff st ON st.id = ar.staff_id
          WHERE ar.society_id = ?
          ORDER BY ar.attendance_date DESC LIMIT 100
        `).all(societyId);
        return sendJson(res, 200, {
          staff: staffList.map((s) => ({ ...s, documents: docsByStaff.get(s.id) || [] })),
          attendance
        });
      }
      if (pathname === "/api/society/staff" && method === "POST") {
        const {
          fullName,
          phone,
          email = null,
          password = null,
          address = "",
          roleId,
          designation,
          joiningDate,
          wageType = "MONTHLY",
          salaryAmount = 0,
          dutySchedule = "",
          assignedDuties = "",
          isOnDuty = true,
          showContactToMembers = true,
          photoUrl = null,
          documentType = null,
          documentNumber = null,
          documentUrl = null
        } = body;
        if (!fullName || !phone || !roleId || !designation) {
          return sendJson(res, 400, { error: "fullName, phone, roleId, and designation are required." });
        }
        const staffId = uuid();
        let staffUserId = null;
        db.exec("BEGIN IMMEDIATE");
        try {
          if (email && password) {
            const cleanEmail = String(email).trim().toLowerCase();
            if (db.prepare("SELECT id FROM users WHERE email = ?").get(cleanEmail)) {
              db.exec("ROLLBACK");
              return sendJson(res, 409, { error: "Email already in use by another user." });
            }
            staffUserId = uuid();
            db.prepare(`
              INSERT INTO users (id, email, phone, password_hash, role, society_id, is_active, email_verified)
              VALUES (?, ?, ?, ?, 'STAFF', ?, 1, 1)
            `).run(staffUserId, cleanEmail, String(phone).trim(), hashPassword(String(password)), societyId);
            db.prepare(`
              INSERT INTO user_profiles (id, user_id, society_id, full_name, avatar_url, preferred_language)
              VALUES (?, ?, ?, ?, ?, 'en')
            `).run(uuid(), staffUserId, societyId, String(fullName).trim(), photoUrl);
          }
          db.prepare(`
            INSERT INTO staff (
              id, society_id, user_id, role_id, full_name, photo_url, phone, email, address,
              designation, joining_date, wage_type, salary_amount, employment_status,
              is_on_duty, duty_schedule, assigned_duties, show_contact_to_members
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, ?)
          `).run(
            staffId,
            societyId,
            staffUserId,
            roleId,
            String(fullName).trim(),
            photoUrl,
            String(phone).trim(),
            email ? String(email).trim().toLowerCase() : null,
            address,
            String(designation).trim(),
            joiningDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
            wageType,
            Number(salaryAmount || 0),
            isOnDuty ? 1 : 0,
            dutySchedule,
            assignedDuties,
            showContactToMembers ? 1 : 0
          );
          if (documentType && documentNumber) {
            const masked = maskDocumentNumber(String(documentType), String(documentNumber));
            db.prepare(`
              INSERT INTO staff_documents (id, society_id, staff_id, document_type, masked_document_number, document_url, uploaded_by)
              VALUES (?, ?, ?, ?, ?, ?, ?)
            `).run(uuid(), societyId, staffId, String(documentType), masked, documentUrl || "/uploads/id-document-placeholder.pdf", auth?.userId ?? "");
          }
          db.prepare(`
            INSERT INTO staff_duty_records (id, society_id, staff_id, duty_status, shift_notes, changed_by)
            VALUES (?, ?, ?, ?, 'Initial staff creation', ?)
          `).run(uuid(), societyId, staffId, isOnDuty ? "ON_DUTY" : "OFF_DUTY", auth?.userId ?? null);
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "STAFF_CREATED",
            entityType: "STAFF",
            entityId: staffId,
            details: { fullName, designation, isOnDuty }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { staffId, message: "Staff profile created successfully." });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      const staffDutyMatch = pathname.match(/^\/api\/society\/staff\/([^/]+)\/duty$/);
      if (staffDutyMatch && method === "PUT") {
        const staffId = staffDutyMatch[1];
        const staffMember = db.prepare("SELECT * FROM staff WHERE id = ? AND society_id = ?").get(staffId, societyId);
        if (!staffMember) return sendJson(res, 404, { error: "Staff member not found." });
        const { isOnDuty, shiftNotes = "" } = body;
        const nextDuty = isOnDuty ? 1 : 0;
        db.prepare("UPDATE staff SET is_on_duty = ?, updated_at = datetime('now') WHERE id = ? AND society_id = ?").run(nextDuty, staffId, societyId);
        db.prepare(`
          INSERT INTO staff_duty_records (id, society_id, staff_id, duty_status, shift_notes, changed_by)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(uuid(), societyId, staffId, nextDuty ? "ON_DUTY" : "OFF_DUTY", shiftNotes, auth?.userId ?? null);
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: "STAFF_DUTY_STATUS_CHANGED",
          entityType: "STAFF",
          entityId: staffId,
          details: { fullName: staffMember.full_name, isOnDuty: Boolean(nextDuty) }
        });
        return sendJson(res, 200, {
          staffId,
          isOnDuty: Boolean(nextDuty),
          message: `${staffMember.full_name} marked as ${nextDuty ? "On Duty" : "Off Duty"}.`
        });
      }
      const staffUpdateMatch = pathname.match(/^\/api\/society\/staff\/([^/]+)$/);
      if (staffUpdateMatch && method === "PUT") {
        const staffId = staffUpdateMatch[1];
        const { fullName, phone, designation, roleId, wageType, salaryAmount, employmentStatus, dutySchedule, assignedDuties, showContactToMembers } = body;
        db.prepare(`
          UPDATE staff
          SET full_name = COALESCE(?, full_name),
              phone = COALESCE(?, phone),
              designation = COALESCE(?, designation),
              role_id = COALESCE(?, role_id),
              wage_type = COALESCE(?, wage_type),
              salary_amount = COALESCE(?, salary_amount),
              employment_status = COALESCE(?, employment_status),
              duty_schedule = COALESCE(?, duty_schedule),
              assigned_duties = COALESCE(?, assigned_duties),
              show_contact_to_members = COALESCE(?, show_contact_to_members),
              is_on_duty = CASE WHEN ? IN ('INACTIVE', 'TERMINATED') THEN 0 ELSE is_on_duty END,
              updated_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(
          fullName ?? null,
          phone ?? null,
          designation ?? null,
          roleId ?? null,
          wageType ?? null,
          salaryAmount !== void 0 ? Number(salaryAmount) : null,
          employmentStatus ?? null,
          dutySchedule ?? null,
          assignedDuties ?? null,
          showContactToMembers !== void 0 ? showContactToMembers ? 1 : 0 : null,
          employmentStatus ?? null,
          staffId,
          societyId
        );
        return sendJson(res, 200, { message: "Staff profile updated." });
      }
      if (pathname === "/api/society/attendance" && method === "POST") {
        const { staffId, attendanceDate, status = "PRESENT", checkInTime = "09:00", checkOutTime = "18:00", salaryPaid = 0, notes = "" } = body;
        if (!staffId || !attendanceDate) return sendJson(res, 400, { error: "staffId and attendanceDate are required." });
        const id = uuid();
        db.prepare(`
          INSERT INTO attendance_records (id, society_id, staff_id, attendance_date, status, check_in_time, check_out_time, salary_paid, notes, recorded_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT (society_id, staff_id, attendance_date)
          DO UPDATE SET status = excluded.status, check_in_time = excluded.check_in_time, check_out_time = excluded.check_out_time, salary_paid = excluded.salary_paid, notes = excluded.notes
        `).run(id, societyId, staffId, attendanceDate, status, checkInTime, checkOutTime, Number(salaryPaid || 0), notes, auth?.userId ?? null);
        return sendJson(res, 201, { message: "Attendance and wage record saved." });
      }
      if (pathname === "/api/society/complaints" && method === "GET") {
        const status = url.searchParams.get("status") || "";
        const category = url.searchParams.get("category") || "";
        const priority = url.searchParams.get("priority") || "";
        const complaints = db.prepare(`
          SELECT c.*, sm.full_name as member_name, sm.phone as member_phone, st.full_name as assigned_staff_name
          FROM complaints c
          JOIN society_members sm ON sm.id = c.member_id
          LEFT JOIN staff st ON st.id = c.assigned_staff_id
          WHERE c.society_id = ?
          ORDER BY c.created_at DESC
        `).all(societyId);
        const attachments = db.prepare("SELECT * FROM complaint_attachments WHERE society_id = ?").all(societyId);
        const comments = db.prepare("SELECT * FROM complaint_comments WHERE society_id = ? ORDER BY created_at ASC").all(societyId);
        const filtered = complaints.map((c) => ({
          ...c,
          attachments: attachments.filter((a) => a.complaint_id === c.id),
          comments: comments.filter((cm) => cm.complaint_id === c.id)
        })).filter((c) => {
          if (status && c.status !== status) return false;
          if (category && c.category !== category) return false;
          if (priority && c.priority !== priority) return false;
          return true;
        });
        const suggestions = db.prepare(`
          SELECT sg.*, sm.full_name as member_name
          FROM suggestions sg
          JOIN society_members sm ON sm.id = sg.member_id
          WHERE sg.society_id = ?
          ORDER BY sg.created_at DESC
        `).all(societyId);
        return sendJson(res, 200, { complaints: filtered, suggestions });
      }
      const compUpdateMatch = pathname.match(/^\/api\/society\/complaints\/([^/]+)$/);
      if (compUpdateMatch && method === "PUT") {
        const compId = compUpdateMatch[1];
        const comp = db.prepare(`
          SELECT c.*, sm.user_id as member_user_id
          FROM complaints c
          JOIN society_members sm ON sm.id = c.member_id
          WHERE c.id = ? AND c.society_id = ?
        `).get(compId, societyId);
        if (!comp) return sendJson(res, 404, { error: "Complaint not found." });
        const { status, priority, assignedStaffId, resolutionNotes, resolutionImageUrl, commentText, isInternal = false } = body;
        db.prepare(`
          UPDATE complaints
          SET status = COALESCE(?, status),
              priority = COALESCE(?, priority),
              assigned_staff_id = COALESCE(?, assigned_staff_id),
              resolution_notes = COALESCE(?, resolution_notes),
              resolution_image_url = COALESCE(?, resolution_image_url),
              resolved_at = CASE WHEN ? = 'RESOLVED' THEN datetime('now') ELSE resolved_at END,
              updated_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(
          status ?? null,
          priority ?? null,
          assignedStaffId ?? null,
          resolutionNotes ?? null,
          resolutionImageUrl ?? null,
          status ?? null,
          compId,
          societyId
        );
        if (commentText) {
          const profile = db.prepare("SELECT full_name FROM user_profiles WHERE user_id = ?").get(auth?.userId ?? "");
          db.prepare(`
            INSERT INTO complaint_comments (id, society_id, complaint_id, author_user_id, author_name, comment_text, is_internal)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `).run(
            uuid(),
            societyId,
            compId,
            auth?.userId ?? "",
            profile?.full_name || "Society Management",
            String(commentText).trim(),
            isInternal ? 1 : 0
          );
        }
        if (status && status !== comp.status) {
          sendNotification({
            societyId,
            userId: comp.member_user_id,
            notificationType: "COMPLAINT_STATUS_CHANGED",
            title: `Complaint ${comp.complaint_number} Status: ${status}`,
            message: `Your complaint "${comp.title}" has been updated to ${status}.`,
            channel: "IN_APP"
          });
        }
        return sendJson(res, 200, { message: "Complaint updated." });
      }
      const suggUpdateMatch = pathname.match(/^\/api\/society\/suggestions\/([^/]+)$/);
      if (suggUpdateMatch && method === "PUT") {
        const suggId = suggUpdateMatch[1];
        const { status = "ACKNOWLEDGED", adminResponse } = body;
        db.prepare(`
          UPDATE suggestions
          SET status = ?, admin_response = ?, responded_by = ?, responded_at = datetime('now')
          WHERE id = ? AND society_id = ?
        `).run(status, adminResponse ?? null, auth?.userId ?? null, suggId, societyId);
        return sendJson(res, 200, { message: "Response saved for resident suggestion." });
      }
      if (pathname === "/api/society/events" && method === "GET") {
        const events = db.prepare("SELECT * FROM society_events WHERE society_id = ? ORDER BY event_date DESC").all(societyId);
        const announcements = db.prepare("SELECT * FROM announcements WHERE society_id = ? ORDER BY created_at DESC").all(societyId);
        return sendJson(res, 200, { events, announcements });
      }
      if (pathname === "/api/society/events" && method === "POST") {
        const { eventType = "GENERAL", title, description, eventDate, eventTime, venue, imageUrl = null, publicationStatus = "PUBLISHED" } = body;
        if (!title || !description || !eventDate || !eventTime || !venue) {
          return sendJson(res, 400, { error: "Title, description, date, time, and venue are required." });
        }
        const id = uuid();
        db.prepare(`
          INSERT INTO society_events (id, society_id, event_type, title, description, event_date, event_time, venue, image_url, publication_status, created_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(id, societyId, eventType, title, description, eventDate, eventTime, venue, imageUrl, publicationStatus, auth?.userId ?? null);
        return sendJson(res, 201, { id, message: "Society event created." });
      }
      if (pathname === "/api/society/announcements" && method === "POST") {
        const { category = "GENERAL", title, content, imageUrl = null, publicationStatus = "PUBLISHED", sendEmail = true } = body;
        if (!title || !content) return sendJson(res, 400, { error: "Title and content are required." });
        const id = uuid();
        db.prepare(`
          INSERT INTO announcements (id, society_id, category, title, content, image_url, publication_status, send_email, created_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(id, societyId, category, title, content, imageUrl, publicationStatus, sendEmail ? 1 : 0, auth?.userId ?? null);
        if (publicationStatus === "PUBLISHED") {
          sendNotification({
            societyId,
            userId: null,
            notificationType: "SOCIETY_ANNOUNCEMENT",
            title: `[${category}] ${title}`,
            message: content,
            channel: sendEmail ? "EMAIL" : "IN_APP",
            dedupKey: `ann:${id}`
          });
        }
        return sendJson(res, 201, { id, message: "Announcement published." });
      }
      if (pathname === "/api/society/expense-categories" && method === "GET") {
        const categories = db.prepare("SELECT * FROM expense_categories WHERE society_id = ? ORDER BY name ASC").all(societyId);
        return sendJson(res, 200, { categories });
      }
      if (pathname === "/api/society/expense-categories" && method === "POST") {
        const { name, description = "" } = body;
        if (!name) return sendJson(res, 400, { error: "Expense category name is required." });
        const id = uuid();
        try {
          db.prepare(`
            INSERT INTO expense_categories (id, society_id, name, description, is_active)
            VALUES (?, ?, ?, ?, 1)
          `).run(id, societyId, String(name).trim(), description);
          return sendJson(res, 201, { id, message: "Expense category created." });
        } catch {
          return sendJson(res, 409, { error: "An expense category with this name already exists." });
        }
      }
      if (pathname === "/api/society/expenses" && method === "GET") {
        const expenses = db.prepare("SELECT * FROM expenses WHERE society_id = ? ORDER BY expense_date DESC, created_at DESC").all(societyId);
        const categories = db.prepare("SELECT * FROM expense_categories WHERE society_id = ? ORDER BY name ASC").all(societyId);
        const accounts = db.prepare("SELECT * FROM financial_accounts WHERE society_id = ?").all(societyId);
        return sendJson(res, 200, { expenses, categories, accounts });
      }
      if (pathname === "/api/society/expenses" && method === "POST") {
        const {
          expenseCategoryId,
          description,
          amount,
          expenseDate,
          paymentMethod = "BANK_TRANSFER",
          accountType = "BANK",
          vendorName,
          invoiceUrl = null
        } = body;
        if (!expenseCategoryId || !description || !amount || Number(amount) <= 0 || !vendorName) {
          return sendJson(res, 400, { error: "Category, description, positive amount, and vendor/payee name are required." });
        }
        const cat = db.prepare("SELECT * FROM expense_categories WHERE id = ? AND society_id = ?").get(expenseCategoryId, societyId);
        if (!cat) return sendJson(res, 404, { error: "Expense category not found." });
        const expId = uuid();
        const amt = Number(amount);
        const accType = accountType === "CASH" ? "CASH" : "BANK";
        const dateStr = expenseDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const txnCode = `TXN-EXP-${Date.now()}-${expId.slice(0, 4).toUpperCase()}`;
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO expenses (
              id, society_id, expense_category_id, category_name, description, amount,
              expense_date, payment_method, account_type, vendor_name, invoice_url, status, entered_by, approved_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'APPROVED', ?, ?)
          `).run(
            expId,
            societyId,
            cat.id,
            cat.name,
            String(description).trim(),
            amt,
            dateStr,
            paymentMethod,
            accType,
            String(vendorName).trim(),
            invoiceUrl,
            auth?.userId ?? "",
            auth?.userId ?? ""
          );
          db.prepare(`
            INSERT INTO ledger_entries (
              id, society_id, transaction_code, entry_date, entry_type, account_type,
              category, description, amount, direction, reference_type, reference_id, payment_method, created_by
            ) VALUES (?, ?, ?, ?, 'EXPENSE', ?, ?, ?, ?, 'DEBIT', 'EXPENSE', ?, ?, ?)
          `).run(
            uuid(),
            societyId,
            txnCode,
            dateStr,
            accType,
            cat.name,
            `${description} (Paid to ${vendorName})`,
            amt,
            expId,
            paymentMethod,
            auth?.userId ?? null
          );
          db.prepare(`
            UPDATE financial_accounts
            SET current_balance = current_balance - ?, updated_at = datetime('now')
            WHERE society_id = ? AND account_type = ?
          `).run(amt, societyId, accType);
          logAudit({
            societyId,
            actorUserId: auth?.userId,
            actorRole: auth?.role || "SOCIETY_ADMIN",
            action: "EXPENSE_RECORDED",
            entityType: "EXPENSE",
            entityId: expId,
            details: { category: cat.name, amount: amt, vendorName, accountType: accType }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { expenseId: expId, transactionCode: txnCode, message: "Expense recorded and posted to financial ledger." });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      const revExpMatch = pathname.match(/^\/api\/society\/expenses\/([^/]+)\/reverse$/);
      if (revExpMatch && method === "POST") {
        const expId = revExpMatch[1];
        const { reason = "Reversal entry authorized by administrator" } = body;
        const exp = db.prepare("SELECT * FROM expenses WHERE id = ? AND society_id = ?").get(expId, societyId);
        if (!exp) return sendJson(res, 404, { error: "Expense not found." });
        if (exp.status === "REVERSED") return sendJson(res, 400, { error: "Expense is already reversed." });
        const origLedger = db.prepare("SELECT * FROM ledger_entries WHERE society_id = ? AND reference_type = 'EXPENSE' AND reference_id = ?").get(societyId, expId);
        const txnCode = `TXN-REV-${Date.now()}-${expId.slice(0, 4).toUpperCase()}`;
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare("UPDATE expenses SET status = 'REVERSED' WHERE id = ?").run(expId);
          db.prepare(`
            INSERT INTO ledger_entries (
              id, society_id, transaction_code, entry_date, entry_type, account_type,
              category, description, amount, direction, reference_type, reference_id,
              reversal_of_entry_id, created_by
            ) VALUES (?, ?, ?, date('now'), 'REVERSAL', ?, ?, ?, ?, 'CREDIT', 'REVERSAL', ?, ?, ?)
          `).run(
            uuid(),
            societyId,
            txnCode,
            exp.account_type,
            exp.category_name,
            `Reversal of ${origLedger?.transaction_code || expId}: ${reason}`,
            Number(exp.amount),
            expId,
            origLedger?.id ?? null,
            auth?.userId ?? null
          );
          db.prepare(`
            UPDATE financial_accounts
            SET current_balance = current_balance + ?, updated_at = datetime('now')
            WHERE society_id = ? AND account_type = ?
          `).run(Number(exp.amount), societyId, exp.account_type);
          db.exec("COMMIT");
          return sendJson(res, 200, { message: "Expense reversed via immutable reversal ledger entry." });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (pathname === "/api/society/reports" && method === "GET") {
        const dateFrom = url.searchParams.get("dateFrom") || "";
        const dateTo = url.searchParams.get("dateTo") || "";
        const flatFilter = normalizeFlatNumber(url.searchParams.get("flatNumber") || "");
        const categoryFilter = url.searchParams.get("category") || "";
        const ledger = db.prepare(`
          SELECT * FROM ledger_entries
          WHERE society_id = ?
          ORDER BY entry_date DESC, created_at DESC
        `).all(societyId);
        const filteredLedger = ledger.filter((l) => {
          if (dateFrom && l.entry_date < dateFrom) return false;
          if (dateTo && l.entry_date > dateTo) return false;
          if (flatFilter && normalizeFlatNumber(l.flat_number || "") !== flatFilter) return false;
          if (categoryFilter && l.category !== categoryFilter && l.entry_type !== categoryFilter) return false;
          return true;
        });
        const realizedIncome = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM ledger_entries WHERE society_id = ? AND entry_type = 'INCOME'").get(societyId).s;
        const approvedExpenses = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM expenses WHERE society_id = ? AND status = 'APPROVED'").get(societyId).s;
        const totalBilledReceivables = db.prepare("SELECT COALESCE(SUM(total_amount), 0) as s FROM member_bills WHERE society_id = ? AND status NOT IN ('CANCELLED', 'DRAFT')").get(societyId).s;
        const outstandingReceivables = db.prepare("SELECT COALESCE(SUM(balance_amount), 0) as s FROM member_bills WHERE society_id = ? AND status NOT IN ('PAID', 'CANCELLED', 'DRAFT')").get(societyId).s;
        const accounts = db.prepare("SELECT * FROM financial_accounts WHERE society_id = ?").all(societyId);
        const cashBalance = accounts.find((a) => a.account_type === "CASH")?.current_balance ?? 0;
        const bankBalance = accounts.find((a) => a.account_type === "BANK")?.current_balance ?? 0;
        const flatStatements = db.prepare(`
          SELECT h.id as household_id, h.flat_number, h.normalized_flat_number, h.block_name,
                 sm.full_name as primary_member_name, sm.phone,
                 COALESCE((SELECT SUM(total_amount) FROM member_bills mb WHERE mb.household_id = h.id AND mb.status NOT IN ('CANCELLED', 'DRAFT')), 0) as total_billed,
                 COALESCE((SELECT SUM(amount) FROM payments p WHERE p.household_id = h.id AND p.status = 'CONFIRMED'), 0) as total_paid,
                 COALESCE((SELECT SUM(balance_amount) FROM member_bills mb WHERE mb.household_id = h.id AND mb.status NOT IN ('PAID', 'CANCELLED', 'DRAFT')), 0) as outstanding_dues
          FROM households h
          LEFT JOIN society_members sm ON sm.id = h.primary_member_id
          WHERE h.society_id = ? AND h.status != 'ARCHIVED'
          ORDER BY h.normalized_flat_number ASC
        `).all(societyId);
        const expenseBreakdown = db.prepare(`
          SELECT category_name, COUNT(*) as count, COALESCE(SUM(amount), 0) as total_amount
          FROM expenses
          WHERE society_id = ? AND status = 'APPROVED'
          GROUP BY category_name
          ORDER BY total_amount DESC
        `).all(societyId);
        return sendJson(res, 200, {
          summary: {
            realizedIncome,
            approvedExpenses,
            netSurplusOrDeficit: Number((realizedIncome - approvedExpenses).toFixed(2)),
            totalBilledReceivables,
            outstandingReceivables,
            cashBalance,
            bankBalance
          },
          ledger: filteredLedger,
          flatStatements,
          expenseBreakdown
        });
      }
      if (pathname === "/api/society/settings" && method === "GET") {
        const society = db.prepare("SELECT * FROM societies WHERE id = ?").get(societyId);
        const settings = db.prepare("SELECT * FROM society_settings WHERE society_id = ?").get(societyId);
        return sendJson(res, 200, {
          society,
          settings: settings ? {
            ...settings,
            has_razorpay_secret: Boolean(settings.razorpay_key_secret_encrypted),
            has_razorpay_webhook_secret: Boolean(settings.razorpay_webhook_secret_encrypted),
            has_paytm_secret: Boolean(settings.paytm_merchant_key_encrypted),
            has_custom_gateway_secret: Boolean(settings.custom_gateway_secret_encrypted),
            razorpay_key_secret_encrypted: void 0,
            razorpay_webhook_secret_encrypted: void 0,
            paytm_merchant_key_encrypted: void 0,
            custom_gateway_secret_encrypted: void 0
          } : null
        });
      }
      if (pathname === "/api/society/settings" && method === "PUT") {
        const {
          name,
          logoUrl,
          address,
          city,
          state,
          pincode,
          contactEmail,
          contactPhone,
          upiEnabled,
          gpayUpiEnabled,
          paytmEnabled,
          razorpayEnabled,
          bankTransferEnabled,
          upiId,
          upiPayeeName,
          upiQrUrl,
          bankName,
          bankAccountNumber,
          bankIfsc,
          razorpayKeyId,
          razorpayKeySecret,
          razorpayWebhookSecret,
          paytmMerchantId,
          paytmMerchantKey,
          customGatewayName,
          customGatewayApiKey,
          customGatewaySecret,
          billDueDay,
          lateFeeAmount,
          allowMemberStaffContacts,
          emailNotificationsEnabled,
          smsNotificationsEnabled,
          whatsappNotificationsEnabled,
          brandPrimaryColor,
          customEnrollmentFields
        } = body;
        if (contactPhone && !isValid10DigitPhone(contactPhone)) {
          return sendJson(res, 400, { error: "Please enter a valid 10-digit society contact phone number." });
        }
        db.prepare(`
          UPDATE societies
          SET name = COALESCE(?, name),
              logo_url = COALESCE(?, logo_url),
              address = COALESCE(?, address),
              city = COALESCE(?, city),
              state = COALESCE(?, state),
              pincode = COALESCE(?, pincode),
              contact_phone = COALESCE(?, contact_phone),
              updated_at = datetime('now')
          WHERE id = ?
        `).run(name ?? null, logoUrl ?? null, address ?? null, city ?? null, state ?? null, pincode ?? null, contactPhone ?? null, societyId);
        db.prepare(`
          UPDATE society_settings
          SET upi_enabled = COALESCE(?, upi_enabled),
              gpay_upi_enabled = COALESCE(?, gpay_upi_enabled),
              paytm_enabled = COALESCE(?, paytm_enabled),
              razorpay_enabled = COALESCE(?, razorpay_enabled),
              bank_transfer_enabled = COALESCE(?, bank_transfer_enabled),
              upi_id = COALESCE(?, upi_id),
              upi_payee_name = COALESCE(?, upi_payee_name),
              upi_qr_url = COALESCE(?, upi_qr_url),
              bank_name = COALESCE(?, bank_name),
              bank_account_number = COALESCE(?, bank_account_number),
              bank_ifsc = COALESCE(?, bank_ifsc),
              razorpay_key_id = COALESCE(?, razorpay_key_id),
              razorpay_key_secret_encrypted = COALESCE(?, razorpay_key_secret_encrypted),
              razorpay_webhook_secret_encrypted = COALESCE(?, razorpay_webhook_secret_encrypted),
              paytm_merchant_id = COALESCE(?, paytm_merchant_id),
              paytm_merchant_key_encrypted = COALESCE(?, paytm_merchant_key_encrypted),
              custom_gateway_name = COALESCE(?, custom_gateway_name),
              custom_gateway_api_key = COALESCE(?, custom_gateway_api_key),
              custom_gateway_secret_encrypted = COALESCE(?, custom_gateway_secret_encrypted),
              bill_due_day = COALESCE(?, bill_due_day),
              late_fee_amount = COALESCE(?, late_fee_amount),
              allow_member_staff_contacts = COALESCE(?, allow_member_staff_contacts),
              email_notifications_enabled = COALESCE(?, email_notifications_enabled),
              sms_notifications_enabled = COALESCE(?, sms_notifications_enabled),
              whatsapp_notifications_enabled = COALESCE(?, whatsapp_notifications_enabled),
              brand_primary_color = COALESCE(?, brand_primary_color),
              custom_enrollment_fields = COALESCE(?, custom_enrollment_fields),
              updated_at = datetime('now')
          WHERE society_id = ?
        `).run(
          upiEnabled !== void 0 ? upiEnabled ? 1 : 0 : null,
          gpayUpiEnabled !== void 0 ? gpayUpiEnabled ? 1 : 0 : null,
          paytmEnabled !== void 0 ? paytmEnabled ? 1 : 0 : null,
          razorpayEnabled !== void 0 ? razorpayEnabled ? 1 : 0 : null,
          bankTransferEnabled !== void 0 ? bankTransferEnabled ? 1 : 0 : null,
          upiId ?? null,
          upiPayeeName ?? null,
          upiQrUrl ?? null,
          bankName ?? null,
          bankAccountNumber ?? null,
          bankIfsc ?? null,
          razorpayKeyId ?? null,
          razorpayKeySecret ? String(razorpayKeySecret).trim() : null,
          razorpayWebhookSecret ? String(razorpayWebhookSecret).trim() : null,
          paytmMerchantId ?? null,
          paytmMerchantKey ? String(paytmMerchantKey).trim() : null,
          customGatewayName ?? null,
          customGatewayApiKey ?? null,
          customGatewaySecret ? String(customGatewaySecret).trim() : null,
          billDueDay !== void 0 ? Number(billDueDay) : null,
          lateFeeAmount !== void 0 ? Number(lateFeeAmount) : null,
          allowMemberStaffContacts !== void 0 ? allowMemberStaffContacts ? 1 : 0 : null,
          emailNotificationsEnabled !== void 0 ? emailNotificationsEnabled ? 1 : 0 : null,
          smsNotificationsEnabled !== void 0 ? smsNotificationsEnabled ? 1 : 0 : null,
          whatsappNotificationsEnabled !== void 0 ? whatsappNotificationsEnabled ? 1 : 0 : null,
          brandPrimaryColor ?? null,
          customEnrollmentFields ? JSON.stringify(customEnrollmentFields) : null,
          societyId
        );
        logAudit({
          societyId,
          actorUserId: auth?.userId,
          actorRole: auth?.role || "SOCIETY_ADMIN",
          action: "SOCIETY_SETTINGS_UPDATED",
          entityType: "SOCIETY_SETTINGS",
          entityId: societyId,
          details: {
            razorpayKeyId: razorpayKeyId || null,
            paytmMerchantId: paytmMerchantId || null,
            customGatewayName: customGatewayName || null
          }
        });
        return sendJson(res, 200, { message: "Society settings and custom payment gateway keys saved." });
      }
      if (pathname === "/api/society/reset-data" && method === "POST") {
        const { confirmation, wipeMembersAndFlats = false } = body;
        if (confirmation !== "RESET") {
          return sendJson(res, 400, { error: "Invalid confirmation. Please type RESET to confirm data wipe." });
        }
        const isSuper = auth.role === "SUPER_ADMIN";
        const isSocAdmin = auth.role === "SOCIETY_ADMIN" && auth.societyId === societyId;
        if (!isSuper && !isSocAdmin) {
          return sendJson(res, 403, { error: "Forbidden: Only Society Admin or Super Admin can reset society data." });
        }
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare("DELETE FROM payment_allocations WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM payment_receipts WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM payments WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM bill_items WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM bill_adjustments WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM member_bills WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM expenses WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM ledger_entries WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM complaint_attachments WHERE complaint_id IN (SELECT id FROM complaints WHERE society_id = ?)").run(societyId);
          db.prepare("DELETE FROM complaint_comments WHERE complaint_id IN (SELECT id FROM complaints WHERE society_id = ?)").run(societyId);
          db.prepare("DELETE FROM complaints WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM suggestions WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM announcements WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM society_events WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM attendance_records WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM staff_duty_records WHERE society_id = ?").run(societyId);
          db.prepare("DELETE FROM notifications WHERE society_id = ? AND notification_type != 'PLATFORM_NOTICE'").run(societyId);
          db.prepare("UPDATE financial_accounts SET opening_balance = 0, current_balance = 0, updated_at = datetime('now') WHERE society_id = ?").run(societyId);
          db.prepare("UPDATE households SET opening_balance = 0, opening_balance_notes = NULL, opening_balance_date = NULL, updated_at = datetime('now') WHERE society_id = ?").run(societyId);
          if (wipeMembersAndFlats) {
            db.prepare("DELETE FROM society_members WHERE society_id = ? AND user_id != ?").run(societyId, auth.userId);
            db.prepare("DELETE FROM member_invitations WHERE society_id = ?").run(societyId);
            db.prepare("DELETE FROM households WHERE society_id = ?").run(societyId);
            db.prepare("DELETE FROM apartment_blocks WHERE society_id = ?").run(societyId);
          }
          db.prepare(`
            INSERT INTO audit_logs (id, society_id, actor_user_id, actor_role, action, entity_type, entity_id, details, created_at)
            VALUES (?, ?, ?, ?, 'RESET_TO_ZERO', 'SOCIETY', ?, 'Society database reset to zero by admin', datetime('now'))
          `).run(uuid(), societyId, auth.userId, auth.role, societyId);
          db.exec("COMMIT");
          syncToMysqlAfterWrite();
          return sendJson(res, 200, { message: "Society database reset to zero successfully. All financial cards are now \u20B90.00." });
        } catch (err) {
          try {
            db.exec("ROLLBACK");
          } catch {
          }
          return sendJson(res, 500, { error: "Failed to reset database: " + err.message });
        }
      }
    }
    if (pathname.startsWith("/api/member")) {
      if (!auth || auth.role !== "MEMBER" || !auth.societyId) {
        return sendJson(res, 403, { error: "Forbidden: Resident Member account required." });
      }
      const societyId = auth.societyId;
      const member = db.prepare(`
        SELECT sm.*, h.flat_number, h.normalized_flat_number, h.block_name, h.floor_number, h.occupancy_type, h.area_sqft,
               h.opening_balance, h.opening_balance_notes, h.opening_balance_date
        FROM society_members sm
        JOIN households h ON h.id = sm.household_id
        WHERE sm.user_id = ? AND sm.society_id = ?
      `).get(auth.userId, societyId);
      if (!member) {
        return sendJson(res, 404, { error: "Resident member profile not found." });
      }
      if (pathname === "/api/member/dashboard" && method === "GET") {
        const society = db.prepare(`
          SELECT id, name, logo_url, address, city, state, pincode, contact_email, contact_phone
          FROM societies WHERE id = ?
        `).get(societyId);
        const settings = db.prepare(`
          SELECT upi_enabled, gpay_upi_enabled, paytm_enabled, razorpay_enabled, bank_transfer_enabled,
                 upi_id, upi_payee_name, upi_qr_url, bank_name, bank_account_number, bank_ifsc,
                 allow_member_staff_contacts, brand_primary_color
          FROM society_settings WHERE society_id = ?
        `).get(societyId);
        const bills = db.prepare(`
          SELECT * FROM member_bills
          WHERE society_id = ? AND household_id = ? AND status NOT IN ('DRAFT', 'CANCELLED')
          ORDER BY billing_year DESC, billing_month DESC, created_at DESC
        `).all(societyId, member.household_id);
        const billItems = db.prepare(`
          SELECT * FROM bill_items WHERE society_id = ? AND household_id = ?
        `).all(societyId, member.household_id);
        const enrichedBills = bills.map((b) => ({
          ...b,
          items: billItems.filter((i) => i.bill_id === b.id)
        }));
        const payments = db.prepare(`
          SELECT p.*, pr.receipt_number, pr.issued_at as receipt_issued_at
          FROM payments p
          LEFT JOIN payment_receipts pr ON pr.payment_id = p.id
          WHERE p.society_id = ? AND p.household_id = ?
          ORDER BY p.created_at DESC
        `).all(societyId, member.household_id);
        const receipts = db.prepare(`
          SELECT pr.*
          FROM payment_receipts pr
          JOIN payments p ON p.id = pr.payment_id
          WHERE pr.society_id = ? AND p.household_id = ?
          ORDER BY pr.issued_at DESC
        `).all(societyId, member.household_id);
        const complaints = db.prepare(`
          SELECT c.*, st.full_name as assigned_staff_name
          FROM complaints c
          LEFT JOIN staff st ON st.id = c.assigned_staff_id
          WHERE c.society_id = ? AND c.household_id = ?
          ORDER BY c.created_at DESC
        `).all(societyId, member.household_id);
        const attachments = db.prepare("SELECT * FROM complaint_attachments WHERE society_id = ?").all(societyId);
        const publicComments = db.prepare("SELECT * FROM complaint_comments WHERE society_id = ? AND is_internal = 0 ORDER BY created_at ASC").all(societyId);
        const enrichedComplaints = complaints.map((c) => ({
          ...c,
          attachments: attachments.filter((a) => a.complaint_id === c.id),
          comments: publicComments.filter((cm) => cm.complaint_id === c.id)
        }));
        const suggestions = db.prepare(`
          SELECT * FROM suggestions WHERE society_id = ? AND household_id = ? ORDER BY created_at DESC
        `).all(societyId, member.household_id);
        const announcements = db.prepare(`
          SELECT * FROM announcements WHERE society_id = ? AND publication_status = 'PUBLISHED' ORDER BY created_at DESC LIMIT 15
        `).all(societyId);
        const events = db.prepare(`
          SELECT * FROM society_events WHERE society_id = ? AND publication_status = 'PUBLISHED' ORDER BY event_date ASC LIMIT 15
        `).all(societyId);
        const onDutyStaff = db.prepare(`
          SELECT id, full_name, designation, duty_schedule, assigned_duties,
                 CASE WHEN show_contact_to_members = 1 AND ? = 1 THEN phone ELSE 'Contact via RWA Desk' END as phone
          FROM staff
          WHERE society_id = ? AND employment_status = 'ACTIVE' AND is_on_duty = 1
          ORDER BY full_name ASC
        `).all(settings?.allow_member_staff_contacts ?? 1, societyId);
        const householdMembers = db.prepare(`
          SELECT id, full_name, email, phone, relationship_to_primary, is_primary_member, ownership_type
          FROM society_members
          WHERE society_id = ? AND household_id = ? AND account_status = 'ACTIVE'
        `).all(societyId, member.household_id);
        const totalOutstanding = enrichedBills.filter((b) => b.status !== "PAID").reduce((sum, b) => sum + Number(b.balance_amount || 0), 0);
        const openingBalanceDues = enrichedBills.filter(
          (b) => (b.bill_type === "OPENING_BALANCE" || b.bill_number?.startsWith("OP-BAL-") || b.bill_type === "ADJUSTMENT" && b.adjustment_reason === "OPENING_BALANCE") && b.status !== "PAID"
        ).reduce((sum, b) => sum + Number(b.balance_amount || 0), 0);
        const otherDues = Math.max(0, Number((totalOutstanding - openingBalanceDues).toFixed(2)));
        return sendJson(res, 200, {
          member,
          householdMembers,
          society,
          settings,
          totalOutstanding,
          openingBalance: Number(member?.opening_balance || 0),
          openingBalanceDues,
          otherDues,
          bills: enrichedBills,
          payments,
          receipts,
          complaints: enrichedComplaints,
          suggestions,
          announcements,
          events,
          onDutyStaff
        });
      }
      if (pathname === "/api/member/payments" && method === "POST") {
        const {
          billIds = [],
          amount,
          paymentDate,
          paymentMethod = "UPI",
          referenceNumber,
          proofUrl = null
        } = body;
        if (!Array.isArray(billIds) || billIds.length === 0 || !amount || Number(amount) <= 0 || !referenceNumber) {
          return sendJson(res, 400, {
            error: "At least one bill, a positive payment amount, and a transaction reference number are required."
          });
        }
        for (const bId of billIds) {
          const billCheck = db.prepare(`
            SELECT * FROM member_bills WHERE id = ? AND society_id = ? AND household_id = ?
          `).get(bId, societyId, member.household_id);
          if (!billCheck) {
            return sendJson(res, 404, { error: "Selected bill not found for your household." });
          }
          const existingPendingPayment = db.prepare(`
            SELECT p.id, p.reference_number
            FROM payments p
            JOIN payment_allocations pa ON pa.payment_id = p.id
            WHERE pa.bill_id = ? AND p.society_id = ? AND p.status = 'PENDING_VERIFICATION'
            LIMIT 1
          `).get(bId, societyId);
          if (billCheck.status === "PENDING_VERIFICATION" || existingPendingPayment) {
            return sendJson(res, 409, {
              error: "Already payment made under verification, cannot make another payment till payment status is paid or unpaid."
            });
          }
          if (billCheck.status === "PAID" || Number(billCheck.balance_amount) <= 0) {
            return sendJson(res, 409, {
              error: `Bill ${billCheck.bill_number} is already paid.`
            });
          }
        }
        const paymentId = uuid();
        const totalPaidInput = Number(amount);
        let remaining = totalPaidInput;
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO payments (
              id, society_id, household_id, member_id, payment_method, amount, payment_date,
              reference_number, proof_url, status, ledger_posted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING_VERIFICATION', 0)
          `).run(
            paymentId,
            societyId,
            member.household_id,
            member.id,
            paymentMethod,
            totalPaidInput,
            paymentDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
            String(referenceNumber).trim(),
            proofUrl
          );
          for (const bId of billIds) {
            const bill = db.prepare(`
              SELECT * FROM member_bills WHERE id = ? AND society_id = ? AND household_id = ?
            `).get(bId, societyId, member.household_id);
            if (!bill) continue;
            const allocAmt = remaining > 0 ? Math.min(remaining, Number(bill.balance_amount || bill.total_amount)) : Number(bill.balance_amount || totalPaidInput);
            const finalAlloc = allocAmt > 0 ? allocAmt : totalPaidInput;
            db.prepare(`
              INSERT INTO payment_allocations (id, society_id, payment_id, bill_id, allocated_amount)
              VALUES (?, ?, ?, ?, ?)
            `).run(uuid(), societyId, paymentId, bill.id, finalAlloc);
            if (bill.status === "UNPAID" || bill.status === "OVERDUE" || bill.status === "PARTIALLY_PAID") {
              db.prepare("UPDATE member_bills SET status = 'PENDING_VERIFICATION', updated_at = datetime('now') WHERE id = ?").run(bill.id);
            }
            remaining = Math.max(0, Number((remaining - finalAlloc).toFixed(2)));
          }
          sendNotification({
            societyId,
            userId: null,
            notificationType: "PAYMENT_SUBMITTED",
            title: `Payment Submitted \u2014 Flat ${member.flat_number}`,
            message: `${member.full_name} (${member.flat_number}) submitted \u20B9${totalPaidInput} via ${paymentMethod} (Ref: ${referenceNumber}) for verification.`,
            channel: "IN_APP",
            dedupKey: `pay-sub:${paymentId}`
          });
          logAudit({
            societyId,
            actorUserId: auth.userId,
            actorRole: "MEMBER",
            action: "MEMBER_SUBMITTED_PAYMENT",
            entityType: "PAYMENT",
            entityId: paymentId,
            details: { amount: totalPaidInput, paymentMethod, referenceNumber, billIds }
          });
          db.exec("COMMIT");
          return sendJson(res, 201, {
            paymentId,
            status: "PENDING_VERIFICATION",
            message: "Payment reference submitted! It is now pending verification by society administration."
          });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (pathname === "/api/member/complaints" && method === "POST") {
        const { title, category = "Maintenance", description, priority = "MEDIUM", attachmentUrls = [] } = body;
        if (!title || !description) {
          return sendJson(res, 400, { error: "Complaint title and description are required." });
        }
        const complaintId = uuid();
        const complaintNumber = `CMP-${Math.floor(1e4 + Math.random() * 9e4)}`;
        db.exec("BEGIN IMMEDIATE");
        try {
          db.prepare(`
            INSERT INTO complaints (
              id, society_id, complaint_number, household_id, member_id, flat_number,
              title, category, description, priority, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED')
          `).run(
            complaintId,
            societyId,
            complaintNumber,
            member.household_id,
            member.id,
            member.flat_number,
            String(title).trim(),
            category,
            String(description).trim(),
            priority
          );
          if (Array.isArray(attachmentUrls)) {
            for (const urlStr of attachmentUrls) {
              if (!urlStr) continue;
              db.prepare(`
                INSERT INTO complaint_attachments (id, society_id, complaint_id, file_url, uploaded_by)
                VALUES (?, ?, ?, ?, ?)
              `).run(uuid(), societyId, complaintId, String(urlStr), auth.userId);
            }
          }
          sendNotification({
            societyId,
            userId: null,
            notificationType: "NEW_COMPLAINT",
            title: `New Complaint ${complaintNumber} (${member.flat_number})`,
            message: `${member.full_name} reported [${category}]: ${title}`,
            channel: "IN_APP",
            dedupKey: `cmp:${complaintId}`,
            linkUrl: `/society-admin?tab=COMPLAINTS&complaintId=${complaintId}`
          });
          db.exec("COMMIT");
          return sendJson(res, 201, { complaintId, complaintNumber, message: `Complaint ${complaintNumber} submitted.` });
        } catch (err) {
          db.exec("ROLLBACK");
          throw err;
        }
      }
      if (pathname === "/api/member/suggestions" && method === "POST") {
        const { title, description } = body;
        if (!title || !description) {
          return sendJson(res, 400, { error: "Suggestion title and description are required." });
        }
        const id = uuid();
        db.prepare(`
          INSERT INTO suggestions (id, society_id, household_id, member_id, flat_number, title, description, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, 'SUBMITTED')
        `).run(id, societyId, member.household_id, member.id, member.flat_number, String(title).trim(), String(description).trim());
        return sendJson(res, 201, { id, message: "Suggestion submitted to society management." });
      }
    }
    return sendJson(res, 404, { error: `API route not found: ${method} ${pathname}` });
  } catch (err) {
    console.error("[API Error]", err);
    return sendJson(res, 500, { error: err?.message || "Internal server error" });
  }
}

// server/index.ts
initDatabase();
seedInitialDataIfEmpty();
function runScheduledRemindersJob() {
  try {
    const overdueBills = db.prepare(`
      SELECT mb.id, mb.bill_number, mb.society_id, mb.balance_amount, mb.due_date, sm.user_id
      FROM member_bills mb
      LEFT JOIN society_members sm ON sm.id = mb.member_id
      WHERE mb.balance_amount > 0
        AND mb.due_date < date('now')
        AND mb.status IN ('UNPAID', 'PARTIALLY_PAID')
    `).all();
    for (const b of overdueBills) {
      db.prepare("UPDATE member_bills SET status = 'OVERDUE' WHERE id = ? AND status = 'UNPAID'").run(b.id);
      if (b.user_id) {
        sendNotification({
          societyId: b.society_id,
          userId: b.user_id,
          notificationType: "OVERDUE_PAYMENT",
          title: `Overdue Bill Reminder: ${b.bill_number}`,
          message: `Your society bill ${b.bill_number} of \u20B9${b.balance_amount} was due on ${b.due_date}. Please submit payment to avoid late fees.`,
          channel: "EMAIL",
          dedupKey: `overdue:${b.id}:${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`
        });
      }
    }
    const expiringSocieties = db.prepare(`
      SELECT id, name, admin_user_id, subscription_status, trial_ends_at, subscription_ends_at
      FROM societies
      WHERE account_status = 'ACTIVE'
    `).all();
    for (const s of expiringSocieties) {
      const targetDate = s.subscription_status === "TRIAL" ? s.trial_ends_at : s.subscription_ends_at;
      if (!targetDate || !s.admin_user_id) continue;
      const daysLeft = Math.ceil((new Date(targetDate).getTime() - Date.now()) / 864e5);
      if (daysLeft >= 0 && daysLeft <= 30) {
        sendNotification({
          societyId: s.id,
          userId: s.admin_user_id,
          notificationType: s.subscription_status === "TRIAL" ? "TRIAL_EXPIRY" : "SUBSCRIPTION_RENEWAL",
          title: `${s.subscription_status === "TRIAL" ? "Free Trial" : "Subscription"} Expiring in ${daysLeft} Day(s)`,
          message: `Your ${s.name} plan expires on ${String(targetDate).slice(0, 10)}. Renew now for uninterrupted access.`,
          channel: "EMAIL",
          dedupKey: `sub-exp:${s.id}:${String(targetDate).slice(0, 10)}`
        });
      }
    }
    syncToMysqlAfterWrite();
  } catch (err) {
    console.error("[Reminder Job Error]", err);
  }
}
async function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let totalBytes = 0;
    req.on("data", (chunk) => {
      totalBytes += chunk.byteLength;
      if (totalBytes > 10 * 1024 * 1024) {
        reject(new Error("Request payload too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      if (chunks.length === 0) {
        resolve({});
        return;
      }
      try {
        const raw = Buffer.concat(chunks).toString("utf8");
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        resolve({});
      }
    });
    req.on("error", reject);
  });
}
function getStaticMimeType(filePath) {
  const ext = path5.extname(filePath).toLowerCase();
  switch (ext) {
    case ".html":
      return "text/html; charset=utf-8";
    case ".js":
    case ".mjs":
      return "text/javascript; charset=utf-8";
    case ".css":
      return "text/css; charset=utf-8";
    case ".json":
      return "application/json; charset=utf-8";
    case ".svg":
      return "image/svg+xml";
    case ".png":
      return "image/png";
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".webp":
      return "image/webp";
    case ".ico":
      return "image/x-icon";
    case ".woff":
      return "font/woff";
    case ".woff2":
      return "font/woff2";
    case ".ttf":
      return "font/ttf";
    case ".pdf":
      return "application/pdf";
    default:
      return "application/octet-stream";
  }
}
async function createServer(options = { withVite: true }) {
  await initMysqlBackend();
  let vite = null;
  const isProd = process.env.NODE_ENV === "production";
  if (options.withVite && !isProd && process.env.NODE_ENV !== "test") {
    const { createServer: createViteServer } = await import("vite");
    vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
  }
  const server = http.createServer(async (req, res) => {
    const host = req.headers.host || "localhost:4000";
    const url = new URL(req.url || "/", `http://${host}`);
    const method = (req.method || "GET").toUpperCase();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }
    if (url.pathname.startsWith("/uploads/")) {
      const safeFile = path5.basename(url.pathname);
      const isServerless2 = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
      const uploadDir = isServerless2 ? path5.join("/tmp", "uploads") : path5.join(process.cwd(), "data", "uploads");
      const filePath = path5.join(uploadDir, safeFile);
      if (fs5.existsSync(filePath)) {
        res.writeHead(200, { "Content-Type": getStaticMimeType(safeFile) });
        fs5.createReadStream(filePath).pipe(res);
        return;
      }
      res.writeHead(404);
      res.end("File not found");
      return;
    }
    if (url.pathname.startsWith("/api/")) {
      try {
        const body = method === "GET" || method === "HEAD" ? {} : await parseJsonBody(req);
        const token = extractBearerToken(req);
        const auth = token ? verifyJwt(token) : null;
        await handleApiRequest({ req, res, url, method, body, auth });
        if (method !== "GET" && method !== "HEAD") {
          syncToMysqlAfterWrite();
        }
      } catch (err) {
        sendJson(res, 400, { error: err?.message || "Bad request" });
      }
      return;
    }
    if (vite) {
      vite.middlewares(req, res, async () => {
        try {
          const indexHtmlPath = path5.join(process.cwd(), "index.html");
          let template = fs5.readFileSync(indexHtmlPath, "utf8");
          template = await vite.transformIndexHtml(url.pathname, template);
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
          res.end(template);
        } catch (e) {
          vite.ssrFixStacktrace(e);
          res.writeHead(500);
          res.end(e.message);
        }
      });
      return;
    }
    const assetCandidates = [
      path5.join(process.cwd(), "dist", url.pathname === "/" ? "index.html" : url.pathname),
      path5.join(process.cwd(), url.pathname === "/" ? "index.html" : url.pathname)
    ];
    for (const candidate of assetCandidates) {
      if (fs5.existsSync(candidate) && fs5.statSync(candidate).isFile()) {
        res.writeHead(200, { "Content-Type": getStaticMimeType(candidate) });
        fs5.createReadStream(candidate).pipe(res);
        return;
      }
    }
    const fallbackCandidates = [
      path5.join(process.cwd(), "dist", "index.html"),
      path5.join(process.cwd(), "index.html")
    ];
    for (const fallback of fallbackCandidates) {
      if (fs5.existsSync(fallback) && fs5.statSync(fallback).isFile()) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        fs5.createReadStream(fallback).pipe(res);
        return;
      }
    }
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("SocietyOS SaaS API Server Running.");
  });
  return server;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 4e3);
  const isProd = process.env.NODE_ENV === "production";
  createServer({ withVite: !isProd }).then((server) => {
    runScheduledRemindersJob();
    setInterval(runScheduledRemindersJob, 5 * 6e4).unref();
    server.listen(port, "0.0.0.0", () => {
      console.log(`SocietyOS Multi-Tenant SaaS Platform running at http://localhost:${port}`);
    });
  });
}
export {
  createServer,
  runScheduledRemindersJob
};
/*! Bundled license information:

mime-db/index.js:
  (*!
   * mime-db
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2015-2022 Douglas Christopher Wilson
   * MIT Licensed
   *)

mime-types/index.js:
  (*!
   * mime-types
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2015 Douglas Christopher Wilson
   * MIT Licensed
   *)

axios/dist/node/axios.cjs:
  (*! Axios v1.20.0 Copyright (c) 2026 Matt Zabriskie and contributors *)
*/
